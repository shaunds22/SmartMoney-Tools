/// <reference path="../pb_data/types.d.ts" />
onRecordAfterCreateSuccess((e) => {
  const message = new MailerMessage({
    from: {
      address: "noreply@smartmoney-tools.com",
      name: "Contact Form"
    },
    to: [{ address: "support@smartmoney-tools.com" }],
    replyTo: [{ address: e.record.get("email") }],
    subject: "New Contact Form Submission: " + e.record.get("subject"),
    html: `
      <h2>New Contact Form Submission</h2>
      <p><strong>From:</strong> ${e.record.get("name")} (${e.record.get("email")})</p>
      <p><strong>Subject:</strong> ${e.record.get("subject")}</p>
      <p><strong>Message:</strong></p>
      <p>${e.record.get("message").replace(/\n/g, "<br>")}</p>
      <p><strong>Submitted:</strong> ${e.record.get("created")}</p>
    `
  });
  $app.newMailClient().send(message);
  e.next();
}, "contact_submissions");