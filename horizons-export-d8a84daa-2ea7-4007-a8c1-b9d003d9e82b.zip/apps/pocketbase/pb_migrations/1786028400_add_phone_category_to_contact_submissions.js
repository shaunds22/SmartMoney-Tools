/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("contact_submissions");

  // Add phone field (optional text)
  collection.fields.add(new Field({
    "type": "text",
    "id": "text_phone_field",
    "name": "phone",
    "required": false,
    "max": 50,
    "min": 0,
    "autogeneratePattern": "",
    "pattern": ""
  }));

  // Add category field (optional text)
  collection.fields.add(new Field({
    "type": "text",
    "id": "text_category_field",
    "name": "category",
    "required": false,
    "max": 100,
    "min": 0,
    "autogeneratePattern": "",
    "pattern": ""
  }));

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("contact_submissions");

  const phone = collection.fields.getByName("phone");
  if (phone) collection.fields.remove(phone);

  const category = collection.fields.getByName("category");
  if (category) collection.fields.remove(category);

  return app.save(collection);
});
