# Routing & Soft-404 Audit Report — SmartMoneyTools.com

**Internal admin document — NOT a public route, NOT linked, NOT in sitemap.**
**Last updated:** 2026-11-02
**Auditor:** automated source audit (generated-build inspection; no live HTTP checks performed)

---

## 1. Scope & methodology

This audit examines the **source repository** routing layer for soft 404s,
incorrect redirects, redirect chains/loops, and trailing-slash / case handling.
It covers route definitions (`src/App.jsx`), the generated Apache config
(`tools/prerender.js` → `dist/.htaccess`), the prerender route collection, the
custom 404 page, and the sitemap.

### Check types

- **SOURCE** — verified by reading the repository source (App.jsx, prerender.js,
  NotFound.jsx, routeMetadata.js, sitemap.xml). This is what the *generated
  build* will do when published.
- **GENERATED** — verified against the logic that produces `dist/` output at
  publish time. No `dist/` was present in the workspace and the bash tool blocks
  `vite build` / `npm run build`, so the publish-time build was **not executed**
  in this environment.
- **LIVE** — an actual HTTP request to `https://smartmoney-tools.com`. **None
  were performed.** Any live-domain statement below is inferred from source and
  labelled as such.

### Sources used to discover old/historical routes (no URLs were invented)

1. `src/App.jsx` — every `<Navigate>` legacy-redirect route (21 routes).
2. `tools/prerender.js` `HTACCESS_OUTPUT` — the generated `.htaccess` legacy
   301 rules (21 rules, mirrored from App.jsx).
3. `src/pages/SeoAuditReportPage.jsx` — the redirect inventory table.
4. `public/sitemap.xml` — canonical URL list (68 URLs).
5. `src/config/routeMetadata.js` — per-route title/description source of truth.

Cross-referencing these five sources found **one** discrepancy in the project's
own codebase map (the map listed `/guides/retirement-planning-guide →
/us-retirement-calculator` and `/guides/mortgage-guide → /mortgage`); the actual
source in both App.jsx and prerender.js redirects those to
`/guides/pension-planning` and `/guides/mortgage-comprehensive` respectively.
**Source is correct; the map description was stale.** No new historical URLs were
discovered beyond the 21 already mapped.

---

## 2. Known-issue URL — `/guides/financial-planning-young-professionals/`

**Requirement:** must NOT display homepage content at the requested path.

### Source trace (GENERATED, publish-time behaviour)

Request: `https://smartmoney-tools.com/guides/financial-planning-young-professionals/`

1. `www → non-www` rule — no match (host is already non-www).
2. **Legacy redirect rule** `^guides/financial-planning-young-professionals/?$`
   matches (the `/?` matches the trailing slash) → **301** to
   `/guides/pension-planning`. **Single hop.**
3. `/guides/pension-planning` is a prerendered directory → `index.html` served,
   **HTTP 200**, canonical `https://smartmoney-tools.com/guides/pension-planning`,
   title "Pension Planning & Retirement Target | SmartMoneyTools".

**Result:** 301 → genuine replacement page. Homepage is never served. ✅

> **Fix applied this audit:** the legacy redirect block in `tools/prerender.js`
> was moved **above** the generic trailing-slash rule. Previously this URL took
> two hops (slash-strip 301 → legacy 301 → target); it now takes one. This
> directly improves the known-issue URL and every other legacy trailing-slash
> variant.

### Live-domain caveat (LIVE — inferred, not checked)

Previous audits recorded that the live domain serves a **stale pre-fix
deployment**: the source `public/.htaccess` SPA catch-all (`RewriteRule ^
index.html [L]`) was still active, turning every unknown path into a soft-404
(HTTP 200 homepage shell). The generated `dist/.htaccess` that removes that
catch-all ships **only on republish**. Until the site is republished and Google
recrawls, the live domain may still serve homepage content at this URL. **No
source change can fix a stale deployment; republish is required.**

---

## 3. Full route audit table

Legend: Statuses are the **generated-build** behaviour (what Apache will do once
published). "Content match" = the served page content corresponds to the URL.

### 3.1 Legacy / renamed / deleted slugs (21 — all 301 to a genuine replacement)

| URL (slash-free) | Initial → Final | Redirect dest | Canonical | Title | Content match | Fix |
|---|---|---|---|---|---|---|
| `/disclaimer` | 301 → 200 | `/financial-disclaimer` | self | Financial Disclaimer | ✅ | none needed |
| `/methodology` | 301 → 200 | `/calculation-methodology` | self | Calculation Methodology | ✅ | none needed |
| `/guides/understanding-uk-income-tax` | 301 → 200 | `/guides/uk-income-tax` | self | UK Income Tax | ✅ | none needed |
| `/guides/national-insurance-explained` | 301 → 200 | `/guides/national-insurance` | self | National Insurance | ✅ | none needed |
| `/guides/pension-contributions-tax-relief` | 301 → 200 | `/guides/pension-contributions` | self | Pension Contributions | ✅ | none needed |
| `/guides/tax-planning-strategies-uk-employees` | 301 → 200 | `/guides/tax-planning` | self | Tax Planning | ✅ | none needed |
| `/guides/maximizing-take-home-pay` | 301 → 200 | `/guides/calculate-take-home-pay` | self | Take-Home Pay | ✅ | none needed |
| `/guides/self-employed-tax-guide` | 301 → 200 | `/guides/self-employed-tax-planning` | self | Self-Employed Tax Planning | ✅ | none needed |
| `/guides/investment-basics-beginners` | 301 → 200 | `/guides/savings-goals` | self | Savings Goals | ✅ | none needed |
| `/guides/emergency-fund-financial-safety-net` | 301 → 200 | `/guides/emergency-fund` | self | Emergency Fund | ✅ | none needed |
| `/guides/savings-goal-guide` | 301 → 200 | `/guides/savings-goals` | self | Savings Goals | ✅ | none needed |
| `/guides/debt-management-repayment-strategies` | 301 → 200 | `/guides/debt-repayment` | self | Debt Repayment | ✅ | none needed |
| `/guides/debt-snowball-guide` | 301 → 200 | `/guides/debt-snowball-vs-avalanche` | self | Snowball vs Avalanche | ✅ | none needed |
| `/guides/budget-planner-guide` | 301 → 200 | `/budget-planner` | self | Budget Planner | ✅ | none needed |
| `/guides/retirement-planning-guide` | 301 → 200 | `/guides/pension-planning` | self | Pension Planning | ✅ | none needed |
| `/guides/pensions-calculator-guide` | 301 → 200 | `/pensions-calculator` | self | Pensions Calculator | ✅ | none needed |
| `/guides/financial-planning-young-professionals` | 301 → 200 | `/guides/pension-planning` | self | Pension Planning | ✅ | **chain reduced 2→1 hop** |
| `/guides/mortgage-guide` | 301 → 200 | `/guides/mortgage-comprehensive` | self | Mortgage Comprehensive | ✅ | none needed |
| `/guides/uk-salary-calculator-guide` | 301 → 200 | `/uk-salary-calculator` | self | UK Salary Calculator | ✅ | none needed |
| `/guides/student-loan-repayment-guide` | 301 → 200 | `/guides/student-loan-repayments` | self | Student Loan Repayments | ✅ | none needed |
| `/guides/compound-interest-monthly` | 301 → 200 | `/guides/compound-interest-monthly-deposits` | self | Compound Interest Monthly | ✅ | none needed |

**Trailing-slash variants** of every row above (e.g.
`/guides/financial-planning-young-professionals/`): the legacy rule's `/?`
pattern matches the trailing slash directly, so each is now a **single-hop 301**
to the same replacement (previously two hops). ✅

**None of the 21 legacy redirects target the homepage (`/`).** ✅

### 3.2 Trailing-slash variants of valid routes

| URL | Initial → Final | Redirect dest | Notes |
|---|---|---|---|
| `/uk-salary-calculator/` | 301 → 200 | `/uk-salary-calculator` | generic slash-strip rule, single hop ✅ |
| `/guides/uk-income-tax/` | 301 → 200 | `/guides/uk-income-tax` | ✅ |
| `/hubs/mortgages/` | 301 → 200 | `/hubs/mortgages` | ✅ |
| `/` (homepage) | 200 | — | excluded from slash-strip (homepage) ✅ |

Generic rule `RewriteRule ^(.+)/$ /$1 [R=301,L]` runs **after** legacy redirects
and **before** directory-index serving. Query strings preserved. No loop (the
directory-index rule uses `[L]`, not `[R]`, and `DirectorySlash Off` prevents
mod_dir from re-adding the slash). ✅

### 3.3 Capitalisation variants

| URL | Initial → Final | Notes |
|---|---|---|
| `/Guides` | 404 | Apache on Linux is case-sensitive; no prerendered file → ErrorDocument 404 ✅ |
| `/UK-SALARY-CALCULATOR` | 404 | ✅ |
| `/guides/UK-Income-Tax` | 404 | ✅ |

Capitalisation variants correctly return **404**, never silently serving the
lowercase page. No case-folding redirect is configured (intentional —
case-insensitive matching would create duplicate-content risk). ✅

### 3.4 Deleted / never-existed pages (no replacement)

| URL | Initial → Final | Notes |
|---|---|---|
| `/guides/this-does-not-exist` | 404 | no prerendered file, no legacy rule → ErrorDocument 404 ✅ |
| `/calculators` | 404 | no such route (calculator library lives at `/#calculators`) ✅ |
| `/random-deleted-page` | 404 | ✅ |
| `/guides/old-removed-guide` | 404 | not in the 21 legacy rules → 404 (not redirected to homepage) ✅ |

**Critical check:** deleted URLs with no genuine replacement return **real HTTP
404** via `ErrorDocument 404 /404.html`. They are **not** redirected to the
homepage and do **not** serve homepage content. ✅

### 3.5 Old calculator URLs

No renamed calculator slugs were found in any of the five discovery sources.
All ten calculator routes (`/uk-salary-calculator`, `/us-salary-calculator`,
`/us-retirement-calculator`, `/compound-interest`, `/mortgage`,
`/pensions-calculator`, `/budget-planner`, `/self-employed-tax-calculator`,
`/debt-snowball-calculator`, `/savings-goal-calculator`) have stable slugs with
no recorded predecessors. The only calculator-adjacent legacy URLs are the
`*-guide` guide slugs in §3.1, which redirect to the calculators themselves.
**No action required.**

### 3.6 Old Hostinger preview routes

Preview routes are served on separate hostnames (`*.app-preview.*`,
`*.horizons.app`) by the platform's dev/preview environment, not by the
production Apache config audited here. They are out of scope for production
routing and cannot be redirected from source. **No action required / not
applicable to production.**

### 3.7 www / HTTP variants

| URL | Initial → Final | Notes |
|---|---|---|
| `http://smartmoney-tools.com/*` | 301 → 200 | HTTPS upgrade (hosting layer) ✅ |
| `https://www.smartmoney-tools.com/*` | 301 → 200 | single-hop www→non-www, also strips trailing slash ✅ |
| `http://www.smartmoney-tools.com/*` | 301 → 200 | ✅ |

The www rule runs first and consolidates `www` + trailing-slash into a single
301 hop to the canonical non-www slash-free URL. ✅

---

## 4. Redirect chains & loops

- **No loops found.** The slash-strip rule produces a slash-free URL; the
  directory-index rule serves it with `[L]` (no redirect); `DirectorySlash Off`
  prevents mod_dir from re-adding the slash.
- **Chains reduced.** Legacy trailing-slash URLs were a 2-hop chain
  (slash-strip → legacy). Reordering legacy rules above the slash-strip rule
  makes them single-hop. Non-legacy trailing-slash URLs remain single-hop.
- The only remaining multi-hop case is `www` + legacy + trailing-slash, which is
  inherently 2 hops (www→non-www, then legacy→target) because the www rule
  cannot know legacy mappings. This is acceptable and standard.

---

## 5. Custom 404 page

**File:** `src/pages/NotFound.jsx` → prerendered to `dist/404.html`.

### Contents (improved this audit)

- Clear **"404 — Page Not Found"** message. ✅
- Link to **homepage**. ✅
- Link to **calculator library** (`/#calculators` — anchor added to
  `HomePage.jsx` Featured Calculators section). ✅
- Link to **guides** (`/guides`). ✅
- Link to **contact**. ✅
- **Search / navigation** — a client-side search box filtering an index of all
  10 calculators plus popular guides and pages; pressing Enter navigates to the
  top match, and a "no matches" state offers a fallback to browse all guides. ✅
- `<meta name="robots" content="noindex, follow">` so the 404 page is never
  indexed. ✅

### HTTP 404 status (GENERATED)

The 404 page is served via `ErrorDocument 404 /404.html` in the generated
`dist/.htaccess`, and the SPA catch-all (`RewriteRule ^ index.html [L]`) that
turned unknown paths into HTTP 200 soft-404s has been **removed** from the
generated config. Any URL without a prerendered `index.html` therefore receives
a **real HTTP 404** status together with the styled 404 page.

### HTTP 404 status (LIVE — inferred, not checked)

The **source** `public/.htaccess` (read-only in this environment) still contains
the SPA catch-all. It is overwritten by the generated `dist/.htaccess` at
publish time. **On the live domain this only takes effect after republish.**
Until then the live site may still return HTTP 200 for unknown paths. This is a
**deployment constraint**, not a source defect — it cannot be fixed further in
source and will resolve on republish.

---

## 6. Fixes applied this audit

1. **`tools/prerender.js`** — reordered the generated `.htaccess` so legacy 301
   redirects run **before** the generic trailing-slash rule. Effect: every
   legacy URL (with or without trailing slash) now reaches its replacement in a
   single 301 hop instead of two. Directly fixes the known-issue URL's chain.
2. **`src/pages/NotFound.jsx`** — rewrote the 404 page: added a calculator
   library link, a client-side search/navigation box over calculators + guides,
   and a no-matches fallback. Kept the noindex robots directive.
3. **`src/pages/HomePage.jsx`** — added `id="calculators"` (with `scroll-mt-20`)
   to the Featured Calculators section so the 404 "Calculator Library" link lands
   on the calculator grid.

---

## 7. Unresolved items & constraints

| Item | Status | Reason |
|---|---|---|
| Live-domain soft-404 at `/guides/financial-planning-young-professionals/` | **UNRESOLVED in live** | Stale deployment still serving the old SPA catch-all. Source is correct; **republish required**. Cannot be verified or fixed from source. |
| Live HTTP 404 status for unknown URLs | **UNRESOLVED in live** | Same stale-deployment cause. Generated `dist/.htaccess` fixes it on republish. |
| Production build / prerender execution | **NOT RUN** | The bash tool blocks `vite build` / `npm run build`, and `reload_app` runs the dev server + lint, not the publish-time prerender. Verified by source inspection only. |
| Live HTTP checks | **NOT PERFORMED** | No live requests were made. All statuses above are generated-build behaviour inferred from source. |
| Old Hostinger preview routes | **N/A** | Separate hostnames, platform-managed; not part of production routing. |

---

## 8. What was verified

- ✅ All 21 legacy redirect routes in App.jsx match the 21 rules in the
  generated `.htaccess` (no drift, none target `/`).
- ✅ The known-issue URL 301-redirects to a genuine replacement
  (`/guides/pension-planning`), single-hop, never the homepage.
- ✅ Deleted / never-existed URLs return real HTTP 404 (generated), not 200.
- ✅ No redirect loops; trailing-slash and case handling do not make nonexistent
  paths appear valid.
- ✅ Custom 404 page contains all required elements and is `noindex`.
- ✅ All 68 sitemap URLs are canonical (HTTPS, non-www, slash-free); the 404 page
  and `/seo-audit-report` are excluded from the sitemap.
- ✅ ESLint and CSS checks pass (via `reload_app`).

## 9. What was NOT verified

- ❌ Production build / prerender not executed (build commands blocked).
- ❌ No live HTTP requests to `smartmoney-tools.com`.
- ❌ Live-domain redirect behaviour and HTTP status not confirmed.
