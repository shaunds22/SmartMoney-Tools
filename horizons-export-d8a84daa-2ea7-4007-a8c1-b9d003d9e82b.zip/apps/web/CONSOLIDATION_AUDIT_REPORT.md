# Content Consolidation Audit Report

**Scope:** Audit of all 36 guides and calculator-supporting articles on SmartMoneyTools.com for overlapping search intent, repetitive structure and low differentiation. No new articles created.

**Date:** 2026-11-02
**Author:** Internal — not routed, not sitemapped, not publicly linked.

## Method

Every guide page was read in full and assessed by (a) the user intent it targets and (b) its actual content. Pages were grouped only where they target **substantially the same user intent** — not merely because they share a broad subject. For each genuine overlap, the strongest page was retained, unique material from the weaker page was folded in, the weaker page was removed from routing, a permanent 301 redirect was added, all internal links were updated, and the removed URL was dropped from `routeMetadata.js` (and therefore the generated sitemap).

Pages that share a broad subject but target distinct intents were **retained separately** (see "Reviewed and retained" below).

## Consolidation decisions (7 merges)

### Group 1 — Emergency funds
| Page | URL | Decision |
|------|-----|----------|
| Building an Emergency Fund | `/guides/emergency-fund` | **Retained (strongest)** — enriched |
| How Much Emergency Fund Should You Keep in the UK? | `/guides/how-much-emergency-fund` | **Consolidated** → 301 to `/guides/emergency-fund` |

**Intent overlap:** Both answered "how much emergency fund do I need and how do I build/keep it." Both covered sizing (3/6/9–12 months), where to keep it, a 6-month worked example, and the build order. The "how much" page added the essential-spending breakdown, the months-by-situation table and the Personal Savings Allowance tax point; these were folded into the retained page. File deleted.

### Group 2 — Savings goals
| Page | URL | Decision |
|------|-----|----------|
| Setting and Reaching Your Savings Goals | `/guides/savings-goals` | **Retained (strongest)** — enriched |
| How to Set a Realistic Savings Goal | `/guides/realistic-savings-goal` | **Consolidated** → 301 to `/guides/savings-goals` |

**Intent overlap:** Both targeted "how to set and reach a savings target." Both had a wrapper-to-horizon table, an automate/standing-order section, a worked example and a limitations block. The "realistic" page added the SMART framing, the affordability stress test and the three-mistakes list; these were folded in. File deleted.

### Group 3 — Compound interest
| Page | URL | Decision |
|------|-----|----------|
| Compound Interest: How Monthly Deposits Grow Your Money | `/guides/compound-interest-monthly-deposits` | **Retained (strongest)** — enriched |
| The Complete Guide to Compound Interest | `/guides/compound-interest-guide` | **Consolidated** → 301 to `/guides/compound-interest-monthly-deposits` |

**Intent overlap:** Both explained compounding, a "time beats capital" worked example, an almost-identical "things that destroy compounding" list and an identical assumptions block. The legacy "complete guide" added the simple-vs-compound concept, the Rule of 72 and the high-fees point; these were folded into the richer monthly-deposits page (which already carried the £200/month growth table). File deleted.

### Group 4 — Debt repayment
| Page | URL | Decision |
|------|-----|----------|
| Debt Repayment Strategies: Snowball vs Avalanche | `/guides/debt-repayment` | **Retained (strongest)** — enriched |
| Debt Snowball vs Debt Avalanche | `/guides/debt-snowball-vs-avalanche` | **Consolidated** → 301 to `/guides/debt-repayment` |

**Intent overlap:** Both answered "which debt should I pay off first / which method." The overview already explained both methods and when each fits; the comparison page added the side-by-side three-debts table, the "when they disagree" scenario and the hybrid approach — all folded into the retained page. File deleted.

### Group 5 — First-time buyer
| Page | URL | Decision |
|------|-----|----------|
| First-Time Buyer's Guide: Process, Costs and Budget | `/guides/first-time-buyer` | **Retained (strongest)** — enriched |
| First-Time Buyer Budgeting Checklist | `/guides/first-time-buyer-budgeting` | **Consolidated** → 301 to `/guides/first-time-buyer` |

**Intent overlap:** Both targeted "what does buying my first home cost and how do I budget for it." The day-one cost list and £250,000 worked example were near-identical. The budgeting page added the ongoing monthly shift (renting→owning), three budgeting mistakes and deposit-source rules; these were folded into the master guide (which already had the AIP→completion process). File deleted.

### Group 6 — Pension contributions / tax & take-home
| Page | URL | Decision |
|------|-----|----------|
| Optimising Pension Contributions and Tax Relief | `/guides/pension-contributions` | **Retained (strongest)** — enriched |
| How Pension Contributions Affect Tax and Take-Home Pay | `/guides/pension-tax-take-home` | **Consolidated** → 301 to `/guides/pension-contributions` |

**Intent overlap:** Both explained tax relief (basic/higher/sacrifice cost), a 5%→10% worked example, the Annual Allowance, the lock-up/NMPA and higher-rate relief claiming. The take-home page added the three-collection-methods table and the £100,000 trap; these were folded into the contributions page. File deleted.

### Group 7 — UK salary / take-home pay
| Page | URL | Decision |
|------|-----|----------|
| How to Calculate Your UK Take-Home Pay | `/guides/calculate-take-home-pay` | **Retained (strongest)** — enriched |
| UK Salary Guide: Understanding Your Take-Home Pay | `/guides/uk-salary-guide` | **Consolidated** → 301 to `/guides/calculate-take-home-pay` |

**Intent overlap:** Both explained PAYE deductions, tax bands, payslip reading and a worked example. The salary guide added the take-home-at-common-salaries comparison table and the "decisions that move the needle" section; these were folded into the mechanics page. File deleted.

## Reviewed and retained (distinct intents — NOT merged)

These share a broad subject with another page but target a genuinely different user intent, so they were kept separate:

| Page | URL | Distinct intent |
|------|-----|-----------------|
| Self-Employment Income Guide | `/guides/self-employment-income` | How taxable profit is calculated (turnover → profit) |
| Self-Employed Tax Planning Basics | `/guides/self-employed-tax-planning` | How to legally reduce the bill (expenses, pension, VAT, cash flow) |
| Comprehensive UK Income Tax Guide | `/guides/uk-income-tax` | How Income Tax bands/allowances work |
| Advanced Tax Planning Guide | `/guides/tax-planning` | Legal strategies to reduce tax (pensions, ISAs, carry forward) |
| Salary Sacrifice vs Normal Pension | `/guides/salary-sacrifice-vs-normal-pension` | The contribution *method* decision and its trade-offs |
| Workplace Pensions & Auto-Enrolment | `/guides/workplace-pensions` | The scheme itself, minimums, auto-enrolment |
| Pension Planning & Retirement Target | `/guides/pension-planning` | How big the pot needs to be; drawdown vs annuity |
| Early Retirement Planning | `/guides/early-retirement` | Bridging income before State Pension age |
| Mortgage Overpayments | `/guides/mortgage-overpayments` | Whether to overpay an existing mortgage |
| Comprehensive Mortgage Guide | `/guides/mortgage-comprehensive` | Choosing a mortgage product/rate type |
| Mortgage Affordability for First-Time Buyers | `/guides/mortgage-affordability-first-time-buyers` | How much a lender will let you borrow |
| Compare Loan Repayments | `/guides/compare-loan-repayments` | Comparing the true cost of new borrowing |
| Debt Consolidation Guide | `/guides/debt-consolidation` | Combining existing debts into one loan |
| Personal Loan Guide | `/guides/personal-loan` | The personal-loan product |
| Credit Card Debt Guide | `/guides/credit-card-debt` | Escaping credit-card debt specifically |
| High-Interest Savings | `/guides/high-interest-savings` | Comparing accounts for the best rate |
| Tax-Free Savings (ISAs) | `/guides/tax-free-savings` | Choosing a tax wrapper |
| Student Loan Repayments | `/guides/student-loan-repayments` | Plan thresholds and graduate-tax behaviour |
| National Insurance Guide | `/guides/national-insurance` | NI classes, thresholds, state benefits |
| Marriage Allowance Guide | `/guides/marriage-allowance` | Transferring Personal Allowance between couples |
| Calculate Take-Home Pay (retained) | `/guides/calculate-take-home-pay` | Gross-to-net mechanics (now also comparison) |
| Freelance Income Guide | `/guides/freelance-income` | Irregular freelance cash flow |
| Side Hustle Tax Guide | `/guides/side-hustle-tax` | Trading Allowance and side-income reporting |

## Changes made

### Routing & redirects
- `App.jsx`: 7 routes converted from page components to `<Navigate to="..." replace />` redirects; 7 imports removed.
- `tools/prerender.js`: 7 new 301 `RewriteRule` entries added to the generated `.htaccess` (single-hop to canonical HTTPS non-www destination). The pre-existing legacy redirect `debt-snowball-guide → debt-snowball-vs-avalanche` was repointed directly to `/guides/debt-repayment` to avoid a 2-hop chain (mirrored in `App.jsx`).
- 7 guide page files deleted.

### Sitemap & metadata
- `config/routeMetadata.js`: 7 removed URLs deleted (so the generated sitemap excludes them); 7 retained pages' titles/descriptions updated to match their merged content.

### Internal links updated
- `pages/GuidesIndexPage.jsx`: 7 duplicate entries removed; consolidated entries' titles/descriptions refreshed.
- `components/Footer.jsx`: 4 links updated (compound-interest-guide, realistic-savings-goal, debt-snowball-vs-avalanche, first-time-buyer-budgeting).
- `pages/hubs/SavingsHubPage.jsx`, `DebtHubPage.jsx`, `MortgagesHubPage.jsx`, `PensionsRetirementHubPage.jsx`, `UKSalaryTaxHubPage.jsx`: guide-group and choose-right-guide entries repointed to the consolidated destinations; duplicate guide groups merged.
- `pages/DebtSnowballCalculatorPage.jsx`: 2 links repointed to `/guides/debt-repayment`.
- `pages/guides/SalarySacrificeGuidePage.jsx`, `TaxPlanningComprehensiveGuidePage.jsx`, `WorkplacePensionsComprehensiveGuidePage.jsx`: cross-links repointed from `/guides/pension-tax-take-home` to `/guides/pension-contributions`.

### Content
- Each of the 7 retained pages was rewritten to absorb the unique material from its consolidated counterpart, with structure varied by subject rather than a repeated template.

## Result

36 guides → 29 guides. Each remaining article has a distinct purpose; the 7 consolidated URLs 301 to their strongest counterpart and are removed from routing and the sitemap.

## Verification performed

- Source inspection confirms: no remaining internal links to the 7 removed URLs (only intentional `<Navigate>` redirects and `.htaccess` 301 rules reference them).
- `routeMetadata.js` no longer lists the 7 URLs; the sitemap generator reads from this file.
- Calculator formulas, unrelated guides, canonical/robots settings, and PocketBase collections are untouched.

## Verification gaps (not performed)

- **Production build / prerender** was not run in this session; the generated `.htaccess` 301 rules and the prerendered route set are source-verified only.
- **Committed `public/sitemap.xml`** is read-only in this environment and still lists the 7 old URLs; it is regenerated from `routeMetadata.js` by the platform publish flow (`tools/generate-sitemap.js`), so it will drop the 7 URLs on the next publish. This was not executed here.
- **Live-domain HTTP behaviour** was not checked. Per prior audits, the live deployment is stale and serves a generic shell; the consolidation redirects take effect only after republish and Google recrawl.
