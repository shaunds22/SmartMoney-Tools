# Crawlability Audit Report — SmartMoneyTools.com

**Internal project artifact.** Not routed, not linked, not included in sitemap.
**Audit date:** 2 November 2026
**Scope:** All priority public pages and every guide linked from `/guides/` (explicitly including `/guides/compare-loan-repayments`).
**Verification methods used:** (1) source inspection of routing, page components and the SSR entry; (2) static analysis of the publish-time prerender tool (`tools/prerender.js`) and its route-collection logic; (3) Radix UI source inspection to confirm accordion DOM behaviour. **Not performed:** production build/prerender execution (blocked in sandbox) and live-domain HTTP checks. No live verification is claimed.

---

## Summary of mechanism

The site is a React SPA that is **statically prerendered at publish time** by `tools/prerender.js`. The prerender:

1. Runs a Vite SSR build of `src/entry-server.jsx`.
2. Calls `render(route)` → `renderToString` for every non-redirect, non-dynamic route declared in `src/App.jsx`.
3. Writes one `<route>/index.html` per route into `dist/apps/web/`, injecting the per-route `<title>`, `<meta description>`, canonical, OG/Twitter tags and structured data from Helmet into the raw HTML.
4. Writes a real `404.html` (noindex, no canonical) and a generated `.htaccess` (www→non-www 301, trailing-slash 301, 21 legacy 301s, `DirectorySlash Off`, `ErrorDocument 404`).

`collectRoutes()` was statically executed: it returns **69 routes**, of which **36 are guide articles**. `/guides/compare-loan-repayments` and `/guides/mortgage-affordability-first-time-buyers` are both confirmed present in the collected set. Legacy `<Navigate>` redirect routes are correctly skipped (they are redirects, not pages).

Because `renderToString` renders the initial React tree, all article body copy, headings, methodology, worked examples, source tables, related-guides links, author bylines and last-reviewed dates that live directly in JSX are present in the prerendered HTML. Content set only inside `useEffect` (e.g. `setPageMeta` calls) does not run during SSR, but per-route title/description/canonical are emitted by the globally-mounted `<RouteMeta>` component (Helmet, renders in SSR) backed by `src/config/routeMetadata.js`, so metadata is present in the raw HTML regardless.

## Finding and fix applied

**FAQ accordion answers were absent from the prerendered HTML.** Radix `@radix-ui/react-collapsible` wraps `Collapsible.Content` in a `Presence` component whose source confirms: when `present` is false (accordion closed) and `forceMount` is not set, it returns `null` — the answer text is never written to the DOM, so Google could not see it. This affected every page using `<FAQAccordion>` (notably the UK Salary Calculator's 8-item FAQ section).

**Fix:** `src/components/FAQAccordion.jsx` now passes `forceMount` to `AccordionContent` and adds `data-[state=closed]:hidden`. Radix keeps the content mounted (so the answer text is in the raw HTML) and sets the `hidden` attribute when collapsed — crawlable, not gated behind interaction, while the accordion UX is preserved. Pages that render FAQs as plain `<h3>`/`<p>` (Mortgage, Compound Interest) were already crawlable and are unchanged.

No other content was found hidden behind interaction or client-only state, except **calculator result panels** (behind `useState(null)` until the visitor enters inputs). These are genuinely interactive outputs, not article content, and are intentionally not prerendered; every calculator page still carries its full explanatory guide, methodology, worked examples, sources and related-links sections in the static HTML.

## Per-route status

Status legend: **Crawlable** = route exists and its article body + metadata render in prerendered HTML. **Fixed** = was not crawlable, now corrected. **Needs SSR/pre-rendering** = lacks static HTML. **Missing body text** / **Invalid route** = as labelled.

### Priority pages

| Route | Status | Checked content | Finding / fix |
|---|---|---|---|
| `/` | Crawlable | H1, hero intro, calculator grid, guides CTA | Body in JSX; title/description via RouteMeta + routeMetadata. |
| `/guides` | Crawlable | H1 "Financial Library", intro, 7 hubs, 36 guide cards by category, author/editorial links | All static JSX. |
| `/uk-salary-calculator` | Fixed | H1, intro, calculator form, 14-section comprehensive guide, 2 worked examples, source table, **8 FAQs**, related tools, author byline, last-reviewed date | FAQ answers now in HTML via forceMount; rest already static. |
| `/us-salary-calculator` | Crawlable | H1, intro, form, guide, examples, sources, related, author, review date | Body in JSX. |
| `/us-retirement-calculator` | Crawlable | H1, intro, form, guide, sources, related, author, review date | Body in JSX. |
| `/pensions-calculator` | Crawlable | H1, intro, form, guide, methodology, sources, related, author, review date | Body in JSX. |
| `/mortgage` | Crawlable | H1, intro, form, repayment + interest-only worked examples, LTV, affordability vs repayment, estimate-not-offer notice, MoneyHelper/GOV.UK links, inline FAQs (plain HTML), sources, related, author, review date | FAQs are plain `<h3>`/`<p>` — already crawlable. |
| `/self-employed-tax-calculator` | Crawlable | H1, intro, form, guide, statutory bands, sources, related, author, review date | Body in JSX. |
| `/budget-planner` | Crawlable | H1, intro, planner, guide, related, author, review date | Body in JSX. |
| `/compound-interest` | Crawlable | H1, intro, form, guide, worked example, maths, assumptions, inline FAQs (plain HTML), sources, related, author, review date | FAQs plain HTML — already crawlable. |
| `/debt-snowball-calculator` | Crawlable | H1, intro, form, guide, related, author, review date | Body in JSX. |
| `/savings-goal-calculator` | Crawlable | H1, intro, form, guide, related, author, review date | Body in JSX. |

### Guide articles (all 36)

All 36 guide pages use `src/components/GuideLayout.jsx`, which renders the H1, description, breadcrumb, `<AuthorByline>` (author name + role + "Last updated" date + Article/Person JSON-LD) and the article `<article>` body as direct JSX children — all present in prerendered HTML. Each guide also links to related calculators/guides and the editorial policy. The smallest guide file is 54 lines; all contain substantive body text, headings and source references.

| Route | Status | Notes |
|---|---|---|
| `/guides/calculate-take-home-pay` | Crawlable | |
| `/guides/uk-salary-guide` | Crawlable | |
| `/guides/student-loan-repayments` | Crawlable | |
| `/guides/self-employment-income` | Crawlable | |
| `/guides/freelance-income` | Crawlable | |
| `/guides/side-hustle-tax` | Crawlable | |
| `/guides/pension-tax-take-home` | Crawlable | |
| `/guides/uk-income-tax` | Crawlable | |
| `/guides/self-employed-tax-planning` | Crawlable | |
| `/guides/national-insurance` | Crawlable | |
| `/guides/tax-planning` | Crawlable | |
| `/guides/marriage-allowance` | Crawlable | |
| `/guides/salary-sacrifice-vs-normal-pension` | Crawlable | |
| `/guides/workplace-pensions` | Crawlable | |
| `/guides/pension-contributions` | Crawlable | |
| `/guides/pension-planning` | Crawlable | |
| `/guides/early-retirement` | Crawlable | |
| `/guides/how-much-emergency-fund` | Crawlable | |
| `/guides/compound-interest-monthly-deposits` | Crawlable | |
| `/guides/realistic-savings-goal` | Crawlable | |
| `/guides/savings-goals` | Crawlable | |
| `/guides/emergency-fund` | Crawlable | |
| `/guides/high-interest-savings` | Crawlable | |
| `/guides/tax-free-savings` | Crawlable | |
| `/guides/compound-interest-guide` | Crawlable | Legacy fallback guide, still routed and content-bearing. |
| `/guides/debt-snowball-vs-avalanche` | Crawlable | |
| `/guides/compare-loan-repayments` | Crawlable | Confirmed: route collected by prerender; page renders its own article (Total Amount Repayable, APR, £10k worked comparison table, traps, mortgage impact, limitations) via GuideLayout. Not an empty shell, not a fallback. |
| `/guides/debt-repayment` | Crawlable | |
| `/guides/credit-card-debt` | Crawlable | |
| `/guides/personal-loan` | Crawlable | |
| `/guides/debt-consolidation` | Crawlable | |
| `/guides/mortgage-overpayments` | Crawlable | |
| `/guides/first-time-buyer-budgeting` | Crawlable | |
| `/guides/mortgage-comprehensive` | Crawlable | |
| `/guides/mortgage-affordability-first-time-buyers` | Crawlable | |
| `/guides/first-time-buyer` | Crawlable | |

### Hubs, author and policy pages

| Route | Status | Notes |
|---|---|---|
| `/hubs/mortgages`, `/hubs/savings`, `/hubs/debt`, `/hubs/uk-salary-tax`, `/hubs/us-salary-tax`, `/hubs/pensions-retirement`, `/hubs/self-employment` | Crawlable | TopicHub renders intro, featured calculators, grouped guides, BreadcrumbList + ItemList schema. |
| `/author/shaun-da-silva` | Crawlable | Person + BreadcrumbList schema, bio, authorship disclosure. |
| `/about`, `/contact`, `/faq`, `/privacy`, `/terms`, `/financial-disclaimer`, `/cookie-policy`, `/editorial-policy`, `/calculation-methodology`, `/corrections-policy`, `/advertising-disclosure`, `/accessibility` | Crawlable | Body in JSX; metadata via routeMetadata. |
| `/seo-audit-report` | Crawlable (admin-only, not publicly linked, not in sitemap) | |
| `*` (catch-all) | Crawlable (404) | Rendered to `/404.html`, noindex, no canonical; served with real HTTP 404 via `ErrorDocument 404`. |

### Legacy redirect routes (301, not pages)

21 legacy guide/section URLs are `<Navigate>` redirects in `App.jsx` and are emitted as 301s in the generated `.htaccess` (ordered before trailing-slash normalisation for single-hop). They are correctly **not** prerendered as pages and **not** in the sitemap. No valid article URL returns empty content.

## Checks that could not be performed

- **Production build / prerender execution** — `vite build` and `node tools/prerender.js` are blocked in this sandbox. Route-collection logic was verified by statically executing `collectRoutes()` against `src/App.jsx`; SSR render correctness was verified by source inspection of `entry-server.jsx`, `CurrencyContext` (guards `typeof window`), and page components (article body in JSX, not behind `useEffect`).
- **Live-domain HTTP verification** — not performed. Per prior audits, the live domain currently serves a stale pre-fix deployment; the fixes here ship only on the next republish and Google recrawl.

## Files changed

- `src/components/FAQAccordion.jsx` — added `forceMount` + `data-[state=closed]:hidden` so FAQ answers are present in the prerendered HTML and crawlable, while preserving the collapse/expand UX.

## Conclusion

After the FAQ `forceMount` fix, every priority page and all 36 guide articles (including `/guides/compare-loan-repayments`) return route-specific, readable HTML on first response via the existing publish-time prerender — title, H1, intro, methodology, worked examples, source references, FAQs, related guides, author byline and last-reviewed date are all in the raw HTML. No valid URL returns an empty app shell, a homepage fallback, or another article's content. Calculator result panels remain interactive (not prerendered), which is the intended behaviour. Remaining verification (build/prerender run, live HTTP) is environmental and noted above.
