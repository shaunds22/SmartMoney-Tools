# SmartMoneyTools — Statutory Data Accuracy Audit

**Audit date:** 2026-11-02
**Auditor:** SmartMoneyTools engineering (automated + manual verification)
**Scope:** All statutory financial figures across calculators, guides, FAQs, worked examples, source tables and config files.
**Primary sources used:** GOV.UK, HMRC, The Pensions Regulator, mygov.scot, IRS.gov, SSA.gov, Rev. Proc. 2025-32.
**UK tax year audited:** 2026/27 (6 April 2026 – 5 April 2027)
**US tax year audited:** 2026 (calendar year)

> **INTERNAL ONLY.** This document is a project artifact and is NOT routed, linked,
> sitemapped or exposed on the public site. It lives at `apps/web/STATUTORY_AUDIT_REPORT.md`.

## Summary of structural changes

- Created a single central source of truth: `apps/web/src/config/statutoryData.js`
  (all UK + US statutory values, source URLs, effective tax years, last-reviewed date).
- Refactored the four existing config files (`taxYear2026_27.js`,
  `federalWithholding2026.js`, `usRetirementLimits2026.js`, `usPayrollTaxData2026.js`)
  into thin wrappers that re-export from `statutoryData.js`, preserving every existing
  export name/shape so no calculator import broke.
- Refactored `SelfEmployedTaxCalculatorPage.jsx` to read Income Tax bands and Class 4 NI
  from the central config instead of hardcoded literals.
- Corrected every mismatched value found in calculator copy, worked examples, FAQs,
  source tables and guides (see table below).

## Audit table

Status key: **Corrected** = was wrong, now fixed. **Verified** = was already correct, confirmed against source. **Added** = newly introduced from central source. **Needs follow-up** = could not be fully confirmed (none outstanding — see notes).

| Page / File | Figure checked | Previous value | Correct value | Official source | Change made | Status |
|---|---|---|---|---|---|---|
| statutoryData.js (NEW) | Central UK + US statutory store | (did not exist) | All values + source URLs + tax years | GOV.UK / IRS / SSA | Created central source of truth | Added |
| taxYear2026_27.js | UK Personal Allowance | £12,570 | £12,570 | gov.uk/income-tax-rates | Re-sourced from central | Verified |
| taxYear2026_27.js | UK Income Tax bands (rUK) | 20/40/45 @ £50,270 / £125,140 | 20/40/45 @ £50,270 / £125,140 | gov.uk/income-tax-rates | Re-sourced from central | Verified |
| taxYear2026_27.js | Scottish Income Tax bands 2026/27 | Starter 19% to £16,537; Basic 20% to £29,526; Intermediate 21% to £43,662; Higher 42% to £75,000; Advanced 45% to £125,140; Top 48% | Same | mygov.scot / gov.uk/scottish-income-tax | Re-sourced from central | Verified |
| taxYear2026_27.js | Employee NI main / upper rate | 8% / 2% | 8% / 2% | gov.uk/national-insurance-rates-letters | Re-sourced from central | Verified |
| taxYear2026_27.js | Employer NI rate | 15% | 15% | gov.uk/guidance/rates-and-thresholds-for-employers-2026-to-2027 | Re-sourced from central | Verified |
| taxYear2026_27.js | Employer NI Secondary Threshold | £5,000 | £5,000 | gov.uk/guidance/rates-and-thresholds-for-employers-2026-to-2027 | Re-sourced from central | Verified |
| taxYear2026_27.js | Class 4 NI rates | 6% / 2% | 6% / 2% | gov.uk/self-employed-national-insurance-rates | Re-sourced from central | Verified |
| taxYear2026_27.js | Student Loan Plan 1 threshold | £26,900 | £26,900 | gov.uk/repaying-your-student-loan/what-you-pay | Re-sourced from central | Verified |
| taxYear2026_27.js | Student Loan Plan 2 threshold | £29,385 | £29,385 | gov.uk/repaying-your-student-loan/what-you-pay | Re-sourced from central | Verified |
| taxYear2026_27.js | Student Loan Plan 4 threshold | £33,795 | £33,795 | gov.uk/repaying-your-student-loan/what-you-pay | Re-sourced from central | Verified |
| taxYear2026_27.js | Student Loan Plan 5 threshold | £25,000 | £25,000 | gov.uk/repaying-your-student-loan/what-you-pay | Re-sourced from central | Verified |
| taxYear2026_27.js | Postgraduate Loan threshold | £21,000 | £21,000 | gov.uk/repaying-your-student-loan/what-you-pay | Re-sourced from central | Verified |
| taxYear2026_27.js | State Pension weekly | (not stored) | £241.30 | gov.uk/new-state-pension/what-youll-get | Added to central config | Added |
| taxYear2026_27.js | State Pension annual | (not stored) | £12,547.60 | gov.uk/new-state-pension/what-youll-get | Added to central config | Added |
| taxYear2026_27.js | Pension Annual Allowance | (not stored) | £60,000 | gov.uk Budget 2026 Annex A | Added to central config | Added |
| taxYear2026_27.js | Money Purchase Annual Allowance | (not stored) | £10,000 | gov.uk Budget 2026 Annex A | Added to central config | Added |
| taxYear2026_27.js | ISA annual limit | (not stored) | £20,000 | gov.uk/individual-savings-accounts/how-isas-work | Added to central config | Added |
| taxYear2026_27.js | Lifetime ISA limit | (not stored) | £4,000 | gov.uk/lifetime-isa | Added to central config | Added |
| taxYear2026_27.js | Auto-enrolment qualifying earnings | £6,240 / £50,270 | £6,240 / £50,270 | thepensionsregulator.gov.uk | Re-sourced from central | Verified |
| federalWithholding2026.js | US 2026 standard deduction (Single) | $15,000 | $16,100 | irs.gov/newsroom/irs-provides-tax-inflation-adjustments-for-tax-year-2026 (Rev. Proc. 2025-32) | Corrected | Corrected |
| federalWithholding2026.js | US 2026 standard deduction (MFJ) | $30,000 | $32,200 | IRS Rev. Proc. 2025-32 | Corrected | Corrected |
| federalWithholding2026.js | US 2026 standard deduction (MFS) | $15,000 | $16,100 | IRS Rev. Proc. 2025-32 | Corrected | Corrected |
| federalWithholding2026.js | US 2026 standard deduction (HoH) | $22,000 | $24,150 | IRS Rev. Proc. 2025-32 | Corrected | Corrected |
| federalWithholding2026.js | US 2026 standard deduction (QSS) | $30,000 | $32,200 | IRS Rev. Proc. 2025-32 | Corrected | Corrected |
| federalWithholding2026.js | US 2026 federal brackets (all statuses) | 2025-era projected thresholds | 2026 official thresholds (e.g. Single 12% over $12,400; 22% over $50,400; 24% over $105,700; 32% over $201,775; 35% over $256,225; 37% over $640,600) | irs.gov/filing/federal-income-tax-rates-and-brackets (Rev. Proc. 2025-32) | Corrected all bracket bounds | Corrected |
| usRetirementLimits2026.js | 401(k) employee deferral 2026 | $23,500 | $24,500 | irs.gov/newsroom/401k-limit-increases-to-24500-for-2026-ira-limit-increases-to-7500 | Corrected | Corrected |
| usRetirementLimits2026.js | 401(k) catch-up (50+) 2026 | $7,500 | $8,000 | IRS COLA limits | Corrected | Corrected |
| usRetirementLimits2026.js | Super catch-up (60–63) 2026 | $11,250 | $11,250 | IRS COLA limits | Verified | Verified |
| usRetirementLimits2026.js | 415(c) total annual additions 2026 | $70,000 | $72,000 | irs.gov/retirement-plans/cola-increases-for-dollar-limitations-on-benefits-and-contributions | Corrected | Corrected |
| usRetirementLimits2026.js | 415(c) + 50+ catch-up 2026 | $77,500 | $80,000 | IRS COLA limits | Corrected | Corrected |
| usRetirementLimits2026.js | 415(c) + super catch-up 2026 | $81,250 | $83,250 | IRS COLA limits | Corrected | Corrected |
| usRetirementLimits2026.js | IRA contribution limit 2026 | $7,000 | $7,500 | irs.gov/newsroom/401k-limit-increases-to-24500-for-2026-ira-limit-increases-to-7500 | Corrected | Corrected |
| usRetirementLimits2026.js | IRA catch-up (50+) 2026 | $1,000 | $1,100 | IRS COLA limits | Corrected | Corrected |
| usRetirementLimits2026.js | Social Security wage base 2026 | $184,500 | $184,500 | ssa.gov/oact/cola/cbb.html | Verified | Verified |
| usRetirementLimits2026.js | 401(a)(17) compensation limit 2026 | $350,000 | $350,000 | IRS COLA limits | Verified | Verified |
| usPayrollTaxData2026.js | Social Security rate | 6.2% | 6.2% | ssa.gov/oact/cola/cbb.html | Verified | Verified |
| usPayrollTaxData2026.js | Medicare rate | 1.45% | 1.45% | irs.gov/taxtopics/tc751 | Verified | Verified |
| usPayrollTaxData2026.js | Additional Medicare rate | 0.9% | 0.9% | irs.gov/taxtopics/tc751 | Verified | Verified |
| usPayrollTaxData2026.js | Additional Medicare thresholds | $200k/$250k/$125k/$200k/$200k | same | irs.gov/taxtopics/tc751 | Verified | Verified |
| USsalaryCalculatorPage.jsx | Standard deduction (Single) copy | $15,000 (projected) | $16,100 | IRS 2026 inflation adjustments | Corrected copy + source table | Corrected |
| USsalaryCalculatorPage.jsx | Standard deduction (MFJ) copy | $30,000 (projected) | $32,200 | IRS 2026 inflation adjustments | Corrected copy + source table | Corrected |
| USsalaryCalculatorPage.jsx | 401(k) limit copy | $23,500 | $24,500 | IRS | Corrected | Corrected |
| USsalaryCalculatorPage.jsx | IRA limit copy | $7,000 | $7,500 (+$1,100 catch-up) | IRS | Corrected | Corrected |
| USsalaryCalculatorPage.jsx | Worked example federal tax | ~$4,200 (inconsistent) | ~$6,370 (10%×$12,400 + 12%×$42,750) | IRS 2026 brackets | Recomputed with verified brackets | Corrected |
| USsalaryCalculatorPage.jsx | Worked example take-home | ~$61,300/yr | ~$59,100/yr | Recomputed | Corrected | Corrected |
| USsalaryCalculatorPage.jsx | "projected" labels | "projected 2026" | "2026" (confirmed) | — | Removed "projected" | Corrected |
| USsalaryCalculatorPage.jsx | Last reviewed date | 11 September 2026 | 2 November 2026 | — | Updated | Corrected |
| USRetirementCalculatorPage.jsx | 401(k) limit (FAQ + copy + table) | $23,500 | $24,500 | IRS | Corrected | Corrected |
| USRetirementCalculatorPage.jsx | 401(k) catch-up (50+) | $7,500 | $8,000 | IRS | Corrected | Corrected |
| USRetirementCalculatorPage.jsx | IRA limit + catch-up | $7,000 / $1,000 | $7,500 / $1,100 | IRS | Corrected | Corrected |
| USRetirementCalculatorPage.jsx | Total DC limit (table) | $70,000 | $72,000 | IRS COLA | Corrected | Corrected |
| USRetirementCalculatorPage.jsx | Last reviewed date | 11 September 2026 | 2 November 2026 | — | Updated | Corrected |
| PensionsCalculatorPage.jsx | State Pension annual (copy) | £11,500 (2025/26) | £12,547.60 (2026/27) | gov.uk/new-state-pension/what-youll-get | Corrected | Corrected |
| PensionsCalculatorPage.jsx | State Pension annual (exclusions) | £11,502 (2025/26) | £12,547.60 (2026/27) | gov.uk/new-state-pension/what-youll-get | Corrected | Corrected |
| NationalInsuranceComprehensiveGuidePage.jsx | Employer NI rate (table) | 13.8% | 15% | gov.uk/national-insurance-rates-letters | Corrected | Corrected |
| NationalInsuranceComprehensiveGuidePage.jsx | Employer NI band (table) | 0% to £12,570 (aligned with PT) | 0% to £5,000 Secondary Threshold; 15% above £5,000 | gov.uk/guidance/rates-and-thresholds-for-employers-2026-to-2027 | Corrected table structure | Corrected |
| NationalInsuranceComprehensiveGuidePage.jsx | Secondary Threshold text | "aligns with Primary Threshold" | £5,000 (below PT since Apr 2025) | GOV.UK employer rates | Corrected | Corrected |
| NationalInsuranceComprehensiveGuidePage.jsx | Worked example employer NI | 13.8% on £17,430 = £2,405; total £32,405 | 15% on £25,000 (above £5,000 ST) = £3,750; total £33,750 | GOV.UK | Recomputed | Corrected |
| NationalInsuranceComprehensiveGuidePage.jsx | Salary-sacrifice saving rate | 13.8% | 15% | GOV.UK | Corrected | Corrected |
| PensionTaxTakeHomeGuidePage.jsx | Employer NI rate | 13.8% | 15% | GOV.UK | Corrected | Corrected |
| SalarySacrificeGuidePage.jsx | Employer NI saving | 13.8% | 15% | GOV.UK | Corrected | Corrected |
| PensionPlanningComprehensiveGuidePage.jsx | State Pension annual | £11,973.60 (2025/26) | £12,547.60 (2026/27) | gov.uk/new-state-pension/what-youll-get | Corrected | Corrected |
| SelfEmployedTaxCalculatorPage.jsx | Income Tax bands (formula) | hardcoded 37700/125140/50270 | sourced from central config | gov.uk/income-tax-rates | Refactored to config | Corrected |
| SelfEmployedTaxCalculatorPage.jsx | Class 4 NI (formula) | hardcoded 12570/50270/0.06/0.02 | sourced from central config | gov.uk/self-employed-national-insurance-rates | Refactored to config | Corrected |
| SelfEmployedTaxCalculatorPage.jsx | Personal Allowance taper | hardcoded 12570/100000/0.5 | sourced from central config | gov.uk/income-tax-rates | Refactored to config | Corrected |
| UKSalaryCalculator.jsx | All statutory values | correct | correct | GOV.UK/HMRC | Verified; updated last-reviewed date + employer NI source URL to 2026/27 | Verified |
| Mortgage / Compound / Budget / Debt Snowball / Savings Goal calculators | Formula constants (rates, terms) | non-statutory / user inputs | non-statutory | n/a | No statutory values to correct; formulas use user inputs only | Verified |

## Values that could not be independently confirmed

None outstanding. Every statutory figure in the audited calculators and guides was
confirmed against an official primary source on 2026-11-02. Non-statutory assumptions
(growth rates, inflation, withdrawal rates, default salaries in worked examples) were
left unchanged and remain clearly labelled as illustrative assumptions on each page.

## Notes / caveats

- The 415(c) total annual additions limit ($72,000) and 401(a)(17) compensation limit
  ($350,000) for 2026 are taken from the IRS COLA limits publication and corroborated by
  Fidelity; they are secondary figures rarely reached by typical users.
- US 2026 federal brackets reflect the TCJA-era rate structure (10/12/22/24/32/35/37)
  as inflation-adjusted by Rev. Proc. 2025-32; the One Big Beautiful Bill Act made the
  TCJA individual provisions permanent, so no sunset reversion applies for 2026.
- Live-domain HTTP status, real-device testing and Core Web Vitals were NOT performed in
  this audit (source-level audit only). Fixes ship on next publish.
- This report is an internal artifact; it is not added to `routeMetadata.js`, the
  sitemap, robots, feeds or any public route.
