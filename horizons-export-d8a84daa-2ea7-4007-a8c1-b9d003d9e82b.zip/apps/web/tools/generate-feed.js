#!/usr/bin/env node
/**
 * Generates public/feed.xml (RSS 2.0) and public/feed.json (JSON Feed 1.1)
 * from src/config/routeMetadata.js — the single source of truth for every
 * indexable route.
 *
 * Only `/guides/*` routes are emitted as feed entries: the guides are the
 * site's editorial articles and are what subscribers expect from an RSS/JSON
 * feed. Calculators and policy pages are intentionally excluded.
 *
 * Both feeds:
 *   - link to canonical HTTPS non-www article URLs (https://smartmoney-tools.com)
 *   - carry valid RFC 822 (RSS) / ISO 8601 (JSON Feed) dates
 *   - use the unique title + description from routeMetadata
 *   - are NOT listed in sitemap.xml (generate-sitemap only reads routeMetadata
 *     keys, and feed.xml/feed.json are not keys)
 *
 * Runs before `vite build`, which copies public/ into the build output.
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const webRoot = path.resolve(__dirname, '..');
const BASE_URL = 'https://smartmoney-tools.com';

function escapeXml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function escapeJson(str) {
  // JSON.stringify handles escaping; this is a no-op safety wrapper kept for clarity.
  return String(str);
}

function rfc822Date(d) {
  // e.g. "Wed, 03 Sep 2026 00:00:00 GMT"
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const pad = (n) => String(n).padStart(2, '0');
  return `${days[d.getUTCDay()]}, ${pad(d.getUTCDate())} ${months[d.getUTCMonth()]} ${d.getUTCFullYear()} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())} GMT`;
}

async function main() {
  const routeModule = await import(
    pathToFileURL(path.join(webRoot, 'src', 'config', 'routeMetadata.js')).href
  );
  const routeMetadata = routeModule.default || routeModule;

  // Only real guide articles, sorted alphabetically for stable output.
  const guideRoutes = Object.keys(routeMetadata)
    .filter((r) => r.startsWith('/guides/'))
    .sort();

  if (guideRoutes.length === 0) {
    console.warn('[generate-feed] no guide routes found in routeMetadata, skipping');
    return;
  }

  // Stable genuine last-revision date for the guide corpus (the 2026-09-11
  // rewrite). Used for every entry's pubDate/date_modified and for
  // lastBuildDate so the feed never auto-changes merely on redeploy.
  const pubDate = new Date('2026-09-11T00:00:00Z');
  const pubDateRfc822 = rfc822Date(pubDate);
  const pubDateIso = pubDate.toISOString();
  const lastBuildRfc822 = rfc822Date(pubDate);

  const entries = guideRoutes.map((r) => {
    const meta = routeMetadata[r];
    const url = `${BASE_URL}${r}`;
    return {
      path: r,
      url,
      title: meta.title,
      description: meta.description,
      guid: url,
    };
  });

  // ---- RSS 2.0 ----
  const rssItems = entries
    .map(
      (e) =>
        `    <item>\n` +
        `      <title>${escapeXml(e.title)}</title>\n` +
        `      <link>${escapeXml(e.url)}</link>\n` +
        `      <guid isPermaLink="true">${escapeXml(e.guid)}</guid>\n` +
        `      <description>${escapeXml(e.description)}</description>\n` +
        `      <pubDate>${pubDateRfc822}</pubDate>\n` +
        `    </item>`
    )
    .join('\n');

  const rss =
    `<?xml version="1.0" encoding="UTF-8"?>\n` +
    `<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">\n` +
    `  <channel>\n` +
    `    <title>SmartMoneyTools Financial Guides</title>\n` +
    `    <link>${BASE_URL}/guides</link>\n` +
    `    <description>Free UK and US financial guides covering salary, tax, pensions, savings, debt and mortgages — clear, actionable and regularly updated.</description>\n` +
    `    <language>en-GB</language>\n` +
    `    <lastBuildDate>${lastBuildRfc822}</lastBuildDate>\n` +
    `    <atom:link href="${BASE_URL}/feed.xml" rel="self" type="application/rss+xml" />\n` +
    `${rssItems}\n` +
    `  </channel>\n` +
    `</rss>\n`;

  fs.writeFileSync(path.join(webRoot, 'public', 'feed.xml'), rss, 'utf8');
  console.log(`[generate-feed] wrote ${entries.length} entries to public/feed.xml (RSS 2.0)`);

  // ---- JSON Feed 1.1 ----
  const jsonFeed = {
    version: 'https://jsonfeed.org/version/1.1',
    title: 'SmartMoneyTools Financial Guides',
    home_page_url: `${BASE_URL}/guides`,
    feed_url: `${BASE_URL}/feed.json`,
    description:
      'Free UK and US financial guides covering salary, tax, pensions, savings, debt and mortgages — clear, actionable and regularly updated.',
    language: 'en-GB',
    items: entries.map((e) => ({
      id: e.guid,
      url: e.url,
      title: e.title,
      summary: e.description,
      date_published: pubDateIso,
      date_modified: pubDateIso,
    })),
  };

  fs.writeFileSync(path.join(webRoot, 'public', 'feed.json'), JSON.stringify(jsonFeed, null, 2) + '\n', 'utf8');
  console.log(`[generate-feed] wrote ${entries.length} entries to public/feed.json (JSON Feed 1.1)`);
}

main().catch((err) => {
  console.error(`[generate-feed] failed: ${err?.message || err}`);
  process.exit(1);
});
