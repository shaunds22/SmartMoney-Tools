/**
 * Static prerendering step.
 *
 * Runs AFTER the normal client `vite build`. It bundles the app for Node
 * (SSR), renders every non-redirect route defined in src/App.jsx to static
 * HTML, and writes a fully-rendered index.html for each route into the client
 * build output. The React app still hydrates/boots normally in the browser, so
 * all calculator interactivity is preserved — but crawlers now receive the real
 * text content, headings, meta tags and structured data in the raw response.
 */
import { build } from 'vite';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const webRoot = path.resolve(__dirname, '..');
const clientOutDir = path.resolve(webRoot, '../../dist/apps/web');
const ssrOutDir = path.resolve(webRoot, '../../dist/ssr');

const BASE_URL = 'https://smartmoney-tools.com';
const DEFAULT_DESCRIPTION =
  'Free financial calculators and educational guides for compound interest, mortgages, UK salary, pensions, savings goals and more.';

/**
 * .htaccess written into the build output (dist) by the prerender step.
 *
 * The source public/.htaccess is read-only and contains a SPA catch-all
 * rewrite that serves index.html (HTTP 200) for every missing path — a
 * soft-404. This replacement:
 *   - 301-redirects the legacy URLs formerly handled by <Navigate> in App.jsx
 *   - 301-redirects every non-canonical origin (HTTP non-www, HTTP www,
 *     HTTPS www) to the HTTPS non-www preferred domain in a single hop,
 *     preserving the full path and query string and stripping any trailing slash
 *   - 301-redirects trailing-slash URLs to the canonical slash-free URL
 *   - drops the catch-all so missing paths fall through to ErrorDocument
 *   - serves the prerendered /404.html with a real HTTP 404 status
 * Legitimate routes are unaffected: each is prerendered to its own
 * <route>/index.html, which Apache serves directly with HTTP 200.
 */
const HTACCESS_OUTPUT = `<IfModule mod_rewrite.c>
\tRewriteEngine On
\tRewriteBase /

\t# Legacy URL redirects (301 permanent) — preserve previously indexed URLs.
\t# These run FIRST and substitute the full canonical HTTPS non-www URL, so a
\t# legacy URL requested from ANY origin (http non-www, http www, https www, or
\t# the canonical host itself, with or without a trailing slash) reaches its
\t# replacement in a single 301 hop — no origin-normalisation → legacy chain.
\t# Query strings are preserved by default (no trailing "?" on the substitution).
\tRewriteRule ^disclaimer/?$ https://smartmoney-tools.com/financial-disclaimer [R=301,L]
\tRewriteRule ^methodology/?$ https://smartmoney-tools.com/calculation-methodology [R=301,L]
\tRewriteRule ^guides/understanding-uk-income-tax/?$ https://smartmoney-tools.com/guides/uk-income-tax [R=301,L]
\tRewriteRule ^guides/national-insurance-explained/?$ https://smartmoney-tools.com/guides/national-insurance [R=301,L]
\tRewriteRule ^guides/pension-contributions-tax-relief/?$ https://smartmoney-tools.com/guides/pension-contributions [R=301,L]
\tRewriteRule ^guides/tax-planning-strategies-uk-employees/?$ https://smartmoney-tools.com/guides/tax-planning [R=301,L]
\tRewriteRule ^guides/maximizing-take-home-pay/?$ https://smartmoney-tools.com/guides/calculate-take-home-pay [R=301,L]
\tRewriteRule ^guides/self-employed-tax-guide/?$ https://smartmoney-tools.com/guides/self-employed-tax-planning [R=301,L]
\tRewriteRule ^guides/investment-basics-beginners/?$ https://smartmoney-tools.com/guides/savings-goals [R=301,L]
\tRewriteRule ^guides/emergency-fund-financial-safety-net/?$ https://smartmoney-tools.com/guides/emergency-fund [R=301,L]
\tRewriteRule ^guides/savings-goal-guide/?$ https://smartmoney-tools.com/guides/savings-goals [R=301,L]
\tRewriteRule ^guides/debt-management-repayment-strategies/?$ https://smartmoney-tools.com/guides/debt-repayment [R=301,L]
\tRewriteRule ^guides/debt-snowball-guide/?$ https://smartmoney-tools.com/guides/debt-repayment [R=301,L]
\tRewriteRule ^guides/budget-planner-guide/?$ https://smartmoney-tools.com/budget-planner [R=301,L]
\tRewriteRule ^guides/retirement-planning-guide/?$ https://smartmoney-tools.com/guides/pension-planning [R=301,L]
\tRewriteRule ^guides/pensions-calculator-guide/?$ https://smartmoney-tools.com/pensions-calculator [R=301,L]
\tRewriteRule ^guides/financial-planning-young-professionals/?$ https://smartmoney-tools.com/guides/pension-planning [R=301,L]
\tRewriteRule ^guides/mortgage-guide/?$ https://smartmoney-tools.com/guides/mortgage-comprehensive [R=301,L]
\tRewriteRule ^guides/uk-salary-calculator-guide/?$ https://smartmoney-tools.com/uk-salary-calculator [R=301,L]
\tRewriteRule ^guides/student-loan-repayment-guide/?$ https://smartmoney-tools.com/guides/student-loan-repayments [R=301,L]
\tRewriteRule ^guides/compound-interest-monthly/?$ https://smartmoney-tools.com/guides/compound-interest-monthly-deposits [R=301,L]

\t# Content consolidation redirects (301 permanent) — weaker overlapping
\t# guides merged into the strongest page on the same intent. Single-hop to
\t# the canonical HTTPS non-www destination, preserving query strings.
\tRewriteRule ^guides/how-much-emergency-fund/?$ https://smartmoney-tools.com/guides/emergency-fund [R=301,L]
\tRewriteRule ^guides/realistic-savings-goal/?$ https://smartmoney-tools.com/guides/savings-goals [R=301,L]
\tRewriteRule ^guides/compound-interest-guide/?$ https://smartmoney-tools.com/guides/compound-interest-monthly-deposits [R=301,L]
\tRewriteRule ^guides/debt-snowball-vs-avalanche/?$ https://smartmoney-tools.com/guides/debt-repayment [R=301,L]
\tRewriteRule ^guides/first-time-buyer-budgeting/?$ https://smartmoney-tools.com/guides/first-time-buyer [R=301,L]
\tRewriteRule ^guides/pension-tax-take-home/?$ https://smartmoney-tools.com/guides/pension-contributions [R=301,L]
\tRewriteRule ^guides/uk-salary-guide/?$ https://smartmoney-tools.com/guides/calculate-take-home-pay [R=301,L]

\t# Canonical origin: redirect every non-canonical request — HTTP on either
\t# host, or HTTPS on the www host — to the HTTPS non-www preferred domain in
\t# a single 301 hop. This covers all three alternate origins of canonical
\t# paths:
\t#   http://smartmoney-tools.com/<path>?<query>
\t#   http://www.smartmoney-tools.com/<path>?<query>
\t#   https://www.smartmoney-tools.com/<path>?<query>
\t# The pattern also drops any trailing slash (except the homepage) so a URL
\t# that is both non-canonical AND trailing-slash consolidates directly to the
\t# canonical slash-free URL with no redirect chain. Query strings are preserved
\t# by default (no trailing "?" on the substitution). Legacy paths never reach
\t# this rule (handled above).
\tRewriteCond %{HTTPS} off [OR]
\tRewriteCond %{HTTP_HOST} ^www\\.smartmoney-tools\\.com$ [NC]
\tRewriteRule ^(.*?)/?$ https://smartmoney-tools.com/$1 [R=301,L]

\t# Trailing slash: 301 to the canonical slash-free URL (homepage excluded).
\t# Query strings (e.g. utm_* referral parameters) are preserved.
\tRewriteRule ^(.+)/$ /$1 [R=301,L]

\t# Serve the prerendered <route>/index.html for extensionless directory
\t# requests directly (HTTP 200) instead of letting mod_dir 301 them to the
\t# trailing-slash form, which would loop with the slash-stripping rule above.
\tRewriteCond %{REQUEST_FILENAME} -d
\tRewriteCond %{REQUEST_FILENAME}/index.html -f
\tRewriteRule ^(.*[^/])$ $1/index.html [L]

\t# No catch-all rewrite to index.html. Every legitimate route is prerendered
\t# to its own <route>/index.html (served with HTTP 200). Any URL without a
\t# prerendered file falls through to ErrorDocument 404 below (real HTTP 404).
</IfModule>

# Disable mod_dir's automatic 301 from slash-free directory URLs to the
# trailing-slash form — the rewrite rule above already serves those requests
# directly, and the automatic redirect would create a redirect loop with it.
<IfModule mod_dir.c>
\tDirectorySlash Off
</IfModule>

# Serve the prerendered 404 page with a real HTTP 404 status for any URL
# that has no matching file or directory on disk.
ErrorDocument 404 /404.html

<IfModule mod_headers.c>
\tHeader set X-Powered-By "Hostinger Horizons"

\t# Cache everything on CDN by default
\tHeader set Cache-Control "public, s-maxage=604800, max-age=0"

\t# Cache in browser all assets
\t<If "%{REQUEST_URI} =~ m#^/assets/.*$#">
\t\tHeader set Cache-Control "public, max-age=604800"
\t</If>
</IfModule>
`;

function collectRoutes() {
  const appSource = fs.readFileSync(path.join(webRoot, 'src/App.jsx'), 'utf-8');
  const routes = new Set(['/']);
  const routeRegex = /<Route\s+path="([^"]+)"\s+element=\{([\s\S]*?)\}\s*\/>/g;
  let match;
  while ((match = routeRegex.exec(appSource)) !== null) {
    const [, routePath, element] = match;
    if (routePath === '*' || element.includes('Navigate')) continue;
    if (routePath.includes(':')) continue;
    routes.add(routePath);
  }
  return [...routes];
}

function stripDefaultHead(template) {
  return template
    // Remove ALL titles (not just the first) and any tag previously injected by
    // react-helmet, so re-running the prerender over already-prerendered output
    // is idempotent instead of stacking duplicate titles/meta on every pass.
    .replace(/<[^>]+\sdata-react-helmet="true"[^>]*>[\s\S]*?<\/(?:title|script|style|noscript)>\s*/gi, '')
    .replace(/<(?:meta|link)[^>]*\sdata-react-helmet="true"[^>]*\/?>\s*/gi, '')
    .replace(/<title[^>]*>[\s\S]*?<\/title>\s*/gi, '')
    .replace(/<meta\s+name="description"[^>]*>\s*/gi, '')
    .replace(/<link\s+rel="canonical"[^>]*>\s*/gi, '')
    .replace(/<meta\s+property="og:[^"]*"[^>]*>\s*/gi, '')
    .replace(/<meta\s+name="twitter:[^"]*"[^>]*>\s*/gi, '');
}

/**
 * Helmet state can leak across renderToString calls in a long prerender run
 * (a prior route's <Helmet> sometimes survives into the next route's head).
 * The current route's tags are always emitted LAST, so for the tags where
 * duplicates would be harmful we keep only the final occurrence and strip the
 * earlier (leaked) ones. OG/Twitter/schema tags are left untouched.
 */
function dedupeHelmetHead(head) {
  const keepLast = (regex) => {
    const matches = head.match(regex);
    if (!matches || matches.length < 2) return;
    const last = matches[matches.length - 1];
    head = head.replace(regex, '').trim() + '\n' + last;
  };
  keepLast(/<title[^>]*>[\s\S]*?<\/title>/gi);
  keepLast(/<meta[^>]*name=["']description["'][^>]*>/gi);
  keepLast(/<link[^>]*rel=["']canonical["'][^>]*>/gi);
  keepLast(/<meta[^>]*name=["']robots["'][^>]*>/gi);
  return head;
}

function escapeAttr(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function textFrom(html, regex) {
  const found = html.match(regex);
  if (!found) return '';
  return found[1]
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function buildHead(route, rendered) {
  // Helmet emits an empty <title></title> when a page sets its meta imperatively;
  // drop it so we can inject a real title below. Also strip any tags leaked from
  // a previous route's render, keeping only the current route's (last) occurrence.
  const helmetHead = dedupeHelmetHead(
    (rendered.head || '').replace(/<title[^>]*>\s*<\/title>/i, '')
  );
  const hasTitle = /<title[^>]*>\s*\S/i.test(helmetHead);
  const hasDescription = /name="description"/i.test(helmetHead);
  const hasCanonical = /rel="canonical"/i.test(helmetHead);

  // Prefer the real <title> / <meta description> emitted by <RouteMeta> via
  // Helmet so OG / Twitter fallbacks match the page's actual metadata instead
  // of an H1-derived guess.
  const titleMatch = helmetHead.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const descMatch =
    helmetHead.match(/<meta[^>]*name=["']description["'][^>]*content=["']([\s\S]*?)["']/i) ||
    helmetHead.match(/<meta[^>]*content=["']([\s\S]*?)["'][^>]*name=["']description["']/i);

  const h1 = textFrom(rendered.html, /<h1[^>]*>([\s\S]*?)<\/h1>/i);
  const paragraph = textFrom(rendered.html, /<p[^>]*>([\s\S]*?)<\/p>/i);

  const title = titleMatch
    ? titleMatch[1].trim()
    : h1
      ? `${h1} | SmartMoneyTools`
      : 'SmartMoneyTools | Free Financial Calculators';
  const description = descMatch ? descMatch[1] : (paragraph || DEFAULT_DESCRIPTION).slice(0, 300);
  const canonical = `${BASE_URL}${route === '/' ? '/' : route}`;

  const tags = [helmetHead];
  if (!hasTitle) tags.push(`<title>${escapeAttr(title)}</title>`);
  if (!hasDescription) tags.push(`<meta name="description" content="${escapeAttr(description)}" />`);
  if (!hasCanonical) tags.push(`<link rel="canonical" href="${canonical}" />`);
  if (!/property="og:title"/i.test(helmetHead)) {
    tags.push(
      `<meta property="og:type" content="website" />`,
      `<meta property="og:site_name" content="SmartMoneyTools" />`,
      `<meta property="og:title" content="${escapeAttr(title)}" />`,
      `<meta property="og:description" content="${escapeAttr(description)}" />`,
      `<meta property="og:url" content="${canonical}" />`,
      `<meta property="og:image" content="${BASE_URL}/og-default.png" />`,
      `<meta name="twitter:card" content="summary_large_image" />`,
      `<meta name="twitter:title" content="${escapeAttr(title)}" />`,
      `<meta name="twitter:description" content="${escapeAttr(description)}" />`,
      `<meta name="twitter:image" content="${BASE_URL}/og-default.png" />`
    );
  }
  return tags.filter(Boolean).join('\n\t\t');
}

async function main() {
  const templatePath = path.join(clientOutDir, 'index.html');
  if (!fs.existsSync(templatePath)) {
    console.warn('[prerender] client build not found, skipping prerender');
    return;
  }

  await build({
    root: webRoot,
    logLevel: 'warn',
    build: {
      ssr: path.join(webRoot, 'src/entry-server.jsx'),
      outDir: ssrOutDir,
      emptyOutDir: true,
      rollupOptions: { output: { entryFileNames: 'entry-server.mjs' } },
    },
  });

  const { render } = await import(pathToFileURL(path.join(ssrOutDir, 'entry-server.mjs')).href);

  let template = stripDefaultHead(fs.readFileSync(templatePath, 'utf-8'));
  // If a previous prerender run already filled #root with the homepage body,
  // reset it to the empty SPA mount point so the <div id="root"></div>
  // injection below finds its target. Without this, re-running the prerender
  // over an already-prerendered build output ships the stale homepage body on
  // every route — a soft-404. The head is already idempotent via
  // stripDefaultHead; this makes the body idempotent too. Only fires when
  // #root is non-empty, so a clean client build (empty #root, optional body
  // script) is left untouched.
  if (!/<div id="root">\s*<\/div>/.test(template)) {
    template = template.replace(
      /<div id="root">[\s\S]*<\/div>\s*(?=<\/body>)/,
      '<div id="root"></div>\n\t'
    );
  }
  const routes = collectRoutes();
  let ok = 0;

  for (const route of routes) {
    try {
      const rendered = render(route);
      if (!rendered.html || rendered.html.length < 200) {
        console.warn(`[prerender] skipped ${route} (empty render)`);
        continue;
      }
      const head = buildHead(route, rendered);
      const html = template
        .replace('</head>', `\t${head}\n\t</head>`)
        .replace('<div id="root"></div>', `<div id="root">${rendered.html}</div>`);

      const outFile =
        route === '/'
          ? path.join(clientOutDir, 'index.html')
          : path.join(clientOutDir, route.replace(/^\//, ''), 'index.html');
      fs.mkdirSync(path.dirname(outFile), { recursive: true });
      fs.writeFileSync(outFile, html);
      ok += 1;
    } catch (error) {
      console.warn(`[prerender] failed ${route}: ${error?.message || error}`);
    }
  }

  // Render the catch-all NotFound page to /404.html. Apache serves this file
  // via `ErrorDocument 404 /404.html` (configured in .htaccess) so any URL
  // without a prerendered index.html receives a real HTTP 404 status together
  // with the styled 404 page. The NotFound component already emits
  // <meta name="robots" content="noindex, follow"> so the page is never
  // indexed even if a soft-404 (HTTP 200) response leaks through.
  try {
    const rendered404 = render('/__not_found_placeholder__');
    if (rendered404.html && rendered404.statusCode === 404) {
      // Use the Helmet head only (title, description, robots noindex) — no
      // canonical or OG tags for a non-indexable error page. Dedupe any leaked
      // tags, strip the canonical the globally-mounted CanonicalLink emits for
      // the placeholder path (a 404 document must not carry a canonical URL),
      // and drop the template's default "index, follow" robots so the
      // 404 page carries a single, correct noindex directive.
      const head404 = dedupeHelmetHead(rendered404.head || '')
        .replace(/<link[^>]*rel=["']canonical["'][^>]*\/?>\s*/gi, '');
      const html404 = template
        .replace(/<meta\s+name="robots"[^>]*>\s*/i, '')
        .replace('</head>', `\t${head404}\n\t</head>`)
        .replace('<div id="root"></div>', `<div id="root">${rendered404.html}</div>`);
      fs.writeFileSync(path.join(clientOutDir, '404.html'), html404);
      console.log('[prerender] wrote /404.html (HTTP 404 error document)');
    } else {
      console.warn('[prerender] 404 page did not render as expected, skipping /404.html');
    }
  } catch (error) {
    console.warn(`[prerender] failed to write /404.html: ${error?.message || error}`);
  }

  // Overwrite the build-output .htaccess with a version that returns real
  // HTTP 404s. The source public/.htaccess is read-only in this environment
  // and ships a SPA catch-all rewrite (`RewriteRule ^ index.html [L]`) that
  // turns every missing path into a soft-404 (HTTP 200). This generated
  // replacement removes that catch-all, adds 301 redirects for the legacy
  // URLs formerly handled by <Navigate>, and points ErrorDocument 404 at the
  // prerendered /404.html above. Only the deployed dist copy is changed; the
  // read-only source file is left untouched.
  try {
    fs.writeFileSync(path.join(clientOutDir, '.htaccess'), HTACCESS_OUTPUT);
    console.log('[prerender] wrote dist .htaccess (real HTTP 404 + 301 legacy redirects)');
  } catch (error) {
    console.warn(`[prerender] failed to write dist .htaccess: ${error?.message || error}`);
  }

  fs.rmSync(ssrOutDir, { recursive: true, force: true });
  console.log(`[prerender] rendered ${ok}/${routes.length} routes to static HTML`);
}

main().catch((error) => {
  console.warn(`[prerender] disabled: ${error?.message || error}`);
});
