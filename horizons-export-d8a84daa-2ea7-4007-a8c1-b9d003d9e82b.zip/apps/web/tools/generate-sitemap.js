#!/usr/bin/env node
/**
 * Generates public/sitemap.xml from src/config/routeMetadata.js — the single
 * source of truth for every indexable route — so the sitemap always lists
 * every page, including newly added guides. Runs before `vite build`, which
 * copies public/ into the build output. Mirrors the generate-llms.js pattern.
 *
 * Inclusion policy (matches Google Search Console best practice):
 *   - only routes present in routeMetadata (real, substantial, indexable pages)
 *   - HTTPS, non-www, slash-free canonical URLs only
 *   - excludes 404/soft-404, redirects (Navigate routes never enter routeMetadata),
 *     noindex pages, search/test/preview/admin pages, and tracking-parameter URLs
 *
 * lastmod: a single real date reflecting the most recent confirmed site-wide
 * material content update (the 2026-11-02 statutory-data audit and content
 * rewrite pass that touched calculators, guides and shared components). It is a
 * genuine date, never invented. Google treats lastmod as a hint; a single
 * accurate site-wide value is preferable to per-URL guesses without reliable
 * per-page change records. changefreq/priority are omitted because Google
 * ignores them and uniform values would be non-informative.
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const webRoot = path.resolve(__dirname, '..');
const BASE_URL = 'https://smartmoney-tools.com';

async function main() {
  const routeModule = await import(
    pathToFileURL(path.join(webRoot, 'src', 'config', 'routeMetadata.js')).href
  );
  const routeMetadata = routeModule.default || routeModule;
  const routes = Object.keys(routeMetadata).sort();

  if (routes.length === 0) {
    console.warn('[generate-sitemap] no routes found in routeMetadata, skipping');
    return;
  }

  // Per-route "Last reviewed" dates. Routes without an explicit date fall back
  // to the site-wide statutory-data audit date.
  const lastmodModule = await import(
    pathToFileURL(path.join(webRoot, 'src', 'config', 'routeLastmod.js')).href
  );
  const routeLastmod = lastmodModule.default || {};
  const DEFAULT_LASTMOD = '2026-11-02';

  const urlEntries = routes
    .map((r) => {
      const loc = `${BASE_URL}${r === '/' ? '/' : r}`;
      const lastmod = routeLastmod[r] || DEFAULT_LASTMOD;
      return `  <url>\n    <loc>${loc}</loc>\n    <lastmod>${lastmod}</lastmod>\n  </url>`;
    })
    .join('\n');

  const xml =
    `<?xml version="1.0" encoding="UTF-8"?>\n` +
    `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n` +
    `${urlEntries}\n` +
    `</urlset>\n`;

  const outPath = path.join(webRoot, 'public', 'sitemap.xml');
  fs.writeFileSync(outPath, xml, 'utf8');
  console.log(`[generate-sitemap] wrote ${routes.length} URLs to public/sitemap.xml`);
}

main().catch((err) => {
  console.error(`[generate-sitemap] failed: ${err?.message || err}`);
  process.exit(1);
});
