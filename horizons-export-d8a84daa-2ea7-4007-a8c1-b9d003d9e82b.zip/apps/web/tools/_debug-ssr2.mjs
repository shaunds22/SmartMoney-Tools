import { build } from 'vite';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const webRoot = path.resolve(__dirname, '..');
const ssrOutDir = path.resolve(webRoot, '../../dist/_ssr_debug2');

await build({
  root: webRoot,
  logLevel: 'warn',
  build: {
    ssr: path.join(webRoot, 'src/entry-server.jsx'),
    outDir: ssrOutDir,
    emptyOutDir: true,
    rollupOptions: { output: { entryFileNames: 'entry-server.mjs' } },
  },
});

const { render } = await import(pathToFileURL(path.join(ssrOutDir, 'entry-server.mjs')).href);

// Mimic prerender order: '/' FIRST, then a guide
for (const route of ['/', '/guides/debt-repayment', '/about']) {
  const r = render(route);
  const h1 = r.html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/);
  console.log(`ROUTE ${route}`);
  console.log('  H1:', h1 ? h1[1].replace(/<[^>]+>/g, '').trim().slice(0, 60) : 'NONE');
  console.log('  has "Avalanche":', r.html.includes('Avalanche'));
  console.log('  has homepage "Skip the complicated":', r.html.includes('Skip the complicated'));
}

fs.rmSync(ssrOutDir, { recursive: true, force: true });
