/**
 * usPayrollTaxData2026.js — 2026 US FICA (Social Security + Medicare) data
 * and pay-frequency / filing-status metadata. Thin wrapper over the central
 * `statutoryData.js`.
 */
import { US } from './statutoryData.js';

export const FICA_DATA_2026 = {
  socialSecurityRate: US.fica.socialSecurityRate,
  socialSecurityWageBase: US.fica.socialSecurityWageBase,
  medicareRate: US.fica.medicareRate,
  additionalMedicareRate: US.fica.additionalMedicareRate,
  additionalMedicareThresholds: US.fica.additionalMedicareThresholds,
};

export const PAY_FREQUENCIES = {
  annual: { periods: 1, label: 'Annual' },
  monthly: { periods: 12, label: 'Monthly' },
  semiMonthly: { periods: 24, label: 'Semi-Monthly' },
  biweekly: { periods: 26, label: 'Bi-Weekly' },
  weekly: { periods: 52, label: 'Weekly' },
  daily: { periods: 260, label: 'Daily' } // Assumes 5 days/week
};

export const FILING_STATUSES = [
  { value: 'single', label: 'Single' },
  { value: 'marriedFilingJointly', label: 'Married Filing Jointly' },
  { value: 'marriedFilingSeparately', label: 'Married Filing Separately' },
  { value: 'headOfHousehold', label: 'Head of Household' },
  { value: 'qualifyingWidow', label: 'Qualifying Widow(er)' }
];

export const METADATA = {
  lastReviewed: '2026-11-02',
  taxYear: US.taxYear,
  sources: [
    US.sources.pub15t,
    US.sources.fica,
    US.sources.medicare,
  ],
};
