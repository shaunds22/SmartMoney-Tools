/**
 * routeMetadata — single source of truth for the <title> and
 * <meta name="description"> of every indexable route on SmartMoneyTools.
 *
 * Consumed by:
 *   - <RouteMeta>  (global, renders <title> + description via React Helmet)
 *   - <PageSeo>    (renders OG / Twitter / canonical / robots using the same
 *                  title + description so social cards always match the page)
 *   - tools/prerender.js (reads Helmet output to build the static <head>)
 *
 * Rules:
 *   - titles are unique per route and under 60 characters
 *   - descriptions are unique per route and under 160 characters
 */
const routeMetadata = {
  '/': {
    title: 'Free Financial Calculators | SmartMoneyTools',
    description:
      'Free UK and US financial calculators for salary, tax, mortgages, pensions, savings and retirement planning.',
  },
  '/uk-salary-calculator': {
    title: 'UK Salary Calculator 2026/27 | SmartMoneyTools',
    description:
      'Calculate your UK take-home pay, income tax, National Insurance, student loan repayments and pension contributions for 2026/27.',
  },
  '/us-salary-calculator': {
    title: 'US Salary Calculator 2026 | SmartMoneyTools',
    description:
      'Calculate your US federal income tax, FICA taxes, and take-home pay for 2026. Includes standard deduction and tax bracket calculations.',
  },
  '/us-retirement-calculator': {
    title: 'US Retirement Calculator | SmartMoneyTools',
    description:
      'Plan your US retirement with Social Security, 401(k), and IRA projections. Calculate retirement income and savings needs.',
  },
  '/compound-interest': {
    title: 'Compound Interest Calculator | SmartMoneyTools',
    description:
      'Calculate compound interest on savings and investments. See how regular deposits and interest rates grow your money over time.',
  },
  '/mortgage': {
    title: 'UK Mortgage Repayment Calculator | SmartMoneyTools',
    description:
      'Free UK mortgage calculator. Estimate your monthly mortgage payment, deposit, loan-to-value, total interest and total repaid, with optional Council Tax, buildings insurance and leasehold costs shown separately.',
  },
  '/pensions-calculator': {
    title: 'Pensions Calculator | SmartMoneyTools',
    description:
      'Project your pension savings and retirement income. Calculate contributions, investment growth, and withdrawal strategies.',
  },
  '/budget-planner': {
    title: 'Budget Planner | SmartMoneyTools',
    description:
      'Create and manage your monthly budget. Track income, expenses, and savings goals. See where your money goes each month.',
  },
  '/self-employed-tax-calculator': {
    title: 'Self-Employed Tax Calculator UK | SmartMoneyTools',
    description:
      'Calculate your self-employed tax, National Insurance, and profit allowance. Includes sole trader and partnership calculations.',
  },
  '/debt-snowball-calculator': {
    title: 'Debt Snowball Calculator | SmartMoneyTools',
    description:
      'Plan your debt repayment using the snowball method. Calculate payoff timelines and interest saved by paying off debts strategically.',
  },
  '/savings-goal-calculator': {
    title: 'Savings Goal Calculator | SmartMoneyTools',
    description:
      'Calculate how much you need to save to reach your financial goals. See how regular deposits and interest grow your savings.',
  },
  '/about': {
    title: 'About SmartMoneyTools | Independent Financial Publisher',
    description:
      'Learn about SmartMoneyTools, our mission to provide transparent financial calculators, and how we verify statutory data.',
  },
  '/about/team': {
    title: 'Our Team | SmartMoneyTools',
    description:
      'Meet the team behind SmartMoneyTools. Each calculator and guide is written and maintained by a named author with a published byline and bio.',
  },
  '/contact': {
    title: 'Contact SmartMoneyTools | Report Errors & Feedback',
    description:
      'Contact SmartMoneyTools with questions, error reports, or feedback. Email support@smartmoney-tools.com or use our contact form.',
  },
  '/faq': {
    title: 'Frequently Asked Questions | SmartMoneyTools',
    description:
      'Find answers to common questions about SmartMoneyTools calculators, data accuracy, privacy, and how to use our financial tools.',
  },
  '/privacy': {
    title: 'Privacy Policy | SmartMoneyTools',
    description:
      'Learn how SmartMoneyTools collects, uses, and protects your personal data. Our privacy policy explains your rights and choices.',
  },
  '/terms': {
    title: 'Terms of Use | SmartMoneyTools',
    description:
      'Read the terms of use for SmartMoneyTools. Understand our disclaimers, limitations, and your rights as a user.',
  },
  '/financial-disclaimer': {
    title: 'Financial Disclaimer | SmartMoneyTools',
    description:
      'Important disclaimer: SmartMoneyTools provides educational estimates only, not financial advice. Read our full disclaimer.',
  },
  '/cookie-policy': {
    title: 'Cookie Policy | SmartMoneyTools',
    description:
      'Learn about the cookies SmartMoneyTools uses. Understand your cookie choices and how to manage your consent preferences.',
  },
  '/guides': {
    title: 'Financial Guides & Resources | SmartMoneyTools',
    description:
      'Browse free UK financial guides covering salary, tax, pensions, savings, debt and mortgages — clear, actionable and regularly updated.',
  },
  // Salary & Income Guides
  '/guides/calculate-take-home-pay': {
    title: 'How to Calculate Your UK Take-Home Pay | SmartMoneyTools',
    description:
      'Understand gross-to-net conversion, tax codes and every payslip deduction, compare take-home across salaries, and see the decisions that move the number.',
  },
  '/guides/student-loan-repayments': {
    title: 'Student Loan Repayments Guide | SmartMoneyTools',
    description:
      'Understand thresholds, repayment rates, and how student loans function as a graduate tax.',
  },
  '/guides/self-employment-income': {
    title: 'Self-Employment Income Guide | SmartMoneyTools',
    description:
      'Navigate turnover, profit, and tax obligations as a sole trader in the UK.',
  },
  '/guides/freelance-income': {
    title: 'Freelance Income & Cash Flow Guide | SmartMoneyTools',
    description:
      'Manage irregular income, forecast tax, and build financial stability as a UK freelancer.',
  },
  '/guides/side-hustle-tax': {
    title: 'Side Hustle Tax Guide | SmartMoneyTools',
    description:
      'Understand the UK Trading Allowance, reporting requirements, and tax on side income.',
  },
  // Tax Planning Guides
  '/guides/uk-income-tax': {
    title: 'Comprehensive UK Income Tax Guide | SmartMoneyTools',
    description:
      'Master tax bands, personal allowances, and relief strategies to optimize your net income.',
  },
  '/guides/self-employed-tax-planning': {
    title: 'Self-Employed Tax Planning Basics | SmartMoneyTools',
    description:
      'Navigate Self Assessment, allowable expenses, and VAT with this survival guide for sole traders.',
  },
  '/guides/national-insurance': {
    title: 'National Insurance: Comprehensive Guide | SmartMoneyTools',
    description:
      'Understand NI contributions, thresholds, and how they secure your state benefits.',
  },
  '/guides/tax-planning': {
    title: 'Advanced Tax Planning Guide | SmartMoneyTools',
    description:
      'Legal strategies to reduce your tax bill through pensions, ISAs, and allowances.',
  },
  '/guides/marriage-allowance': {
    title: 'Marriage Allowance Guide | SmartMoneyTools',
    description:
      'Eligibility rules and claiming process to reduce your household tax bill.',
  },
  // Pensions & Retirement Guides
  '/guides/salary-sacrifice-vs-normal-pension': {
    title: 'Salary Sacrifice vs Normal Pension | SmartMoneyTools',
    description:
      'Maximize take-home pay and pension growth by understanding how contribution methods differ.',
  },
  '/guides/workplace-pensions': {
    title: 'Workplace Pensions & Auto-Enrolment | SmartMoneyTools',
    description:
      'Understand employer contributions, tax relief, and how to maximize your workplace pension.',
  },
  '/guides/pension-contributions': {
    title: 'Optimising Pension Contributions and Tax Relief | SmartMoneyTools',
    description:
      'Decide how much to pay into your pension, see how tax relief and NI change your take-home pay, and navigate the Annual Allowance and the £100,000 trap.',
  },
  '/guides/pension-planning': {
    title: 'Pension Planning & Retirement Target | SmartMoneyTools',
    description:
      'Calculate your retirement income needs and plan your drawdown strategy.',
  },
  '/guides/early-retirement': {
    title: 'Early Retirement Planning Guide | SmartMoneyTools',
    description:
      'Strategies for retiring before State Pension age and bridging the income gap.',
  },
  // Savings & Investments Guides
  '/guides/compound-interest-monthly-deposits': {
    title: 'Compound Interest: How Monthly Deposits Grow Your Money | SmartMoneyTools',
    description:
      'Understand compound interest and the Rule of 72, then see in concrete numbers how regular monthly deposits build wealth over time.',
  },
  '/guides/savings-goals': {
    title: 'Setting and Reaching Your Savings Goals | SmartMoneyTools',
    description:
      'Turn a vague intention into a monthly number you can hit: size the target, stress-test it against your budget, and automate the habit.',
  },
  '/guides/emergency-fund': {
    title: 'Building an Emergency Fund: How Much & Where to Keep It | SmartMoneyTools',
    description:
      'Work out exactly how large your UK emergency fund should be, build it in the right order, and keep it where it stays accessible and beats inflation.',
  },
  '/guides/high-interest-savings': {
    title: 'Maximizing High-Interest Savings | SmartMoneyTools',
    description:
      'Compare accounts and secure the best rates to combat inflation.',
  },
  '/guides/tax-free-savings': {
    title: 'Tax-Free Savings (ISAs) Guide | SmartMoneyTools',
    description:
      'Shield your wealth using ISAs, Lifetime ISAs, and Premium Bonds.',
  },
  // Debt Management Guides
  '/guides/compare-loan-repayments': {
    title: 'Compare Loan Repayments Before Borrowing | SmartMoneyTools',
    description:
      'Look past the monthly payment illusion and calculate the true cost of credit.',
  },
  '/guides/debt-repayment': {
    title: 'Debt Repayment Strategies: Snowball vs Avalanche | SmartMoneyTools',
    description:
      'Build a single structured plan to become debt-free: compare the snowball and avalanche methods, see the trade-off in numbers, and know when to seek free help.',
  },
  '/guides/credit-card-debt': {
    title: 'Escaping Credit Card Debt | SmartMoneyTools',
    description:
      'Understand interest mechanics, balance transfers, and how to break the debt spiral.',
  },
  '/guides/personal-loan': {
    title: 'Personal Loans Explained | SmartMoneyTools',
    description:
      'Navigate interest rates, terms, and when unsecured borrowing makes sense.',
  },
  '/guides/debt-consolidation': {
    title: 'Debt Consolidation Guide | SmartMoneyTools',
    description:
      'When to combine debts, how it works, and the traps to avoid.',
  },
  // Mortgage & Housing Guides
  '/guides/mortgage-overpayments': {
    title: 'Mortgage Overpayments Interest Savings | SmartMoneyTools',
    description:
      'Discover how overpaying your mortgage strips years off your term and saves tens of thousands.',
  },
  '/guides/mortgage-comprehensive': {
    title: 'Comprehensive Mortgage Guide | SmartMoneyTools',
    description:
      'Understand mortgage types, calculate true affordability, and navigate interest rates.',
  },
  '/guides/mortgage-affordability-first-time-buyers': {
    title: 'First-Time Buyer Mortgage Affordability | SmartMoneyTools',
    description:
      'How much can you borrow? Understand UK mortgage affordability rules, income multiples, deposit requirements and lender stress tests.',
  },
  '/guides/first-time-buyer': {
    title: "First-Time Buyer's Guide: Process, Costs and Budget | SmartMoneyTools",
    description:
      'The full UK first-time buyer journey: Agreements in Principle, how much you can borrow, every upfront and ongoing cost, and the process from offer to completion.',
  },
  // Legacy fallback guide
  '/hubs/mortgages': {
    title: 'Mortgages & Home Buying Hub | SmartMoneyTools',
    description:
      'UK mortgages and home buying explained: how much you can borrow, the real upfront costs of buying, choosing a mortgage and whether to overpay. Calculators and guides by question.',
  },
  '/hubs/savings': {
    title: 'Savings & Compound Interest Hub | SmartMoneyTools',
    description:
      'How compound interest works, setting savings goals you will stick to, building an emergency fund and choosing tax-free accounts. Calculators and guides grouped by question.',
  },
  '/hubs/debt': {
    title: 'Debt & Repayment Hub | SmartMoneyTools',
    description:
      'Clear paths out of debt: snowball vs avalanche, escaping credit card debt, comparing loans and when consolidation helps. Calculators and guides grouped by question.',
  },
  '/hubs/uk-salary-tax': {
    title: 'UK Salary & Tax Hub | SmartMoneyTools',
    description:
      'Understand your UK payslip and keep more of it: take-home pay, income tax, National Insurance, student loans and legal tax planning for 2026/27. Calculators and guides by question.',
  },
  '/hubs/us-salary-tax': {
    title: 'US Salary & Tax Hub | SmartMoneyTools',
    description:
      'Understand your US paycheck and plan retirement: federal income tax brackets, FICA, standard deduction, 401(k) and IRA planning. Calculators and guides by question.',
  },
  '/hubs/pensions-retirement': {
    title: 'Pensions & Retirement Hub | SmartMoneyTools',
    description:
      'Build and access your UK pension: workplace pensions, tax relief, salary sacrifice, the Annual Allowance and early retirement. Calculators and guides grouped by question.',
  },
  '/hubs/self-employment': {
    title: 'Self-Employment Hub | SmartMoneyTools',
    description:
      'Sole-trader tax and income explained: profit, Self Assessment, allowable expenses, irregular freelance income and side-hustle tax. Calculators and guides grouped by question.',
  },
  '/author/shaun-da-silva': {
    title: 'Shaun Da Silva \u2014 Financial Consultant | SmartMoneyTools',
    description:
      'Shaun Da Silva, Financial Consultant with over 20 years in the financial sector, writes and maintains the SmartMoneyTools calculators and guides.',
  },
  '/editorial-policy': {
    title: 'Editorial Policy | SmartMoneyTools',
    description:
      "Learn about SmartMoneyTools' editorial standards, data verification process, and commitment to accuracy and transparency.",
  },
  '/calculation-methodology': {
    title: 'Calculation Methodology | SmartMoneyTools',
    description:
      'Understand how SmartMoneyTools calculators work. Learn about our formulas, assumptions, data sources, and calculation methods.',
  },
  '/corrections-policy': {
    title: 'Corrections Policy | SmartMoneyTools',
    description:
      'Learn how SmartMoneyTools handles corrections and updates. Report errors and see how we maintain accuracy and transparency.',
  },
  '/advertising-disclosure': {
    title: 'Advertising Disclosure | SmartMoneyTools',
    description:
      'Learn how SmartMoneyTools is funded through advertising. Understand how ads work and that they don\u2019t influence our calculators.',
  },
  '/accessibility': {
    title: 'Accessibility | SmartMoneyTools',
    description:
      'SmartMoneyTools is committed to web accessibility. Learn about our accessibility features and how to report accessibility issues.',
  },
};

export default routeMetadata;
