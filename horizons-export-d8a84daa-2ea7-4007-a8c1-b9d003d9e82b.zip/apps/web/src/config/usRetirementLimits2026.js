/**
 * usRetirementLimits2026.js — 2026 IRS retirement contribution limits.
 * Thin wrapper over the central `statutoryData.js`.
 */
import { US } from './statutoryData.js';

export const US_RETIREMENT_LIMITS_2026 = {
  taxYear: US.taxYear,
  lastReviewed: '2026-11-02',

  // 401(k), 403(b), most 457 plans — employee deferral
  definedContributionLimit: US.retirement.definedContributionLimit,

  // Standard Catch-up (Age 50+)
  catchUpLimit: US.retirement.catchUpLimit,

  // Super Catch-up (Age 60–63) — SECURE 2.0 Act
  superCatchUpLimit: US.retirement.superCatchUpLimit,

  // Total contribution limit (Employee + Employer) — 415(c) annual additions
  totalContributionLimit: US.retirement.totalContributionLimit,
  totalContributionLimitWithCatchUp: US.retirement.totalContributionLimitWithCatchUp,
  totalContributionLimitWithSuperCatchUp: US.retirement.totalContributionLimitWithSuperCatchUp,

  // IRAs
  iraContributionLimit: US.retirement.iraContributionLimit,
  iraCatchUpLimit: US.retirement.iraCatchUpLimit,

  // Social Security
  socialSecurityWageBase: US.fica.socialSecurityWageBase,

  // Compensation limit for calculating contributions — 401(a)(17)
  annualCompensationLimit: US.retirement.annualCompensationLimit,

  sources: [
    US.sources.retirementNews,
    US.sources.retirementLimits,
    US.sources.fica,
  ],
};
