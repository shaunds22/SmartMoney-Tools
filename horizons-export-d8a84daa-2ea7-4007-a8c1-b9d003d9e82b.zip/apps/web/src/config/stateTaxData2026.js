// State tax modules architecture for all 50 states + DC
// Utilizing typical projected structures for 2026
const NO_INCOME_TAX = { type: 'none', rate: 0 };
const FLAT_TAX = (rate) => ({ type: 'flat', rate });
const PROGRESSIVE = (standardDeduction) => ({ type: 'progressive', standardDeduction, defaultEffectiveRate: 0.045 }); // Simplified progressive simulation

export const STATE_TAX_DATA_2026 = {
  AK: NO_INCOME_TAX,
  FL: NO_INCOME_TAX,
  NV: NO_INCOME_TAX,
  NH: NO_INCOME_TAX,
  SD: NO_INCOME_TAX,
  TN: NO_INCOME_TAX,
  TX: NO_INCOME_TAX,
  WA: NO_INCOME_TAX,
  WY: NO_INCOME_TAX,
  
  AZ: FLAT_TAX(0.025),
  CO: FLAT_TAX(0.0495),
  ID: FLAT_TAX(0.058),
  IL: FLAT_TAX(0.0495),
  IN: FLAT_TAX(0.0305),
  KY: FLAT_TAX(0.04),
  MI: FLAT_TAX(0.0305),
  NC: FLAT_TAX(0.045),
  PA: FLAT_TAX(0.0307),
  UT: FLAT_TAX(0.058),

  AL: PROGRESSIVE(3000),
  AR: PROGRESSIVE(2270),
  CA: PROGRESSIVE(5363),
  CT: FLAT_TAX(0.05), // Currently transitioning, treating as flat/simplified
  DC: PROGRESSIVE(4500),
  DE: PROGRESSIVE(3250),
  GA: FLAT_TAX(0.0549), // Transitioned to flat
  HI: PROGRESSIVE(2200),
  IA: FLAT_TAX(0.057),
  KS: FLAT_TAX(0.057),
  LA: PROGRESSIVE(4500),
  MA: PROGRESSIVE(4400),
  MD: PROGRESSIVE(3250),
  ME: FLAT_TAX(0.05),
  MN: FLAT_TAX(0.0425),
  MO: PROGRESSIVE(13800),
  MS: PROGRESSIVE(13800),
  MT: PROGRESSIVE(4500),
  ND: PROGRESSIVE(13800),
  NE: PROGRESSIVE(3500),
  NJ: PROGRESSIVE(3000),
  NM: PROGRESSIVE(13800),
  NY: PROGRESSIVE(1000),
  OH: PROGRESSIVE(13800),
  OK: PROGRESSIVE(13800),
  OR: PROGRESSIVE(13800),
  RI: PROGRESSIVE(2605),
  SC: PROGRESSIVE(13800),
  VA: PROGRESSIVE(13800),
  VT: PROGRESSIVE(13800),
  WI: PROGRESSIVE(6500),
  WV: PROGRESSIVE(4500)
};

export const STATE_OPTIONS = Object.keys(STATE_TAX_DATA_2026).map(state => ({
  value: state,
  label: state
}));