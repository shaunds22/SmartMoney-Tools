/**
 * federalWithholding2026.js — 2026 US federal income tax brackets and
 * standard deductions. Thin wrapper over the central `statutoryData.js`.
 *
 * Brackets use `over` = lower bound of each bracket (taxable income after
 * the standard deduction). Values per IRS Rev. Proc. 2025-32.
 */
import { US } from './statutoryData.js';

export const FEDERAL_BRACKETS_2026 = US.federalBrackets;

export const FEDERAL_METADATA = {
  taxYear: US.taxYear,
  lastReviewed: '2026-11-02',
  source: US.sources.federalBrackets,
};
