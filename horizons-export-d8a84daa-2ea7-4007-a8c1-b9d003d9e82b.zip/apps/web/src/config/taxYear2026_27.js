/**
 * taxYear2026_27.js — UK statutory values for the 2026/27 tax year.
 *
 * Thin wrapper over the central source of truth in `statutoryData.js`.
 * Calculators import `taxYear2026_27` and access the fields below; the
 * canonical values, source URLs and effective tax year live in one place.
 */
import { UK } from './statutoryData.js';

export const taxYear2026_27 = {
  taxYear: UK.taxYear,
  lastReviewed: '2026-11-02',

  personalAllowance: UK.personalAllowance,

  incomeTax: UK.incomeTax,

  nationalInsurance: UK.nationalInsurance,

  studentLoan: UK.studentLoan,

  statePension: UK.statePension,

  pension: UK.pension,

  isa: UK.isa,

  vatThreshold: UK.vatThreshold,

  sources: UK.sources,
};
