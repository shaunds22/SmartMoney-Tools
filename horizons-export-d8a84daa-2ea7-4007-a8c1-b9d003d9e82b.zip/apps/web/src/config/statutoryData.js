/**
 * statutoryData.js — CENTRAL SOURCE OF TRUTH for all statutory financial
 * values used across SmartMoneyTools.
 *
 * Every UK and US statutory figure (tax bands, thresholds, allowances,
 * contribution limits, National Insurance, State Pension, FICA, retirement
 * limits) is declared ONCE here with its official source URL and effective
 * tax year. Calculators, guides and supporting copy should import from here
 * (directly or via the thin wrapper configs) so values never drift between
 * the formula, the worked examples and the explanatory text.
 *
 * All values below were independently verified against official primary
 * sources on 2026-11-02. See the `sources` blocks for the exact URLs.
 *
 *   UK tax year:  2026/27  (6 April 2026 – 5 April 2027)
 *   US tax year:  2026     (calendar year 2026)
 *
 * IMPORTANT: These are statutory figures only — not financial advice.
 * Non-statutory assumptions (growth rates, inflation, withdrawal rates) are
 * labelled separately on each calculator and are NOT held here.
 */

export const AUDIT = {
  lastReviewed: '2026-11-02',
  ukTaxYear: '2026/27',
  usTaxYear: '2026',
};

/* ------------------------------------------------------------------ UK */

export const UK = {
  taxYear: '2026/27',
  taxYearLabel: '2026/27',

  personalAllowance: {
    base: 12570, // frozen at £12,570
    reductionThreshold: 100000, // tapered above £100,000 adjusted net income
    reductionRate: 0.5, // £1 lost for every £2 over £100,000
  },

  // Income Tax — England, Wales, Northern Ireland (rest of UK)
  // Band limits are expressed RELATIVE to the Personal Allowance (i.e. the
  // taxable amount above £12,570), matching the existing calculator shape.
  incomeTax: {
    englandWalesNI: [
      { name: 'Basic Rate', rate: 0.20, threshold: 0, limit: 37700 }, // £12,571–£50,270
      { name: 'Higher Rate', rate: 0.40, threshold: 37700, limit: 125140 }, // £50,271–£125,140
      { name: 'Additional Rate', rate: 0.45, threshold: 125140, limit: Infinity }, // over £125,140
    ],
    // Scotland 2026/27 — thresholds relative to PA. Absolute bands:
    // Starter 19% £12,571–£16,537; Basic 20% £16,538–£29,526;
    // Intermediate 21% £29,527–£43,662; Higher 42% £43,663–£75,000;
    // Advanced 45% £75,001–£125,140; Top 48% over £125,140.
    scotland: [
      { name: 'Starter Rate', rate: 0.19, threshold: 0, limit: 3967 },
      { name: 'Basic Rate', rate: 0.20, threshold: 3967, limit: 16956 },
      { name: 'Intermediate Rate', rate: 0.21, threshold: 16956, limit: 31092 },
      { name: 'Higher Rate', rate: 0.42, threshold: 31092, limit: 62430 },
      { name: 'Advanced Rate', rate: 0.45, threshold: 62430, limit: 125140 },
      { name: 'Top Rate', rate: 0.48, threshold: 125140, limit: Infinity },
    ],
  },

  nationalInsurance: {
    employee: {
      primaryThreshold: 12570, // annual Primary Threshold
      upperEarningsLimit: 50270, // annual UEL
      mainRate: 0.08, // 8% between PT and UEL
      upperRate: 0.02, // 2% above UEL
    },
    employer: {
      // Raised to 15% and Secondary Threshold lowered to £5,000 from 6 April 2025;
      // unchanged for 2026/27.
      secondaryThreshold: 5000,
      mainRate: 0.15,
    },
    class4: {
      // Self-employed NI on profits
      lowerProfitsLimit: 12570,
      upperProfitsLimit: 50270,
      mainRate: 0.06, // 6% between LPL and UPL
      upperRate: 0.02, // 2% above UPL
    },
  },

  studentLoan: {
    plan1: { threshold: 26900, rate: 0.09 },
    plan2: { threshold: 29385, rate: 0.09 },
    plan4: { threshold: 33795, rate: 0.09 }, // Scotland
    plan5: { threshold: 25000, rate: 0.09 },
    postgrad: { threshold: 21000, rate: 0.06 },
  },

  statePension: {
    weekly: 241.30, // full new State Pension, 2026/27
    annual: 12547.60, // £241.30 × 52
    qualifyingYears: 35,
  },

  pension: {
    annualAllowance: 60000,
    moneyPurchaseAnnualAllowance: 10000,
    taperedAnnualAllowanceThreshold: 260000, // adjusted income above which taper may apply
    qualifyingEarningsLower: 6240, // auto-enrolment lower limit
    qualifyingEarningsUpper: 50270, // auto-enrolment upper limit
    autoEnrolmentTrigger: 10000,
    taxFreeLumpSumCap: 268275, // Lump Sum Allowance
  },

  isa: {
    annualLimit: 20000,
    lifetimeIsaLimit: 4000,
  },

  vatThreshold: 90000, // VAT registration threshold 2026/27

  sources: {
    personalAllowance: 'https://www.gov.uk/income-tax-rates',
    incomeTax: 'https://www.gov.uk/income-tax-rates',
    scottishIncomeTax: 'https://www.gov.uk/scottish-income-tax/2025-to-2026-tax-year',
    nationalInsurance: 'https://www.gov.uk/national-insurance-rates-letters',
    employerNi: 'https://www.gov.uk/guidance/rates-and-thresholds-for-employers-2026-to-2027',
    studentLoan: 'https://www.gov.uk/repaying-your-student-loan/what-you-pay',
    statePension: 'https://www.gov.uk/new-state-pension/what-youll-get',
    pensionAllowances: 'https://www.gov.uk/government/publications/budget-2026-overview-of-tax-legislation-and-rates-ootlar/annex-a-rates-and-allowances',
    autoEnrolment: 'https://www.thepensionsregulator.gov.uk/en/employers/new-employers/im-an-employer-who-has-to-provide-a-pension/declare-your-compliance/ongoing-duties-for-employers/earnings-thresholds',
    isa: 'https://www.gov.uk/individual-savings-accounts/how-isas-work',
    selfEmployedNi: 'https://www.gov.uk/self-employed-national-insurance-rates',
  },
};

/* ------------------------------------------------------------------ US */

export const US = {
  taxYear: 2026,

  // 2026 federal income tax brackets (Rev. Proc. 2025-32). `over` = lower
  // bound of each bracket (taxable income). Standard deduction per status.
  federalBrackets: {
    single: {
      standardDeduction: 16100,
      brackets: [
        { rate: 0.10, over: 0 },
        { rate: 0.12, over: 12400 },
        { rate: 0.22, over: 50400 },
        { rate: 0.24, over: 105700 },
        { rate: 0.32, over: 201775 },
        { rate: 0.35, over: 256225 },
        { rate: 0.37, over: 640600 },
      ],
    },
    marriedFilingJointly: {
      standardDeduction: 32200,
      brackets: [
        { rate: 0.10, over: 0 },
        { rate: 0.12, over: 24800 },
        { rate: 0.22, over: 100800 },
        { rate: 0.24, over: 211400 },
        { rate: 0.32, over: 403550 },
        { rate: 0.35, over: 512450 },
        { rate: 0.37, over: 768700 },
      ],
    },
    marriedFilingSeparately: {
      standardDeduction: 16100,
      brackets: [
        { rate: 0.10, over: 0 },
        { rate: 0.12, over: 12400 },
        { rate: 0.22, over: 50400 },
        { rate: 0.24, over: 105700 },
        { rate: 0.32, over: 201775 },
        { rate: 0.35, over: 256225 },
        { rate: 0.37, over: 384350 },
      ],
    },
    headOfHousehold: {
      standardDeduction: 24150,
      brackets: [
        { rate: 0.10, over: 0 },
        { rate: 0.12, over: 17700 },
        { rate: 0.22, over: 67450 },
        { rate: 0.24, over: 105700 },
        { rate: 0.32, over: 201750 },
        { rate: 0.35, over: 256200 },
        { rate: 0.37, over: 640600 },
      ],
    },
    qualifyingWidow: {
      standardDeduction: 32200,
      brackets: [
        { rate: 0.10, over: 0 },
        { rate: 0.12, over: 24800 },
        { rate: 0.22, over: 100800 },
        { rate: 0.24, over: 211400 },
        { rate: 0.32, over: 403550 },
        { rate: 0.35, over: 512450 },
        { rate: 0.37, over: 768700 },
      ],
    },
  },

  fica: {
    socialSecurityRate: 0.062, // employee + employer each
    socialSecurityWageBase: 184500,
    medicareRate: 0.0145, // employee + employer each, no cap
    additionalMedicareRate: 0.009, // employee only
    additionalMedicareThresholds: {
      single: 200000,
      marriedFilingJointly: 250000,
      marriedFilingSeparately: 125000,
      headOfHousehold: 200000,
      qualifyingWidow: 200000,
    },
  },

  retirement: {
    definedContributionLimit: 24500, // 401(k)/403(b)/457 employee deferral
    catchUpLimit: 8000, // age 50+ standard catch-up
    superCatchUpLimit: 11250, // SECURE 2.0 age 60–63 super catch-up
    totalContributionLimit: 72000, // 415(c) annual additions (employee + employer)
    totalContributionLimitWithCatchUp: 80000, // 415(c) + 50+ catch-up
    totalContributionLimitWithSuperCatchUp: 83250, // 415(c) + 60–63 super catch-up
    iraContributionLimit: 7500,
    iraCatchUpLimit: 1100, // age 50+
    annualCompensationLimit: 350000, // 401(a)(17)
    hceThreshold: 160000, // highly compensated employee
  },

  sources: {
    federalBrackets: 'https://www.irs.gov/filing/federal-income-tax-rates-and-brackets',
    standardDeduction: 'https://www.irs.gov/newsroom/irs-provides-tax-inflation-adjustments-for-tax-year-2026',
    fica: 'https://www.ssa.gov/oact/cola/cbb.html',
    medicare: 'https://www.irs.gov/taxtopics/tc751',
    retirementLimits: 'https://www.irs.gov/retirement-plans/cola-increases-for-dollar-limitations-on-benefits-and-contributions',
    retirementNews: 'https://www.irs.gov/newsroom/401k-limit-increases-to-24500-for-2026-ira-limit-increases-to-7500',
    pub15t: 'https://www.irs.gov/pub/irs-pdf/p15t.pdf',
  },
};

export default { AUDIT, UK, US };
