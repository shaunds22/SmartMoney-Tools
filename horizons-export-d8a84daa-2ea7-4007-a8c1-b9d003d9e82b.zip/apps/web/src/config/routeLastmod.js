/**
 * routeLastmod — per-route "Last reviewed" dates used as <lastmod> in the
 * generated sitemap.xml.
 *
 * Each value is the genuine "Last reviewed" date shown on that page:
 *   - guides: the `lastUpdated` field rendered by GuideLayout
 *   - calculators: the "Last reviewed" date in the page's accuracy statement
 *   - hubs / standard pages: the 2026-11-02 site-wide statutory-data audit
 *
 * Routes absent from this map fall back to DEFAULT_LASTMOD in the sitemap
 * generator. Dates are ISO yyyy-mm-dd.
 */
const routeLastmod = {
  '/': '2026-11-02',

  // Calculators
  '/uk-salary-calculator': '2026-11-02',
  '/us-salary-calculator': '2026-11-02',
  '/us-retirement-calculator': '2026-11-02',
  '/compound-interest': '2026-09-11',
  '/mortgage': '2026-11-02',
  '/pensions-calculator': '2026-09-11',
  '/budget-planner': '2026-09-11',
  '/self-employed-tax-calculator': '2026-09-11',
  '/debt-snowball-calculator': '2026-09-11',
  '/savings-goal-calculator': '2026-09-11',

  // Standard pages
  '/about': '2026-11-02',
  '/about/team': '2026-11-02',
  '/contact': '2026-11-02',
  '/faq': '2026-11-02',
  '/privacy': '2026-11-02',
  '/terms': '2026-11-02',
  '/financial-disclaimer': '2026-11-02',
  '/cookie-policy': '2026-11-02',
  '/guides': '2026-11-02',
  '/editorial-policy': '2026-11-02',
  '/calculation-methodology': '2026-11-02',
  '/corrections-policy': '2026-11-02',
  '/advertising-disclosure': '2026-11-02',
  '/accessibility': '2026-11-02',
  '/author/shaun-da-silva': '2026-11-02',

  // Topic hubs
  '/hubs/mortgages': '2026-11-02',
  '/hubs/savings': '2026-11-02',
  '/hubs/debt': '2026-11-02',
  '/hubs/uk-salary-tax': '2026-11-02',
  '/hubs/us-salary-tax': '2026-11-02',
  '/hubs/pensions-retirement': '2026-11-02',
  '/hubs/self-employment': '2026-11-02',

  // Salary & Income guides
  '/guides/calculate-take-home-pay': '2026-11-02',
  '/guides/student-loan-repayments': '2026-09-11',
  '/guides/self-employment-income': '2026-11-02',
  '/guides/freelance-income': '2026-11-02',
  '/guides/side-hustle-tax': '2026-11-02',

  // Tax Planning guides
  '/guides/uk-income-tax': '2026-11-02',
  '/guides/self-employed-tax-planning': '2026-09-11',
  '/guides/national-insurance': '2026-11-02',
  '/guides/tax-planning': '2026-11-02',
  '/guides/marriage-allowance': '2026-11-02',

  // Pensions & Retirement guides
  '/guides/salary-sacrifice-vs-normal-pension': '2026-09-11',
  '/guides/workplace-pensions': '2026-11-02',
  '/guides/pension-contributions': '2026-11-02',
  '/guides/pension-planning': '2026-11-02',
  '/guides/early-retirement': '2026-11-02',

  // Savings & Investments guides
  '/guides/compound-interest-monthly-deposits': '2026-11-02',
  '/guides/savings-goals': '2026-11-02',
  '/guides/emergency-fund': '2026-11-02',
  '/guides/high-interest-savings': '2026-11-02',
  '/guides/tax-free-savings': '2026-11-02',

  // Debt Management guides
  '/guides/compare-loan-repayments': '2026-09-11',
  '/guides/debt-repayment': '2026-11-02',
  '/guides/credit-card-debt': '2026-11-02',
  '/guides/personal-loan': '2026-11-02',
  '/guides/debt-consolidation': '2026-11-02',

  // Mortgage & Housing guides
  '/guides/mortgage-overpayments': '2026-09-11',
  '/guides/mortgage-comprehensive': '2026-11-02',
  '/guides/first-time-buyer': '2026-11-02',
  '/guides/mortgage-affordability-first-time-buyers': '2026-09-03',
};

export default routeLastmod;
