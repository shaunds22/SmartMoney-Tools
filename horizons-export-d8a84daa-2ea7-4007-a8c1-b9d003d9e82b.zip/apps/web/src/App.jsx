import React from 'react';
import { Route, Routes, BrowserRouter as Router, useLocation, Navigate } from 'react-router-dom';
import ScrollToTop from './components/ScrollToTop.jsx';
import CanonicalLink from './components/CanonicalLink.jsx';
import RouteMeta from './components/RouteMeta.jsx';
import HomePage from './pages/HomePage.jsx';
import CompoundInterestPage from './pages/CompoundInterestPage.jsx';
import MortgagePage from './pages/MortgagePage.jsx';
import UKSalaryCalculator from './pages/UKSalaryCalculator.jsx';
import USsalaryCalculatorPage from './pages/USsalaryCalculatorPage.jsx';
import USRetirementCalculatorPage from './pages/USRetirementCalculatorPage.jsx';
import PensionsCalculatorPage from './pages/PensionsCalculatorPage.jsx';
import BudgetPlannerPage from './pages/BudgetPlannerPage.jsx';
import SelfEmployedTaxCalculatorPage from './pages/SelfEmployedTaxCalculatorPage.jsx';
import DebtSnowballCalculatorPage from './pages/DebtSnowballCalculatorPage.jsx';
import SavingsGoalCalculatorPage from './pages/SavingsGoalCalculatorPage.jsx';
import AboutPage from './pages/AboutPage.jsx';
import ContactPage from './pages/ContactPage.jsx';
import FAQPage from './pages/FAQPage.jsx';
import PrivacyPage from './pages/PrivacyPage.jsx';
import TermsPage from './pages/TermsPage.jsx';
import FinancialDisclaimerPage from './pages/FinancialDisclaimerPage.jsx';
import CookiePolicyPage from './pages/CookiePolicyPage.jsx';
import GuidesIndexPage from './pages/GuidesIndexPage.jsx';
import AuthorProfilePage from './pages/AuthorProfilePage.jsx';
import TeamPage from './pages/TeamPage.jsx';

// Topic hubs
import MortgagesHubPage from './pages/hubs/MortgagesHubPage.jsx';
import SavingsHubPage from './pages/hubs/SavingsHubPage.jsx';
import DebtHubPage from './pages/hubs/DebtHubPage.jsx';
import UKSalaryTaxHubPage from './pages/hubs/UKSalaryTaxHubPage.jsx';
import USSalaryTaxHubPage from './pages/hubs/USSalaryTaxHubPage.jsx';
import PensionsRetirementHubPage from './pages/hubs/PensionsRetirementHubPage.jsx';
import SelfEmploymentHubPage from './pages/hubs/SelfEmploymentHubPage.jsx';

import EditorialPolicyPage from './pages/EditorialPolicyPage.jsx';
import Header from './components/Header.jsx';
import Footer from './components/Footer.jsx';

// Salary & Income
import SelfEmploymentIncomeGuidePage from './pages/guides/SelfEmploymentIncomeGuidePage.jsx';
import FreelanceIncomeGuidePage from './pages/guides/FreelanceIncomeGuidePage.jsx';
import SideHustleTaxGuidePage from './pages/guides/SideHustleTaxGuidePage.jsx';
import CalculateTakeHomePayGuidePage from './pages/guides/CalculateTakeHomePayGuidePage.jsx';
import StudentLoanRepaymentsGuidePage from './pages/guides/StudentLoanRepaymentsGuidePage.jsx';

// Tax Planning
import UKIncomeTaxComprehensiveGuidePage from './pages/guides/UKIncomeTaxComprehensiveGuidePage.jsx';
import NationalInsuranceComprehensiveGuidePage from './pages/guides/NationalInsuranceComprehensiveGuidePage.jsx';
import TaxPlanningComprehensiveGuidePage from './pages/guides/TaxPlanningComprehensiveGuidePage.jsx';
import MarriageAllowanceComprehensiveGuidePage from './pages/guides/MarriageAllowanceComprehensiveGuidePage.jsx';
import SelfEmployedTaxPlanningGuidePage from './pages/guides/SelfEmployedTaxPlanningGuidePage.jsx';

// Pensions & Retirement
import WorkplacePensionsComprehensiveGuidePage from './pages/guides/WorkplacePensionsComprehensiveGuidePage.jsx';
import PensionContributionsComprehensiveGuidePage from './pages/guides/PensionContributionsComprehensiveGuidePage.jsx';
import PensionPlanningComprehensiveGuidePage from './pages/guides/PensionPlanningComprehensiveGuidePage.jsx';
import EarlyRetirementComprehensiveGuidePage from './pages/guides/EarlyRetirementComprehensiveGuidePage.jsx';
import SalarySacrificeGuidePage from './pages/guides/SalarySacrificeGuidePage.jsx';

// Savings & Investments
import SavingsGoalsComprehensiveGuidePage from './pages/guides/SavingsGoalsComprehensiveGuidePage.jsx';
import EmergencyFundComprehensiveGuidePage from './pages/guides/EmergencyFundComprehensiveGuidePage.jsx';
import HighInterestSavingsComprehensiveGuidePage from './pages/guides/HighInterestSavingsComprehensiveGuidePage.jsx';
import TaxFreeSavingsComprehensiveGuidePage from './pages/guides/TaxFreeSavingsComprehensiveGuidePage.jsx';
import CompoundInterestMonthlyGuidePage from './pages/guides/CompoundInterestMonthlyGuidePage.jsx';

// Debt Management
import DebtRepaymentComprehensiveGuidePage from './pages/guides/DebtRepaymentComprehensiveGuidePage.jsx';
import CreditCardDebtComprehensiveGuidePage from './pages/guides/CreditCardDebtComprehensiveGuidePage.jsx';
import PersonalLoanComprehensiveGuidePage from './pages/guides/PersonalLoanComprehensiveGuidePage.jsx';
import DebtConsolidationComprehensiveGuidePage from './pages/guides/DebtConsolidationComprehensiveGuidePage.jsx';
import CompareLoanRepaymentsGuidePage from './pages/guides/CompareLoanRepaymentsGuidePage.jsx';

// Mortgage & Housing
import MortgageComprehensiveGuidePage from './pages/guides/MortgageComprehensiveGuidePage.jsx';
import FirstTimeBuyerComprehensiveGuidePage from './pages/guides/FirstTimeBuyerComprehensiveGuidePage.jsx';
import MortgageOverpaymentsGuidePage from './pages/guides/MortgageOverpaymentsGuidePage.jsx';
import MortgageAffordabilityFirstTimeBuyersGuidePage from './pages/guides/MortgageAffordabilityFirstTimeBuyersGuidePage.jsx';

import NotFound from './pages/NotFound.jsx';
import CalculationMethodologyPage from './pages/CalculationMethodologyPage.jsx';
import CorrectionsPolicy from './pages/CorrectionsPolicy.jsx';
import AdvertisingDisclosure from './pages/AdvertisingDisclosure.jsx';
import AccessibilityStatement from './pages/AccessibilityStatement.jsx';
import SeoAuditReportPage from './pages/SeoAuditReportPage.jsx';
import { CurrencyProvider } from './contexts/CurrencyContext.jsx';
import CookieBanner from './components/CookieBanner.jsx';

export function AppRoutes() {
  const location = useLocation();

  return (
    <>
      <ScrollToTop />
      <CanonicalLink />
      <RouteMeta />
      <Header />
      <main className="min-h-screen">
        <Routes location={location}>
          <Route path="/" element={<HomePage key={location.pathname} />} />
          
          {/* Specific Calculator Routes */}
          <Route path="/uk-salary-calculator" element={<UKSalaryCalculator key={location.pathname} />} />
          <Route path="/us-salary-calculator" element={<USsalaryCalculatorPage key={location.pathname} />} />
          <Route path="/us-retirement-calculator" element={<USRetirementCalculatorPage key={location.pathname} />} />
          <Route path="/compound-interest" element={<CompoundInterestPage key={location.pathname} />} />
          <Route path="/mortgage" element={<MortgagePage key={location.pathname} />} />
          <Route path="/pensions-calculator" element={<PensionsCalculatorPage key={location.pathname} />} />
          <Route path="/budget-planner" element={<BudgetPlannerPage key={location.pathname} />} />
          <Route path="/self-employed-tax-calculator" element={<SelfEmployedTaxCalculatorPage key={location.pathname} />} />
          <Route path="/debt-snowball-calculator" element={<DebtSnowballCalculatorPage key={location.pathname} />} />
          <Route path="/savings-goal-calculator" element={<SavingsGoalCalculatorPage key={location.pathname} />} />
          
          {/* Standard Pages */}
          <Route path="/about" element={<AboutPage key={location.pathname} />} />
          <Route path="/about/team" element={<TeamPage key={location.pathname} />} />
          <Route path="/contact" element={<ContactPage key={location.pathname} />} />
          <Route path="/faq" element={<FAQPage key={location.pathname} />} />
          <Route path="/privacy" element={<PrivacyPage key={location.pathname} />} />
          <Route path="/terms" element={<TermsPage key={location.pathname} />} />
          <Route path="/financial-disclaimer" element={<FinancialDisclaimerPage key={location.pathname} />} />
          <Route path="/disclaimer" element={<Navigate to="/financial-disclaimer" replace />} />
          <Route path="/cookie-policy" element={<CookiePolicyPage key={location.pathname} />} />
          <Route path="/guides" element={<GuidesIndexPage key={location.pathname} />} />

          {/* Topic hubs */}
          <Route path="/hubs/mortgages" element={<MortgagesHubPage key={location.pathname} />} />
          <Route path="/hubs/savings" element={<SavingsHubPage key={location.pathname} />} />
          <Route path="/hubs/debt" element={<DebtHubPage key={location.pathname} />} />
          <Route path="/hubs/uk-salary-tax" element={<UKSalaryTaxHubPage key={location.pathname} />} />
          <Route path="/hubs/us-salary-tax" element={<USSalaryTaxHubPage key={location.pathname} />} />
          <Route path="/hubs/pensions-retirement" element={<PensionsRetirementHubPage key={location.pathname} />} />
          <Route path="/hubs/self-employment" element={<SelfEmploymentHubPage key={location.pathname} />} />
          <Route path="/author/shaun-da-silva" element={<AuthorProfilePage key={location.pathname} />} />
          <Route path="/methodology" element={<Navigate to="/calculation-methodology" replace />} />
          <Route path="/editorial-policy" element={<EditorialPolicyPage key={location.pathname} />} />
          <Route path="/calculation-methodology" element={<CalculationMethodologyPage key={location.pathname} />} />
          <Route path="/corrections-policy" element={<CorrectionsPolicy key={location.pathname} />} />
          <Route path="/advertising-disclosure" element={<AdvertisingDisclosure key={location.pathname} />} />
          <Route path="/accessibility" element={<AccessibilityStatement key={location.pathname} />} />
          
          {/* Salary & Income Guides */}
          <Route path="/guides/calculate-take-home-pay" element={<CalculateTakeHomePayGuidePage key={location.pathname} />} />
          <Route path="/guides/uk-salary-guide" element={<Navigate to="/guides/calculate-take-home-pay" replace />} />
          <Route path="/guides/student-loan-repayments" element={<StudentLoanRepaymentsGuidePage key={location.pathname} />} />
          <Route path="/guides/self-employment-income" element={<SelfEmploymentIncomeGuidePage key={location.pathname} />} />
          <Route path="/guides/freelance-income" element={<FreelanceIncomeGuidePage key={location.pathname} />} />
          <Route path="/guides/side-hustle-tax" element={<SideHustleTaxGuidePage key={location.pathname} />} />

          {/* Tax Planning Guides */}
          <Route path="/guides/pension-tax-take-home" element={<Navigate to="/guides/pension-contributions" replace />} />
          <Route path="/guides/uk-income-tax" element={<UKIncomeTaxComprehensiveGuidePage key={location.pathname} />} />
          <Route path="/guides/self-employed-tax-planning" element={<SelfEmployedTaxPlanningGuidePage key={location.pathname} />} />
          <Route path="/guides/national-insurance" element={<NationalInsuranceComprehensiveGuidePage key={location.pathname} />} />
          <Route path="/guides/tax-planning" element={<TaxPlanningComprehensiveGuidePage key={location.pathname} />} />
          <Route path="/guides/marriage-allowance" element={<MarriageAllowanceComprehensiveGuidePage key={location.pathname} />} />

          {/* Pensions & Retirement Guides */}
          <Route path="/guides/salary-sacrifice-vs-normal-pension" element={<SalarySacrificeGuidePage key={location.pathname} />} />
          <Route path="/guides/workplace-pensions" element={<WorkplacePensionsComprehensiveGuidePage key={location.pathname} />} />
          <Route path="/guides/pension-contributions" element={<PensionContributionsComprehensiveGuidePage key={location.pathname} />} />
          <Route path="/guides/pension-planning" element={<PensionPlanningComprehensiveGuidePage key={location.pathname} />} />
          <Route path="/guides/early-retirement" element={<EarlyRetirementComprehensiveGuidePage key={location.pathname} />} />

          {/* Savings & Investments Guides */}
          <Route path="/guides/how-much-emergency-fund" element={<Navigate to="/guides/emergency-fund" replace />} />
          <Route path="/guides/compound-interest-monthly-deposits" element={<CompoundInterestMonthlyGuidePage key={location.pathname} />} />
          <Route path="/guides/realistic-savings-goal" element={<Navigate to="/guides/savings-goals" replace />} />
          <Route path="/guides/savings-goals" element={<SavingsGoalsComprehensiveGuidePage key={location.pathname} />} />
          <Route path="/guides/emergency-fund" element={<EmergencyFundComprehensiveGuidePage key={location.pathname} />} />
          <Route path="/guides/high-interest-savings" element={<HighInterestSavingsComprehensiveGuidePage key={location.pathname} />} />
          <Route path="/guides/tax-free-savings" element={<TaxFreeSavingsComprehensiveGuidePage key={location.pathname} />} />

          {/* Debt Management Guides */}
          <Route path="/guides/debt-snowball-vs-avalanche" element={<Navigate to="/guides/debt-repayment" replace />} />
          <Route path="/guides/compare-loan-repayments" element={<CompareLoanRepaymentsGuidePage key={location.pathname} />} />
          <Route path="/guides/debt-repayment" element={<DebtRepaymentComprehensiveGuidePage key={location.pathname} />} />
          <Route path="/guides/credit-card-debt" element={<CreditCardDebtComprehensiveGuidePage key={location.pathname} />} />
          <Route path="/guides/personal-loan" element={<PersonalLoanComprehensiveGuidePage key={location.pathname} />} />
          <Route path="/guides/debt-consolidation" element={<DebtConsolidationComprehensiveGuidePage key={location.pathname} />} />

          {/* Mortgage & Housing Guides */}
          <Route path="/guides/mortgage-overpayments" element={<MortgageOverpaymentsGuidePage key={location.pathname} />} />
          <Route path="/guides/first-time-buyer-budgeting" element={<Navigate to="/guides/first-time-buyer" replace />} />
          <Route path="/guides/mortgage-comprehensive" element={<MortgageComprehensiveGuidePage key={location.pathname} />} />
          <Route path="/guides/first-time-buyer" element={<FirstTimeBuyerComprehensiveGuidePage key={location.pathname} />} />

          {/* Legacy fallback Guides */}
          <Route path="/guides/compound-interest-guide" element={<Navigate to="/guides/compound-interest-monthly-deposits" replace />} />

          {/* Legacy guide redirects — preserve indexed URLs */}
          <Route path="/guides/understanding-uk-income-tax" element={<Navigate to="/guides/uk-income-tax" replace />} />
          <Route path="/guides/national-insurance-explained" element={<Navigate to="/guides/national-insurance" replace />} />
          <Route path="/guides/pension-contributions-tax-relief" element={<Navigate to="/guides/pension-contributions" replace />} />
          <Route path="/guides/tax-planning-strategies-uk-employees" element={<Navigate to="/guides/tax-planning" replace />} />
          <Route path="/guides/maximizing-take-home-pay" element={<Navigate to="/guides/calculate-take-home-pay" replace />} />
          <Route path="/guides/self-employed-tax-guide" element={<Navigate to="/guides/self-employed-tax-planning" replace />} />
          <Route path="/guides/investment-basics-beginners" element={<Navigate to="/guides/savings-goals" replace />} />
          <Route path="/guides/emergency-fund-financial-safety-net" element={<Navigate to="/guides/emergency-fund" replace />} />
          <Route path="/guides/savings-goal-guide" element={<Navigate to="/guides/savings-goals" replace />} />
          <Route path="/guides/debt-management-repayment-strategies" element={<Navigate to="/guides/debt-repayment" replace />} />
          <Route path="/guides/debt-snowball-guide" element={<Navigate to="/guides/debt-repayment" replace />} />
          <Route path="/guides/budget-planner-guide" element={<Navigate to="/budget-planner" replace />} />
          <Route path="/guides/retirement-planning-guide" element={<Navigate to="/guides/pension-planning" replace />} />
          <Route path="/guides/pensions-calculator-guide" element={<Navigate to="/pensions-calculator" replace />} />
          <Route path="/guides/financial-planning-young-professionals" element={<Navigate to="/guides/pension-planning" replace />} />
          <Route path="/guides/mortgage-guide" element={<Navigate to="/guides/mortgage-comprehensive" replace />} />
          <Route path="/guides/mortgage-affordability-first-time-buyers" element={<MortgageAffordabilityFirstTimeBuyersGuidePage key={location.pathname} />} />
          <Route path="/guides/uk-salary-calculator-guide" element={<Navigate to="/uk-salary-calculator" replace />} />
          <Route path="/guides/student-loan-repayment-guide" element={<Navigate to="/guides/student-loan-repayments" replace />} />
          <Route path="/guides/compound-interest-monthly" element={<Navigate to="/guides/compound-interest-monthly-deposits" replace />} />

          {/* Internal admin pages — not publicly linked */}
          <Route path="/seo-audit-report" element={<SeoAuditReportPage key={location.pathname} />} />

          {/* Fallback */}
          <Route path="*" element={<NotFound key={location.pathname} />} />
        </Routes>
      </main>
      <Footer />
      <CookieBanner />
    </>
  );
}

function App() {
  return (
    <CurrencyProvider>
      <Router>
        <AppRoutes />
      </Router>
    </CurrencyProvider>
  );
}

export default App;