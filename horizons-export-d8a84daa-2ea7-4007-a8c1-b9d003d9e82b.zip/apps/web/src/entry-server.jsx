import React from 'react';
import { renderToString } from 'react-dom/server';
import { StaticRouter } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { AppRoutes } from '@/App';
import { CurrencyProvider } from '@/contexts/CurrencyContext.jsx';

/**
 * Server-side render entry used by tools/prerender.js at build time.
 *
 * This site is statically prerendered and served by Apache, so there is no
 * runtime Node server to set HTTP status codes. Real HTTP 404s are produced
 * at the Apache layer: every legitimate route is prerendered to its own
 * <route>/index.html (HTTP 200), and any URL without a prerendered file is
 * routed to /404.html via `ErrorDocument 404` in .htaccess (HTTP 404).
 *
 * `render` returns a `statusCode` so the prerender step can label output:
 * 200 for known routes, 404 for the catch-all (rendered to /404.html).
 */
export function render(url) {
  // Clear any Helmet state left over from a previous render in this process.
  // react-helmet shares a module-level instance list across renderToString
  // calls; without resetting, a prior route's <Helmet> can leak into the
  // next route's head (e.g. the homepage title appearing on every page).
  // rewind() returns and clears the accumulated state (server-only, safe in Node).
  Helmet.rewind();

  const html = renderToString(
    <CurrencyProvider>
      <StaticRouter location={url}>
        <AppRoutes />
      </StaticRouter>
    </CurrencyProvider>
  );

  const helmet = Helmet.renderStatic();

  const head = [
    helmet.title?.toString() || '',
    helmet.meta?.toString() || '',
    helmet.link?.toString() || '',
    helmet.script?.toString() || '',
  ].join('\n');

  // The catch-all NotFound route renders the 404 page. Detect it via the
  // unique <title> emitted by NotFound.jsx so the prerenderer can write
  // /404.html and tag it with a 404 status.
  const isNotFound = /Page Not Found \(404\)/i.test(helmet.title?.toString() || '');
  const statusCode = isNotFound ? 404 : 200;

  return { html, head, statusCode };
}
