const injectSchema = (id, schemaObj) => {
  let script = document.getElementById(id);
  if (!script) {
    script = document.createElement('script');
    script.id = id;
    script.setAttribute('type', 'application/ld+json');
    document.head.appendChild(script);
  }
  script.textContent = JSON.stringify(schemaObj);
};

export const addOrganizationSchema = () => {
  const schema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "SmartMoneyTools",
    "url": "https://smartmoney-tools.com/",
    "logo": "https://smartmoney-tools.com/logo.png",
    "description": "Free financial calculators and educational guides to help you make smarter money decisions."
  };
  injectSchema('schema-organization', schema);
};

export const addWebSiteSchema = () => {
  const schema = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": "SmartMoneyTools",
    "url": "https://smartmoney-tools.com/",
    "potentialAction": {
      "@type": "SearchAction",
      "target": "https://smartmoney-tools.com/search?q={search_term_string}",
      "query-input": "required name=search_term_string"
    }
  };
  injectSchema('schema-website', schema);
};

export const addWebApplicationSchema = (name, url, description) => {
  const schema = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    "name": name,
    "url": url,
    "description": description,
    "applicationCategory": "BusinessApplication",
    "operatingSystem": "All",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    }
  };
  injectSchema('schema-webapplication', schema);
};

export const addFAQSchema = (faqs) => {
  if (!faqs || faqs.length === 0) return;
  const schema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": faqs.map(faq => ({
      "@type": "Question",
      "name": faq.question,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": faq.answer
      }
    }))
  };
  injectSchema('schema-faq', schema);
};