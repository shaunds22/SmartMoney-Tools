import { currencyData } from './currencyData.js';

export default function formatCurrency(amount, currencyCode = 'USD') {
  if (amount === null || amount === undefined || isNaN(amount)) return '';
  
  const currency = currencyData[currencyCode] || currencyData.USD;
  
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency.code,
    minimumFractionDigits: currency.decimalPlaces,
    maximumFractionDigits: currency.decimalPlaces,
  }).format(amount);
}