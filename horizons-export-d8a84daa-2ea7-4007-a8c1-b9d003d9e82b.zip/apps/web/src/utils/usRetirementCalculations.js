import { US_RETIREMENT_LIMITS_2026 as LIMITS } from '../config/usRetirementLimits2026.js';

/**
 * Calculates employer match amount based on common formulas
 */
export const calculateEmployerMatch = (salary, employeeContribPct, matchType, customMatchParams = null) => {
  if (employeeContribPct <= 0 || matchType === 'none') return 0;
  
  let matchAmount = 0;
  
  switch (matchType) {
    case '100_up_to_3':
      // 100% match on the first 3% of salary
      matchAmount = salary * Math.min(employeeContribPct, 0.03) * 1.0;
      break;
      
    case '50_up_to_6':
      // 50% match on the first 6% of salary
      matchAmount = salary * Math.min(employeeContribPct, 0.06) * 0.5;
      break;
      
    case '100_to_3_50_to_5':
      // 100% on first 3%, 50% on next 2% (up to 5%)
      const firstTier = Math.min(employeeContribPct, 0.03);
      const secondTier = Math.max(0, Math.min(employeeContribPct, 0.05) - 0.03);
      matchAmount = (salary * firstTier * 1.0) + (salary * secondTier * 0.5);
      break;
      
    case 'custom':
      if (!customMatchParams) return 0;
      const { tier1Match, tier1Limit, tier2Match, tier2Limit } = customMatchParams;
      
      const t1 = Math.min(employeeContribPct, tier1Limit / 100);
      const t2 = Math.max(0, Math.min(employeeContribPct, tier2Limit / 100) - (tier1Limit / 100));
      
      matchAmount = (salary * t1 * (tier1Match / 100)) + (salary * t2 * (tier2Match / 100));
      break;
      
    default:
      matchAmount = 0;
  }
  
  return matchAmount;
};

/**
 * Validates and caps contributions against IRS limits
 */
export const capContributions = (age, employeeAmount, employerAmount) => {
  let maxEmployeeLimit = LIMITS.definedContributionLimit;
  
  // Super catch-up (SECURE 2.0)
  if (age >= 60 && age <= 63) {
    maxEmployeeLimit += LIMITS.superCatchUpLimit;
  } 
  // Standard catch-up
  else if (age >= 50) {
    maxEmployeeLimit += LIMITS.catchUpLimit;
  }
  
  const cappedEmployee = Math.min(employeeAmount, maxEmployeeLimit);
  
  // Total limit (Employee + Employer)
  let maxTotalLimit = LIMITS.totalContributionLimit;
  if (age >= 60 && age <= 63) maxTotalLimit = LIMITS.totalContributionLimitWithSuperCatchUp;
  else if (age >= 50) maxTotalLimit = LIMITS.totalContributionLimitWithCatchUp;
  
  const totalCapped = Math.min(cappedEmployee + employerAmount, maxTotalLimit);
  const cappedEmployer = totalCapped - cappedEmployee;
  
  return {
    employee: cappedEmployee,
    employer: cappedEmployer,
    capped: employeeAmount > cappedEmployee || (employeeAmount + employerAmount) > totalCapped
  };
};

/**
 * Projects retirement savings year by year (Accumulation and Distribution)
 */
export const projectRetirement = (params) => {
  const {
    currentAge,
    retireAge,
    planningAge,
    currentSalary,
    salaryGrowthRate = 2,
    currentBalance,
    employeeContribPct,
    matchType,
    customMatchParams,
    iraContribAmount = 0,
    annualIncreasePct = 0, // Auto-escalation of contribution %
    preRetirementReturn = 7,
    postRetirementReturn = 5,
    inflationRate = 2.5,
    investmentFees = 0.5,
    incomeGoalPct = 80,
    socialSecurityMonthly = 0,
    ssClaimAge = 67,
    pensionMonthly = 0,
    pensionStartAge = 65,
    pensionCola = 0
  } = params;

  let balance = currentBalance;
  let salary = currentSalary;
  let currentContribPct = employeeContribPct / 100;
  
  const data = [];
  let isDepleted = false;
  let ageDepleted = null;

  // Initialize accumulators
  let totalPersonalContributions = 0;
  let totalEmployerContributions = 0;
  let totalInvestmentGrowth = 0;

  for (let age = currentAge; age <= planningAge; age++) {
    const isRetired = age >= retireAge;
    const yearIndex = age - currentAge;
    
    // Returns adjusted for fees
    const netReturnRate = isRetired 
      ? (postRetirementReturn - investmentFees) / 100 
      : (preRetirementReturn - investmentFees) / 100;
      
    // Growth on starting balance
    const growth = balance * netReturnRate;
    const feesPaid = balance * (investmentFees / 100); // Track nominal fees
    
    let employeeContrib = 0;
    let employerContrib = 0;
    let iraContrib = 0;
    let withdrawal = 0;
    let ssIncome = 0;
    let pensionInc = 0;
    
    if (!isRetired) {
      // Accumulation Phase
      const rawEmployeeContrib = salary * currentContribPct;
      const rawEmployerContrib = calculateEmployerMatch(salary, currentContribPct, matchType, customMatchParams);
      
      // Apply IRS Limits
      const capped = capContributions(age, rawEmployeeContrib, rawEmployerContrib);
      employeeContrib = capped.employee;
      employerContrib = capped.employer;
      iraContrib = Math.min(iraContribAmount, age >= 50 ? LIMITS.iraContributionLimit + LIMITS.iraCatchUpLimit : LIMITS.iraContributionLimit);
      
      balance += growth + employeeContrib + employerContrib + iraContrib;
      
      totalPersonalContributions += (employeeContrib + iraContrib);
      totalEmployerContributions += employerContrib;
      totalInvestmentGrowth += growth;
      
      // Update variables for next year
      salary = salary * (1 + salaryGrowthRate / 100);
      if (annualIncreasePct > 0) {
        currentContribPct = Math.min(currentContribPct + (annualIncreasePct / 100), 1.0);
      }
    } else {
      // Distribution Phase
      // Income Goal grows with inflation relative to retirement year
      const yearsInRetirement = age - retireAge;
      // The target income in the first year of retirement
      const initialIncomeGoal = (currentSalary * Math.pow(1 + salaryGrowthRate/100, retireAge - currentAge)) * (incomeGoalPct / 100);
      const currentYearGoal = initialIncomeGoal * Math.pow(1 + inflationRate/100, yearsInRetirement);
      
      if (age >= ssClaimAge) {
        // Adjust SS for inflation from today to now
        ssIncome = (socialSecurityMonthly * 12) * Math.pow(1 + inflationRate/100, yearIndex);
      }
      
      if (age >= pensionStartAge) {
        const yearsReceivingPension = age - pensionStartAge;
        pensionInc = (pensionMonthly * 12) * Math.pow(1 + pensionCola/100, yearsReceivingPension);
      }
      
      // Needed from portfolio
      const shortfall = Math.max(0, currentYearGoal - ssIncome - pensionInc);
      
      if (balance + growth >= shortfall) {
        withdrawal = shortfall;
        balance = balance + growth - withdrawal;
        totalInvestmentGrowth += growth;
      } else if (balance + growth > 0) {
        withdrawal = balance + growth;
        totalInvestmentGrowth += growth;
        balance = 0;
        isDepleted = true;
        if (!ageDepleted) ageDepleted = age;
      } else {
        withdrawal = 0;
        balance = 0;
        isDepleted = true;
        if (!ageDepleted) ageDepleted = age;
      }
    }

    // Convert balance to today's purchasing power
    const balanceTodaysDollars = balance / Math.pow(1 + inflationRate/100, yearIndex);

    data.push({
      age,
      year: new Date().getFullYear() + yearIndex,
      salary: isRetired ? 0 : salary,
      balance,
      balanceTodaysDollars,
      employeeContrib,
      employerContrib,
      iraContrib,
      growth,
      feesPaid,
      withdrawal,
      ssIncome,
      pensionInc,
      totalIncome: withdrawal + ssIncome + pensionInc,
      targetIncome: isRetired ? (currentSalary * Math.pow(1 + salaryGrowthRate/100, retireAge - currentAge)) * (incomeGoalPct / 100) * Math.pow(1 + inflationRate/100, age - retireAge) : 0
    });
  }

  // Calculate high-level summary
  const retirementYearData = data.find(d => d.age === retireAge);
  const finalYearData = data[data.length - 1];
  
  const firstYearRetirementIncomeTarget = retirementYearData ? retirementYearData.targetIncome : 0;
  const firstYearRetirementIncomeGenerated = retirementYearData ? retirementYearData.totalIncome : 0;
  
  return {
    projection: data,
    summary: {
      balanceAtRetirement: retirementYearData ? retirementYearData.balance : 0,
      balanceAtRetirementTodaysDollars: retirementYearData ? retirementYearData.balanceTodaysDollars : 0,
      finalBalance: finalYearData.balance,
      isDepleted,
      ageDepleted,
      firstYearRetirementIncomeTarget,
      firstYearRetirementIncomeGenerated,
      monthlyShortfall: Math.max(0, (firstYearRetirementIncomeTarget - firstYearRetirementIncomeGenerated) / 12),
      totalPersonalContributions,
      totalEmployerContributions,
      totalInvestmentGrowth
    }
  };
};