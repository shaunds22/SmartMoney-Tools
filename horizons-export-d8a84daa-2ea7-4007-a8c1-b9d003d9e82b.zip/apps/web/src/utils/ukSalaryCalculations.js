import { taxYear2026_27 as config } from '../config/taxYear2026_27.js';

export const convertToAnnualSalary = (amount, frequency, hoursPerWeek = 37.5) => {
  const value = parseFloat(amount) || 0;
  switch (frequency) {
    case 'Monthly': return value * 12;
    case 'Weekly': return value * 52;
    case 'Daily': return value * 5 * 52; // Assuming standard 5-day week
    case 'Hourly': return value * (parseFloat(hoursPerWeek) || 0) * 52;
    default: return value;
  }
};

export const calculatePersonalAllowance = (grossSalary, customPA) => {
  if (customPA !== undefined && customPA !== null && customPA !== '') {
    return parseFloat(customPA) || 0;
  }
  const base = config.personalAllowance.base;
  const threshold = config.personalAllowance.reductionThreshold;
  
  if (grossSalary <= threshold) return base;
  
  const reduction = Math.floor((grossSalary - threshold) * config.personalAllowance.reductionRate);
  return Math.max(0, base - reduction);
};

export const calculatePensionContribution = (grossSalary, percentage, reliefType, basis) => {
  const rate = (parseFloat(percentage) || 0) / 100;
  let pensionableEarnings = grossSalary;
  
  if (basis === 'Qualifying Earnings') {
    const { qualifyingEarningsLower, qualifyingEarningsUpper } = config.pension;
    if (grossSalary <= qualifyingEarningsLower) {
      pensionableEarnings = 0;
    } else {
      pensionableEarnings = Math.min(grossSalary, qualifyingEarningsUpper) - qualifyingEarningsLower;
    }
  }
  
  const employeeContribution = pensionableEarnings * rate;
  return { employeeContribution, reliefType };
};

export const calculateIncomeTax = (taxableIncome, region) => {
  if (taxableIncome <= 0) return { total: 0, breakdown: [] };
  
  const bands = region === 'Scotland' ? config.incomeTax.scotland : config.incomeTax.englandWalesNI;
  let totalTax = 0;
  const breakdown = [];
  
  for (const band of bands) {
    if (taxableIncome > band.threshold) {
      const taxableInThisBand = Math.min(taxableIncome, band.limit) - band.threshold;
      const taxInThisBand = taxableInThisBand * band.rate;
      if (taxInThisBand > 0) {
        totalTax += taxInThisBand;
        breakdown.push({
          name: band.name,
          taxableAmount: taxableInThisBand,
          rate: band.rate,
          taxAmount: taxInThisBand
        });
      }
    }
  }
  
  return { total: totalTax, breakdown };
};

export const calculateNationalInsurance = (niAssessableIncome) => {
  const { primaryThreshold, upperEarningsLimit, mainRate, upperRate } = config.nationalInsurance.employee;
  let employeeNI = 0;
  
  if (niAssessableIncome > primaryThreshold) {
    const mainBandIncome = Math.min(niAssessableIncome, upperEarningsLimit) - primaryThreshold;
    employeeNI += mainBandIncome * mainRate;
  }
  
  if (niAssessableIncome > upperEarningsLimit) {
    const upperBandIncome = niAssessableIncome - upperEarningsLimit;
    employeeNI += upperBandIncome * upperRate;
  }
  
  // Employer NI
  const { secondaryThreshold, mainRate: employerRate } = config.nationalInsurance.employer;
  let employerNI = 0;
  if (niAssessableIncome > secondaryThreshold) {
    employerNI = (niAssessableIncome - secondaryThreshold) * employerRate;
  }
  
  return { employee: employeeNI, employer: employerNI };
};

export const calculateStudentLoan = (grossSalary, plans) => {
  let totalDeduction = 0;
  const breakdown = [];
  
  // Only the highest threshold among undergraduate plans applies for undergraduate deductions
  let highestUgThreshold = 0;
  let applyUg = false;
  
  if (plans.plan1) { applyUg = true; highestUgThreshold = Math.max(highestUgThreshold, config.studentLoan.plan1.threshold); }
  if (plans.plan2) { applyUg = true; highestUgThreshold = Math.max(highestUgThreshold, config.studentLoan.plan2.threshold); }
  if (plans.plan4) { applyUg = true; highestUgThreshold = Math.max(highestUgThreshold, config.studentLoan.plan4.threshold); }
  if (plans.plan5) { applyUg = true; highestUgThreshold = Math.max(highestUgThreshold, config.studentLoan.plan5.threshold); }
  
  if (applyUg && grossSalary > highestUgThreshold) {
    const ugDeduction = (grossSalary - highestUgThreshold) * 0.09; // Rate is 9% for all UG
    totalDeduction += ugDeduction;
    breakdown.push({ name: 'Undergraduate Loan', amount: ugDeduction });
  }
  
  if (plans.postgrad && grossSalary > config.studentLoan.postgrad.threshold) {
    const pgDeduction = (grossSalary - config.studentLoan.postgrad.threshold) * config.studentLoan.postgrad.rate;
    totalDeduction += pgDeduction;
    breakdown.push({ name: 'Postgraduate Loan', amount: pgDeduction });
  }
  
  return { total: totalDeduction, breakdown };
};

export const calculateEffectiveTaxRate = (totalDeductions, grossSalary) => {
  if (grossSalary <= 0) return 0;
  return (totalDeductions / grossSalary) * 100;
};

export const calculateMarginalTaxRate = (grossSalary, region) => {
  // Rough estimate by simulating an extra £100
  const baseTakeHome = calculateTakeHomePay(grossSalary, {
    region, pensionPercentage: 0, studentLoans: { plan1: false, plan2: false, plan4: false, plan5: false, postgrad: false }
  }).netAnnual;
  
  const higherTakeHome = calculateTakeHomePay(grossSalary + 100, {
    region, pensionPercentage: 0, studentLoans: { plan1: false, plan2: false, plan4: false, plan5: false, postgrad: false }
  }).netAnnual;
  
  const takeHomeDifference = higherTakeHome - baseTakeHome;
  const marginalDeduction = 100 - takeHomeDifference;
  return Math.max(0, marginalDeduction); 
};

export const calculateTakeHomePay = (baseSalary, inputs) => {
  const {
    region = 'England',
    customPA = null,
    pensionPercentage = 0,
    pensionReliefType = 'Relief at Source',
    pensionBasis = 'Full Salary',
    employerPensionPercentage = 0,
    studentLoans = { plan1: false, plan2: false, plan4: false, plan5: false, postgrad: false },
    bonus = 0
  } = inputs;

  const totalGross = baseSalary + (parseFloat(bonus) || 0);

  // 1. Pension
  const { employeeContribution: pensionDed } = calculatePensionContribution(totalGross, pensionPercentage, pensionReliefType, pensionBasis);
  const employerPension = calculatePensionContribution(totalGross, employerPensionPercentage, 'Relief at Source', pensionBasis).employeeContribution;

  // 2. Assessable amounts based on relief type
  let taxAssessableIncome = totalGross;
  let niAssessableIncome = totalGross;
  let takeHomeDeductions = 0;
  // Amount the employee actually pays from take-home pay, and the basic-rate
  // tax relief the pension provider claims from HMRC on their behalf.
  let employeePensionPaid = 0;
  let pensionTaxRelief = 0;

  if (pensionReliefType === 'Salary Sacrifice') {
    taxAssessableIncome -= pensionDed;
    niAssessableIncome -= pensionDed;
    takeHomeDeductions += pensionDed;
    employeePensionPaid = pensionDed;
  } else if (pensionReliefType === 'Net Pay') {
    taxAssessableIncome -= pensionDed;
    takeHomeDeductions += pensionDed;
    employeePensionPaid = pensionDed;
  } else {
    // Relief at Source: Income Tax and NI are calculated on the FULL gross pay.
    // The employee pays only 80% of their gross contribution from take-home
    // pay; the pension provider claims the other 20% basic-rate relief from
    // HMRC. This applies in all regions including Scotland.
    pensionTaxRelief = pensionDed * 0.2;
    employeePensionPaid = pensionDed * 0.8;
    takeHomeDeductions += employeePensionPaid;
  }

  // 3. Tax
  const personalAllowance = calculatePersonalAllowance(taxAssessableIncome, customPA);
  const taxableIncome = Math.max(0, taxAssessableIncome - personalAllowance);
  const incomeTaxResult = calculateIncomeTax(taxableIncome, region);

  // 4. NI
  const niResult = calculateNationalInsurance(niAssessableIncome);

  // 5. Student Loans
  const slResult = calculateStudentLoan(totalGross, studentLoans); // SL usually calculated on gross

  // Total Deductions
  const totalDeductions = incomeTaxResult.total + niResult.employee + slResult.total + takeHomeDeductions;
  const netAnnual = totalGross - totalDeductions;

  return {
    totalGross,
    taxAssessableIncome,
    personalAllowance,
    taxableIncome,
    incomeTax: incomeTaxResult.total,
    taxBreakdown: incomeTaxResult.breakdown,
    employeeNI: niResult.employee,
    employerNI: niResult.employer,
    employeePension: pensionDed,
    employeePensionPaid,
    pensionTaxRelief,
    pensionReliefType,
    employerPension,
    studentLoan: slResult.total,
    slBreakdown: slResult.breakdown,
    totalDeductions,
    netAnnual,
    effectiveTaxRate: calculateEffectiveTaxRate(totalDeductions, totalGross)
  };
};