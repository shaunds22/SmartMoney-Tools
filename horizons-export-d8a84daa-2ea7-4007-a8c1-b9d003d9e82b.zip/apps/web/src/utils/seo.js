const setMetaTag = (selector, attrName, attrValue, content) => {
  let meta = document.querySelector(selector);
  if (!meta) {
    meta = document.createElement('meta');
    meta.setAttribute(attrName, attrValue);
    document.head.appendChild(meta);
  }
  meta.setAttribute('content', content);
};

export const setCanonicalTag = (url) => {
  if (!url) return;
  let link = document.querySelector("link[rel='canonical']");
  if (!link) {
    link = document.createElement('link');
    link.setAttribute('rel', 'canonical');
    document.head.appendChild(link);
  }
  link.setAttribute('href', url);
};

export const setRobotsMeta = (content) => {
  if (!content) return;
  setMetaTag("meta[name='robots']", 'name', 'robots', content);
};

export const setPageMeta = (title, description, canonical) => {
  if (title) {
    document.title = title;
  }
  if (description) {
    setMetaTag("meta[name='description']", 'name', 'description', description);
  }
  if (canonical) {
    setCanonicalTag(canonical);
  }
  setRobotsMeta('index, follow');

  // Open Graph tags
  const ogTitle = title || document.title;
  const ogDesc = description || '';
  const ogUrl = canonical || window.location.href;
  const ogImage = 'https://smartmoney-tools.com/og-default.png';
  const siteName = 'SmartMoneyTools';

  setMetaTag("meta[property='og:type']", 'property', 'og:type', 'website');
  setMetaTag("meta[property='og:title']", 'property', 'og:title', ogTitle);
  setMetaTag("meta[property='og:description']", 'property', 'og:description', ogDesc);
  setMetaTag("meta[property='og:url']", 'property', 'og:url', ogUrl);
  setMetaTag("meta[property='og:image']", 'property', 'og:image', ogImage);
  setMetaTag("meta[property='og:site_name']", 'property', 'og:site_name', siteName);

  // Twitter Card tags
  setMetaTag("meta[name='twitter:card']", 'name', 'twitter:card', 'summary_large_image');
  setMetaTag("meta[name='twitter:title']", 'name', 'twitter:title', ogTitle);
  setMetaTag("meta[name='twitter:description']", 'name', 'twitter:description', ogDesc);
  setMetaTag("meta[name='twitter:image']", 'name', 'twitter:image', ogImage);
};
