import { FICA_DATA_2026, PAY_FREQUENCIES } from '../config/usPayrollTaxData2026.js';
import { FEDERAL_BRACKETS_2026 } from '../config/federalWithholding2026.js';
import { STATE_TAX_DATA_2026 } from '../config/stateTaxData2026.js';

export const calculateGrossIncome = (baseAmount, frequency, hoursPerWeek, weeksPerYear, overtimeHours, overtimeMultiplier, bonuses) => {
  let annualGross = 0;
  
  if (frequency === 'hourly') {
    const regularAnnual = baseAmount * hoursPerWeek * weeksPerYear;
    const overtimeAnnual = baseAmount * overtimeMultiplier * overtimeHours * weeksPerYear;
    annualGross = regularAnnual + overtimeAnnual;
  } else {
    annualGross = baseAmount * PAY_FREQUENCIES[frequency]?.periods || baseAmount;
  }
  
  return annualGross + (bonuses || 0);
};

export const calculateFICA = (annualGross, filingStatus) => {
  const ssTaxable = Math.min(annualGross, FICA_DATA_2026.socialSecurityWageBase);
  const socialSecurityTax = ssTaxable * FICA_DATA_2026.socialSecurityRate;
  
  const medicareTax = annualGross * FICA_DATA_2026.medicareRate;
  
  const addMedThreshold = FICA_DATA_2026.additionalMedicareThresholds[filingStatus] || FICA_DATA_2026.additionalMedicareThresholds.single;
  const additionalMedicareTax = annualGross > addMedThreshold 
    ? (annualGross - addMedThreshold) * FICA_DATA_2026.additionalMedicareRate 
    : 0;

  return {
    socialSecurityTax,
    medicareTax,
    additionalMedicareTax,
    totalFICA: socialSecurityTax + medicareTax + additionalMedicareTax
  };
};

export const calculateFederalWithholding = (taxableGross, filingStatus) => {
  const statusData = FEDERAL_BRACKETS_2026[filingStatus] || FEDERAL_BRACKETS_2026.single;
  let tax = 0;
  let remainingIncome = Math.max(0, taxableGross - statusData.standardDeduction);

  const brackets = [...statusData.brackets].reverse();
  
  for (let i = 0; i < brackets.length; i++) {
    const bracket = brackets[i];
    if (remainingIncome > bracket.over) {
      const taxableInThisBracket = remainingIncome - bracket.over;
      tax += taxableInThisBracket * bracket.rate;
      remainingIncome = bracket.over;
    }
  }
  
  return tax;
};

export const calculateStateWithholding = (taxableGross, stateCode) => {
  if (!stateCode || !STATE_TAX_DATA_2026[stateCode]) return 0;
  
  const stateData = STATE_TAX_DATA_2026[stateCode];
  
  if (stateData.type === 'none') return 0;
  if (stateData.type === 'flat') return taxableGross * stateData.rate;
  
  // Simplified progressive calculation for generic estimation
  const stateTaxable = Math.max(0, taxableGross - (stateData.standardDeduction || 0));
  return stateTaxable * (stateData.defaultEffectiveRate || 0.04); 
};

export const calculateDeductions = (deductions, grossIncome) => {
  let preTax = 0;
  let postTax = 0;
  
  deductions.forEach(d => {
    const amount = d.isPercentage ? (grossIncome * (d.amount / 100)) : d.amount;
    if (d.type === 'pre') preTax += amount;
    else postTax += amount;
  });
  
  return { preTax, postTax };
};

export const calculateNetPay = (params) => {
  const {
    baseAmount,
    frequency,
    hoursPerWeek,
    weeksPerYear,
    overtimeHours,
    overtimeMultiplier,
    bonuses,
    filingStatus,
    stateCode,
    deductions
  } = params;

  const annualGross = calculateGrossIncome(baseAmount, frequency, hoursPerWeek, weeksPerYear, overtimeHours, overtimeMultiplier, bonuses);
  
  const { preTax: preTaxDeductions, postTax: postTaxDeductions } = calculateDeductions(deductions, annualGross);
  
  const federalTaxable = Math.max(0, annualGross - preTaxDeductions);
  const ficaTaxable = Math.max(0, annualGross - preTaxDeductions); // Simplification: assuming pre-tax limits FICA (true for health, not 401k usually, but simplified here)
  
  const fica = calculateFICA(ficaTaxable, filingStatus);
  const federalTax = calculateFederalWithholding(federalTaxable, filingStatus);
  const stateTax = calculateStateWithholding(federalTaxable, stateCode);
  
  const totalTaxes = federalTax + stateTax + fica.totalFICA;
  const netPay = annualGross - totalTaxes - preTaxDeductions - postTaxDeductions;
  
  const effectiveTaxRate = annualGross > 0 ? (totalTaxes / annualGross) * 100 : 0;
  const takeHomePercentage = annualGross > 0 ? (netPay / annualGross) * 100 : 0;

  return {
    annualGross,
    federalTax,
    stateTax,
    fica,
    preTaxDeductions,
    postTaxDeductions,
    totalTaxes,
    totalDeductions: preTaxDeductions + postTaxDeductions,
    netPay,
    effectiveTaxRate,
    takeHomePercentage
  };
};