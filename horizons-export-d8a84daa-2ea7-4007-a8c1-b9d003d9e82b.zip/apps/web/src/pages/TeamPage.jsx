import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { User, ArrowRight, BookOpen, Linkedin } from 'lucide-react';
import PageSeo from '@/components/PageSeo.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';
import { AUTHORS } from '@/data/authors.js';

export default function TeamPage() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <PageSeo path="/about/team" type="profile" />

      <section className="bg-primary py-16 text-primary-foreground lg:py-20">
        <div className="container mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="mb-4 text-4xl font-extrabold leading-tight md:text-5xl" style={{ letterSpacing: '-0.02em' }}>
              Our Team
            </h1>
            <p className="text-xl text-primary-foreground/90 leading-relaxed max-w-2xl">
              The people who research, write, and maintain every calculator and guide on SmartMoneyTools.
            </p>
          </motion.div>
        </div>
      </section>

      <div className="container mx-auto max-w-4xl px-4 pt-6 sm:px-6 lg:px-8">
        <Breadcrumb items={[{ label: 'About', href: '/about' }, { label: 'Team' }]} />
      </div>

      <main className="flex-grow py-10 lg:py-14">
        <div className="container mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="prose prose-lg prose-slate max-w-none text-muted-foreground prose-headings:text-foreground prose-a:text-primary hover:prose-a:text-primary/80 prose-strong:text-foreground">
            <p className="text-lg leading-relaxed">
              SmartMoneyTools is written and maintained by Shaun Da Silva. Every calculator and
              guide carries a byline so you always know who is responsible for the figures and
              explanations you are reading.
            </p>
          </div>

          <ul className="mt-10 space-y-6 not-prose">
            {AUTHORS.map((author) => (
              <li
                key={author.slug}
                className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-6 shadow-sm sm:flex-row sm:items-start"
              >
                <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                  <User className="h-8 w-8 text-primary" />
                </div>
                <div className="flex-1">
                  <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                    <Link
                      to={author.profilePath}
                      className="text-xl font-bold text-foreground hover:text-primary transition-colors"
                    >
                      {author.name}
                    </Link>
                    <span className="text-sm font-medium text-primary">{author.credential}</span>
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{author.fullBio}</p>
                  <Link
                    to={author.profilePath}
                    className="mt-3 inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
                  >
                    View full profile <ArrowRight className="h-4 w-4" />
                  </Link>
                  <a
                    href="https://www.linkedin.com/in/shaun-da-silva-748b91a2/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2 inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
                  >
                    <Linkedin className="h-4 w-4" /> Connect on LinkedIn
                  </a>
                </div>
              </li>
            ))}
          </ul>

          <div className="mt-12 flex flex-wrap gap-3 border-t border-border pt-8 not-prose">
            <Link
              to="/guides"
              className="inline-flex items-center gap-2 rounded-lg bg-muted px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted/80"
            >
              <BookOpen className="h-4 w-4" /> Browse the guides
            </Link>
            <Link
              to="/about"
              className="inline-flex items-center gap-2 rounded-lg bg-muted px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted/80"
            >
              About SmartMoneyTools
            </Link>
            <Link
              to="/editorial-policy"
              className="inline-flex items-center gap-2 rounded-lg bg-muted px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted/80"
            >
              Editorial Policy
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}
