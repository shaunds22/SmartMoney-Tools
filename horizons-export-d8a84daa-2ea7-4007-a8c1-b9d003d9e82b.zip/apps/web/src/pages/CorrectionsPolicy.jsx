import React from 'react';
import PageSeo from '@/components/PageSeo.jsx';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { AlertCircle, Search, Clock, Bell, RefreshCw, Mail } from 'lucide-react';
import Breadcrumb from '@/components/Breadcrumb.jsx';

export default function CorrectionsPolicy() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageSeo
        title="Corrections Policy | SmartMoneyTools"
        description="How SmartMoneyTools investigates and corrects errors in calculators and guides. Learn how to report a mistake and what happens next."
        path="/corrections-policy"
      />

      <section className="bg-primary text-primary-foreground py-12 border-b border-primary/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <h1 className="text-4xl md:text-5xl font-extrabold mb-4 leading-tight" style={{ letterSpacing: '-0.02em' }}>
              Corrections Policy
            </h1>
            <p className="text-lg text-primary-foreground/85">
              How we handle errors, update our calculators, and keep you informed when significant corrections are made.
            </p>
          </motion.div>
        </div>
      </section>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl pt-6 pb-0">
        <Breadcrumb items={[{ label: 'Corrections Policy' }]} />
      </div>

      <main className="flex-grow py-10 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">

          <div className="bg-primary/5 border border-primary/20 rounded-xl px-6 py-4 mb-10">
            <p className="text-sm text-foreground leading-relaxed">
              <strong>Our commitment:</strong> When a calculator or guide contains a material error, we correct it promptly, update the "Last reviewed" date, and — where the error was significant — disclose what changed. We do not silently delete or backdate content to hide mistakes.
            </p>
          </div>

          <div className="prose prose-slate max-w-none text-muted-foreground prose-headings:text-foreground prose-a:text-primary hover:prose-a:text-primary/80 prose-strong:text-foreground space-y-2">

            <h2 className="flex items-center gap-3 text-2xl font-semibold text-foreground mt-10 mb-4">
              <AlertCircle className="w-6 h-6 text-primary shrink-0" /> 1. How to Report an Error
            </h2>
            <p>
              If you believe a calculator result, tax threshold, rate, or any other figure on SmartMoneyTools is incorrect, please tell us. You can report errors by:
            </p>
            <ul>
              <li><strong>Email:</strong> <a href="mailto:support@smartmoney-tools.com">support@smartmoney-tools.com</a> — use the subject line "Error Report".</li>
              <li><strong>Contact form:</strong> Visit our <Link to="/contact">Contact page</Link> and select <em>Calculation Issue / Bug Report</em> from the category dropdown.</li>
              <li><strong>Report an error link:</strong> Every calculator page carries a "Report an error" link in the author attribution bar at the top of the content area.</li>
            </ul>
            <p>
              To help us investigate quickly, please include: the page URL, the calculator name, the inputs you entered, the result the calculator produced, the result you believe is correct, and a link to the official source supporting your claim (for example, a GOV.UK or HMRC page).
            </p>

            <h2 className="flex items-center gap-3 text-2xl font-semibold text-foreground mt-10 mb-4">
              <Search className="w-6 h-6 text-primary shrink-0" /> 2. How We Investigate Reports
            </h2>
            <p>
              Every error report is reviewed by Shaun Da Silva, who writes and maintains the site. Our investigation process involves:
            </p>
            <ol>
              <li><strong>Acknowledging receipt</strong> within 2 business days.</li>
              <li><strong>Verifying the claim</strong> against the official primary source (see section 3 below).</li>
              <li><strong>Reproducing the issue</strong> by running the calculator with the reported inputs.</li>
              <li><strong>Checking the underlying code</strong> to identify whether the error is a formula error, a data-entry error, or an outdated statutory value.</li>
              <li><strong>Consulting secondary sources</strong> if the primary sources are ambiguous or transitional (for example, during a tax year changeover).</li>
            </ol>
            <p>
              We do not dismiss reports without investigation. If we conclude the calculator is correct, we will explain the reasoning and the source that supports our figure.
            </p>

            <h2 className="flex items-center gap-3 text-2xl font-semibold text-foreground mt-10 mb-4">
              <Search className="w-6 h-6 text-primary shrink-0" /> 3. Official Sources We Check
            </h2>
            <p>
              When verifying UK statutory rates and allowances, we consult the following primary sources:
            </p>
            <ul>
              <li>HM Revenue & Customs (HMRC) — <a href="https://www.gov.uk/government/organisations/hm-revenue-customs" target="_blank" rel="noopener noreferrer">gov.uk/hmrc</a></li>
              <li>GOV.UK income tax rates — <a href="https://www.gov.uk/income-tax-rates" target="_blank" rel="noopener noreferrer">gov.uk/income-tax-rates</a></li>
              <li>GOV.UK National Insurance rates — <a href="https://www.gov.uk/national-insurance-rates-letters" target="_blank" rel="noopener noreferrer">gov.uk/national-insurance-rates-letters</a></li>
              <li>GOV.UK student loan repayment thresholds — <a href="https://www.gov.uk/repaying-your-student-loan" target="_blank" rel="noopener noreferrer">gov.uk/repaying-your-student-loan</a></li>
              <li>The Pensions Regulator — <a href="https://www.thepensionsregulator.gov.uk" target="_blank" rel="noopener noreferrer">thepensionsregulator.gov.uk</a></li>
              <li>MoneyHelper — <a href="https://www.moneyhelper.org.uk" target="_blank" rel="noopener noreferrer">moneyhelper.org.uk</a></li>
            </ul>
            <p>For US statutory rates, we consult:</p>
            <ul>
              <li>Internal Revenue Service (IRS) — <a href="https://www.irs.gov" target="_blank" rel="noopener noreferrer">irs.gov</a></li>
              <li>Social Security Administration (SSA) — <a href="https://www.ssa.gov" target="_blank" rel="noopener noreferrer">ssa.gov</a></li>
              <li>US Department of Labor — <a href="https://www.dol.gov" target="_blank" rel="noopener noreferrer">dol.gov</a></li>
            </ul>

            <h2 className="flex items-center gap-3 text-2xl font-semibold text-foreground mt-10 mb-4">
              <Clock className="w-6 h-6 text-primary shrink-0" /> 4. Correction Timeline
            </h2>
            <p>Our target timelines, measured from the date an error is confirmed:
            </p>
            <ul>
              <li><strong>Critical errors</strong> (incorrect statutory rate or threshold that materially affects calculator outputs): corrected within <strong>24–48 hours</strong>.</li>
              <li><strong>Significant errors</strong> (material factual error in a guide or content page): corrected within <strong>3–5 business days</strong>.</li>
              <li><strong>Minor errors</strong> (typos, broken links, formatting issues): corrected within <strong>7–14 business days</strong>.</li>
            </ul>
            <p>
              During periods of legislative change (for example, immediately after a UK Budget announcement or a US IRS inflation adjustment publication), we prioritise statutory rate updates above all other content work.
            </p>

            <h2 className="flex items-center gap-3 text-2xl font-semibold text-foreground mt-10 mb-4">
              <Bell className="w-6 h-6 text-primary shrink-0" /> 5. How Significant Corrections Are Disclosed
            </h2>
            <p>
              When a material error is corrected, we:
            </p>
            <ul>
              <li>Update the <strong>"Last reviewed"</strong> date displayed in the author attribution bar and in any source tables on the affected page.</li>
              <li>Add a correction note near the top of the affected section if the error could have materially misled users (for example, an incorrect tax rate that understated a tax bill).</li>
              <li>Retain the correction note for at least 30 days before removing it.</li>
            </ul>
            <p>
              We do <strong>not</strong> silently delete or backdate content, replace the original wording without disclosure, or prevent cached versions from being crawled.
            </p>

            <h2 className="flex items-center gap-3 text-2xl font-semibold text-foreground mt-10 mb-4">
              <RefreshCw className="w-6 h-6 text-primary shrink-0" /> 6. Revision Date Updates
            </h2>
            <p>
              Every calculator and guide page carries a <strong>"Last reviewed"</strong> date. This date is updated whenever:
            </p>
            <ul>
              <li>A statutory rate, threshold, or limit is corrected or refreshed.</li>
              <li>A material factual error in the surrounding guide text is corrected.</li>
              <li>The underlying calculation logic is changed.</li>
              <li>A new tax year or IRS inflation-adjustment cycle is applied.</li>
            </ul>
            <p>
              Minor copy edits (fixing a typo, improving a sentence for clarity) that do not affect accuracy do not trigger a revision date update.
            </p>

            <h2 className="flex items-center gap-3 text-2xl font-semibold text-foreground mt-10 mb-4">
              <Mail className="w-6 h-6 text-primary shrink-0" /> 7. Contact for Error Reports
            </h2>
            <p>
              Reach the author via:
            </p>
            <ul>
              <li><strong>Email:</strong> <a href="mailto:support@smartmoney-tools.com">support@smartmoney-tools.com</a></li>
              <li><strong>Contact form:</strong> <Link to="/contact">smartmoney-tools.com/contact</Link> — select "Calculation Issue / Bug Report"</li>
            </ul>
            <p>
              We aim to acknowledge every report within 2 business days. We do not guarantee that we will agree with every correction request, but we commit to investigating every report and explaining our conclusion.
            </p>

            <div className="mt-12 pt-8 border-t border-border text-sm text-muted-foreground">
              <p>Related policies: <Link to="/editorial-policy">Editorial Policy</Link> · <Link to="/calculation-methodology">Calculation Methodology</Link> · <Link to="/contact">Contact Us</Link></p>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
}
