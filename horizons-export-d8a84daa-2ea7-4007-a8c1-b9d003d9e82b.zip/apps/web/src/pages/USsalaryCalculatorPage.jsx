import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import GuideLayout from '@/components/GuideLayout.jsx';
import USsalaryCalculatorForm from '@/components/USsalaryCalculatorForm.jsx';
import USsalaryCalculatorResults from '@/components/USsalaryCalculatorResults.jsx';
import FAQAccordion from '@/components/FAQAccordion.jsx';
import DisclaimerBanner from '@/components/DisclaimerBanner.jsx';
import HowWeCalculateThis from '@/components/HowWeCalculateThis.jsx';
import { calculateNetPay } from '@/utils/usSalaryCalculations.js';
import { setPageMeta, setCanonicalTag } from '@/utils/seo.js';
import AuthorAttribution from '@/components/AuthorAttribution.jsx';
import useCurrencyDefault from '@/hooks/useCurrencyDefault.js';

export default function USsalaryCalculatorPage() {
  const [results, setResults] = useState(null);

  // US-specific page: default to US dollars until the visitor picks a currency
  useCurrencyDefault('USD');

  useEffect(() => {
    // Reset state on mount
    setResults(null);
    
    setPageMeta(
      'US Salary Calculator 2026 | Estimate Take-Home Pay',
      'Free 2026 US salary calculator to estimate your net take-home pay after federal taxes, state taxes, Social Security, Medicare, and deductions.',
      'https://smartmoney-tools.com/us-salary-calculator'
    );
  }, []);

  const handleCalculate = (data) => {
    const calcResults = calculateNetPay(data);
    setResults(calcResults);
  };

  // FAQ items with proper structure
  const faqItems = [
    { 
      question: 'How do I calculate my take-home pay in the USA?', 
      answer: 'To calculate take-home pay, subtract federal income tax, state income tax, Social Security (6.2%), Medicare (1.45%), and any workplace deductions from your gross pay.' 
    },
    { 
      question: 'What is the difference between gross pay and net pay?', 
      answer: 'Gross pay is your total earnings before any taxes or deductions are removed. Net pay is the amount you actually receive in your bank account after all taxes, benefits, and garnishments are deducted.' 
    },
    { 
      question: 'How much federal tax is taken from a paycheck?', 
      answer: 'Federal tax withholding depends on your taxable income, filing status, and information provided on your Form W-4. The US uses a progressive tax system where higher income tiers are taxed at higher percentages (10% up to 37%).' 
    },
    { 
      question: 'What percentage is Social Security tax?', 
      answer: 'The Social Security tax rate is 6.2% for employees, levied on earnings up to the annual wage base limit ($184,500 for 2026).' 
    },
    { 
      question: 'What percentage is Medicare tax?', 
      answer: 'The Medicare tax rate is 1.45% for employees, applied to all covered wages with no upper limit.' 
    },
    { 
      question: 'Is there a maximum amount of Social Security tax?', 
      answer: 'Yes. Social Security tax is only withheld up to the wage base limit. Earnings above this threshold are not subject to the 6.2% tax.' 
    },
    { 
      question: 'What is Additional Medicare Tax?', 
      answer: 'An extra 0.9% Additional Medicare Tax is withheld on earnings exceeding specific thresholds ($200,000 for single filers, $250,000 for married filing jointly).' 
    },
    { 
      question: 'Which states do not levy individual wage income tax?', 
      answer: 'Currently, Alaska, Florida, Nevada, New Hampshire, South Dakota, Tennessee, Texas, Washington, and Wyoming do not tax individual wage income.' 
    },
    { 
      question: 'Is biweekly pay the same as semi-monthly pay?', 
      answer: 'No. Biweekly means you are paid every two weeks (26 paychecks per year). Semi-monthly means you are paid twice a month (24 paychecks per year).' 
    },
    { 
      question: 'Do 401(k) contributions reduce payroll taxes?', 
      answer: 'Traditional 401(k) contributions reduce your taxable income for federal and state income taxes, but they do NOT reduce your wages for Social Security and Medicare taxes (FICA).' 
    },
    { 
      question: 'How are bonuses taxed?', 
      answer: 'Bonuses are considered supplemental wages. Employers typically withhold federal tax on bonuses at a flat rate of 22% (or higher for massive bonuses), plus applicable state and FICA taxes.' 
    },
    { 
      question: 'Why is my actual paycheck different from the calculator?', 
      answer: 'Calculators use standard withholding formulas. Your actual paycheck may vary based on exact W-4 allowances, mid-year salary changes, local city taxes, pre-tax benefit premiums (like health insurance), and rounding differences in employer payroll software.' 
    },
    { 
      question: 'Does this calculator calculate my tax refund?', 
      answer: 'No. This tool estimates your paycheck withholding, not your end-of-year tax liability or refund.' 
    },
    { 
      question: 'Can I use this calculator if I live and work in different states?', 
      answer: 'This calculator applies the tax rules for the state selected. If you live and work in different states, you may be subject to complex reciprocity agreements and should consult a tax professional.' 
    }
  ];

  return (
    <GuideLayout
      title="US Salary Calculator 2026 – Estimate Your Take-Home Pay"
      description="Calculate your net pay after federal, state, and local taxes. See exactly where your money goes with our 2026 paycheck calculator."
      url="/us-salary-calculator"
      lastUpdated="2026-09-11"
    >
      <Helmet>
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": faqItems.map(faq => ({
              "@type": "Question",
              "name": faq.question,
              "acceptedAnswer": {
                "@type": "Answer",
                "text": faq.answer
              }
            }))
          })}
        </script>
      </Helmet>

      <div className="mb-4">
        <span className="inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-sm font-medium text-primary border border-primary/20">Tax Year: 2026 · Last reviewed: 11 September 2026</span>
      </div>
      <AuthorAttribution lastReviewedDate="2026-09-11" />
      <div className="mb-8 max-w-prose">
        <p className="text-lg text-muted-foreground leading-relaxed">
          Wondering how much of your salary you'll actually keep? Our US Salary Calculator estimates your federal withholding, state taxes, Social Security, Medicare, and net pay. Adjust your location, filing status, and deductions to see your true take-home pay for the 2026 tax year.
        </p>
      </div>

      <DisclaimerBanner />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-16">
        <div className="lg:col-span-7">
          <USsalaryCalculatorForm onCalculate={handleCalculate} />
        </div>
        <div className="lg:col-span-5">
          <div className="sticky top-24">
            <USsalaryCalculatorResults results={results} />
          </div>
        </div>
      </div>

      <HowWeCalculateThis region="US" />

      <div className="prose prose-slate dark:prose-invert max-w-none space-y-12">
        <section className="guide-section">
          <h2>How the US salary calculator works</h2>
          <p>
            Understanding your paycheck requires untangling a web of federal, state, and local tax rules. This calculator uses the IRS Publication 15-T percentage method alongside 2026 federal brackets and state-specific formulas to provide an accurate estimate of your net income.
          </p>
          <p>
            You start by entering your gross pay (annual salary or hourly wage). We then apply the standard deduction for your filing status, calculate your federal income tax, deduct the flat 7.65% for FICA (Social Security and Medicare), and apply the specific tax rules for your state.
          </p>
        </section>

        <section className="guide-section">
          <h2>Gross pay versus net pay</h2>
          <p>
            <strong>Gross pay</strong> is the big number on your offer letter—it's the total amount you earn before the government or your employer touches a dime. 
          </p>
          <p>
            <strong>Net pay</strong> (or take-home pay) is what actually hits your checking account on payday. The gap between gross and net is filled by mandatory taxes, voluntary retirement contributions, and insurance premiums. 
          </p>
        </section>

        <section className="guide-section">
          <h2>How federal income tax withholding works</h2>
          <p>
            The US operates on a progressive tax system. You aren't taxed a single flat rate; instead, your income fills up "buckets" (tax brackets). The first bucket is taxed at 10%, the next at 12%, and so on. Employers use the information you provide on your Form W-4 to estimate how much to withhold from each paycheck so you don't owe a massive bill in April.
          </p>
        </section>

        <section className="guide-section">
          <h2>Social Security and Medicare (FICA)</h2>
          <p>
            The Federal Insurance Contributions Act (FICA) funds Social Security and Medicare. 
          </p>
          <ul>
            <li><strong>Social Security:</strong> 6.2% of your gross pay, but only up to an annual limit (the wage base). Once you earn more than this limit, you stop paying the 6.2% for the rest of the year.</li>
            <li><strong>Medicare:</strong> 1.45% of your gross pay, with no upper limit.</li>
            <li><strong>Additional Medicare:</strong> If you earn over $200,000 (Single) or $250,000 (Married Filing Jointly), an extra 0.9% is withheld on the excess amount.</li>
          </ul>
        </section>

        <section className="guide-section">
          <h2>Who this calculator is for</h2>
          <p>This tool is built for US employees paid through regular payroll who want to know what actually lands in their bank account. It suits anyone comparing job offers across states, deciding how much to contribute to a 401(k), or checking whether their withholding is on track for the 2026 tax year.</p>
          <p>It is <em>not</em> designed for self-employment income (which uses SE tax rules), complex multi-state situations, or estimating your end-of-year refund — it models per-paycheck withholding, not final tax liability.</p>
        </section>

        <section className="guide-section">
          <h2>What you need before you start</h2>
          <ul>
            <li>Your <strong>gross pay</strong> — annual salary, or hourly wage and hours — before any deductions.</li>
            <li>Your <strong>pay frequency</strong> (weekly, biweekly, semi-monthly, monthly) and <strong>filing status</strong> from your W-4.</li>
            <li>Your <strong>state</strong> of employment, since state income tax varies widely and several states levy none.</li>
            <li>Any <strong>pre-tax deductions</strong> you want to model — chiefly 401(k) contributions, which lower federal and state taxable income but not FICA.</li>
          </ul>
        </section>

        <section className="guide-section">
          <h2>What each input means</h2>
          <ul>
            <li><strong>Gross pay / hourly wage</strong> — your total earnings before taxes. Enter an annual salary or an hourly rate with hours worked.</li>
            <li><strong>Pay frequency</strong> — how often you're paid. Biweekly (26 checks) and semi-monthly (24 checks) are not the same and change the per-check amount.</li>
            <li><strong>Filing status</strong> — Single, Married Filing Jointly, or Head of Household. This sets your standard deduction and bracket widths.</li>
            <li><strong>State</strong> — determines whether state income tax is withheld and at what effective rate. Nine states have no individual wage income tax.</li>
            <li><strong>401(k) contribution</strong> — pre-tax retirement savings that reduce federal and state taxable income but leave FICA unchanged. The 2026 employee limit is $24,500.</li>
          </ul>
        </section>

        <section className="guide-section">
          <h2>How to read your results</h2>
          <p>The headline figure is your <strong>net (take-home) pay</strong> per paycheck and per year. The breakdown shows each layer that's removed: federal income tax (progressive, based on brackets and your standard deduction), FICA (a flat 7.65% — 6.2% Social Security up to the wage base plus 1.45% Medicare with no cap), state income tax, and your 401(k) contribution.</p>
          <p>A useful check: FICA should be roughly 7.65% of gross until you cross the Social Security wage base ($184,500 for 2026), after which it drops to 1.45% for the rest of the year. If your federal tax looks very different from a colleague's on the same salary, the usual cause is a different W-4 (extra withholding or fewer allowances) rather than a calculation error.</p>
        </section>

        <section className="guide-section">
          <h2>Worked example</h2>
          <p>A single filer in a state with no income tax, earning $75,000 a year, paid biweekly, contributing 5% to a 401(k):</p>
          <ul>
            <li><strong>Gross annual:</strong> $75,000 → ~$2,885 gross per biweekly check.</li>
            <li><strong>401(k) (5%):</strong> $3,750/year pre-tax, lowering federal taxable income to $71,250.</li>
            <li><strong>Standard deduction (Single):</strong> $16,100 (2026), so $55,150 is taxed across the 10% and 12% brackets.</li>
            <li><strong>Federal income tax:</strong> 10% on the first $12,400 ($1,240) + 12% on the remaining $42,750 ($5,130) ≈ $6,370.</li>
            <li><strong>FICA (7.65%):</strong> ~$5,738/year on the full $75,000 (401(k) doesn't reduce FICA).</li>
            <li><strong>Result:</strong> roughly $6,370 in federal tax and $5,738 in FICA, leaving a take-home of around $59,100/year — about $2,275 per biweekly check.</li>
          </ul>
          <p>Numbers are illustrative; exact withholding depends on the IRS Publication 15-T formula and your W-4 entries.</p>
        </section>

        <section className="guide-section">
          <h2>Common mistakes to avoid</h2>
          <ul>
            <li><strong>Confusing gross with net when budgeting.</strong> A $75,000 offer does not mean $6,250 a month to spend — plan against take-home.</li>
            <li><strong>Forgetting that 401(k) doesn't cut FICA.</strong> Pre-tax contributions lower income tax but Social Security and Medicare still apply to the full gross.</li>
            <li><strong>Ignoring state and local tax.</strong> Some cities (e.g. New York City, Philadelphia) levy their own income tax on top of the state's.</li>
            <li><strong>Treating the estimate as your refund.</strong> This tool shows withholding, not your final tax bill; credits like the Child Tax Credit or EITC can change what you actually owe at filing.</li>
          </ul>
        </section>

        <section className="guide-section">
          <h2>Frequently Asked Questions</h2>
          <FAQAccordion faqItems={faqItems} />
        </section>

        <section className="guide-section">
          <h2>Sensible next steps</h2>
          <ul>
            <li>Compare your estimated take-home to your actual pay stub. Large gaps usually mean a W-4 adjustment is needed — submit a new one to your payroll department.</li>
            <li>If you're not yet capturing the full employer 401(k) match, increase your contribution first — that match is free money.</li>
            <li>Use the result to build a monthly budget, then direct any surplus to an emergency fund or debt.</li>
            <li>For a full retirement projection including Social Security and 401(k) growth, try our <Link to="/us-retirement-calculator" className="text-primary hover:underline">US Retirement Calculator</Link>.</li>
          </ul>
        </section>

        <section className="guide-section">
          <h2>Related tools</h2>
          <ul>
            <li><Link to="/us-retirement-calculator" className="text-primary hover:underline">US Retirement Calculator</Link>: Project 401(k), IRA, and Social Security income for retirement.</li>
            <li><Link to="/compound-interest" className="text-primary hover:underline">Compound Interest Calculator</Link>: Model how invested savings grow over time.</li>
            <li><Link to="/budget-planner" className="text-primary hover:underline">Budget Planner</Link>: Allocate your take-home pay across needs, wants, and savings.</li>
          </ul>
        </section>

        <section className="guide-section mt-12 pt-8 border-t border-border">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-4">Sources, Assumptions &amp; Accuracy Statement</h3>
          <p className="text-sm bg-primary/5 p-3 rounded-lg border border-primary/20 mb-4">SmartMoneyTools checks statutory rates and thresholds against official government publications. Results are estimates for educational purposes and may not reflect every individual circumstance. <strong>Tax year: 2026. Last reviewed: 2 November 2026.</strong></p>

          <h4 className="font-semibold text-sm text-foreground mt-4 mb-2">Assumptions</h4>
          <ul className="text-sm space-y-1 text-muted-foreground mb-4">
            <li>Standard 2026 federal tax brackets and standard deduction applied (IRS Rev. Proc. 2025-32 / Publication 15-T).</li>
            <li>No itemized deductions – standard deduction only ($16,100 single / $32,200 MFJ for 2026).</li>
            <li>W-4 default withholding with no additional per-period withholding amount.</li>
            <li>Social Security wage base cap: $184,500 (2026).</li>
            <li>Medicare Additional Tax (0.9%) applies above $200,000 (single) / $250,000 (MFJ).</li>
            <li>State taxes use simplified flat/effective-rate estimates – consult your state DOR for exact figures.</li>
            <li>No tax credits (Child Tax Credit, EITC, etc.) applied.</li>
          </ul>

          <h4 className="font-semibold text-sm text-foreground mt-4 mb-2">What This Calculator Does Not Include</h4>
          <ul className="text-sm space-y-1 text-muted-foreground mb-6">
            <li>City/local income taxes (e.g., New York City, Philadelphia).</li>
            <li>State Disability Insurance (SDI) in CA, NJ, NY, HI, RI, WA.</li>
            <li>Tax credits or itemized deductions.</li>
            <li>Self-employment income (use SE tax rules separately).</li>
          </ul>

          <h4 className="font-semibold text-sm text-foreground mb-2">Data Source Table</h4>
          <div className="overflow-x-auto">
            <table className="w-full text-sm border-collapse">
              <thead><tr className="bg-muted text-left"><th className="p-2 font-semibold border border-border">Data Item</th><th className="p-2 font-semibold border border-border">Value Used</th><th className="p-2 font-semibold border border-border">Period</th><th className="p-2 font-semibold border border-border">Source</th></tr></thead>
              <tbody>
                <tr><td className="p-2 border border-border">Federal tax withholding method</td><td className="p-2 border border-border">Percentage Method (IRS Pub 15-T)</td><td className="p-2 border border-border">2026</td><td className="p-2 border border-border"><a href="https://www.irs.gov/pub/irs-pdf/p15t.pdf" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">IRS Publication 15-T</a></td></tr>
                <tr><td className="p-2 border border-border">Standard deduction (Single)</td><td className="p-2 border border-border">$16,100</td><td className="p-2 border border-border">2026</td><td className="p-2 border border-border"><a href="https://www.irs.gov/newsroom/irs-provides-tax-inflation-adjustments-for-tax-year-2026" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">IRS</a></td></tr>
                <tr><td className="p-2 border border-border">Standard deduction (MFJ)</td><td className="p-2 border border-border">$32,200</td><td className="p-2 border border-border">2026</td><td className="p-2 border border-border"><a href="https://www.irs.gov/newsroom/irs-provides-tax-inflation-adjustments-for-tax-year-2026" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">IRS</a></td></tr>
                <tr><td className="p-2 border border-border">Social Security tax rate (employee)</td><td className="p-2 border border-border">6.2%</td><td className="p-2 border border-border">2026</td><td className="p-2 border border-border"><a href="https://www.ssa.gov/oact/cola/cbb.html" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">SSA – Contribution and Benefit Bases</a></td></tr>
                <tr><td className="p-2 border border-border">Social Security wage base</td><td className="p-2 border border-border">$184,500</td><td className="p-2 border border-border">2026</td><td className="p-2 border border-border"><a href="https://www.ssa.gov/oact/cola/cbb.html" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">SSA</a></td></tr>
                <tr><td className="p-2 border border-border">Medicare tax rate (employee)</td><td className="p-2 border border-border">1.45% (no cap)</td><td className="p-2 border border-border">2026</td><td className="p-2 border border-border"><a href="https://www.irs.gov/taxtopics/tc751" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">IRS Topic 751</a></td></tr>
                <tr><td className="p-2 border border-border">Additional Medicare Tax</td><td className="p-2 border border-border">0.9% above $200k (Single) / $250k (MFJ)</td><td className="p-2 border border-border">2026</td><td className="p-2 border border-border"><a href="https://www.irs.gov/taxtopics/tc751" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">IRS Topic 751</a></td></tr>
                <tr><td className="p-2 border border-border">401(k) employee contribution limit</td><td className="p-2 border border-border">$24,500</td><td className="p-2 border border-border">2026</td><td className="p-2 border border-border"><a href="https://www.irs.gov/newsroom/401k-limit-increases-to-24500-for-2026-ira-limit-increases-to-7500" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">IRS</a></td></tr>
                <tr><td className="p-2 border border-border">IRA contribution limit</td><td className="p-2 border border-border">$7,500 (+$1,100 catch-up)</td><td className="p-2 border border-border">2026</td><td className="p-2 border border-border"><a href="https://www.irs.gov/retirement-plans/cola-increases-for-dollar-limitations-on-benefits-and-contributions" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">IRS COLA limits</a></td></tr>
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </GuideLayout>
  );
}