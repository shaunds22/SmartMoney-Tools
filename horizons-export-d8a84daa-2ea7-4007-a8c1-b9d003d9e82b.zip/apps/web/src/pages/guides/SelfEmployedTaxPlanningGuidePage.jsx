import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import ChooseGuide from '@/components/ChooseGuide.jsx';
import { Link } from 'react-router-dom';

export default function SelfEmployedTaxPlanningGuidePage() {
  return (
    <GuideLayout
      title="Self-Employed Tax Planning Basics in the UK"
      description="Navigate Self Assessment, allowable expenses, and VAT with this survival guide for sole traders."
      url="/guides/self-employed-tax-planning"
      lastUpdated="2026-09-11"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <ChooseGuide items={[
              { question: 'How taxable profit is calculated?', path: '/guides/self-employment-income', text: 'self-employment income guide' },
              { question: 'Estimate the tax on my profit?', path: '/self-employed-tax-calculator', text: 'self-employed tax calculator' },
            ]} />
            <p>
              For UK sole traders who have moved past the basics of turnover and profit and want to legally reduce what they owe. Where the <Link to="/guides/self-employment-income" className="text-primary hover:underline font-medium">self-employment income guide</Link> explains how taxable profit is calculated, this one covers the planning moves — expense claims, pension wrappers, payments on account and VAT — that lower the bill or prevent nasty January surprises.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The January cash-flow trap',
          content: (<>
            <p>
              The single biggest risk for new sole traders is not the tax itself but its timing. If your bill exceeds £1,000, HMRC assumes you will owe similar next year and collects advance "payments on account" — half in January, half in July. Your first January bill is therefore roughly 150% of what you expected: this year's balance plus half of next year's estimate. Plan for it from day one.
            </p>
          </>),
        },
        {
          type: 'step-by-step',
          title: 'Move 1 — claim everything allowable',
          content: (<>
            <p>
              You are taxed on profit, so legitimate expenses directly reduce the bill. Common ones sole traders miss:
            </p>
            <ul>
              <li>Use of home as office — a proportion of heat, light and power, or the simplified flat-rate based on hours worked.</li>
              <li>Business proportion of mobile phone and broadband.</li>
              <li>Professional subscriptions relevant to your trade.</li>
              <li>Capital allowances on equipment (laptops, tools) rather than leaving the cost unrecovered.</li>
            </ul>
            <p>
              The rule is "wholly and exclusively" for the trade — see <a href="https://www.gov.uk/expenses-if-youre-self-employed" target="_blank" rel="noreferrer">GOV.UK: Self-employed expenses</a>. Everyday clothes and routine lunches do not qualify.
            </p>
          </>),
        },
        {
          type: 'step-by-step',
          title: 'Move 2 — the £1,000 Trading Allowance choice',
          content: (<>
            <p>
              If your expenses are small, claiming the flat £1,000 Trading Allowance instead of actual expenses can give a lower taxable profit. You cannot do both, so compare: if real costs are below £1,000, the allowance usually wins; above £1,000, actual expenses usually win.
            </p>
          </>),
        },
        {
          type: 'step-by-step',
          title: 'Move 3 — use a pension to pull profit out of higher rate',
          content: (<>
            <p>
              A SIPP contribution before 5 April reduces your taxable profit for that year. This is especially valuable if you are tipping into the 40% band.
            </p>
            <h3>Worked example: £60,000 turnover</h3>
            <ul>
              <li>Allowable expenses: £4,000 (home office, laptop, travel, software).</li>
              <li>Net profit: £56,000.</li>
              <li>Income Tax: £12,570 tax-free, 20% on £37,700 = £7,540, plus 40% on £5,730 = £2,292 → £9,832.</li>
              <li>Class 4 NI: 6% on £37,700 = £2,262, plus 2% on £5,730 = £114 → £2,376.</li>
              <li><strong>Total bill: ≈ £12,208.</strong></li>
            </ul>
            <p>
              Paying £6,000 into a SIPP before 5 April drops taxable profit to £50,000 — below the higher-rate threshold — removing the 40% slice entirely and securing tax relief on the retirement saving.
            </p>
          </>),
        },
        {
          type: 'step-by-step',
          title: 'Move 4 — watch the VAT threshold',
          content: (<>
            <p>
              If rolling 12-month turnover exceeds £90,000 you must register for VAT, charge 20% on invoices and file quarterly returns. Crossing the threshold by accident — a few large contracts late in the year — is a common sole-trader problem. Monitor your rolling turnover so you can register in good time. See <a href="https://www.gov.uk/vat-registration" target="_blank" rel="noreferrer">GOV.UK: VAT registration</a>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Common mistakes',
          content: (<>
            <ul>
              <li><strong>Spending the gross.</strong> Transfer 25–30% of every invoice to a separate tax account the day it clears. Never treat your business balance as personal money.</li>
              <li><strong>Mixing personal and business accounts.</strong> A dedicated business account turns year-end expense calculation from weeks into hours.</li>
              <li><strong>Missing deadlines.</strong> Register by 5 October; file and pay by 31 January. Late filing and late payment both carry automatic penalties.</li>
            </ul>
          </>),
        },
        {
          type: 'when-useful',
          title: 'When an accountant earns their fee',
          content: (<>
            <p>
              A simple sole trader with few expenses can self-file. Once you near the VAT threshold, consider incorporating, or have significant capital allowances, a good accountant typically saves more in tax planning than they charge.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              This covers sole traders only. Limited company directors face Corporation Tax, dividend tax and PAYE — different rules entirely. Tax bands, NI rates and the VAT threshold are 2026/27 and change each Budget. Forecast your bill with the <Link to="/self-employed-tax-calculator" className="text-primary hover:underline font-medium">UK Self-Employed Tax Calculator</Link> and manage variable income with the <Link to="/budget-planner" className="text-primary hover:underline font-medium">Budget Planner</Link>.
            </p>
          </>),
        },
      ]}
    />
  );
}
