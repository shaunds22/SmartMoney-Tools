import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import ChooseGuide from '@/components/ChooseGuide.jsx';
import { Link } from 'react-router-dom';

export default function EmergencyFundComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="Building an Emergency Fund: How Much and Where to Keep It"
      description="Work out exactly how large your UK emergency fund should be, build it in the right order, and keep it where it stays accessible and beats inflation."
      url="/guides/emergency-fund"
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <ChooseGuide items={[
              { question: 'Where to get the best return on cash?', path: '/guides/high-interest-savings', text: 'maximising high-interest savings' },
              { question: 'Shielding savings from tax?', path: '/guides/tax-free-savings', text: 'tax-free savings (ISAs) guide' },
            ]} />
            <p>
              An emergency fund is not an investment — it is insurance: a pool of instantly accessible cash reserved for urgent, unavoidable costs so that a broken boiler or a redundancy does not push you onto a credit card. This guide covers the why, how to size the target precisely, the order to build it in, and where to keep it so inflation does the least damage.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'What counts as an emergency',
          content: (<>
            <p>
              A useful test: if you would not put it on a high-interest credit card, do not take it from this fund. Genuine emergencies are urgent, necessary and unexpected — job loss, an essential car repair, a boiler failure in winter. Holidays, gifts and a new television are not emergencies; they belong in a separate sinking fund.
            </p>
          </>),
        },
        {
          type: 'step-by-step',
          title: 'Step 1 — size the target from essential spending',
          content: (<>
            <p>
              The target is based on <em>needs</em>, not <em>wants</em>. Add up only what you must pay to keep life stable:
            </p>
            <ul>
              <li>Rent or mortgage, and council tax.</li>
              <li>Utilities, broadband, mobile.</li>
              <li>Basic groceries and household essentials.</li>
              <li>Transport to work or job-hunting.</li>
              <li>Minimum payments on all debts.</li>
              <li>Essential childcare.</li>
            </ul>
            <p>
              Exclude dining out, subscriptions, holidays and luxuries. The <Link to="/budget-planner" className="text-primary hover:underline font-medium">Budget Planner</Link> helps separate the two.
            </p>
          </>),
        },
        {
          type: 'comparison-table',
          title: 'Step 2 — pick your months based on income risk',
          content: (
            <table className="w-full text-sm border border-border">
              <thead className="bg-muted">
                <tr>
                  <th className="text-left p-3 border-b border-border">Your situation</th>
                  <th className="text-left p-3 border-b border-border">Months of essentials</th>
                </tr>
              </thead>
              <tbody>
                <tr><td className="p-3 border-b border-border">Single, renting, secure job, no dependants</td><td className="p-3 border-b border-border">3</td></tr>
                <tr><td className="p-3 border-b border-border">Homeowner or family on one income</td><td className="p-3 border-b border-border">6</td></tr>
                <tr><td className="p-3 border-b border-border">Freelancer, sole trader, volatile industry</td><td className="p-3 border-b border-border">9–12</td></tr>
              </tbody>
            </table>
          ),
        },
        {
          type: 'worked-example',
          title: 'Worked example: a couple with one child, 6-month target',
          content: (<>
            <ul>
              <li>Mortgage &amp; council tax: £1,200</li>
              <li>Utilities &amp; broadband: £250</li>
              <li>Basic groceries: £400</li>
              <li>Transport &amp; insurance: £250</li>
              <li>Minimum debt payments: £100</li>
              <li><strong>Monthly baseline: £2,200 → 6-month target: £13,200</strong></li>
            </ul>
            <p>
              Saving £300/month reaches the target in about 3.5 years. Held in a 4.5% easy-access account, the final-year balance earns around £600 in interest, partly offsetting inflation.
            </p>
          </>),
        },
        {
          type: 'step-by-step',
          title: 'The build order: starter fund first',
          content: (<>
            <p>
              If you cannot afford the full target yet, do not wait. Build in stages:
            </p>
            <ol>
              <li><strong>Save £1,000 as a starter fund.</strong> This covers most minor emergencies and stops you taking on new debt while you work on the rest. One month's rent in reserve is infinitely better than none — even £50 a month, automated, builds momentum.</li>
              <li><strong>Clear high-interest consumer debt</strong> (credit cards, store cards). Paying 20% to clear a card beats earning 4% on cash.</li>
              <li><strong>Build the full 3–6 month fund.</strong> Only then redirect spare cash to investing or extra pension contributions.</li>
            </ol>
          </>),
        },
        {
          type: 'content',
          title: 'Where to keep it',
          content: (<>
            <p>
              The fund must be liquid and protected from loss, so never invest it in the stock market. Easy-access savings accounts, Premium Bonds and Cash ISAs all work. Within those, hunt for a competitive rate so inflation does the least damage — leaving £13,200 in a 0% current account is needlessly costly. See the <Link to="/guides/high-interest-savings" className="text-primary hover:underline font-medium">high-interest savings guide</Link> for comparing accounts.
            </p>
            <p>
              Watch the tax on the interest. A large fund at a good rate can exceed the Personal Savings Allowance (£1,000 for basic-rate payers, £500 for higher-rate payers). Holding the fund in a Cash ISA removes that risk entirely — see the <Link to="/guides/tax-free-savings" className="text-primary hover:underline font-medium">tax-free savings guide</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Do not over-save in cash',
          content: (<>
            <p>
              Once the target is reached, redirect further savings to investments and pensions, which historically outpace inflation. Holding £50,000 "just in case" has a real opportunity cost — the fund's purpose is safety, not growth. Find your timeline with the <Link to="/savings-goal-calculator" className="text-primary hover:underline font-medium">Savings Goal Calculator</Link>.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              The right number depends on your job security, health, dependants and access to other credit — these are rules of thumb, not guarantees. Cash savings carry inflation risk. For tailored liquidity planning, a certified financial planner can help. General guidance at <a href="https://www.moneyhelper.org.uk/en/savings/building-your-savings" target="_blank" rel="noreferrer">MoneyHelper: Building your savings</a>.
            </p>
          </>),
        },
      ]}
    />
  );
}
