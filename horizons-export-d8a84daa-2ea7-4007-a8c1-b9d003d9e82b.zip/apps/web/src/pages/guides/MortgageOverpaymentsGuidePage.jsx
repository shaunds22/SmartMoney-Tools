import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';
import { MORTGAGE_SERIES } from '@/data/guideSeries.js';

export default function MortgageOverpaymentsGuidePage() {
  return (
    <GuideLayout
      title="Mortgage Overpayments: How Much Interest Could You Save?"
      description="Discover how overpaying your mortgage strips years off your term and saves tens of thousands in interest."
      url="/guides/mortgage-overpayments"
      series={MORTGAGE_SERIES}
      lastUpdated="2026-09-11"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              For homeowners on a repayment mortgage wondering whether overpaying is worth it. Because mortgage interest is charged daily on the outstanding balance, every extra pound you pay above the required amount goes straight at the principal — and permanently kills the interest that pound would have generated over the remaining term. This guide quantifies that effect and weighs it against the alternatives. For the mortgage product itself, see the <Link to="/guides/mortgage-comprehensive" className="text-primary hover:underline font-medium">comprehensive mortgage guide</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Why the early years feel so slow',
          content: (<>
            <p>
              A repayment mortgage is amortised so that interest dominates the early payments and principal dominates the later ones. On a £200,000 loan at 5%, the first month's interest is roughly £833; if your required payment is £1,100, only about £267 reduces the debt. That is why the balance barely moves in the first few years — and why overpayments, which bypass the interest calculation entirely, have an outsized effect early on.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked example: £250,000 at 4.5% over 25 years',
          content: (<>
            <p>
              The required monthly payment is about £1,389.
            </p>
            <div className="overflow-x-auto my-6">
              <table className="w-full text-sm border border-border">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left p-3 border-b border-border">Overpayment</th>
                    <th className="text-left p-3 border-b border-border">Term shortened by</th>
                    <th className="text-left p-3 border-b border-border">Interest saved</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="p-3 border-b border-border">£0</td><td className="p-3 border-b border-border">—</td><td className="p-3 border-b border-border">—</td></tr>
                  <tr><td className="p-3 border-b border-border">£100/month</td><td className="p-3 border-b border-border">≈ 2 years 11 months</td><td className="p-3 border-b border-border">≈ £23,500</td></tr>
                  <tr><td className="p-3 border-b border-border">£250/month</td><td className="p-3 border-b border-border">≈ 6 years 2 months</td><td className="p-3 border-b border-border">≈ £48,200</td></tr>
                </tbody>
              </table>
            </div>
            <p>
              An extra £250 a month — a meaningful but not extreme sum — clears the loan over six years early and saves nearly £50,000 in interest. Model your own balance and rate with the <Link to="/mortgage" className="text-primary hover:underline font-medium">Mortgage Calculator</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Reduce the term or reduce the payment?',
          content: (<>
            <p>
              When you overpay, lenders usually offer a choice: keep the monthly payment the same and finish earlier (reduce the term), or keep the original end date and lower your monthly payment. Reducing the term saves vastly more interest, because the debt is cleared sooner. Reducing the payment gives you monthly breathing room but costs more overall. Choose term reduction unless you specifically need the monthly cash flow.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Check your overpayment allowance first',
          content: (<>
            <p>
              Most fixed-rate mortgages let you overpay up to 10% of the outstanding balance each year without an Early Repayment Charge. Exceed that limit and the ERC — often 1–5% of the overpaid amount — can wipe out the benefit. Tracker and SVR mortgages often allow unlimited overpayments. Always confirm your limit in your mortgage terms before overpaying.
            </p>
          </>),
        },
        {
          type: 'when-useful',
          title: 'When overpaying is the wrong move',
          content: (<>
            <ul>
              <li><strong>You have higher-interest debt.</strong> Overpaying a 4% mortgage while carrying an 18% credit card balance is backwards — clear the expensive debt first.</li>
              <li><strong>You have no emergency fund.</strong> Money paid into a standard mortgage is locked in the equity; if you need it back, you generally cannot have it. Keep a liquid buffer first.</li>
              <li><strong>Investing could beat the mortgage rate.</strong> If your mortgage rate is 3% and a Stocks &amp; Shares ISA might reasonably return more over your horizon, investing the spare cash could leave you wealthier overall — though overpaying gives a guaranteed, risk-free return and peace of mind that investing cannot. Compare with the <Link to="/compound-interest" className="text-primary hover:underline font-medium">Compound Interest Calculator</Link>.</li>
            </ul>
          </>),
        },
        {
          type: 'content',
          title: 'Lump sum or monthly?',
          content: (<>
            <p>
              Because interest is calculated daily, reducing the balance sooner saves more. Overpaying £100 every month beats saving up £1,200 and paying it at year-end, because the monthly route starts shrinking the interest base immediately. If you have a lump sum now, paying it in now is better than dribbling it in.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              Figures are illustrative; lenders calculate interest daily and exact outcomes vary with payment dates and leap years. Always review your Key Facts Illustration and mortgage contract for your specific overpayment limits and ERCs. Overpayments yield a guaranteed return but lock cash into property equity; investments carry capital risk but stay accessible. For tailored advice on overpaying versus investing, an FCA-regulated adviser can help.
            </p>
          </>),
        },
      ]}
    />
  );
}
