import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';

export default function DebtRepaymentComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="Debt Repayment Strategies: Snowball vs Avalanche"
      description="Build a single structured plan to become debt-free — compare the snowball and avalanche methods, see the trade-off in numbers, and know when to seek free help."
      url="/guides/debt-repayment"
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              For people juggling several debts — credit cards, a store card, a personal loan, car finance — who need a single structured plan rather than spreading spare cash thinly across all of them. This guide covers the two mainstream methods, puts them side by side so the trade-off is visible, and explains when each fits. For combining debts into one loan, see <Link to="/guides/debt-consolidation" className="text-primary hover:underline font-medium">debt consolidation</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The one rule both methods share',
          content: (<>
            <p>
              Whatever you choose, keep paying the legal minimum on every debt — missing minimums triggers fees, defaults and credit-file damage. The strategy is only about where your <em>extra</em> cash goes each month. Find that extra amount first: comb your budget for surplus, then throw all of it at one target debt at a time. When that target clears, its full payment (minimum + extra) rolls onto the next — the "snowball" effect.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Two ways to pick the target',
          content: (<>
            <ul>
              <li><strong>The Avalanche</strong> targets the highest-APR debt first. It is mathematically optimal — you kill the most expensive debt fastest and pay the least interest overall.</li>
              <li><strong>The Snowball</strong> targets the smallest balance first, ignoring APR. It is psychologically optimal — clearing a debt entirely gives a quick win that keeps you motivated through a long plan.</li>
            </ul>
            <p>
              When the smallest balance also has the highest APR, the two methods agree. When they disagree, the Avalanche saves more money but the Snowball is easier to stick with — and a plan you stick with beats one you abandon.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Side by side: the same three debts',
          content: (<>
            <p>
              A borrower has £200 of extra cash each month and three debts:
            </p>
            <ul>
              <li><strong>Store card:</strong> £500 balance, 24% APR, £25 minimum.</li>
              <li><strong>Credit card:</strong> £3,000 balance, 19% APR, £60 minimum.</li>
              <li><strong>Car loan:</strong> £8,000 balance, 6% APR, £200 minimum.</li>
            </ul>
            <div className="overflow-x-auto my-6">
              <table className="w-full text-sm border border-border">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left p-3 border-b border-border">Method</th>
                    <th className="text-left p-3 border-b border-border">Order by</th>
                    <th className="text-left p-3 border-b border-border">First target</th>
                    <th className="text-left p-3 border-b border-border">Strength</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="p-3 border-b border-border">Snowball</td><td className="p-3 border-b border-border">Smallest balance</td><td className="p-3 border-b border-border">Store card (£500)</td><td className="p-3 border-b border-border">Quick win, motivation</td></tr>
                  <tr><td className="p-3 border-b border-border">Avalanche</td><td className="p-3 border-b border-border">Highest APR</td><td className="p-3 border-b border-border">Store card (24%)</td><td className="p-3 border-b border-border">Least interest overall</td></tr>
                </tbody>
              </table>
            </div>
            <p>
              Here the methods agree — the smallest balance also has the highest APR — so the Snowball's quick win and the Avalanche's maths point the same way. The disagreement only appears when the largest balance carries the highest rate.
            </p>
          </>),
        },
        {
          type: 'when-useful',
          title: 'When they disagree',
          content: (<>
            <p>
              Suppose the £8,000 car loan carried 24% APR instead of 6%. The Avalanche would attack it first — but at £200 extra against an £8,000 balance, the first debt would not vanish for around two years, and many borrowers give up before seeing a single balance hit zero. The Snowball would still clear the £500 store card in under three months, delivering the early win that keeps the plan alive. The Avalanche saves more money in theory; the Snowball succeeds more often in practice.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'A hybrid that often works well',
          content: (<>
            <p>
              Many people start with the Snowball to clear two or three small balances and build momentum, then switch to the Avalanche to crush the remaining large, high-rate debts mathematically. There is no rule against switching — the method serves the goal, not the other way round.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The cost of minimum payments',
          content: (<>
            <p>
              £5,000 on a credit card at 18% APR.
            </p>
            <ul>
              <li>Paying the £150 minimum: cleared in over 3 years, with roughly £1,500 of interest.</li>
              <li>Paying £300 a month: cleared in about 19 months, with roughly £750 of interest.</li>
              <li><strong>Doubling the payment roughly halves both the time and the interest.</strong></li>
            </ul>
            <p>
              Minimum payments are set deliberately low — that is how balances linger for years. Map your own payoff with the <Link to="/debt-snowball-calculator" className="text-primary hover:underline font-medium">Debt Snowball Calculator</Link>.
            </p>
          </>),
        },
        {
          type: 'step-by-step',
          title: 'Before you start: stop the bleeding',
          content: (<>
            <ol>
              <li><strong>Stop new borrowing.</strong> You cannot get out of a hole while still digging. Freeze or cut up the cards you are paying down.</li>
              <li><strong>List everything.</strong> Write down each debt's balance, minimum payment and APR — the full picture is less frightening than the vague worry.</li>
              <li><strong>Build a £1,000 starter emergency fund.</strong> Otherwise the next unexpected bill sends you straight back to the card you just cleared.</li>
            </ol>
          </>),
        },
        {
          type: 'content',
          title: 'Two things that override both methods',
          content: (<>
            <ul>
              <li><strong>Payday loans.</strong> With APRs that can run into four figures, these destroy any behavioural strategy — attack them immediately regardless of balance size.</li>
              <li><strong>Rolling payments over.</strong> When a debt clears, that payment must roll onto the next target, not back into your lifestyle. Absorbing it into spending breaks the snowball effect entirely.</li>
            </ul>
          </>),
        },
        {
          type: 'when-useful',
          title: 'When to seek free help instead',
          content: (<>
            <p>
              These strategies assume you have enough cash flow to meet all minimums and find some extra. If you cannot cover food, rent and minimums at the same time, an optimisation plan is not the right tool — contact a free debt charity such as <a href="https://www.stepchange.org" target="_blank" rel="noreferrer">StepChange</a> or <a href="https://www.citizensadvice.org.uk/debt-and-money/" target="_blank" rel="noreferrer">Citizens Advice</a> about formal solutions like a Debt Management Plan.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              The methods assume fixed balances and steady cash flow; real life has surprises. This is educational, not advice; for serious debt problems, a free debt adviser is the right first step. Find your extra cash with the <Link to="/budget-planner" className="text-primary hover:underline font-medium">Budget Planner</Link>.
            </p>
          </>),
        },
      ]}
    />
  );
}
