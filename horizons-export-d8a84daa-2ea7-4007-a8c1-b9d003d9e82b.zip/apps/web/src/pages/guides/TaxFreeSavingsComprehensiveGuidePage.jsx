import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';

export default function TaxFreeSavingsComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="The Guide to Tax-Free Savings (ISAs)"
      description="Shield your wealth using ISAs, Lifetime ISAs, and Premium Bonds."
      url="/guides/tax-free-savings"
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              For UK savers and investors whose cash interest or investment gains are starting to attract tax, and who want to understand which ISA wrapper fits their goal. ISAs are government-approved wrappers that shield money from Income Tax on interest, Dividend Tax and Capital Gains Tax — and once money is inside, the shelter is permanent. This is the wrapper guide; for comparing cash account rates see the <Link to="/guides/high-interest-savings" className="text-primary hover:underline font-medium">high-interest savings guide</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The £20,000 allowance — use it or lose it',
          content: (<>
            <p>
              You can put £20,000 into ISAs in each tax year, split across ISA types however you choose. The allowance resets on 6 April and unused allowance cannot be carried forward. So the timing rule is simple: if you have spare cash near the end of the tax year, funding the ISA before 5 April matters more than almost any rate-shopping. Rules and limits are at <a href="https://www.gov.uk/individual-savings-accounts" target="_blank" rel="noreferrer">GOV.UK: ISAs</a>.
            </p>
          </>),
        },
        {
          type: 'comparison-table',
          title: 'Which ISA for which goal',
          content: (
            <table className="w-full text-sm border border-border">
              <thead className="bg-muted">
                <tr>
                  <th className="text-left p-3 border-b border-border">Type</th>
                  <th className="text-left p-3 border-b border-border">Holds</th>
                  <th className="text-left p-3 border-b border-border">Best for</th>
                </tr>
              </thead>
              <tbody>
                <tr><td className="p-3 border-b border-border">Cash ISA</td><td className="p-3 border-b border-border">Cash savings</td><td className="p-3 border-b border-border">Emergency funds, short-term goals; interest always tax-free</td></tr>
                <tr><td className="p-3 border-b border-border">Stocks &amp; Shares ISA</td><td className="p-3 border-b border-border">Funds, shares, bonds</td><td className="p-3 border-b border-border">Goals 5+ years out; growth and dividends tax-free</td></tr>
                <tr><td className="p-3 border-b border-border">Lifetime ISA (LISA)</td><td className="p-3 border-b border-border">Cash or investments</td><td className="p-3 border-b border-border">First home (up to £450k) or retirement; 25% government bonus</td></tr>
                <tr><td className="p-3 border-b border-border">Innovative Finance ISA</td><td className="p-3 border-b border-border">Peer-to-peer loans</td><td className="p-3 border-b border-border">Higher risk, specialist use only</td></tr>
              </tbody>
            </table>
          ),
        },
        {
          type: 'content',
          title: 'The Lifetime ISA bonus — and its catch',
          content: (<>
            <p>
              A LISA is powerful for first-time buyers: pay in up to £4,000 a year and the government adds a 25% bonus (so £4,000 becomes £5,000), usable towards a first home up to £450,000. The catch is the withdrawal penalty: take the money out for anything other than a qualifying first home or retirement (age 60), and a 25% charge applies — which means you lose slightly more than the bonus, not just the bonus itself. So a LISA only suits money you are confident will go to a first home or stay until 60.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked example: allocating a £20,000 allowance',
          content: (<>
            <ul>
              <li>£4,000 into a Cash LISA → £5,000 after the 25% bonus, towards a first home deposit.</li>
              <li>£6,000 into a Cash ISA → emergency fund, tax-free interest.</li>
              <li>£10,000 into a Stocks &amp; Shares ISA → long-term index-fund investment.</li>
              <li><strong>Result:</strong> the full £20,000 allowance used, all future growth and interest permanently tax-free.</li>
            </ul>
          </>),
        },
        {
          type: 'content',
          title: 'Transferring ISAs without breaking the wrapper',
          content: (<>
            <p>
              You can move money between ISA providers, but you must use the official transfer process. Withdraw the cash yourself and re-deposit it and it counts against this year's allowance — and you may exceed it. Always initiate a transfer through the new provider.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Premium Bonds — the tax-free lottery alternative',
          content: (<>
            <p>
              NS&amp;I Premium Bonds pay no guaranteed interest; instead, each £1 bond enters a monthly prize draw with tax-free prizes. They suit higher-rate taxpayers with larger cash balances who have used their ISA allowance, because the prizes are tax-free and the capital is 100% backed by the Treasury. The trade-off is no guaranteed return and the risk of earning nothing in a given year.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              The £20,000 allowance, the £4,000 LISA limit, the £450,000 LISA property cap and the 25% withdrawal charge are 2026/27 rules and change with legislation. Investment ISAs can fall in value. This is educational, not advice. Project your ISA growth with the <Link to="/savings-goal-calculator" className="text-primary hover:underline font-medium">Savings Goal Calculator</Link> or <Link to="/compound-interest" className="text-primary hover:underline font-medium">Compound Interest Calculator</Link>.
            </p>
          </>),
        },
      ]}
    />
  );
}
