import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import ChooseGuide from '@/components/ChooseGuide.jsx';
import { Link } from 'react-router-dom';

export default function SavingsGoalsComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="Setting and Reaching Your Savings Goals"
      description="Turn a vague intention into a monthly number you can actually hit — size the target, stress-test it against your budget, and automate the habit."
      url="/guides/savings-goals"
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <ChooseGuide items={[
              { question: 'The maths of how regular deposits grow?', path: '/guides/compound-interest-monthly-deposits', text: 'compound interest with monthly deposits' },
              { question: 'How big should your cash safety net be?', path: '/guides/emergency-fund', text: 'building an emergency fund' },
            ]} />
            <p>
              For anyone saving towards a specific, named target — a house deposit, a car, a wedding, a year off — who wants to turn a vague intention into a monthly number they can actually hit. This guide covers both halves of the problem: the maths of reaching a target, and the behavioural side of setting a goal you will stick to.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Make the goal specific and time-bound',
          content: (<>
            <p>
              "Save for a house" fails because it has no number and no deadline. "Save a 10% deposit for a £250,000 house in 36 months" works because you can divide £25,000 by 36 and get a monthly figure of about £694. The transformation from intention to target happens the moment you attach a number and a date — specific, measurable, achievable, relevant and time-bound.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Reverse-engineer the monthly number',
          content: (<>
            <p>
              The whole method is one calculation: take your target, subtract what you have already saved, divide by the months remaining. Everything else is about making that number achievable and automatic.
            </p>
            <ul>
              <li><strong>£20,000 house deposit in 3 years:</strong> ≈ £555/month.</li>
              <li><strong>£5,000 emergency fund in 12 months:</strong> ≈ £416/month.</li>
              <li><strong>£15,000 car in 18 months:</strong> ≈ £833/month.</li>
            </ul>
            <p>
              These ignore interest. A competitive Cash ISA at 4% trims the monthly figure slightly because compound growth contributes the rest — the <Link to="/savings-goal-calculator" className="text-primary hover:underline font-medium">Savings Goal Calculator</Link> does this precisely.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The affordability stress test',
          content: (<>
            <p>
              This is the step most people skip, and it is why goals collapse. Take the monthly figure the maths gives you and lay it over your actual budget. If the goal needs £500 a month but you only have £200 of surplus after rent, food and bills, the goal is a fantasy — and pretending otherwise guarantees you abandon it. You have only three levers:
            </p>
            <ul>
              <li><strong>Lower the target</strong> — a cheaper car, a smaller deposit.</li>
              <li><strong>Extend the timeline</strong> — 4 years instead of 3.</li>
              <li><strong>Free up cash</strong> — cut expenses or increase income.</li>
            </ul>
            <p>
              Run the test with the <Link to="/budget-planner" className="text-primary hover:underline font-medium">Budget Planner</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Match the wrapper to the horizon',
          content: (<>
            <div className="overflow-x-auto my-6">
              <table className="w-full text-sm border border-border">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left p-3 border-b border-border">Timeframe</th>
                    <th className="text-left p-3 border-b border-border">Suitable home</th>
                    <th className="text-left p-3 border-b border-border">Why</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="p-3 border-b border-border">Under 1 year</td><td className="p-3 border-b border-border">Easy-access savings account</td><td className="p-3 border-b border-border">Need it back quickly; no market risk</td></tr>
                  <tr><td className="p-3 border-b border-border">1–5 years</td><td className="p-3 border-b border-border">Cash ISA or fixed-rate bond</td><td className="p-3 border-b border-border">Better rates, tax-free, still protected from falls</td></tr>
                  <tr><td className="p-3 border-b border-border">5+ years</td><td className="p-3 border-b border-border">Stocks &amp; Shares ISA (LISA for first home)</td><td className="p-3 border-b border-border">Time to ride out market volatility for higher expected growth</td></tr>
                </tbody>
              </table>
            </div>
            <p>
              First-time buyers should look at the <Link to="/guides/tax-free-savings" className="text-primary hover:underline font-medium">Lifetime ISA</Link>: the government adds a 25% bonus on up to £4,000 a year, which is hard to beat for a deposit.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Case study 1: £15,000 wedding and honeymoon in 24 months',
          content: (<>
            <ul>
              <li>The maths: £15,000 ÷ 24 = £625/month.</li>
              <li>The stress test: combined take-home £4,200, essential bills £2,600, leaving £1,600. After £625, £975 remains for food, transport and leisure — tight but real.</li>
              <li>The verdict: achievable, with conscious leisure budgeting.</li>
              <li>The execution: a joint easy-access savings account at 4%, with an automatic transfer of £625 on the 1st of each month. The interest means they hit £15,000 a month early.</li>
            </ul>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Case study 2: £25,000 house deposit in 36 months',
          content: (<>
            <ul>
              <li>The maths: £25,000 ÷ 36 ≈ £694/month. At a 4% Cash ISA rate, compound growth trims the monthly figure to roughly £660 — the <Link to="/savings-goal-calculator" className="text-primary hover:underline font-medium">Savings Goal Calculator</Link> confirms the exact number.</li>
              <li>The stress test: single take-home £3,100, essential bills £2,000, leaving £1,100. After £660, £440 remains for food, transport and leisure — workable but leaves little buffer, so a 3-month emergency fund is built first.</li>
              <li>The verdict: achievable, but only after the emergency fund is in place and non-essential spending is kept in check.</li>
              <li>The wrapper: a Lifetime ISA, because the 25% government bonus on up to £4,000 a year adds £1,000 of free money annually — £3,000 over the three years — knocking roughly £80 off the effective monthly contribution for a first home under £450,000.</li>
              <li>The execution: automatic transfer of £333/month into the LISA (to max the £4,000 annual limit) plus £330/month into an easy-access Cash ISA, both moved the morning after payday.</li>
            </ul>
          </>),
        },
        {
          type: 'content',
          title: 'Automate, then handle the setbacks',
          content: (<>
            <p>
              Willpower is finite and spending friction is low, so remove the decision: a standing order the morning after payday moves the money before you can spend it. Use separate "sinking fund" accounts for each goal so a holiday fund does not quietly subsidise the deposit fund. When you miss a month — and you will — do not abandon the plan; extend the timeline by a month and continue. Consistency beats perfection.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Three mistakes that sink a savings plan',
          content: (<>
            <ul>
              <li><strong>Too many goals at once.</strong> Saving for a house, a wedding, a car and an emergency fund simultaneously dilutes every pot. Prioritise — emergency fund first, then one major goal.</li>
              <li><strong>Ignoring irregular expenses.</strong> December (Christmas) and March (annual insurance) wreck monthly plans. Treat annual costs as monthly line items so they do not raid the goal.</li>
              <li><strong>Over-restricting lifestyle.</strong> A goal that requires never socialising for three years will break. Leave a small sliver for enjoyment.</li>
            </ul>
          </>),
        },
        {
          type: 'when-useful',
          title: 'When cash is the wrong choice',
          content: (<>
            <p>
              For goals more than five years out, cash savings tend to lose purchasing power to inflation. Moving some of a long-horizon pot into investments historically gives a better real return, at the cost of short-term volatility. The <Link to="/guides/compound-interest-monthly-deposits" className="text-primary hover:underline font-medium">compound interest guide</Link> shows the long-run difference.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              Interest rates fluctuate with the Bank of England base rate, so the monthly figures are estimates. Inflation erodes cash savings over time. Frameworks like SMART are behavioural tools, not guarantees — job loss, inflation shocks or emergencies can force a pause. Always keep a liquid emergency fund before chasing illiquid goals like a deposit. This is educational, not advice; for large sums or complex situations an FCA-regulated adviser can help. Find your exact monthly requirement with the <Link to="/savings-goal-calculator" className="text-primary hover:underline font-medium">Savings Goal Calculator</Link>. Savings guidance at <a href="https://www.moneyhelper.org.uk/en/savings" target="_blank" rel="noreferrer">MoneyHelper: Savings</a>.
            </p>
          </>),
        },
      ]}
    />
  );
}
