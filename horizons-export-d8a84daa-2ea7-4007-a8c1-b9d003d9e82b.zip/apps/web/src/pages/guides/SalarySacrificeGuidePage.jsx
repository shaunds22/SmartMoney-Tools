import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import ChooseGuide from '@/components/ChooseGuide.jsx';
import { Link } from 'react-router-dom';
import { PENSION_SERIES } from '@/data/guideSeries.js';

export default function SalarySacrificeGuidePage() {
  return (
    <GuideLayout
      title="Salary Sacrifice vs Normal Pension Contributions"
      description="Maximize your take-home pay and pension growth by understanding how contribution methods differ."
      url="/guides/salary-sacrifice-vs-normal-pension"
      series={PENSION_SERIES}
      lastUpdated="2026-09-11"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <ChooseGuide items={[
              { question: 'How a contribution changes my payslip?', path: '/guides/pension-contributions', text: 'optimising pension contributions' },
              { question: 'How much to pay in and the allowances?', path: '/guides/pension-contributions', text: 'optimising pension contributions' },
            ]} />
            <p>
              For UK employees whose employer offers salary sacrifice and who want to know whether to use it. The short answer is usually yes — it is the most tax-efficient way to pay into a workplace pension — but the contractual change it involves puts many people off, and there are a few situations where it needs care. This guide explains the mechanics and the trade-offs. For the broader relief maths, see the <Link to="/guides/pension-contributions" className="text-primary hover:underline font-medium">pension contributions guide</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The two ways money reaches your pension',
          content: (<>
            <p>
              <strong>Normal contributions (Relief at Source or Net Pay):</strong> you earn your salary, your employer deducts your pension contribution from pay, and tax relief is applied — either before tax (Net Pay) or reclaimed from HMRC by the provider (Relief at Source). Either way, you still pay National Insurance on the money you contributed.
            </p>
            <p>
              <strong>Salary sacrifice:</strong> you agree to a lower contractual salary, and your employer pays that amount directly into your pension as an employer contribution. Because your gross salary is lower, that money never touches Income Tax <em>or</em> National Insurance — yours or your employer's.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Why sacrifice usually wins',
          content: (<>
            <ul>
              <li><strong>You save Employee NI</strong> — 8% (or 2% above £50,270) that you would still pay under normal contributions.</li>
              <li><strong>Your employer saves 15% Employer NI</strong> on the sacrificed amount — and many pass some or all of that saving back into your pension, boosting the pot at no cost to you.</li>
              <li><strong>Higher-rate relief is automatic.</strong> Under Relief at Source, higher-rate payers must manually claim the extra 20% via Self Assessment. Salary sacrifice handles it through payroll, so nothing is left unclaimed.</li>
            </ul>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked example: £45,000, putting £2,250 into the pension',
          content: (<>
            <p><strong>Normal contribution (Relief at Source):</strong></p>
            <ul>
              <li>You pay £1,800 from net pay; the provider reclaims £450 from HMRC → £2,250 in the pension.</li>
              <li>Take-home ≈ £34,120.</li>
            </ul>
            <p><strong>Salary sacrifice:</strong></p>
            <ul>
              <li>Salary drops to £42,750; employer pays £2,250 into the pension.</li>
              <li>Take-home ≈ £34,300.</li>
            </ul>
            <p>
              <strong>The difference:</strong> identical £2,250 in the pension, but sacrifice puts roughly £180 more in your pocket each year because you avoided NI on the contribution. Over a career, compounded, that is a meaningful sum — and it is larger still if your employer passes on their NI saving.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The trade-offs to weigh before signing',
          content: (<>
            <ul>
              <li><strong>The £2,000 cap from April 2029.</strong> <a href="https://www.gov.uk/government/publications/changes-to-salary-sacrifice-for-pensions-from-april-2029" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">From 6 April 2029</a>, only the first £2,000 a year you sacrifice into a pension will be free of National Insurance. Amounts above that will attract employee NI (8%, or 2% above £50,270) and employer NI (15%), although they will still get Income Tax relief. Until then, the full sacrificed amount avoids NI. If you sacrifice well over £2,000 a year, expect the NI saving shown in this guide to shrink from 2029/30.</li>
              <li><strong>It is a real pay cut.</strong> Your contractual salary falls, which can affect life-cover and death-in-service benefits, and how a future pay rise is calculated. Good employers keep a "reference salary" on record so you are not disadvantaged.</li>
              <li><strong>Mortgage affordability.</strong> Some lenders assess borrowing on your post-sacrifice salary. Most will use the reference salary if you provide documentation, but it is worth checking with a broker.</li>
              <li><strong>State benefits.</strong> A lower gross income can increase entitlement to Universal Credit or help avoid the High Income Child Benefit Charge — a plus. But if sacrifice pushes you below relevant thresholds, it could reduce Statutory Maternity Pay or other earnings-linked benefits.</li>
              <li><strong>Minimum wage floor.</strong> Your employer cannot let sacrifice take your pay below the National Minimum Wage.</li>
            </ul>
          </>),
        },
        {
          type: 'when-useful',
          title: 'What if your employer does not offer it?',
          content: (<>
            <p>
              You cannot force them — it requires contract changes and payroll support. You then use normal contributions, and if you are a higher-rate payer, remember to claim the extra relief from HMRC each year.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              Figures use 2026/27 tax and NI rates. Salary sacrifice changes your employment contract and can affect borrowing, benefits and death-in-service cover, so review your employer's scheme documents before opting in. For complex situations — bonus sacrifice, very high earnings, or benefit interactions — an FCA-regulated adviser can confirm it suits you. See the exact difference on your pay with the <Link to="/uk-salary-calculator" className="text-primary hover:underline font-medium">UK Salary Calculator</Link> and project the larger pot with the <Link to="/pensions-calculator" className="text-primary hover:underline font-medium">Pensions Calculator</Link>.
            </p>
          </>),
        },
      ]}
    />
  );
}
