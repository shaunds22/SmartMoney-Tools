import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import ChooseGuide from '@/components/ChooseGuide.jsx';
import { Link } from 'react-router-dom';

export default function SelfEmploymentIncomeGuidePage() {
  return (
    <GuideLayout
      title="Self-Employment Income Guide"
      description="Navigate turnover, profit, and tax obligations as a sole trader in the UK."
      url="/guides/self-employment-income"
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <ChooseGuide items={[
              { question: 'Legal ways to reduce my tax bill?', path: '/guides/self-employed-tax-planning', text: 'self-employed tax planning basics' },
              { question: 'Estimate the tax on my profit?', path: '/self-employed-tax-calculator', text: 'self-employed tax calculator' },
            ]} />
            <p>
              Written for new UK sole traders who need to understand what they actually owe HMRC. The central idea is simple but routinely missed: you are taxed on <em>profit</em>, not on the money that comes through the door. This guide covers how to get from turnover to taxable profit and what falls due. It is the foundation; for legal ways to reduce that bill (pensions, timing, allowances), see the <Link to="/guides/self-employed-tax-planning" className="text-primary hover:underline font-medium">self-employed tax planning guide</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Turnover is not profit',
          content: (<>
            <p>
              Turnover is everything you invoiced for. Profit is turnover minus the expenses HMRC lets you deduct. A consultant billing £60,000 but spending only £5,000 has a very different tax bill from an online seller billing £30,000 with £15,000 of stock and postage costs — both have £15,000 of taxable profit in the second case but £55,000 in the first. Confusing the two is the most common reason new sole traders underestimate their January bill.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'What counts as an allowable expense',
          content: (<>
            <p>
              HMRC lets you deduct costs incurred <em>wholly and exclusively</em> for the trade. Typical allowable expenses include:
            </p>
            <ul>
              <li>Office costs — stationery, software subscriptions, phone and broadband (business proportion).</li>
              <li>Travel — fuel, parking, train fares and hotels for business trips. Ordinary commuting to a regular workplace is <strong>not</strong> allowable.</li>
              <li>Equipment — laptops, tools and machinery, either expensed outright or through capital allowances.</li>
              <li>Home office — a proportion of heat, light, power and a dedicated workspace, or the simplified flat-rate.</li>
              <li>Professional fees — accountant, business insurance, relevant professional subscriptions.</li>
            </ul>
            <p>
              Full lists are at <a href="https://www.gov.uk/expenses-if-youre-self-employed" target="_blank" rel="noreferrer">GOV.UK: Self-employed expenses</a>.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked example: £40,000 turnover',
          content: (<>
            <p>
              A graphic designer bills £40,000 and has £5,000 of allowable expenses (software, a new laptop, business travel, home-office proportion).
            </p>
            <ul>
              <li>Net profit: £35,000</li>
              <li>Income Tax: £12,570 tax-free, then 20% on £22,430 = £4,486</li>
              <li>Class 4 NI: 6% on profit between £12,570 and £50,270 = £1,346</li>
              <li>Class 2 NI has been abolished — no flat weekly charge applies.</li>
              <li><strong>Total tax and NI: ≈ £5,832</strong></li>
              <li><strong>Income after tax: ≈ £29,168</strong></li>
            </ul>
            <p>
              Model your own figures with the <Link to="/self-employed-tax-calculator" className="text-primary hover:underline font-medium">UK Self-Employed Tax Calculator</Link>.
            </p>
          </>),
        },
        {
          type: 'when-useful',
          title: 'When you must register for VAT',
          content: (<>
            <p>
              If your taxable turnover exceeds £90,000 in any rolling 12-month period you must register for VAT, charge it on your invoices and submit returns. You can register voluntarily below that if it suits your customers. See <a href="https://www.gov.uk/vat-registration" target="_blank" rel="noreferrer">GOV.UK: VAT registration</a>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Key deadlines',
          content: (<>
            <ul>
              <li><strong>Register for Self Assessment:</strong> by 5 October after the tax year you became self-employed.</li>
              <li><strong>File and pay online:</strong> by 31 January after the end of the tax year.</li>
              <li><strong>Payments on account:</strong> if your bill is over £1,000, HMRC collects advance payments each January and July — your first bill can therefore be around 150% of what you expected.</li>
            </ul>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              This covers sole traders only. Limited company directors face Corporation Tax, salary-plus-dividend tax, and different NI rules — the figures above do not apply. Capital allowances and complex depreciation need an accountant. Figures use 2026/27 rates, which change each Budget.
            </p>
          </>),
        },
      ]}
    />
  );
}
