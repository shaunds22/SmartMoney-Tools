import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';

export default function StudentLoanRepaymentsGuidePage() {
  return (
    <GuideLayout
      title="How Student Loan Repayments Affect Your Monthly Pay"
      description="Understand thresholds, repayment rates, and how student loans function as a graduate tax."
      url="/guides/student-loan-repayments"
      lastUpdated="2026-09-11"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              This guide is for UK graduates who see a "Student Loan" line on their payslip and want to know what it means, how it is calculated, and whether overpaying is ever worth it. It is deliberately narrow: it covers only the repayment mechanism, not general take-home pay (see the <Link to="/guides/calculate-take-home-pay" className="text-primary hover:underline font-medium">take-home pay guide</Link> for the full payslip) or self-employed tax.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'First: which plan are you on?',
          content: (<>
            <p>
              The plan type determines your threshold, rate and write-off date, so this is the single most important thing to confirm. Check your payslip or the Student Loans Company. The table reflects the main plans and 2026/27 thresholds.
            </p>
            <div className="overflow-x-auto my-6">
              <table className="w-full text-sm border border-border">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left p-3 border-b border-border">Plan</th>
                    <th className="text-left p-3 border-b border-border">Who</th>
                    <th className="text-left p-3 border-b border-border">Threshold</th>
                    <th className="text-left p-3 border-b border-border">Rate</th>
                    <th className="text-left p-3 border-b border-border">Written off</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="p-3 border-b border-border">Plan 1</td><td className="p-3 border-b border-border">Started before Sept 2012</td><td className="p-3 border-b border-border">£24,990</td><td className="p-3 border-b border-border">9%</td><td className="p-3 border-b border-border">25 years after due</td></tr>
                  <tr><td className="p-3 border-b border-border">Plan 2</td><td className="p-3 border-b border-border">Sept 2012 – July 2023</td><td className="p-3 border-b border-border">£27,295</td><td className="p-3 border-b border-border">9%</td><td className="p-3 border-b border-border">30 years after due</td></tr>
                  <tr><td className="p-3 border-b border-border">Plan 5</td><td className="p-3 border-b border-border">From August 2023</td><td className="p-3 border-b border-border">£25,000</td><td className="p-3 border-b border-border">9%</td><td className="p-3 border-b border-border">40 years after due</td></tr>
                  <tr><td className="p-3 border-b border-border">Postgraduate</td><td className="p-3 border-b border-border">Master's / doctoral loan</td><td className="p-3 border-b border-border">£21,000</td><td className="p-3 border-b border-border">6%</td><td className="p-3 border-b border-border">30 years after due</td></tr>
                </tbody>
              </table>
            </div>
            <p>
              Thresholds are reviewed annually. Confirm current figures at <a href="https://www.gov.uk/repaying-your-student-loan" target="_blank" rel="noreferrer">GOV.UK: Repaying your student loan</a>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'How the deduction is calculated',
          content: (<>
            <p>
              You pay a percentage of earnings <em>above</em> the threshold — not on the threshold itself, and not on the whole salary. For a Plan 2 graduate earning £35,000:
            </p>
            <ul>
              <li>Earnings above £27,295: £7,705</li>
              <li>Annual repayment (9% of £7,705): £693</li>
              <li><strong>Monthly deduction: ≈ £58</strong></li>
            </ul>
            <p>
              If income drops below the threshold — part-time work, a career break, unemployment — deductions stop automatically. There is nothing to defer; the PAYE system simply takes nothing.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Why the balance can grow even while you pay',
          content: (<>
            <p>
              Interest accrues from the day the loan is paid out. Plan 2 and Plan 5 rates are tied to RPI plus an income-based margin, so a typical graduate paying £693 a year can still see the balance rise when interest charged exceeds repayments. This is alarming to look at but, for most earners, irrelevant — because of the write-off.
            </p>
          </>),
        },
        {
          type: 'when-useful',
          title: 'Should you overpay? Usually no',
          content: (<>
            <p>
              Because the debt is wiped after 25–40 years depending on plan, overpaying only makes sense if you are on track to clear the full balance <em>before</em> the write-off date. For most middle-income earners that is unlikely — voluntary overpayments can amount to paying off debt the government would have forgiven. Overpaying tends to make sense only for high earners confident they will clear the balance naturally. The <a href="https://www.gov.uk/repaying-your-student-loan" target="_blank" rel="noreferrer">GOV.UK repayment guidance</a> and the Student Loans Company's projection tool can help you judge this.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'How it affects a mortgage application',
          content: (<>
            <p>
              A student loan does not appear on your credit file. But because it reduces your net monthly take-home, lenders factor the deduction into affordability, which can slightly lower the maximum they will lend. It is a cash-flow consideration, not a credit-score one.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'If you have more than one loan',
          content: (<>
            <p>
              Holding an undergraduate plan and a postgraduate loan means both deductions run at once — 9% above the plan threshold plus 6% above £21,000 — so the marginal rate on earnings above both thresholds is 15 percentage points before tax and NI.
            </p>
          </>),
        },
        {
          type: 'resources',
          title: 'See your exact deduction',
          content: (<>
            <p>
              Enter your salary and select your plan in the <Link to="/uk-salary-calculator" className="text-primary hover:underline font-medium">UK Salary Calculator</Link> to see the precise monthly figure. This guide is educational; thresholds, rates and write-off periods are set by legislation and can change, so confirm your plan before acting on any of it.
            </p>
          </>),
        },
      ]}
    />
  );
}
