import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';

export default function PersonalLoanComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="Personal Loans Explained"
      description="Navigate interest rates, terms, and when unsecured borrowing makes sense."
      url="/guides/personal-loan"
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              For people considering an unsecured personal loan — usually for a car, home improvements or to consolidate other borrowing — who want to understand how the rate, the term and the small print change the true cost. A personal loan gives a lump sum repaid in fixed monthly instalments over a set term, so unlike a credit card it has a definite end date. For comparing the total cost of several borrowing options side by side, see <Link to="/guides/compare-loan-repayments" className="text-primary hover:underline font-medium">how to compare loan repayments</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Representative APR is not the rate you will get',
          content: (<>
            <p>
              Adverts show a "Representative APR", but by law the lender only has to offer that rate to 51% of accepted applicants. If your credit file is average, the rate you are actually offered can be materially higher — and the monthly payment jumps with it. Always check the real rate on any offer before signing, and use soft-search eligibility checkers to see likely rates without leaving a hard mark on your credit file.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Term length is where the money hides',
          content: (<>
            <p>
              A longer term lowers the monthly payment but raises the total interest, because the balance sits with the lender for longer. Borrowing £10,000 at 6% APR:
            </p>
            <ul>
              <li><strong>3-year term:</strong> £304/month, total interest ≈ £951.</li>
              <li><strong>5-year term:</strong> £193/month, total interest ≈ £1,599.</li>
              <li><strong>Stretching to 5 years costs about £648 more in total</strong> for a £111 lower monthly payment.</li>
            </ul>
            <p>
              Choose the shortest term you can comfortably afford, not the longest the lender will offer.
            </p>
          </>),
        },
        {
          type: 'when-useful',
          title: 'When an unsecured loan makes sense — and when it does not',
          content: (<>
            <ul>
              <li><strong>Sensible:</strong> a planned purchase with a clear repayment source, or consolidating higher-rate credit card debt into one lower fixed payment.</li>
              <li><strong>Risky:</strong> borrowing to fund lifestyle spending you cannot sustain, or taking an unsecured loan when a secured product would put your home at risk on default.</li>
            </ul>
          </>),
        },
        {
          type: 'content',
          title: 'Early repayment',
          content: (<>
            <p>
              Under the Consumer Credit Act you can settle a loan early. Lenders may charge an early settlement fee, but it is capped by law — usually one or two months' interest. If you expect a bonus or windfall, check the ERC before signing so you know the cost of clearing the loan ahead of schedule.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'If you are declined',
          content: (<>
            <p>
              Do not immediately apply elsewhere — multiple hard searches in a short period signal "credit hungry" to lenders and can cause automatic declines. Check your credit file for errors first, address anything inaccurate, and use a soft-search checker to find loans you are likely to be accepted for.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              APRs depend on Bank of England base rates, lender criteria and your credit history; the figures above are illustrative. Unsecured loans typically carry higher rates than secured loans because the lender takes more risk. Missing payments leads to default notices, County Court Judgments and possible debt collection. Never borrow to fund lifestyle or speculative investments. Plan repayment with the <Link to="/budget-planner" className="text-primary hover:underline font-medium">Budget Planner</Link> and map early payoff with the <Link to="/debt-snowball-calculator" className="text-primary hover:underline font-medium">Debt Snowball Calculator</Link>. Consumer guidance at <a href="https://www.fca.org.uk/consumers/loans" target="_blank" rel="noreferrer">FCA: Loans</a>.
            </p>
          </>),
        },
      ]}
    />
  );
}
