import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';
import { PENSION_SERIES } from '@/data/guideSeries.js';

export default function EarlyRetirementComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="Early Retirement Planning Guide"
      description="Strategies for retiring before State Pension age and bridging the income gap."
      url="/guides/early-retirement"
      series={PENSION_SERIES}
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              For people aiming to stop work before State Pension age — whether by choice (the FIRE approach) or through an unexpected mid-career redundancy. The defining problem of early retirement is not saving enough; it is the <em>bridge</em>: the years between when you stop earning and when your pensions and the State Pension become payable. This guide is about sequencing that bridge. For sizing the pot itself, see the <Link to="/guides/pension-planning" className="text-primary hover:underline font-medium">pension planning guide</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The two age gates that shape everything',
          content: (<>
            <ul>
              <li><strong>Normal Minimum Pension Age</strong> — the earliest you can access private/workplace pensions: 55 now, rising to 57 in 2028.</li>
              <li><strong>State Pension age</strong> — currently 66, due to rise to 67 by 2028 and later to 68. Check yours at <a href="https://www.gov.uk/state-pension-age" target="_blank" rel="noreferrer">GOV.UK: State Pension age</a>.</li>
            </ul>
            <p>
              Retiring at 50 means funding yourself for roughly 7 years before you can touch a private pension, and 16+ years before the State Pension arrives. Retiring at 60 collapses the first gap but still leaves around 7 years to the State Pension. The size of those gaps dictates how much accessible cash you need.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Build the bridge with ISAs',
          content: (<>
            <p>
              Money you need <em>before</em> 57 cannot live in a pension — it must be accessible. A Stocks &amp; Shares ISA is the natural wrapper: up to £20,000 a year, tax-free growth and withdrawals, and no age gate. The strategy is to build an ISA pot large enough to cover the years between stopping work and 57, then let the pension take over.
            </p>
          </>),
        },
        {
          type: 'step-by-step',
          title: 'A drawdown sequence that minimises tax',
          content: (<>
            <p>
              The order you spend your pots matters as much as their size. A common sequence:
            </p>
            <ol>
              <li><strong>Years before 57:</strong> spend ISA savings (tax-free) and any cash reserves.</li>
              <li><strong>57 to State Pension age:</strong> draw from the SIPP/workplace pension, using the 25% tax-free lump sum and your Personal Allowance to keep Income Tax low.</li>
              <li><strong>State Pension age onwards:</strong> the State Pension covers a chunk of baseline spending, so you draw less from the remaining pot, reducing strain on your investments.</li>
            </ol>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked example: retiring at 55 on £30,000/year',
          content: (<>
            <p>
              Someone has £400,000 in a SIPP and £150,000 in an ISA, and wants £30,000 a year.
            </p>
            <ul>
              <li><strong>55–60:</strong> withdraw £30,000/year entirely from the ISA (tax-free). The SIPP stays invested and keeps growing.</li>
              <li><strong>60–67:</strong> ISA is depleted; draw £30,000/year from the SIPP, using the Personal Allowance and 25% tax-free portion to minimise tax.</li>
              <li><strong>67+:</strong> State Pension (≈ £12,000) covers part of the need, so SIPP withdrawals fall to around £18,000/year.</li>
            </ul>
            <p>
              The point is not the exact numbers but the shape: ISAs first, pension second, State Pension last.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Sequence-of-returns risk is amplified here',
          content: (<>
            <p>
              Early retirement means a longer retirement — 40 years or more — so your money must last longer and inflation has more time to erode it. A market crash in the first few years of drawdown is especially damaging because you are withdrawing from a shrinking pot. Holding 2–3 years of cash expenses lets you avoid selling investments after a fall.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations and when to get advice',
          content: (<>
            <p>
              Access ages, the State Pension timetable and ISA allowances are 2026/27 and change with legislation. Withdrawing from a pension before State Pension age can affect means-tested benefits, and drawing too much too early can leave you short later. For a 40-year retirement, an FCA-regulated adviser's plan is usually worth the cost. Model your trajectory with the <Link to="/pensions-calculator" className="text-primary hover:underline font-medium">Pensions Calculator</Link> and <Link to="/compound-interest" className="text-primary hover:underline font-medium">Compound Interest Calculator</Link>. Background at <a href="https://www.moneyhelper.org.uk/en/pensions-and-retirement" target="_blank" rel="noreferrer">MoneyHelper: Pensions and retirement</a>.
            </p>
          </>),
        },
      ]}
    />
  );
}
