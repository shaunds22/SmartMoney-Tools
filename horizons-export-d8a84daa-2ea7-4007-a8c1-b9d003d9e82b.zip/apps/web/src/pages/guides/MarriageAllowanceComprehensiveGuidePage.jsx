import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';

export default function MarriageAllowanceComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="Marriage Allowance Guide"
      description="Eligibility rules and claiming process to reduce your household tax bill."
      url="/guides/marriage-allowance"
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              For married couples and civil partners in the UK where one person earns below the Personal Allowance and the other is a basic-rate taxpayer. Marriage Allowance lets the lower earner transfer £1,260 of their unused tax-free allowance to the higher earner, reducing the household tax bill by £252 a year. It is free to claim, takes minutes, and can be backdated — yet a large share of eligible couples never claim it.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Who qualifies',
          content: (<>
            <ul>
              <li>You are married or in a civil partnership (living together without marriage does not count).</li>
              <li>One partner's income is below the Personal Allowance (£12,570).</li>
              <li>The other partner is a basic-rate taxpayer — income between £12,571 and £50,270 (or the Scottish basic-rate band).</li>
            </ul>
            <p>
              Higher-rate or additional-rate payers are excluded: if the receiving partner is in the 40% or 45% band, the claim is invalid. Full eligibility detail at <a href="https://www.gov.uk/marriage-allowance" target="_blank" rel="noreferrer">GOV.UK: Marriage Allowance</a>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'How the maths works',
          content: (<>
            <p>
              The transfer is a fixed £1,260 — you cannot choose a different amount. The receiving partner's Personal Allowance rises from £12,570 to £13,830, so £1,260 of their income that would have been taxed at 20% is now tax-free. 20% of £1,260 = <strong>£252 saved</strong>, usually collected through a small change to their tax code.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked example',
          content: (<>
            <p>
              One partner works part-time and earns £9,000 — well below £12,570, so they have unused allowance. The other earns £35,000, a basic-rate salary.
            </p>
            <ul>
              <li>The part-time partner transfers £1,260.</li>
              <li>The higher earner's allowance rises to £13,830.</li>
              <li>They pay 20% less tax on that £1,260 — <strong>£252 less tax for the household</strong>.</li>
              <li>The part-time partner's allowance falls to £11,310, but since they only earn £9,000 they still pay nothing.</li>
            </ul>
          </>),
        },
        {
          type: 'step-by-step',
          title: 'How to claim',
          content: (<>
            <ol>
              <li>Apply online at the GOV.UK Marriage Allowance page — the lower earner makes the application.</li>
              <li>HMRC adjusts the higher earner's tax code, so the saving appears automatically in take-home pay.</li>
              <li>You can backdate a claim to the start of the current tax year and, where you were eligible, to the previous four tax years — potentially over £1,000 in total.</li>
            </ol>
          </>),
        },
        {
          type: 'when-useful',
          title: 'When eligibility changes mid-year',
          content: (<>
            <p>
              If the receiving partner's income rises into the higher-rate band during the year, the allowance must be cancelled — otherwise HMRC will reclaim the relief later. Equally, if the lower earner's income rises above £12,570, transferring may no longer make sense. Life events like retirement, returning to work, or a pay rise are the moments to revisit the claim.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'What it does not affect',
          content: (<>
            <p>
              Marriage Allowance does not impact Universal Credit or most other benefits, and it is separate from the (now abolished) Married Couple's Allowance that applies only to couples where at least one partner was born before 6 April 1935.
            </p>
          </>),
        },
        {
          type: 'resources',
          title: 'See the impact on your pay',
          content: (<>
            <p>
              The <Link to="/uk-salary-calculator" className="text-primary hover:underline font-medium">UK Salary Calculator</Link> lets you toggle Marriage Allowance to show the net effect. This is a 2026/27 figure; the transfer amount and bands are set by HMRC and can change.
            </p>
          </>),
        },
      ]}
    />
  );
}
