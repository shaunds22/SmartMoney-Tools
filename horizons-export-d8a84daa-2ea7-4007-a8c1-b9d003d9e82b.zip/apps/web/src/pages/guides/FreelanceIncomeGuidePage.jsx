import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';

export default function FreelanceIncomeGuidePage() {
  return (
    <GuideLayout
      title="Freelance Income & Cash Flow Guide"
      description="Manage irregular income, forecast tax, and build financial stability as a UK freelancer."
      url="/guides/freelance-income"
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              For UK freelancers and contractors whose income swings from month to month. The hardest part of freelancing is rarely the work — it is keeping cash flowing when a client pays late or a quiet month arrives. This guide is about cash flow and reserves, not tax calculation; for the numbers themselves use the <Link to="/guides/self-employment-income" className="text-primary hover:underline font-medium">self-employment income guide</Link> and the tax calculator.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The core problem: lumpy income, fixed bills',
          content: (<>
            <p>
              A web designer might bill £8,000 one month and £1,000 the next, while rent, council tax and software subscriptions fall due on the same date every month. The danger is not the quiet month itself — it is spending a bumper month's cash as if it were recurring income.
            </p>
          </>),
        },
        {
          type: 'step-by-step',
          title: 'Step 1 — find your survival number',
          content: (<>
            <p>
              Add up the absolute minimum you need to keep life and business running: rent or mortgage, utilities, food, transport, minimum debt payments, and unavoidable business costs. This is your monthly floor. Everything above it, in a good month, is not yet yours to spend.
            </p>
          </>),
        },
        {
          type: 'step-by-step',
          title: 'Step 2 — pay yourself a flat salary from a buffer',
          content: (<>
            <p>
              The simplest fix for lumpy income is to flatten it deliberately. Funnel all client receipts into one business account and transfer a fixed monthly amount — your survival number plus a modest margin — into your personal account. A bumper month simply tops up the business buffer; a quiet month draws it down. Aim to build that buffer to three months of survival costs before you treat any surplus as profit.
            </p>
          </>),
        },
        {
          type: 'step-by-step',
          title: 'Step 3 — skim tax from every invoice',
          content: (<>
            <p>
              Move a set percentage of <em>every</em> invoice into a separate tax account the day it clears — 25–30% is a reasonable starting point for a basic-rate sole trader, more if you are near higher rate. Do this before the money feels like income. The classic freelancer disaster is a £20,000 quarter that gets spent, followed by a January tax bill with nothing set aside.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'A lumpy year, made safe',
          content: (<>
            <p>
              A freelancer bills £10,000 in Q1 and £20,000 in Q2. Tax is calculated on annual profit, so the Q2 spike does not change the bracket mid-year — but it does create a cash risk. Skimming 25% of Q2 (£5,000) into the tax account the day it lands means January is covered. Without that habit, the same £5,000 tends to become a holiday or a new laptop, and January brings a shortfall.
            </p>
          </>),
        },
        {
          type: 'when-useful',
          title: 'When to raise your rates',
          content: (<>
            <ul>
              <li>You are booked out three or more months ahead — demand is clearly outstripping supply.</li>
              <li>A year has passed since your last increase — inflation erodes a static day rate.</li>
              <li>You are turning down work regularly, or clients accept quotes without negotiating.</li>
            </ul>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              This assumes sole-trader status and no serious bad-debt problem. Unpaid invoices are a separate risk — chase promptly and consider late-payment provisions under the <a href="https://www.gov.uk/late-commercial-payments-interest-debt-recovery" target="_blank" rel="noreferrer">Late Payment of Commercial Debts</a> rules. For choosing between sole trader and limited company, or handling flat-rate VAT, an accountant's view is worth the cost. Plan your numbers with the <Link to="/budget-planner" className="text-primary hover:underline font-medium">Budget Planner</Link> and forecast liabilities with the <Link to="/self-employed-tax-calculator" className="text-primary hover:underline font-medium">Self-Employed Tax Calculator</Link>.
            </p>
          </>),
        },
      ]}
    />
  );
}
