import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';

export default function TaxPlanningComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="Advanced Tax Planning Guide"
      description="Legal strategies to reduce your tax bill through pensions, ISAs, and allowances."
      url="/guides/tax-planning"
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              For UK earners — especially those approaching £50,270 or £100,000 — who want to use the government's own wrappers and allowances to keep more of what they earn. This is about legal tax planning within rules HMRC designed, not avoidance schemes. It draws on the <Link to="/guides/uk-income-tax" className="text-primary hover:underline font-medium">Income Tax guide</Link> for band mechanics and the <Link to="/guides/pension-contributions" className="text-primary hover:underline font-medium">pension contributions guide</Link> for relief detail, then focuses on the decisions that move you between bands.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The three levers that actually reduce taxable income',
          content: (<>
            <ul>
              <li><strong>Pension contributions</strong> — the most powerful. They extend your basic-rate band (or reduce adjusted net income), pulling money out of higher-rate tax. Up to 100% of earnings, capped at the £60,000 Annual Allowance for most people.</li>
              <li><strong>ISAs</strong> — up to £20,000 a year. They do not reduce taxable income, but they shield all future growth and withdrawals from Income Tax, Dividend Tax and Capital Gains Tax. See <Link to="/guides/tax-free-savings" className="text-primary hover:underline font-medium">tax-free savings (ISAs)</Link>.</li>
              <li><strong>Gift Aid donations</strong> — extend your basic-rate band, and higher-rate payers claim the extra relief through Self Assessment.</li>
            </ul>
          </>),
        },
        {
          type: 'comparison-table',
          title: 'Decision: which threshold are you near?',
          content: (
            <table className="w-full text-sm border border-border">
              <thead className="bg-muted">
                <tr>
                  <th className="text-left p-3 border-b border-border">Your situation</th>
                  <th className="text-left p-3 border-b border-border">Most useful action</th>
                </tr>
              </thead>
              <tbody>
                <tr><td className="p-3 border-b border-border">Just above £50,270 (higher rate)</td><td className="p-3 border-b border-border">Pension contributions to pull income back into basic rate</td></tr>
                <tr><td className="p-3 border-b border-border">£100,000–£125,140 (allowance taper)</td><td className="p-3 border-b border-border">Pension contributions to restore Personal Allowance (60% effective relief)</td></tr>
                <tr><td className="p-3 border-b border-border">Spouse earns below £12,570</td><td className="p-3 border-b border-border"><Link to="/guides/marriage-allowance" className="text-primary hover:underline">Marriage Allowance</Link> — £252/year, free to claim</td></tr>
                <tr><td className="p-3 border-b border-border">Large bonus due in March</td><td className="p-3 border-b border-border">Time pension/SIPP payment before 5 April to use this year's allowance</td></tr>
              </tbody>
            </table>
          ),
        },
        {
          type: 'worked-example',
          title: 'Worked example: the £100,000 trap',
          content: (<>
            <p>
              An employee earns £110,000. The £10,000 above £100,000 is taxed at 40% <em>and</em> strips out £5,000 of Personal Allowance (taxed at 40%), so they keep only £4,000 of that £10,000 — a 60% effective rate.
            </p>
            <ul>
              <li><strong>Without planning:</strong> £6,000 of the £10,000 goes to HMRC.</li>
              <li><strong>With planning:</strong> £10,000 goes into a pension. Adjusted net income falls to £100,000, the full Personal Allowance is restored, and the pension pot grows by £10,000.</li>
            </ul>
            <p>
              For a basic-rate earner the same £100 of pension costs £80 of take-home; for this person it effectively costs £40. That is why pension contributions above £100,000 are hard to beat.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Carry forward',
          content: (<>
            <p>
              If you have unused Annual Allowance from the previous three tax years and a pension pot already in place, you can carry it forward to contribute more than £60,000 in a single year and still get relief. This matters for people with a sudden windfall or bonus who want to make a large pension payment.
            </p>
          </>),
        },
        {
          type: 'when-useful',
          title: 'When professional advice is worth it',
          content: (<>
            <ul>
              <li>You earn over £100,000 and face the taper or a tapered Annual Allowance.</li>
              <li>You are self-employed and choosing between sole trader and limited company.</li>
              <li>You have significant investment or rental income alongside earnings.</li>
              <li>You are considering large one-off pension contributions near the allowance.</li>
            </ul>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              The £60,000 Annual Allowance and the £100,000 taper are 2026/27 figures and change with legislation. Very high earners face a tapered allowance below £60,000. ISA and pension rules can change each Budget. This is educational, not advice; for substantial sums an FCA-regulated adviser typically saves more than their fee. Model the impact with the <Link to="/uk-salary-calculator" className="text-primary hover:underline font-medium">UK Salary Calculator</Link> and <Link to="/pensions-calculator" className="text-primary hover:underline font-medium">Pensions Calculator</Link>. Authoritative background at <a href="https://www.gov.uk/tax-on-your-private-pension" target="_blank" rel="noreferrer">GOV.UK: Tax on your private pension</a>.
            </p>
          </>),
        },
      ]}
    />
  );
}
