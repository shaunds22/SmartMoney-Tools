import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';

export default function SideHustleTaxGuidePage() {
  return (
    <GuideLayout
      title="Side Hustle Tax Guide"
      description="Understand the UK Trading Allowance, reporting requirements, and tax on side income."
      url="/guides/side-hustle-tax"
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              For people earning a little on top of a main income — selling on Vinted or eBay, weekend tutoring, driving for a delivery app, the odd freelance gig. The question this answers is narrow: <em>do I need to tell HMRC about this, and if so, how much tax do I owe?</em> It is not a guide to running a full business; for that see the <Link to="/guides/self-employment-income" className="text-primary hover:underline font-medium">self-employment income guide</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The £1,000 Trading Allowance',
          content: (<>
            <p>
              The UK gives you a £1,000 tax-free allowance for trading income each tax year. It is based on <em>gross</em> income (total sales before any costs), not profit. If your side hustle takes in £800 selling crafts, nothing is owed and nothing needs reporting. Cross £1,000 and the whole amount becomes reportable — though you still get to use the allowance. See <a href="https://www.gov.uk/guidance/tax-free-allowances-on-property-and-trading-income" target="_blank" rel="noreferrer">GOV.UK: Tax-free allowances for trading and property income</a>.
            </p>
          </>),
        },
        {
          type: 'when-useful',
          title: 'Below £1,000: nothing to do',
          content: (<>
            <p>
              If your gross trading income for the tax year is £1,000 or less, you do not need to register for Self Assessment or declare it, even if you also have a PAYE job. Keep a simple record of what you earned in case HMRC asks.
            </p>
          </>),
        },
        {
          type: 'step-by-step',
          title: 'Above £1,000: register and declare',
          content: (<>
            <p>
              Once gross income passes £1,000, you must register for Self Assessment by 5 October after the tax year ends, then file a return and pay by the following 31 January. When you declare, you choose one of two options for each tax year:
            </p>
            <ul>
              <li><strong>Claim the £1,000 allowance</strong> — deduct £1,000 from gross income and pay tax on the rest, with no separate expense claims.</li>
              <li><strong>Claim actual expenses</strong> — deduct your real costs instead, and pay tax on the resulting profit.</li>
            </ul>
            <p>
              You cannot do both. Pick whichever gives the lower taxable figure.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked example: £3,000 of side income',
          content: (<>
            <p>
              You have a £30,000 PAYE job and earn £3,000 from weekend tutoring, with £400 of genuine expenses (materials, a proportion of broadband, software).
            </p>
            <ul>
              <li><strong>Actual expenses:</strong> £3,000 − £400 = £2,600 taxable profit.</li>
              <li><strong>Trading Allowance:</strong> £3,000 − £1,000 = £2,000 taxable profit.</li>
              <li><strong>Result:</strong> the allowance wins. As a basic-rate payer you owe 20% of £2,000 = £400.</li>
            </ul>
            <p>
              The allowance tends to win when your real costs are below £1,000 — common for low-overhead side hustles. Once your expenses exceed £1,000, actual expenses usually win.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Common mistakes',
          content: (<>
            <ul>
              <li><strong>Confusing gross and net.</strong> The £1,000 test is on total sales, not on what you keep after costs.</li>
              <li><strong>Assuming platforms report for you.</strong> Selling platforms and gig apps may share data with HMRC, but the legal duty to register and declare is yours.</li>
              <li><strong>Forgetting benefits.</strong> New self-employed income can affect Universal Credit entitlements — report it to the benefits office separately.</li>
            </ul>
          </>),
        },
        {
          type: 'content',
          title: 'Where this does not apply',
          content: (<>
            <p>
              The Trading Allowance cannot be set against income from your employer or against partnership income. Selling personal possessions you no longer want is generally outside trading rules, but regular buying-to-sell is trading. Capital Gains Tax applies separately to selling personal investments.
            </p>
          </>),
        },
        {
          type: 'resources',
          title: 'See the combined impact',
          content: (<>
            <p>
              Add your side income in the <Link to="/uk-salary-calculator" className="text-primary hover:underline font-medium">UK Salary Calculator</Link> to see how it sits alongside your PAYE salary. Figures use 2026/27 rules, which can change each Budget.
            </p>
          </>),
        },
      ]}
    />
  );
}
