import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';

export default function NationalInsuranceComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="National Insurance: A Comprehensive Guide"
      description="Understand NI contributions, thresholds, and how they secure your state benefits."
      url="/guides/national-insurance"
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              For UK employees and sole traders who want to understand what National Insurance is, why it sits separately from Income Tax, and what it actually buys you. It is the companion to the <Link to="/guides/uk-income-tax" className="text-primary hover:underline font-medium">Income Tax guide</Link>: together they make up the two statutory deductions on earnings, but NI has its own thresholds, its own per-period calculation, and a direct link to your State Pension entitlement that Income Tax lacks.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'What NI pays for',
          content: (<>
            <p>
              Unlike Income Tax, which funds general spending, NI contributions build your entitlement to certain state benefits — most importantly the State Pension, plus Maternity Allowance and contributory benefits. A year of contributions is a "qualifying year"; you need 35 to get the full new State Pension and at least 10 to get any. You can check your contribution record at <a href="https://www.gov.uk/check-state-pension" target="_blank" rel="noreferrer">GOV.UK: Check your State Pension</a>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Employee (Class 1) NI in 2026/27',
          content: (<>
            <div className="overflow-x-auto my-6">
              <table className="w-full text-sm border border-border">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left p-3 border-b border-border">Earnings band</th>
                    <th className="text-left p-3 border-b border-border">Employee rate</th>
                    <th className="text-left p-3 border-b border-border">Employer rate</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="p-3 border-b border-border">Up to £5,000 (Secondary Threshold)</td><td className="p-3 border-b border-border">0%</td><td className="p-3 border-b border-border">0%</td></tr>
                  <tr><td className="p-3 border-b border-border">£5,000 – £12,570</td><td className="p-3 border-b border-border">0%</td><td className="p-3 border-b border-border">15%</td></tr>
                  <tr><td className="p-3 border-b border-border">£12,570 – £50,270</td><td className="p-3 border-b border-border">8%</td><td className="p-3 border-b border-border">15%</td></tr>
                  <tr><td className="p-3 border-b border-border">Above £50,270</td><td className="p-3 border-b border-border">2%</td><td className="p-3 border-b border-border">15%</td></tr>
                </tbody>
              </table>
            </div>
            <p>
              The employer rate (Secondary NI) is charged on earnings above the Secondary Threshold of £5,000 — lower than the employee's Primary Threshold of £12,570 since April 2025. Employees never pay the employer portion, but it is a real cost of employing you — relevant when negotiating salary or benefits. Rates are set out at <a href="https://www.gov.uk/national-insurance-rates-letters" target="_blank" rel="noreferrer">GOV.UK: National Insurance rates and letters</a>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Why NI behaves differently from Income Tax',
          content: (<>
            <ul>
              <li><strong>Per-period, not cumulative.</strong> Income Tax accumulates across the tax year; NI is recalculated each pay period on that period's earnings. A one-off bonus can therefore trigger a higher NI deduction in that month that is not refunded later.</li>
              <li><strong>It caps out.</strong> Above £50,270 the employee rate drops to 2%, so unlike Income Tax there is no escalating rate for very high earners.</li>
              <li><strong>Calculated per job.</strong> If you have two jobs, each is assessed against the threshold separately, which can produce under- or over-payments that HMRC reconciles at year end.</li>
            </ul>
          </>),
        },
        {
          type: 'content',
          title: 'Self-employed NI',
          content: (<>
            <p>
              Sole traders pay Class 4 NI on profits: 6% between £12,570 and £50,270, and 2% above. The flat weekly Class 2 charge has been abolished, so low-profit sole traders no longer pay it — but they can still build qualifying years through Class 3 voluntary contributions where needed.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked example: £30,000 salary',
          content: (<>
            <ul>
              <li>Earnings above £12,570 (Primary Threshold): £17,430</li>
              <li>Employee NI (8%): £1,394/year</li>
              <li>Employer NI (15% on earnings above the £5,000 Secondary Threshold = £25,000): £3,750/year</li>
              <li><strong>Total cost of employing you: ≈ £33,750</strong> — useful context for salary-sacrifice and total-compensation discussions.</li>
            </ul>
          </>),
        },
        {
          type: 'content',
          title: 'The salary-sacrifice angle',
          content: (<>
            <p>
              Because NI is charged on gross pay, reducing your gross salary through <Link to="/guides/salary-sacrifice-vs-normal-pension" className="text-primary hover:underline font-medium">salary sacrifice</Link> avoids employee <em>and</em> employer NI on the sacrificed amount. Many employers pass their 15% saving back into your pension, which is why sacrifice is usually the most efficient way to contribute.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              NI rates and thresholds change frequently — the employee main rate has been cut several times in recent years. Figures here are 2026/27. Self-employed rules differ from employee rules, and benefit entitlement depends on your full contribution history, not just this year. See your exact NI split in the <Link to="/uk-salary-calculator" className="text-primary hover:underline font-medium">UK Salary Calculator</Link>.
            </p>
          </>),
        },
      ]}
    />
  );
}
