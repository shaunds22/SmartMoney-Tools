import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';

export default function HighInterestSavingsComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="Maximizing High-Interest Savings"
      description="Compare accounts and secure the best rates to combat inflation."
      url="/guides/high-interest-savings"
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              For people holding cash in a low- or no-interest account who want to earn a competitive rate without taking market risk. The case is simple: leaving £20,000 in a 1% account instead of a 4.5% one costs you hundreds of pounds a year for ten minutes' effort. This guide covers how to compare accounts, the tax on interest, and the safety limits. For the tax-free wrapper alternative, see the <Link to="/guides/tax-free-savings" className="text-primary hover:underline font-medium">tax-free savings (ISA) guide</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Compare by AER, not by headline rate',
          content: (<>
            <p>
              The Annual Equivalent Rate (AER) factors in how often interest is compounded, so it is the honest basis for comparison between accounts. A 4.5% AER easy-access account and a 5% AER fixed bond are directly comparable on AER, even though they pay interest differently.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Three account types, three trade-offs',
          content: (<>
            <div className="overflow-x-auto my-6">
              <table className="w-full text-sm border border-border">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left p-3 border-b border-border">Account</th>
                    <th className="text-left p-3 border-b border-border">Typical rate</th>
                    <th className="text-left p-3 border-b border-border">Access</th>
                    <th className="text-left p-3 border-b border-border">Best for</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="p-3 border-b border-border">Easy access</td><td className="p-3 border-b border-border">Variable, ~4–5%</td><td className="p-3 border-b border-border">Instant</td><td className="p-3 border-b border-border">Emergency funds</td></tr>
                  <tr><td className="p-3 border-b border-border">Notice account</td><td className="p-3 border-b border-border">Variable, slightly higher</td><td className="p-3 border-b border-border">30–120 days' notice</td><td className="p-3 border-b border-border">Funds you won't need suddenly</td></tr>
                  <tr><td className="p-3 border-b border-border">Fixed-rate bond</td><td className="p-3 border-b border-border">Fixed, often highest</td><td className="p-3 border-b border-border">Locked for the term</td><td className="p-3 border-b border-border">Money tied to a known date</td></tr>
                </tbody>
              </table>
            </div>
            <p>
              Rates shown are illustrative — they track the Bank of England base rate and move constantly. Never lock your emergency fund in a multi-year fixed bond.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The tax on savings interest',
          content: (<>
            <p>
              Most people do not pay tax on savings interest thanks to the Personal Savings Allowance:
            </p>
            <ul>
              <li><strong>Basic-rate payers:</strong> first £1,000 of interest tax-free.</li>
              <li><strong>Higher-rate payers:</strong> first £500 tax-free.</li>
              <li><strong>Additional-rate payers:</strong> no allowance.</li>
            </ul>
            <p>
              Above the allowance, HMRC usually collects the tax automatically by adjusting your tax code — you rarely need to file a return just for savings interest. A large balance at a good rate can push you over: £25,000 at 5% earns £1,250, so a basic-rate payer would owe tax on £250. Moving some cash into an ISA removes that exposure entirely. See <a href="https://www.gov.uk/apply-tax-free-interest-on-savings" target="_blank" rel="noreferrer">GOV.UK: Tax on savings interest</a>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Safety: the £85,000 limit',
          content: (<>
            <p>
              Money in a UK-regulated bank or building society is protected by the Financial Services Compensation Scheme (FSCS) up to £85,000 per person, per banking licence. If you hold more than that in cash, spread it across institutions with separate licences — note that some brands share a licence (e.g. NatWest and Royal Bank of Scotland), so check the FSCS register.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked example: £20,000 moved from 1% to 4.5%',
          content: (<>
            <ul>
              <li>At 1%: £200 interest in a year.</li>
              <li>At 4.5%: £900 interest in a year.</li>
              <li><strong>Difference: £700 of risk-free return for ten minutes' work.</strong></li>
            </ul>
          </>),
        },
        {
          type: 'when-useful',
          title: 'When chasing rates stops being worth it',
          content: (<>
            <p>
              For small balances, the gain from switching every few months is tiny and the admin is real. A reasonable approach: pick a competitive easy-access account, move once a year if the rate has fallen well below the market, and use a fixed bond only for money with a known future date. Project the growth with the <Link to="/compound-interest" className="text-primary hover:underline font-medium">Compound Interest Calculator</Link>. Consumer guidance at <a href="https://www.fca.org.uk/consumers" target="_blank" rel="noreferrer">FCA: Consumers</a>.
            </p>
          </>),
        },
      ]}
    />
  );
}
