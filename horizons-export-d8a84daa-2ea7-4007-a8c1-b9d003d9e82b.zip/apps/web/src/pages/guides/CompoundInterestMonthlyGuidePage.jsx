import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import ChooseGuide from '@/components/ChooseGuide.jsx';
import { Link } from 'react-router-dom';

export default function CompoundInterestMonthlyGuidePage() {
  return (
    <GuideLayout
      title="Compound Interest: How Monthly Deposits Grow Your Money"
      description="Understand compound interest and the Rule of 72, then see in concrete numbers how regular monthly deposits build wealth over time."
      url="/guides/compound-interest-monthly-deposits"
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <ChooseGuide items={[
              { question: 'Set a target and work out the monthly amount?', path: '/guides/savings-goals', text: 'setting and reaching your savings goals' },
              { question: 'Put your own numbers in?', path: '/compound-interest', text: 'compound interest calculator' },
            ]} />
            <p>
              Compound interest is the single concept that does most of the heavy lifting in long-term wealth. This guide explains how it works, the Rule of 72, and — the part most people actually want — what time and rate do to a modest monthly saving habit, with worked numbers rather than theory.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Simple vs compound: the difference that matters',
          content: (<>
            <p>
              With <strong>simple interest</strong>, you only ever earn returns on your original deposit. With <strong>compound interest</strong>, the interest you earn is added to your balance, and that larger balance then earns interest in the next cycle. The effect is a snowball: slow and almost linear at first, then accelerating as the "interest on interest" begins to eclipse your own contributions.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The Rule of 72',
          content: (<>
            <p>
              A quick mental shortcut for how long it takes money to double: divide 72 by your expected annual return.
            </p>
            <ul>
              <li>At <strong>4%</strong>, money doubles every 18 years (72 ÷ 4).</li>
              <li>At <strong>8%</strong>, every 9 years.</li>
              <li>At <strong>10%</strong>, every 7.2 years.</li>
            </ul>
            <p>
              It is an approximation, not exact, but it makes the power of a higher rate over a long horizon immediately legible.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Why monthly deposits change the shape of growth',
          content: (<>
            <p>
              A lump sum left alone compounds, but adding fresh capital every month keeps expanding the base that interest is calculated on. Early on, your contributions dominate the balance; later, the interest earned on past interest overtakes what you put in. The crossover — where growth exceeds contributions — is the moment compounding takes over.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The same £200/month across horizons and rates',
          content: (<>
            <p>
              Illustrative figures, rounded, assuming contributions made monthly and interest compounded monthly. They are not projections of any specific account.
            </p>
            <div className="overflow-x-auto my-6">
              <table className="w-full text-sm border border-border">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left p-3 border-b border-border">Horizon</th>
                    <th className="text-left p-3 border-b border-border">Contributed</th>
                    <th className="text-left p-3 border-b border-border">At 1% (current account)</th>
                    <th className="text-left p-3 border-b border-border">At 4% (Cash ISA)</th>
                    <th className="text-left p-3 border-b border-border">At 7% (index fund, illustrative)</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="p-3 border-b border-border">10 years</td><td className="p-3 border-b border-border">£24,000</td><td className="p-3 border-b border-border">≈ £25,200</td><td className="p-3 border-b border-border">≈ £29,500</td><td className="p-3 border-b border-border">≈ £34,600</td></tr>
                  <tr><td className="p-3 border-b border-border">20 years</td><td className="p-3 border-b border-border">£48,000</td><td className="p-3 border-b border-border">≈ £52,900</td><td className="p-3 border-b border-border">≈ £73,300</td><td className="p-3 border-b border-border">≈ £104,100</td></tr>
                  <tr><td className="p-3 border-b border-border">30 years</td><td className="p-3 border-b border-border">£72,000</td><td className="p-3 border-b border-border">≈ £83,600</td><td className="p-3 border-b border-border">≈ £138,600</td><td className="p-3 border-b border-border">≈ £243,900</td></tr>
                </tbody>
              </table>
            </div>
            <p>
              Two things stand out. First, the gap between 4% and 7% over 30 years is enormous — £105,000 — even though the rate difference is only 3 points. Second, in the 30-year/7% row you contributed £72,000 and the balance is £243,900: roughly £172,000 of the final pot came from compounding, not from you.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Time beats extra capital',
          content: (<>
            <p>
              Starting earlier with less usually beats starting later with more. A 25-year-old saving £150 a month until 65 has 40 years of compounding; a 45-year-old saving £450 a month until 65 has 20 years and three times the monthly outlay — and typically ends with less, because the older saver missed two decades of compounding on the early contributions. The lesson is unglamorous: start now, even if the amount is small.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Four things that quietly destroy compounding',
          content: (<>
            <ul>
              <li><strong>Withdrawing mid-course.</strong> Pulling money out to buy a car resets the base that future interest would have compounded on. Keep a separate sinking fund for planned spending.</li>
              <li><strong>Waiting until you can afford "enough."</strong> £50 a month for 30 years beats £0 a month while you wait to afford £200.</li>
              <li><strong>High fees.</strong> A fund charging 1.5% a year silently removes a large slice of long-term returns. Low-cost broad-market index funds keep more of the compounding working for you.</li>
              <li><strong>Ignoring inflation.</strong> If cash earns 3% and inflation is 4%, real purchasing power falls. For horizons over 5 years, investments have historically delivered the higher real returns needed for compounding to work in your favour.</li>
            </ul>
          </>),
        },
        {
          type: 'when-useful',
          title: 'Cash or invest?',
          content: (<>
            <p>
              Money you need within 5 years (a house deposit, an emergency fund) belongs in cash to avoid selling after a market fall. Money you can leave for 10+ years has historically grown more in diversified investments, at the cost of short-term volatility. Inside an ISA, all the growth is tax-free; outside one, basic-rate payers pay tax on interest above £1,000 a year.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Run your own numbers',
          content: (<>
            <p>
              Plug in your deposit, monthly contribution and expected rate with the <Link to="/compound-interest" className="text-primary hover:underline font-medium">Compound Interest Calculator</Link>, or reverse-engineer the monthly amount needed to hit a target with the <Link to="/savings-goal-calculator" className="text-primary hover:underline font-medium">Savings Goal Calculator</Link>.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Assumptions and limitations',
          content: (<>
            <p>
              The 7% figure is an illustrative long-run average based on historical global stock-market returns; past performance does not guarantee future results, investments can fall as well as rise, and you may get back less than you put in. The Rule of 72 is an approximation. Cash rates fluctuate with the Bank of England base rate. Consider your risk tolerance and time horizon, and seek independent financial advice before allocating capital to equities. Learn how we ensure accuracy and quality in our <Link to="/editorial-policy" className="text-primary hover:underline font-medium">editorial policy</Link>.
            </p>
          </>),
        },
      ]}
    />
  );
}
