import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';
import { MORTGAGE_SERIES } from '@/data/guideSeries.js';

export default function MortgageComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="Comprehensive Mortgage Guide"
      description="Understand mortgage types, calculate true affordability, and navigate interest rates."
      url="/guides/mortgage-comprehensive"
      series={MORTGAGE_SERIES}
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              For people choosing or remortgaging a UK mortgage who want to understand how rate type, loan-to-value and term interact to change the monthly payment and the total interest. It is the product-and-rate guide; for the buying process itself see <Link to="/guides/first-time-buyer" className="text-primary hover:underline font-medium">first-time buyer</Link>, for overpaying see <Link to="/guides/mortgage-overpayments" className="text-primary hover:underline font-medium">mortgage overpayments</Link>, and for how much you can borrow see <Link to="/guides/mortgage-affordability-first-time-buyers" className="text-primary hover:underline font-medium">mortgage affordability</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Fixed vs tracker: what you are really choosing',
          content: (<>
            <ul>
              <li><strong>Fixed-rate</strong> locks your rate for a set period (commonly 2, 5 or 10 years). You gain budget certainty — the payment does not move even if the Bank of England base rate does — but if rates fall you are stuck, and leaving early usually means a hefty Early Repayment Charge.</li>
              <li><strong>Tracker / variable</strong> follows the base rate (or the lender's SVR). It is typically cheaper at the start but can rise sharply and unpredictably, so your monthly payment is not guaranteed.</li>
            </ul>
            <p>
              The choice is largely about certainty versus cost. If a payment rise would break your budget, fix; if you have headroom and believe rates will fall, a tracker may suit.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Loan-to-value: why your deposit sets your rate',
          content: (<>
            <p>
              Lenders price by LTV bands — the loan as a percentage of the property value. A bigger deposit means a lower LTV and a cheaper rate, because the lender takes less risk.
            </p>
            <ul>
              <li><strong>95% LTV</strong> (5% deposit): highest rates, strictest checks.</li>
              <li><strong>90% LTV</strong> (10% deposit): the standard entry point for first-time buyers.</li>
              <li><strong>60% LTV</strong> (40% deposit): the cheapest rates on the market.</li>
            </ul>
            <p>
              Even a small extra deposit that tips you into a lower LTV band can unlock a meaningfully cheaper rate.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked example: rate and term on a £250,000 loan',
          content: (<>
            <ul>
              <li><strong>4% over 25 years:</strong> ≈ £1,319/month, ≈ £145,700 total interest.</li>
              <li><strong>5.5% over 25 years:</strong> ≈ £1,535/month, ≈ £210,500 total interest.</li>
            </ul>
            <p>
              A 1.5-point rate rise adds roughly £216 to the monthly payment and over £64,000 to the total interest across the term — which is why remortgaging at the right time matters. Model your own figures with the <Link to="/mortgage" className="text-primary hover:underline font-medium">Mortgage Calculator</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Fees: sometimes a higher rate with no fee is cheaper',
          content: (<>
            <p>
              Arrangement fees can be £999 or more. A fee-free deal at a slightly higher rate can cost less overall than a low-rate deal with a big fee, depending on the loan size and fix length. The only reliable way to judge is to compare the total cost over the fixed period — fee plus monthly payments — not the headline rate alone.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Remortgaging: do not drift onto the SVR',
          content: (<>
            <p>
              When a fixed deal ends, you move onto the lender's Standard Variable Rate, which is usually much higher. Start shopping for a new deal around six months before your fix expires so you can switch seamlessly. See <a href="https://www.moneyhelper.org.uk/en/homes/buying-a-home" target="_blank" rel="noreferrer">MoneyHelper: Buying a home</a>.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              Mortgage rates are macroeconomic and unpredictable; locking in fixes you to a rate that may later look expensive, and leaving early usually incurs ERCs. LTV bands, fees and affordability criteria vary by lender. Your home may be repossessed if you do not keep up repayments. This is educational, not advice; for a tailored recommendation, speak to a mortgage adviser or broker.
            </p>
          </>),
        },
      ]}
    />
  );
}
