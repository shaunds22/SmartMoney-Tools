import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';

export default function DebtConsolidationComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="Debt Consolidation Guide"
      description="When to combine debts, how it works, and the traps to avoid."
      url="/guides/debt-consolidation"
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              For people with several high-interest debts who are wondering whether a single consolidation loan would help. Consolidation means taking one new loan to pay off several existing ones, aiming for a lower overall rate, one monthly payment and a clear end date. Done well it saves money and simplifies life; done badly it costs more and puts your home at risk. This guide covers the decision; for the payoff methods to apply afterwards, see the <Link to="/guides/debt-repayment" className="text-primary hover:underline font-medium">debt repayment guide</Link>.
            </p>
          </>),
        },
        {
          type: 'when-useful',
          title: 'When consolidation actually helps',
          content: (<>
            <ul>
              <li>You can secure a new loan at a lower APR than the average of your existing debts.</li>
              <li>You keep the new term short — not stretching 3 years of card debt into a 10-year loan.</li>
              <li>You close or freeze the old credit cards the moment they are paid off.</li>
            </ul>
            <p>
              If all three hold, consolidation can meaningfully reduce both the monthly payment and the total interest.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked example: £15,000 across three high-rate debts',
          content: (<>
            <p><strong>Before:</strong></p>
            <ul>
              <li>Card 1: £5,000 at 20%</li>
              <li>Card 2: £5,000 at 24%</li>
              <li>Overdraft: £5,000 at 39%</li>
              <li>Combined minimums: ≈ £450/month, mostly interest — balances barely move.</li>
            </ul>
            <p><strong>After — a £15,000 personal loan at 8% over 4 years:</strong></p>
            <ul>
              <li>New monthly payment: ≈ £366.</li>
              <li><strong>Payment drops by ≈ £84/month, the debt has a firm 4-year end date, and thousands in interest are saved.</strong></li>
            </ul>
          </>),
        },
        {
          type: 'content',
          title: 'The two traps that undo consolidation',
          content: (<>
            <ul>
              <li><strong>Re-borrowing.</strong> The primary risk is behavioural. Consolidation frees up your card limits; if you start spending on them again, you end up with the new loan <em>and</em> fresh card balances — double the debt. Close or freeze the cards the day you consolidate.</li>
              <li><strong>Securing unsecured debt against your home.</strong> Some consolidation products are secured homeowner loans with low rates because your property is collateral. Default on an unsecured personal loan and your credit is damaged; default on a secured loan and your home can be repossessed. Avoid tying consumer debt to your property.</li>
            </ul>
          </>),
        },
        {
          type: 'when-useful',
          title: 'When consolidation is the wrong answer',
          content: (<>
            <p>
              If your credit is already damaged, you will not qualify for a rate low enough to help — and a high-rate consolidation loan can cost more than leaving the debts where they are. In that situation a formal Debt Management Plan through a free charity like <a href="https://www.stepchange.org/debt-info/debt-consolidation.aspx" target="_blank" rel="noreferrer">StepChange</a> is usually the safer route. Consolidation is also unnecessary if you can clear the existing debts within a year through the Avalanche method.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'After consolidating: keep the plan',
          content: (<>
            <p>
              A consolidation loan removes the high interest, not the debt itself. Apply a structured payoff method to the new loan — overpay where you can, and treat the freed-up monthly cash as payoff fuel rather than spending money. Model the alternative of paying the debts down directly with the <Link to="/debt-snowball-calculator" className="text-primary hover:underline font-medium">Debt Snowball Calculator</Link>.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              The rates in the example are illustrative; actual APRs depend on your credit history and market conditions. Early repayment charges may apply to the new loan. This is educational, not advice; for serious debt problems, a free debt adviser is the right first step.
            </p>
          </>),
        },
      ]}
    />
  );
}
