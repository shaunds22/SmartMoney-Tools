import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';
import { MORTGAGE_SERIES } from '@/data/guideSeries.js';

export default function MortgageAffordabilityFirstTimeBuyersGuidePage() {
  return (
    <GuideLayout
      title="Mortgage Affordability for First-Time Buyers"
      description="How much can you borrow? Understand UK mortgage affordability rules, income multiples, deposit requirements and lender stress tests."
      url="/guides/mortgage-affordability-first-time-buyers"
      series={MORTGAGE_SERIES}
      lastUpdated="2026-09-03"
      sections={[
        {
          type: 'introduction',
          title: 'Introduction',
          content: (<>
            <p>
              Mortgage affordability is the calculation a lender uses to decide the maximum amount they will lend you. It is not a single number plucked from the air — it is the product of your income, your outgoings, your deposit, and the lender's own risk appetite. For a first-time buyer, understanding this calculation before you start house-hunting is the difference between a realistic search and a string of disappointing rejections.
            </p>
            <p>
              This guide explains how UK lenders assess affordability in 2026, the income multiples that cap your borrowing, the role your deposit plays, and how to estimate your own maximum price before you ever speak to a broker.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'How Lenders Calculate How Much You Can Borrow',
          content: (<>
            <p>
              UK mortgage lenders use two main filters to set your maximum loan: an <strong>income multiple</strong> (a rough cap) and a <strong>detailed affordability assessment</strong> (the real test). You must pass both.
            </p>
            <h3>The Income Multiple (The 4.5x Rule)</h3>
            <p>
              As a rule of thumb, most high-street lenders will lend up to <strong>4.5 times your gross annual income</strong>. Earn £35,000 and your theoretical maximum mortgage is around £157,500. For joint applications, lenders apply the multiple to your combined gross income.
            </p>
            <p>
              Some lenders stretch to <strong>5x income</strong> for higher earners (typically those earning £75,000 or more) or for certain professions. A handful of specialist lenders offer 5.5x or even 6x, but the criteria are strict and the rates are less competitive. The 4.5x figure remains the benchmark most first-time buyers should plan around.
            </p>
            <h3>The Affordability Assessment (The Real Test)</h3>
            <p>
              Since the Mortgage Market Review, lenders cannot simply hand you 4.5x your salary. They run a detailed affordability assessment that looks at your <strong>net disposable income</strong> after:
            </p>
            <ul>
              <li>Income tax, National Insurance and pension contributions</li>
              <li>Existing credit commitments — personal loans, car finance, credit card minimum payments</li>
              <li>Childcare, school fees and maintenance payments</li>
              <li>Essential living costs and estimated future spending</li>
            </ul>
            <p>
              The lender then checks whether the monthly mortgage payment comfortably fits within what is left. If your outgoings are high, you may be offered significantly less than the 4.5x headline figure.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'How Your Deposit Affects Affordability',
          content: (<>
            <p>
              Your deposit does two things. First, it sets the maximum property price: <em>max property = max mortgage + deposit</em>. Second, it determines your <strong>Loan-to-Value (LTV)</strong> ratio, which directly controls the interest rate you are offered — and therefore the monthly payment you must pass the affordability check on.
            </p>
            <ul>
              <li><strong>5% deposit (95% LTV):</strong> The minimum, but rates are highest and fewer lenders participate.</li>
              <li><strong>10% deposit (90% LTV):</strong> The most common first-time buyer tier, with noticeably better rates than 95%.</li>
              <li><strong>15–20% deposit (80–85% LTV):</strong> A meaningful step down in rate, which can materially raise the price you can afford.</li>
              <li><strong>25%+ deposit (75% LTV or lower):</strong> The best rates, typically reserved for buyers with substantial savings or equity.</li>
            </ul>
            <p>
              Because a bigger deposit unlocks a lower rate, your deposit indirectly increases affordability twice: once by adding cash to the purchase, and again by reducing the monthly payment the lender must approve.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Stress Testing: Could You Still Afford It If Rates Rise?',
          content: (<>
            <p>
              Lenders do not just check that you can afford the mortgage at today's rate — they check that you could still afford it if rates rise. Historically, regulators required lenders to stress-test at 3 percentage points above the revert rate. The FCA removed that mandatory 3% test in August 2022, but lenders still run their own internal stress tests, typically assuming a rate 1–2% above your actual deal.
            </p>
            <p>
              In practice this means a lender may lend you less than the raw affordability maths suggests, to leave a buffer for future rate increases. If you are taking a 2-year fix, plan your own budget on the assumption that the follow-on rate could be higher.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Schemes That Boost First-Time Buyer Affordability',
          content: (<>
            <p>
              Several government-backed schemes can increase the deposit you can put down or reduce the price you pay, both of which improve affordability:
            </p>
            <ul>
              <li><strong>Lifetime ISA (LISA):</strong> Save up to £4,000 a year and the government adds a 25% bonus (up to £1,000 a year), but only for a first home under £450,000 or retirement.</li>
              <li><strong>First Homes scheme:</strong> A 30–50% discount on eligible new-build homes for first-time buyers, with the discount locked in for future resales.</li>
              <li><strong>Shared Ownership:</strong> Buy a 25–75% share of a property and pay subsidised rent on the remainder, lowering the deposit and mortgage needed to get on the ladder.</li>
            </ul>
            <p>
              Note: the Help to Buy equity loan scheme closed to new applications in October 2022 and is no longer available.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked Example',
          content: (<>
            <p>A single first-time buyer earns <strong>£35,000</strong> a year and has saved a <strong>£17,500</strong> deposit. They have no debts and minimal committed outgoings.</p>
            <p><strong>Step 1 — Income multiple:</strong> 4.5 × £35,000 = <strong>£157,500</strong> maximum mortgage.</p>
            <p><strong>Step 2 — Max property price:</strong> £157,500 + £17,500 = <strong>£175,000</strong>. The deposit is exactly 10% of this price (90% LTV), which qualifies for competitive first-time buyer rates.</p>
            <p><strong>Step 3 — Monthly payment check:</strong> Borrowing £157,500 at 4.5% over 25 years costs roughly <strong>£877 a month</strong>. The buyer's net take-home pay is around £2,300 a month. After the mortgage, council tax and insurance (roughly £200), about £1,200 remains for living costs — comfortably passing the affordability assessment.</p>
            <p>If the same buyer wanted a <strong>£200,000</strong> home, they would need a £42,500 deposit (over 21%) to stay within the 4.5x cap, or a lender willing to stretch to a higher income multiple — which is far less common for a £35,000 salary.</p>
          </>),
        },
        {
          type: 'content',
          title: 'Common Mistakes',
          content: (<>
            <p>
              <strong>Confusing the income multiple with a guarantee:</strong> 4.5x your salary is a ceiling, not a promise. High existing outgoings — a car loan, childcare, or heavy credit card balances — can cut your actual offer well below it. Clear what debt you can before applying.
            </p>
            <p>
              <strong>Ignoring the rate impact of a small deposit:</strong> A 5% deposit gets you into a cheaper price band on paper, but the higher 95% LTV rate can push the monthly payment past the affordability limit, reducing the loan you are offered. Sometimes saving a few thousand more to reach 10% LTV unlocks a larger mortgage, not a smaller one.
            </p>
            <p>
              <strong>Forgetting that bonus and overtime are not always counted in full:</strong> Lenders typically use base salary for the income multiple and may only count a percentage of variable pay (bonus, commission, overtime) if it is guaranteed or has a consistent two-year history.
            </p>
          </>),
        },
        {
          type: 'resources',
          title: 'Related Calculators',
          content: (<>
            <ul>
              <li><Link to="/mortgage" className="font-medium hover:underline text-primary">Mortgage Calculator</Link>: Turn your target price, deposit and rate into a monthly payment you can stress-test against your take-home pay.</li>
              <li><Link to="/uk-salary-calculator" className="font-medium hover:underline text-primary">UK Salary Calculator</Link>: See your true net monthly income — the figure lenders base the affordability assessment on.</li>
              <li><Link to="/budget-planner" className="font-medium hover:underline text-primary">Budget Planner</Link>: Map your committed outgoings so you know how much disposable income a lender will see.</li>
            </ul>
          </>),
        },
        {
          type: 'faq',
          title: 'Frequently Asked Questions',
          items: [
            { question: 'How many times my salary can I borrow for a mortgage?', answer: 'Most UK lenders cap lending at 4 to 4.5 times your gross annual income. Higher earners and certain professions may access 5x, with specialist lenders occasionally offering more.' },
            { question: 'Does a bigger deposit increase how much I can borrow?', answer: 'Indirectly, yes. A larger deposit lowers your Loan-to-Value, which usually secures a lower interest rate. A lower rate means a lower monthly payment, which improves the affordability assessment and can increase the loan you are offered.' },
            { question: 'Do lenders still stress-test mortgages?', answer: 'The mandatory 3% stress test was withdrawn in August 2022, but lenders still run their own internal stress tests to ensure you could cope with higher rates. Expect them to assume a rate 1–2% above your actual deal.' },
            { question: 'Can I use a Lifetime ISA for my deposit?', answer: 'Yes. A LISA can be used for your first home (up to £450,000) and the 25% government bonus effectively increases your deposit, improving both your LTV and affordability.' },
          ],
        },
        {
          type: 'limitations',
          title: 'Financial Disclaimer',
          content: (<>
            <p>
              Mortgage income multiples, Loan-to-Value bands and stress-test practices vary by lender and change over time; the figures here are typical for the UK market in 2026 and are educational estimates, not a guarantee of any offer. Government scheme rules and thresholds are subject to change — verify current details on GOV.UK. Your home may be repossessed if you do not keep up repayments on your mortgage.
            </p>
          </>),
        },
      ]}
    />
  );
}
