import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';

export default function CompareLoanRepaymentsGuidePage() {
  return (
    <GuideLayout
      title="How to Compare Loan Repayments Before Borrowing"
      description="Look past the monthly payment illusion and calculate the true cost of credit."
      url="/guides/compare-loan-repayments"
      lastUpdated="2026-09-11"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              For people about to borrow — for home improvements, a car, or to consolidate other debts — who want to compare options honestly rather than be sold on a monthly payment. Lenders and dealers anchor your attention on "only £199 a month" because a low monthly figure hides a long term and a high total cost. This guide shows how to compare the true cost of borrowing the same amount through different routes. For the personal-loan product itself, see <Link to="/guides/personal-loan" className="text-primary hover:underline font-medium">personal loans explained</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The metric that matters: Total Amount Repayable',
          content: (<>
            <p>
              The monthly payment tells you affordability; the Total Amount Repayable (monthly payment × number of months, plus any fees) tells you cost. Two loans with identical monthly payments can differ by thousands in total cost if their terms differ. Always compare on total repayable, not on the monthly figure alone.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'APR — and why "Representative" is a warning',
          content: (<>
            <p>
              The APR folds the interest rate and any mandatory fees into one percentage, so it is the honest basis for comparison between products. But adverts quote a "Representative APR" that the lender only has to offer to 51% of accepted applicants — the rate you actually get can be higher. Use soft-search eligibility checkers to see your likely personal rate before applying, because multiple hard applications in a short period damage your credit file.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked comparison: borrowing £10,000 for home repairs',
          content: (<>
            <div className="overflow-x-auto my-6">
              <table className="w-full text-sm border border-border">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left p-3 border-b border-border">Option</th>
                    <th className="text-left p-3 border-b border-border">APR</th>
                    <th className="text-left p-3 border-b border-border">Term</th>
                    <th className="text-left p-3 border-b border-border">Monthly</th>
                    <th className="text-left p-3 border-b border-border">Total interest</th>
                    <th className="text-left p-3 border-b border-border">Total repayable</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="p-3 border-b border-border">A — good credit</td><td className="p-3 border-b border-border">6.5%</td><td className="p-3 border-b border-border">3 yrs</td><td className="p-3 border-b border-border">£306</td><td className="p-3 border-b border-border">£1,016</td><td className="p-3 border-b border-border">£11,016</td></tr>
                  <tr><td className="p-3 border-b border-border">B — good credit, longer</td><td className="p-3 border-b border-border">6.5%</td><td className="p-3 border-b border-border">5 yrs</td><td className="p-3 border-b border-border">£195</td><td className="p-3 border-b border-border">£1,700</td><td className="p-3 border-b border-border">£11,700</td></tr>
                  <tr><td className="p-3 border-b border-border">C — fair credit</td><td className="p-3 border-b border-border">15.9%</td><td className="p-3 border-b border-border">5 yrs</td><td className="p-3 border-b border-border">£243</td><td className="p-3 border-b border-border">£4,580</td><td className="p-3 border-b border-border">£14,580</td></tr>
                </tbody>
              </table>
            </div>
            <p>
              The same £10,000 costs anywhere from £1,016 to £4,580 in interest depending on term and credit score. Option B feels £111/month cheaper than A but costs £684 more overall. Option C costs more than four times as much in interest as Option A.
            </p>
          </>),
        },
        {
          type: 'when-useful',
          title: 'Does a 0% card beat a loan?',
          content: (<>
            <p>
              Sometimes. Borrowing £5,000 on a 24-month 0% purchase card and paying exactly £208.33 a month costs nothing in interest — beating any loan. The risk is the discipline: miss a payment or fail to clear it before the 0% period ends and the rate jumps to 20%+. A 0% card suits disciplined borrowers with a clear plan; a fixed-term loan suits those who want the structure and certainty.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Three traps to check before signing',
          content: (<>
            <ul>
              <li><strong>Early Repayment Charges.</strong> If you plan to clear the loan early with a bonus, check the ERC — some lenders charge up to 58 days' interest on early settlement.</li>
              <li><strong>Secured vs unsecured.</strong> Homeowner loans offer low rates because your property is collateral. Default on an unsecured loan and your credit suffers; default on a secured loan and your home is at risk.</li>
              <li><strong>Multiple hard searches.</strong> Applying to several lenders in one afternoon leaves multiple hard searches and can cause automatic declines. Use soft-search checkers first.</li>
            </ul>
          </>),
        },
        {
          type: 'content',
          title: 'How a loan affects a future mortgage',
          content: (<>
            <p>
              Outstanding loan balances reduce mortgage affordability: lenders deduct the monthly loan payment from your disposable income, lowering the maximum they will lend. If a mortgage is on the horizon, factor that in before taking new borrowing.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              APRs are illustrative and depend on Bank of England base rates, lender criteria and your credit history. Missing repayments carries severe consequences including defaults and CCJs. Never borrow to fund lifestyle or speculative investments. Test affordability with the <Link to="/budget-planner" className="text-primary hover:underline font-medium">Budget Planner</Link> and map early payoff with the <Link to="/debt-snowball-calculator" className="text-primary hover:underline font-medium">Debt Snowball Calculator</Link>.
            </p>
          </>),
        },
      ]}
    />
  );
}
