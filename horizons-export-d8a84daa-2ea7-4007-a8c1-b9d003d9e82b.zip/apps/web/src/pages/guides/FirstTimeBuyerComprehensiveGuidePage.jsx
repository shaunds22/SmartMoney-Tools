import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import ChooseGuide from '@/components/ChooseGuide.jsx';
import { Link } from 'react-router-dom';
import { MORTGAGE_SERIES } from '@/data/guideSeries.js';

export default function FirstTimeBuyerComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="First-Time Buyer's Guide: Process, Costs and Budget"
      description="The full UK first-time buyer journey end to end — Agreements in Principle, how much you can borrow, every upfront and ongoing cost, and the process from offer to completion."
      url="/guides/first-time-buyer"
      series={MORTGAGE_SERIES}
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <ChooseGuide items={[
              { question: 'How much can I actually borrow?', path: '/guides/mortgage-affordability-first-time-buyers', text: 'mortgage affordability for first-time buyers' },
              { question: 'Which mortgage product should I pick?', path: '/guides/mortgage-comprehensive', text: 'comprehensive mortgage guide' },
            ]} />
            <p>
              For people buying their first UK home who want the full picture in one place — from proving you can borrow, through every cash cost on day one and the ongoing monthly shift from renting to owning, to collecting the keys.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Before you view anything: the Agreement in Principle',
          content: (<>
            <p>
              An Agreement in Principle (AIP) is a soft-check document from a lender stating roughly how much they will lend you. Estate agents expect one before they will take an offer seriously, so get it early — it also tells you your real price ceiling before you fall for a house you cannot afford. It usually involves a soft credit search that does not affect your score.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'How much you can borrow: the 4.5× rule',
          content: (<>
            <p>
              Most lenders cap borrowing at around 4.5 times gross annual household income, subject to affordability checks that stress your ability to pay at a higher rate. On a £40,000 salary that is roughly £180,000; the rest of any purchase price must come from your deposit. Joint buyers are assessed on combined income. See the <Link to="/guides/mortgage-affordability-first-time-buyers" className="text-primary hover:underline font-medium">mortgage affordability guide</Link> for the full mechanics.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The deposit and the LTV it buys you',
          content: (<>
            <ul>
              <li><strong>5% deposit</strong> — possible under government guarantee schemes, but carries the highest rates and strictest checks.</li>
              <li><strong>10% deposit</strong> — the standard entry point, with better rates and a higher chance of approval.</li>
              <li><strong>20%+ deposit</strong> — unlocks significantly cheaper rates by dropping you into a lower LTV band.</li>
            </ul>
            <p>
              First-time buyers can use a <Link to="/guides/tax-free-savings" className="text-primary hover:underline font-medium">Lifetime ISA</Link> to save the deposit: the 25% government bonus on up to £4,000 a year is hard to beat for this purpose.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The day-one cash checklist',
          content: (<>
            <p>
              The biggest first-time buyer mistake is assuming the deposit is the only cash needed. Budget for:
            </p>
            <ul>
              <li><strong>Conveyancing (solicitor):</strong> £1,000–£2,000.</li>
              <li><strong>Survey:</strong> £400–£800 for a Level 2 Homebuyer's Report — this is for you, not the lender, and flags damp, structural issues and costly repairs.</li>
              <li><strong>Mortgage arrangement fee:</strong> often £999, sometimes addable to the loan (but you then pay interest on it for 25 years).</li>
              <li><strong>Stamp Duty Land Tax:</strong> first-time buyers pay no SDLT on the first £300,000 of a property up to £500,000 (5% on the portion from £300,001 to £500,000). Above £500,000 the relief does not apply. Verify current thresholds at <a href="https://www.gov.uk/stamp-duty-land-tax" target="_blank" rel="noreferrer">GOV.UK: Stamp Duty Land Tax</a>.</li>
              <li><strong>Move and furnish:</strong> removal van (£300–£1,000) plus immediate essentials (bed, fridge, white goods).</li>
            </ul>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked example: total cash on day one for a £250,000 home',
          content: (<>
            <ul>
              <li>10% deposit: £25,000</li>
              <li>Solicitor: £1,500</li>
              <li>Level 2 survey: £500</li>
              <li>Stamp Duty: £0 (within FTB relief)</li>
              <li>Move and furnish: £2,500</li>
              <li>Mortgage fee: £999 (added to loan)</li>
              <li><strong>Total cash needed up front: ≈ £29,500</strong></li>
            </ul>
            <p>
              Plan your deposit timeline with the <Link to="/savings-goal-calculator" className="text-primary hover:underline font-medium">Savings Goal Calculator</Link> and stress-test the monthly payment with the <Link to="/mortgage" className="text-primary hover:underline font-medium">Mortgage Calculator</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The ongoing monthly shift: renting to owning',
          content: (<>
            <p>
              Once you own, the monthly housing cost usually rises — and repairs become your problem, not a landlord's. For the same £250,000 home with a £225,000 mortgage at 4.5%:
            </p>
            <ul>
              <li>Mortgage: ≈ £1,250</li>
              <li>Council tax (Band C): ≈ £160</li>
              <li>Home and contents insurance: ≈ £30</li>
              <li>Maintenance sinking fund (boiler, roof): ≈ £150</li>
              <li><strong>Core housing cost: ≈ £1,590/month</strong> — often up from £1,000 rent where the landlord covered repairs.</li>
            </ul>
            <p>
              Stress-test these numbers with the <Link to="/mortgage" className="text-primary hover:underline font-medium">Mortgage Calculator</Link> and the <Link to="/budget-planner" className="text-primary hover:underline font-medium">Budget Planner</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Three budgeting mistakes first-time buyers make',
          content: (<>
            <ul>
              <li><strong>Draining savings to fund the deposit.</strong> Moving in with £0 in the bank is dangerous — a broken boiler is a £2,500 emergency that is now your problem. Keep a £3,000 buffer post-completion.</li>
              <li><strong>Ignoring leasehold charges.</strong> Flats carry ground rent and service charges that can rise unpredictably. Factor them into the monthly budget, not just the mortgage.</li>
              <li><strong>Borrowing to the max offer.</strong> Just because a lender will lend £250,000 does not mean you should take it. Maxing out affordability leaves no room if rates rise at remortgage or one income drops.</li>
            </ul>
          </>),
        },
        {
          type: 'content',
          title: 'Deposit source rules',
          content: (<>
            <p>
              The deposit must come from genuine savings or a documented, non-repayable family gift — lenders check bank statements, and a personal loan taken out for the deposit will usually be spotted and decline the application. Plan the source early so there are no surprises in underwriting.
            </p>
          </>),
        },
        {
          type: 'step-by-step',
          title: 'From offer to completion',
          content: (<>
            <ol>
              <li><strong>Make an offer</strong> once you have an AIP; it is subject to contract and survey, so you are not committed yet.</li>
              <li><strong>Instruct a solicitor and surveyor.</strong> The survey tells you whether the price is fair and whether expensive repairs are coming.</li>
              <li><strong>Formal mortgage application</strong> — the lender does their own valuation and full affordability checks.</li>
              <li><strong>Exchange contracts</strong> — you pay the deposit and become legally bound.</li>
              <li><strong>Completion</strong> — your solicitor transfers the mortgage funds to the seller's solicitor; once cleared, you get the keys.</li>
            </ol>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              Housing markets are highly localised and SDLT thresholds and FTB relief change with government budgets — confirm current rules on GOV.UK before relying on the figures. Affordability multiples and rates vary by lender and credit history. Council tax bands and insurance costs vary by property and area. Your home may be repossessed if you do not keep up mortgage payments. This is educational, not advice; a mortgage broker can tailor recommendations to your situation.
            </p>
          </>),
        },
      ]}
    />
  );
}
