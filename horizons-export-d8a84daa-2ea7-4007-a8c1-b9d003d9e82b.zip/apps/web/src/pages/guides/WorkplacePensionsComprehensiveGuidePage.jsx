import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';
import { PENSION_SERIES } from '@/data/guideSeries.js';

export default function WorkplacePensionsComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="Workplace Pensions & Auto-Enrolment Guide"
      description="Understand employer contributions, tax relief, and how to maximize your workplace pension."
      url="/guides/workplace-pensions"
      series={PENSION_SERIES}
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              For UK employees who have been auto-enrolled into a workplace pension — or are about to be — and want to know what they are getting, what it costs them, and how to make it worth more. It is distinct from the <Link to="/guides/pension-contributions" className="text-primary hover:underline font-medium">pension contributions guide</Link> (which is about how much to pay in, the allowances and the tax-relief maths). This one stays focused on the workplace scheme itself: who is enrolled, the minimums, and the choices inside it.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Who gets auto-enrolled',
          content: (<>
            <p>
              Your employer must enrol you and contribute if you are aged between 22 and State Pension age and earn more than £10,000 a year. You can opt out, but you then forfeit your employer's contribution — effectively a voluntary pay cut. Lower earners and younger staff can ask to join. The rules are set by <a href="https://www.thepensionsregulator.gov.uk/en/employers" target="_blank" rel="noreferrer">The Pensions Regulator</a>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The statutory minimums',
          content: (<>
            <p>
              Minimum contributions are based on qualifying earnings (the band between £6,240 and £50,270):
            </p>
            <ul>
              <li><strong>You:</strong> 5%</li>
              <li><strong>Your employer:</strong> 3%</li>
              <li><strong>Tax relief:</strong> tops it up, so the total going in is at least 8% of qualifying earnings.</li>
            </ul>
            <p>
              On a £35,000 salary, qualifying earnings are £28,760. At minimums, about £1,438 comes from you, £863 from your employer, and tax relief adds the rest — roughly £2,300 a year into the pot before any investment growth.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The decision that matters most: match the employer',
          content: (<>
            <p>
              Many employers match your contributions above the 3% minimum, often up to 5%, 6% or 8%. An employer match is the closest thing to free money in personal finance — every pound you contribute to the match limit is doubled. Find out your employer's maximum matching percentage and raise your contribution to meet it. Failing to do so is leaving part of your salary on the table.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Inside the scheme: the default fund',
          content: (<>
            <p>
              Workplace pensions invest your money in a "default" fund, usually a balanced, medium-risk option chosen to suit a typical member. That is fine for many people, but if you are decades from retirement you may prefer a higher-equity fund for greater long-term growth potential, and some schemes offer lower-cost passive options. You can usually switch funds within the scheme at no charge. MoneyHelper has a plain-English guide at <a href="https://www.moneyhelper.org.uk/en/pensions-and-retirement/pensions-and-retirement" target="_blank" rel="noreferrer">MoneyHelper: Pensions and retirement</a>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'What happens when you change jobs',
          content: (<>
            <p>
              The pension belongs to you, not the employer. You can leave it invested where it is, transfer it to your new employer's scheme, or consolidate it into a personal pension. Consolidating can reduce fees and simplify tracking, but check for exit penalties and whether you would lose any guaranteed benefits before transferring.
            </p>
          </>),
        },
        {
          type: 'when-useful',
          title: 'Are the minimums enough?',
          content: (<>
            <p>
              Probably not for a comfortable retirement. The 8% minimum was designed as a starting point, not a target; many retirement models suggest a total contribution of 12–15% (including employer and tax relief) is closer to what most people need. The <Link to="/guides/pension-contributions" className="text-primary hover:underline font-medium">contributions guide</Link> covers how to judge the right level for you.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              Minimum percentages and the qualifying-earnings band are 2026/27 figures and change with legislation. Scheme rules, fund ranges and matching terms vary by employer. Pension values can fall as well as rise and depend on investment performance. Project your pot with the <Link to="/pensions-calculator" className="text-primary hover:underline font-medium">Pensions Calculator</Link>; for a tailored retirement plan, an FCA-regulated adviser can help.
            </p>
          </>),
        },
      ]}
    />
  );
}
