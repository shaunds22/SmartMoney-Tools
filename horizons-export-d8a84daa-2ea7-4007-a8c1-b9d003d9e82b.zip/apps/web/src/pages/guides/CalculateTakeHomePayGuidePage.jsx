import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import ChooseGuide from '@/components/ChooseGuide.jsx';
import { Link } from 'react-router-dom';

export default function CalculateTakeHomePayGuidePage() {
  return (
    <GuideLayout
      title="How to Calculate Your UK Take-Home Pay"
      description="Understand gross-to-net conversion, tax codes and every payslip deduction, compare take-home across salaries, and see the decisions that move the number."
      url="/guides/calculate-take-home-pay"
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <ChooseGuide items={[
              { question: 'Put your own numbers in now?', path: '/uk-salary-calculator', text: 'UK salary calculator' },
              { question: 'How income tax bands and the £100,000 trap work?', path: '/guides/uk-income-tax', text: 'comprehensive UK income tax guide' },
            ]} />
            <p>
              This guide is for UK employees who want to understand their payslip — exactly why a £40,000 salary lands in their bank account as roughly £2,450 a month, how take-home compares across salary levels, and which decisions move the number. It explains the mechanics of the PAYE system deduction by deduction.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'What comes off your gross pay, in order',
          content: (<>
            <p>
              Your gross salary is the headline number in your contract. Between that and the cash that hits your account sit several deductions, and the order matters because some are calculated on different bases:
            </p>
            <ul>
              <li><strong>Pension contributions</strong> — under auto-enrolment these are usually worked out on <em>qualifying earnings</em> (the band between £6,240 and £50,270), not your whole salary, unless your scheme uses a different definition.</li>
              <li><strong>Income Tax</strong> — charged on salary above your Personal Allowance (£12,570 under the standard 1257L code), using progressive bands.</li>
              <li><strong>National Insurance (Class 1)</strong> — charged on earnings above the Primary Threshold (£12,570), calculated per pay period rather than cumulatively.</li>
              <li><strong>Student loan repayments</strong> — charged on earnings above your plan's threshold, behaving like a graduate tax.</li>
              <li><strong>Other deductions</strong> — salary sacrifice benefits (Cycle to Work, childcare), union dues, or attachment orders.</li>
            </ul>
          </>),
        },
        {
          type: 'content',
          title: 'The 2026/27 tax and NI bands (England, Wales, Northern Ireland)',
          content: (<>
            <div className="overflow-x-auto my-6">
              <table className="w-full text-sm border border-border">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left p-3 border-b border-border">Band</th>
                    <th className="text-left p-3 border-b border-border">Taxable income</th>
                    <th className="text-left p-3 border-b border-border">Rate</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="p-3 border-b border-border">Personal Allowance</td><td className="p-3 border-b border-border">Up to £12,570</td><td className="p-3 border-b border-border">0%</td></tr>
                  <tr><td className="p-3 border-b border-border">Basic rate</td><td className="p-3 border-b border-border">£12,571 – £50,270</td><td className="p-3 border-b border-border">20%</td></tr>
                  <tr><td className="p-3 border-b border-border">Higher rate</td><td className="p-3 border-b border-border">£50,271 – £125,140</td><td className="p-3 border-b border-border">40%</td></tr>
                  <tr><td className="p-3 border-b border-border">Additional rate</td><td className="p-3 border-b border-border">Above £125,140</td><td className="p-3 border-b border-border">45%</td></tr>
                </tbody>
              </table>
            </div>
            <p>
              Employee National Insurance is 8% on earnings between £12,570 and £50,270, then 2% above that. Scotland sets its own Income Tax bands (Starter, Basic, Intermediate, Higher, Advanced and Top), so Scottish residents will see different deductions — check <a href="https://www.gov.uk/scottish-income-tax" target="_blank" rel="noreferrer">GOV.UK: Scottish Income Tax</a>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Take-home pay at common UK salaries',
          content: (<>
            <p>
              Indicative annual net pay for an employee in England on a 1257L code, with 5% auto-enrolment pension and no student loan. Use the calculator for your exact situation.
            </p>
            <div className="overflow-x-auto my-6">
              <table className="w-full text-sm border border-border">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left p-3 border-b border-border">Gross salary</th>
                    <th className="text-left p-3 border-b border-border">Approx. annual net</th>
                    <th className="text-left p-3 border-b border-border">Band you sit in</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="p-3 border-b border-border">£20,000</td><td className="p-3 border-b border-border">≈ £17,300</td><td className="p-3 border-b border-border">Basic rate</td></tr>
                  <tr><td className="p-3 border-b border-border">£35,000</td><td className="p-3 border-b border-border">≈ £27,300</td><td className="p-3 border-b border-border">Basic rate</td></tr>
                  <tr><td className="p-3 border-b border-border">£50,000</td><td className="p-3 border-b border-border">≈ £37,300</td><td className="p-3 border-b border-border">Top of basic rate</td></tr>
                  <tr><td className="p-3 border-b border-border">£75,000</td><td className="p-3 border-b border-border">≈ £52,000</td><td className="p-3 border-b border-border">Higher rate</td></tr>
                </tbody>
              </table>
            </div>
            <p>
              Notice the jump between £50,000 and £75,000 is smaller than the gross gap suggests: the portion above £50,270 loses 40% to tax, though National Insurance drops to 2% on that same portion.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'A worked payslip: £40,000 in England',
          content: (<>
            <p>
              Assume a standard 1257L code, 5% auto-enrolment pension on qualifying earnings, and a Plan 2 student loan. Figures are rounded to the nearest pound per month.
            </p>
            <ul>
              <li><strong>Gross pay:</strong> £40,000 ÷ 12 = £3,333/month</li>
              <li><strong>Pension (5% of £33,760 qualifying earnings):</strong> £141/month</li>
              <li><strong>Income Tax (20% of £27,430 taxable income):</strong> £457/month</li>
              <li><strong>National Insurance (8% of £27,430):</strong> £183/month</li>
              <li><strong>Student loan (9% of £12,705 above the Plan 2 threshold):</strong> £95/month</li>
              <li><strong>Net take-home: ≈ £2,457/month</strong></li>
            </ul>
            <p>
              That is about 74% of gross. The key insight is the <em>marginal</em> rate: for every extra pound earned above £27,295, this person loses 20p tax + 8p NI + 9p student loan = 37p before any pension. Use the <Link to="/uk-salary-calculator" className="text-primary hover:underline font-medium">UK Salary Calculator</Link> to plug in your exact code, pension % and loan plan.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Reading your tax code',
          content: (<>
            <p>
              The code on your payslip tells your employer how much tax-free pay to give you. <strong>1257L</strong> means £12,570 of allowance. Codes like <strong>BR</strong> (basic rate on everything), <strong>0T</strong> (no allowance), or anything ending <strong>W1/M1</strong> (emergency, non-cumulative) usually mean HMRC does not yet have your correct details — you may be overpaying. Check your code in the HMRC app or at <a href="https://www.gov.uk/check-income-tax-current-year" target="_blank" rel="noreferrer">GOV.UK: Check your Income Tax</a>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Decisions that move the needle',
          content: (<>
            <ul>
              <li><strong>Increasing pension contributions</strong> lowers taxable income — see <Link to="/guides/pension-contributions" className="text-primary hover:underline font-medium">how pension contributions affect tax and take-home pay</Link>.</li>
              <li><strong>Salary sacrifice</strong> saves NI as well as tax — compare it with normal contributions in the <Link to="/guides/salary-sacrifice-vs-normal-pension" className="text-primary hover:underline font-medium">salary sacrifice guide</Link>.</li>
              <li><strong>Marriage Allowance</strong> is worth £252/year if one spouse earns below the Personal Allowance and the other is a basic-rate payer.</li>
            </ul>
          </>),
        },
        {
          type: 'content',
          title: 'Common mistakes',
          content: (<>
            <ul>
              <li><strong>Treating the pension deduction as pure loss.</strong> Because contributions are taken before tax (or get relief at source), opting out of a £100 contribution typically raises take-home by only around £80 for a basic-rate payer — you give up £100 of pension to gain £80 of cash.</li>
              <li><strong>Forgetting NI drops at £50,270.</strong> Crossing into higher-rate tax feels like a 20% jump, but NI simultaneously falls from 8% to 2%, so the real marginal increase is 14 percentage points, not 20.</li>
              <li><strong>Ignoring a second job.</strong> Your allowance usually sits on your main job; a second job on a BR code is taxed at 20% from the first pound, which can cause over- or under-payment that HMRC reconciles later.</li>
            </ul>
          </>),
        },
        {
          type: 'when-useful',
          title: 'When to check with HMRC or payroll',
          content: (<>
            <p>
              Check promptly if you start a new job, get a bonus that lands you near a band boundary, change pension contributions, or see an unexpected code. Persistent, unexplained shortfalls are usually a code problem rather than a calculation error — your employer's payroll can only follow the code HMRC issues.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Assumptions and limitations',
          content: (<>
            <p>
              Figures use 2026/27 rates for England/Wales/NI and assume a standard tax code, no Scottish bands, no Marriage Allowance or blind person's allowance, and pension calculated on qualifying earnings. Your exact net pay depends on your code, your scheme's pensionable-earnings definition, and whether your employer uses salary sacrifice. For complex affairs (multiple incomes, benefits in kind, Scottish residency) speak to HMRC or an FCA-regulated adviser. Rates sourced from <a href="https://www.gov.uk/income-tax-rates" target="_blank" rel="noreferrer">GOV.UK: Income Tax rates</a> and <a href="https://www.gov.uk/national-insurance" target="_blank" rel="noreferrer">GOV.UK: National Insurance</a>. This is educational estimation, not financial advice.
            </p>
          </>),
        },
      ]}
    />
  );
}
