import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import ChooseGuide from '@/components/ChooseGuide.jsx';
import { Link } from 'react-router-dom';
import { PENSION_SERIES } from '@/data/guideSeries.js';

export default function PensionPlanningComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="Pension Planning & Retirement Target Guide"
      description="Calculate your retirement income needs and plan your drawdown strategy."
      url="/guides/pension-planning"
      series={PENSION_SERIES}
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <ChooseGuide items={[
              { question: 'How much to pay in and the allowances?', path: '/guides/pension-contributions', text: 'optimising pension contributions' },
              { question: 'Retiring before State Pension age?', path: '/guides/early-retirement', text: 'early retirement planning guide' },
              { question: 'Project your pot with your numbers?', path: '/pensions-calculator', text: 'pensions calculator' },
            ]} />
            <p>
              For people in mid-career — roughly 40 to 55 — checking whether they are on track for the retirement they actually want. The question it answers is: <em>how big does my pot need to be, and am I getting there?</em> It is the planning counterpart to the <Link to="/guides/pension-contributions" className="text-primary hover:underline font-medium">contributions guide</Link> (how much to pay in) and the <Link to="/guides/early-retirement" className="text-primary hover:underline font-medium">early retirement guide</Link> (bridging the gap before State Pension age).
            </p>
          </>),
        },
        {
          type: 'step-by-step',
          title: 'Start from spending, not from a pot size',
          content: (<>
            <p>
              A common mistake is to pick a round-number pot target (£500k, £1m) and work backwards. The right direction is the opposite: estimate what you will actually spend in retirement, subtract guaranteed income, and size the pot to cover the gap.
            </p>
            <ol>
              <li><strong>Estimate retirement spending.</strong> No mortgage or commute, but more leisure, travel and, later, healthcare. Many people spend roughly 50–70% of their working-life outgoings.</li>
              <li><strong>Subtract guaranteed income.</strong> The State Pension (the full new State Pension is £12,547.60 a year in 2026/27, rising with the triple lock) plus any Defined Benefit / final-salary pension.</li>
              <li><strong>Size the pot.</strong> A common rule of thumb is to multiply the remaining annual shortfall by roughly 25 — the inverse of a 4% sustainable withdrawal rate.</li>
            </ol>
            <p>
              Check your State Pension forecast at <a href="https://www.gov.uk/check-state-pension" target="_blank" rel="noreferrer">GOV.UK: Check your State Pension</a>.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked example: a £500,000 pot at 66',
          content: (<>
            <ul>
              <li>Take 25% tax-free lump sum: £125,000 (kept as a cash buffer or for one-off costs).</li>
              <li>Remaining pot invested in drawdown: £375,000.</li>
              <li>4% withdrawal: £15,000/year.</li>
              <li>State Pension: ≈ £12,000/year.</li>
              <li><strong>Gross retirement income: ≈ £27,000/year</strong>, subject to Income Tax above the Personal Allowance.</li>
            </ul>
            <p>
              Whether that is enough depends entirely on the spending figure from step 1 — for one person in a paid-off home it may be comfortable; for a couple wanting regular travel it likely is not.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Drawdown vs annuity — the core choice',
          content: (<>
            <div className="overflow-x-auto my-6">
              <table className="w-full text-sm border border-border">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left p-3 border-b border-border">Feature</th>
                    <th className="text-left p-3 border-b border-border">Drawdown</th>
                    <th className="text-left p-3 border-b border-border">Annuity</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="p-3 border-b border-border">Income</td><td className="p-3 border-b border-border">Flexible, you decide each year</td><td className="p-3 border-b border-border">Fixed, guaranteed for life</td></tr>
                  <tr><td className="p-3 border-b border-border">Investment risk</td><td className="p-3 border-b border-border">You bear it — pot can fall</td><td className="p-3 border-b border-border">Insurer bears it</td></tr>
                  <tr><td className="p-3 border-b border-border">Inheritance</td><td className="p-3 border-b border-border">Remaining pot can pass on</td><td className="p-3 border-b border-border">Usually nothing on death</td></tr>
                  <tr><td className="p-3 border-b border-border">Best for</td><td className="p-3 border-b border-border">Those comfortable managing risk</td><td className="p-3 border-b border-border">Those wanting certainty</td></tr>
                </tbody>
              </table>
            </div>
            <p>
              Many people blend the two: annuitise enough to cover essential spending, and keep the rest in drawdown for flexibility. Since April 2015 there is no obligation to buy an annuity. The FCA's <a href="https://www.fca.org.uk/consumers/pensions-retirement" target="_blank" rel="noreferrer">retirement guidance</a> and the free Pension Wise service are worth using before deciding.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'Sequence-of-returns risk',
          content: (<>
            <p>
              The 4% rule assumes steady long-term returns, but the order matters. If markets crash in the first few years of drawdown while you are still withdrawing, the pot can be drained far faster than the same crash later in retirement. Holding 2–3 years of cash expenses so you do not have to sell investments after a fall is a common mitigation.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations and when to get advice',
          content: (<>
            <p>
              The 4% rule is a heuristic from historical US data, not a guarantee; high inflation or poor early returns can deplete a pot faster. Drawdown decisions are hard to reverse and have tax consequences. For pots above £30,000 you are entitled to free Pension Wise guidance, and for a tailored plan an FCA-regulated adviser is worthwhile. Project your trajectory with the <Link to="/pensions-calculator" className="text-primary hover:underline font-medium">Pensions Calculator</Link>.
            </p>
          </>),
        },
      ]}
    />
  );
}
