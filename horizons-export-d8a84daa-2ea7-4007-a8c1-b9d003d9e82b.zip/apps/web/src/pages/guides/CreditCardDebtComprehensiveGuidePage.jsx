import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';

export default function CreditCardDebtComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="Escaping Credit Card Debt"
      description="Understand interest mechanics, balance transfers, and how to break the debt spiral."
      url="/guides/credit-card-debt"
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              For people carrying a balance on a credit card who want to stop paying interest long enough to actually clear it. Credit cards are useful when paid in full each month and corrosive when not — typical APRs above 20% mean a sizeable chunk of each payment disappears as interest before the balance moves. This guide focuses on the two tools that break that cycle: understanding how the interest accrues, and using a 0% balance transfer. For choosing between payoff methods, see the <Link to="/guides/debt-repayment" className="text-primary hover:underline font-medium">debt repayment guide</Link>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'How credit card interest actually accrues',
          content: (<>
            <p>
              Credit card interest is calculated daily on the outstanding balance. That has a practical consequence: paying earlier in the billing cycle saves money, and the minimum payment is set deliberately low (often 1–2% of the balance) so that interest consumes most of it and the balance lingers for years.
            </p>
            <ul>
              <li><strong>£3,000 at 18% APR:</strong> roughly £45 of interest a month before any principal is touched.</li>
              <li><strong>£10,000 at 22% APR:</strong> roughly £180 of interest a month — meaning a £200 payment barely moves the balance.</li>
            </ul>
          </>),
        },
        {
          type: 'content',
          title: 'The 0% balance transfer',
          content: (<>
            <p>
              If your credit file is reasonable, you can move the balance to a card charging 0% for an introductory period (often 12–24 months). You pay a transfer fee of around 2–3%, but interest freezes for the whole period — so every pound you pay reduces the principal. The discipline is essential: divide the new balance by the number of 0% months and pay exactly that each month, so the debt is gone before the promotional rate ends.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked example: £5,000 at 20% moved to a 20-month 0% card',
          content: (<>
            <ul>
              <li>Transfer fee at 3%: £150 → new balance £5,150.</li>
              <li>Monthly payment to clear in 20 months: £257/month, all reducing principal.</li>
              <li>Interest if left at 20% and paying £250/month: roughly £800 over the same period.</li>
              <li><strong>Result:</strong> a £150 fee saves around £650 in interest and clears the debt faster.</li>
            </ul>
          </>),
        },
        {
          type: 'content',
          title: 'The trap that undoes the transfer',
          content: (<>
            <p>
              The single biggest failure mode is behavioural: you transfer the balance, then start spending on the now-empty old card. Within months you have the new loan <em>and</em> a fresh balance. The moment you transfer, close or freeze the old card. A balance transfer is a tool for clearing debt, not a licence to borrow more.
            </p>
          </>),
        },
        {
          type: 'when-useful',
          title: 'When a transfer is not available',
          content: (<>
            <p>
              If your credit score is too low to be accepted for a 0% card, a transfer is not an option. In that case, focus on the Avalanche approach — pay minimums on everything and throw all spare cash at the highest-APR card — and consider whether a <Link to="/guides/debt-consolidation" className="text-primary hover:underline font-medium">consolidation loan</Link> at a lower rate is possible. Some providers will agree a temporary hardship plan or reduced rate if you call them; there is no harm in asking.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              Balance transfer cards require a sufficient credit score and the promotional lengths and fees vary by provider and change over time. Missing a payment on a 0% card can end the promotional rate immediately. This is educational, not advice; for persistent debt you cannot service, contact <a href="https://www.stepchange.org" target="_blank" rel="noreferrer">StepChange</a>. Target your cards with the <Link to="/debt-snowball-calculator" className="text-primary hover:underline font-medium">Debt Snowball Calculator</Link>. Card guidance at <a href="https://www.moneyhelper.org.uk/en/everyday-money/credit-and-purchases/credit-cards" target="_blank" rel="noreferrer">MoneyHelper: Credit cards</a>.
            </p>
          </>),
        },
      ]}
    />
  );
}
