import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import { Link } from 'react-router-dom';

export default function UKIncomeTaxComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="Comprehensive UK Income Tax Guide"
      description="Master tax bands, personal allowances, and relief strategies to optimize your net income."
      url="/guides/uk-income-tax"
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <p>
              For UK employees who want to understand how Income Tax is actually applied to their pay — not just the headline rates, but how the Personal Allowance, progressive bands and the £100,000 trap interact. It complements the <Link to="/guides/calculate-take-home-pay" className="text-primary hover:underline font-medium">take-home pay guide</Link> (which covers the full payslip including NI and pensions) by focusing on Income Tax mechanics and the decisions that shift which band you sit in.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'How progressive bands actually work',
          content: (<>
            <p>
              A common misconception is that crossing a threshold taxes your <em>whole</em> salary at the higher rate. It does not. Only the portion of income above each threshold is taxed at that rate. On a £45,000 salary in England:
            </p>
            <ul>
              <li>First £12,570: tax-free (Personal Allowance)</li>
              <li>£12,571 – £45,000 at 20%: £6,486</li>
              <li><strong>Total Income Tax: £6,486</strong> — not 20% of £45,000.</li>
            </ul>
          </>),
        },
        {
          type: 'content',
          title: 'The 2026/27 bands at a glance',
          content: (<>
            <div className="overflow-x-auto my-6">
              <table className="w-full text-sm border border-border">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left p-3 border-b border-border">Band</th>
                    <th className="text-left p-3 border-b border-border">Taxable income</th>
                    <th className="text-left p-3 border-b border-border">Rate</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="p-3 border-b border-border">Personal Allowance</td><td className="p-3 border-b border-border">Up to £12,570</td><td className="p-3 border-b border-border">0%</td></tr>
                  <tr><td className="p-3 border-b border-border">Basic rate</td><td className="p-3 border-b border-border">£12,571 – £50,270</td><td className="p-3 border-b border-border">20%</td></tr>
                  <tr><td className="p-3 border-b border-border">Higher rate</td><td className="p-3 border-b border-border">£50,271 – £125,140</td><td className="p-3 border-b border-border">40%</td></tr>
                  <tr><td className="p-3 border-b border-border">Additional rate</td><td className="p-3 border-b border-border">Above £125,140</td><td className="p-3 border-b border-border">45%</td></tr>
                </tbody>
              </table>
            </div>
            <p>
              Scotland uses different bands and rates — see <a href="https://www.gov.uk/scottish-income-tax" target="_blank" rel="noreferrer">GOV.UK: Scottish Income Tax</a>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The £100,000 Personal Allowance trap',
          content: (<>
            <p>
              For every £2 of adjusted net income above £100,000, you lose £1 of Personal Allowance. By £125,140 the allowance is gone entirely. In that band, each extra £2 is taxed at 40% <em>and</em> exposes another £1 (previously tax-free) to 40% — an effective marginal rate of 60%. This is the steepest spike in the UK tax system, and it is the main reason higher earners channel income above £100,000 into pensions.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked example: the 60% band',
          content: (<>
            <p>
              Someone earning £110,000 has £10,000 above the £100,000 threshold.
            </p>
            <ul>
              <li>That £10,000 is taxed at 40% = £4,000.</li>
              <li>It also strips out £5,000 of Personal Allowance, which becomes taxable at 40% = another £2,000.</li>
              <li><strong>Effective tax on that £10,000: £6,000 — a 60% marginal rate.</strong></li>
              <li>Putting £10,000 into a pension instead brings adjusted net income back to £100,000, restoring the full allowance and avoiding the trap.</li>
            </ul>
          </>),
        },
        {
          type: 'content',
          title: 'Relief that genuinely reduces taxable income',
          content: (<>
            <ul>
              <li><strong>Pension contributions</strong> — extend your basic-rate band or reduce adjusted net income; the most powerful lever for higher earners.</li>
              <li><strong>Gift Aid donations</strong> — extend your basic-rate band, and higher-rate payers claim the extra relief via Self Assessment.</li>
              <li><strong>Marriage Allowance</strong> — worth £252/year where one spouse does not use their full allowance and the other is a basic-rate payer.</li>
              <li><strong>Specific employment expenses</strong> — limited, but includes professional subscriptions and some working-from-home costs under the rules at <a href="https://www.gov.uk/tax-relief-for-employees" target="_blank" rel="noreferrer">GOV.UK: Tax relief for employees</a>.</li>
            </ul>
          </>),
        },
        {
          type: 'when-useful',
          title: 'When you need a Self Assessment',
          content: (<>
            <p>
              Not just for the self-employed. You generally need to file if you earn over £100,000, have income from property or investments above the relevant limits, are a company director, or have foreign income. Check at <a href="https://www.gov.uk/check-if-you-need-tax-return" target="_blank" rel="noreferrer">GOV.UK: Check if you need a tax return</a>.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              Bands and the Personal Allowance taper are 2026/27 figures for England, Wales and Northern Ireland and change each Budget. Scottish bands differ. This is educational, not advice; for complex planning — especially around the £100,000 trap, tapered pension allowances, or cross-border income — an FCA-regulated adviser is worthwhile. Model your own bands with the <Link to="/uk-salary-calculator" className="text-primary hover:underline font-medium">UK Salary Calculator</Link>.
            </p>
          </>),
        },
      ]}
    />
  );
}
