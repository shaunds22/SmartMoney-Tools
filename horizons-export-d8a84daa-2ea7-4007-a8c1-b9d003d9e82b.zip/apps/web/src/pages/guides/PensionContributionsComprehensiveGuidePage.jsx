import React from 'react';
import GuideLayout from '@/components/GuideLayout.jsx';
import ChooseGuide from '@/components/ChooseGuide.jsx';
import { Link } from 'react-router-dom';
import { PENSION_SERIES } from '@/data/guideSeries.js';

export default function PensionContributionsComprehensiveGuidePage() {
  return (
    <GuideLayout
      title="Optimising Pension Contributions and Tax Relief"
      description="Decide how much to pay into your pension, see exactly how tax relief and NI change your take-home pay, and navigate the Annual Allowance and the £100,000 trap."
      url="/guides/pension-contributions"
      series={PENSION_SERIES}
      lastUpdated="2026-11-02"
      sections={[
        {
          type: 'introduction',
          content: (<>
            <ChooseGuide items={[
              { question: 'How big does my pot need to be?', path: '/guides/pension-planning', text: 'pension planning & retirement target' },
              { question: 'The scheme and auto-enrolment?', path: '/guides/workplace-pensions', text: 'workplace pensions & auto-enrolment' },
              { question: 'Salary sacrifice vs normal contributions?', path: '/guides/salary-sacrifice-vs-normal-pension', text: 'salary sacrifice vs normal pension' },
            ]} />
            <p>
              For UK savers asking "how much should I be paying into my pension, and what does it actually cost me?" The common assumption — "I can't afford to increase my pension" — usually rests on a misunderstanding: people see a £200 deduction and assume opting out would return £200 to their bank account. It would not. Because pension contributions bypass Income Tax (and sometimes National Insurance), the real cost to your take-home is much smaller than the amount that lands in your pension. This guide covers the relief maths, the contribution methods, the allowances and the decisions that follow.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'A starting rule of thumb, then reality',
          content: (<>
            <p>
              A common heuristic: take the age you start saving, halve it, and contribute that percentage of your salary for life. Start at 30 → 15%; start at 40 → 20%. It is a rough prompt to start early, not a guarantee. The real test is whether your projected pot, plus the State Pension, covers the retirement income you want — which the <Link to="/pensions-calculator" className="text-primary hover:underline font-medium">Pensions Calculator</Link> can model.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The real cost is less than the headline',
          content: (<>
            <p>
              Because of tax relief, the amount leaving your take-home is always smaller than the amount entering your pension. If you are a basic-rate (20%) taxpayer, earning £100 normally leaves you £80 after tax; put that £100 into a pension and the full £100 lands in your pension, but your take-home only fell by £80. For a higher-rate (40%) taxpayer, £100 in the pension costs £60 of take-home. The government is, in effect, matching part of your contribution.
            </p>
            <ul>
              <li><strong>Basic-rate payer:</strong> £100 into the pension costs £80 of take-home.</li>
              <li><strong>Higher-rate payer:</strong> £100 into the pension costs £60 of take-home.</li>
              <li><strong>With salary sacrifice:</strong> add NI savings, so a basic-rate payer's £100 costs around £72 of take-home.</li>
            </ul>
          </>),
        },
        {
          type: 'content',
          title: 'Three ways contributions are collected — and why it matters',
          content: (<>
            <div className="overflow-x-auto my-6">
              <table className="w-full text-sm border border-border">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left p-3 border-b border-border">Method</th>
                    <th className="text-left p-3 border-b border-border">Income Tax saved?</th>
                    <th className="text-left p-3 border-b border-border">Employee NI saved?</th>
                    <th className="text-left p-3 border-b border-border">Higher-rate relief automatic?</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="p-3 border-b border-border">Net Pay Arrangement</td><td className="p-3 border-b border-border">Yes, before tax</td><td className="p-3 border-b border-border">No</td><td className="p-3 border-b border-border">Yes</td></tr>
                  <tr><td className="p-3 border-b border-border">Relief at Source</td><td className="p-3 border-b border-border">20% added by provider; rest claimed manually</td><td className="p-3 border-b border-border">No</td><td className="p-3 border-b border-border">No — must claim via Self Assessment</td></tr>
                  <tr><td className="p-3 border-b border-border">Salary Sacrifice</td><td className="p-3 border-b border-border">Yes</td><td className="p-3 border-b border-border">Yes (8% or 2%)</td><td className="p-3 border-b border-border">Yes</td></tr>
                </tbody>
              </table>
            </div>
            <p>
              Salary sacrifice is the most efficient because it lowers your gross salary, so you avoid NI as well as tax — and your employer avoids their 15% NI, which many pass back into your pot. But it is a contractual change to your salary, with the caveats covered in the <Link to="/guides/salary-sacrifice-vs-normal-pension" className="text-primary hover:underline font-medium">salary sacrifice guide</Link>.
            </p>
          </>),
        },
        {
          type: 'worked-example',
          title: 'Worked example: raising 5% to 10%',
          content: (<>
            <p>
              An employee earns £50,000 and uses salary sacrifice. They raise their pension contribution from 5% to 10%.
            </p>
            <ul>
              <li><strong>At 5%:</strong> £2,500/year into the pension; take-home ≈ £37,700.</li>
              <li><strong>At 10%:</strong> £5,000/year into the pension; take-home ≈ £35,900.</li>
              <li><strong>The result:</strong> the pension pot doubles (+£2,500), but take-home falls by only about £1,800. Tax and NI relief absorb the other £700.</li>
            </ul>
            <p>
              This is why "pay rises into the pension" works well: if you get a 5% raise, directing 3% into the pension and keeping 2% still leaves you better off month-to-month while materially improving your pot.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The £100,000 trap — where relief is worth 60%',
          content: (<>
            <p>
              For every £2 of income above £100,000 you lose £1 of Personal Allowance, creating a 60% effective marginal rate. Channelling earnings above £100,000 straight into a pension restores the allowance, so each £100 contributed effectively costs just £40 of take-home. For earners in this band, pension contributions are unusually hard to beat. See the <Link to="/guides/tax-planning" className="text-primary hover:underline font-medium">tax planning guide</Link> for the full mechanics.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The allowances to know',
          content: (<>
            <ul>
              <li><strong>Annual Allowance:</strong> £60,000 of tax-relieved contributions per year, or 100% of earnings, whichever is lower. Some very high earners face a tapered allowance below this.</li>
              <li><strong>Carry forward:</strong> unused allowance from the previous three tax years can be added to this year's, useful for bonuses or windfalls.</li>
              <li><strong>Non-earners:</strong> you can still pay in up to £3,600 a year and get basic-rate relief (so £2,880 of your money becomes £3,600 in the pot).</li>
            </ul>
            <p>
              Exceeding the Annual Allowance triggers a charge that claws back the relief. See <a href="https://www.gov.uk/tax-on-your-private-pension/annual-allowance" target="_blank" rel="noreferrer">GOV.UK: Annual Allowance</a>.
            </p>
          </>),
        },
        {
          type: 'content',
          title: 'The lock-up and the relief you must claim',
          content: (<>
            <p>
              Money in a pension cannot normally be accessed until Normal Minimum Pension Age — 55 now, rising to 57 in 2028. The generous tax relief is the trade for that lock-up, so before increasing contributions aggressively, make sure you have a liquid emergency fund and no high-interest consumer debt; paying 20% on a credit card to get 20% pension relief is a wash at best. And if your scheme uses Relief at Source, the provider claims only the basic 20% automatically — as a higher-rate payer you must claim the remaining 20% via Self Assessment or by contacting HMRC, otherwise it stays unclaimed.
            </p>
          </>),
        },
        {
          type: 'limitations',
          title: 'Limitations',
          content: (<>
            <p>
              Figures use 2026/27 bands and assume salary sacrifice on qualifying earnings. Your exact outcome depends on your tax code, Scottish residency, and your employer's collection method. Pension rules change with legislation; the £60,000 allowance and the £100,000 taper are not fixed forever. For tapered allowances, large one-off contributions, or planning around the £100,000 trap, an FCA-regulated adviser is worthwhile. Dial your own percentage up and down in the <Link to="/uk-salary-calculator" className="text-primary hover:underline font-medium">UK Salary Calculator</Link>, and project the long-term result in the <Link to="/pensions-calculator" className="text-primary hover:underline font-medium">Pensions Calculator</Link>.
            </p>
          </>),
        },
      ]}
    />
  );
}
