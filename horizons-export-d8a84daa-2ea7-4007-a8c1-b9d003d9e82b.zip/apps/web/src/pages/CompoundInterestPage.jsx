import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import CalculatorCard from '@/components/CalculatorCard.jsx';
import ResultsCard from '@/components/ResultsCard.jsx';
import CompoundInterestCalculator from '@/components/CompoundInterestCalculator.jsx';
import GrowthChart from '@/components/GrowthChart.jsx';
import YearByYearTable from '@/components/YearByYearTable.jsx';
import DisclaimerBanner from '@/components/DisclaimerBanner.jsx';
import HowWeCalculateThis from '@/components/HowWeCalculateThis.jsx';
import CalculatorContentSection from '@/components/CalculatorContentSection.jsx';
import useCurrency from '@/hooks/useCurrency.js';
import formatCurrency from '@/utils/formatCurrency.js';
import Breadcrumb from '@/components/Breadcrumb.jsx';
import AuthorAttribution from '@/components/AuthorAttribution.jsx';
import AuthorBylineBar from '@/components/AuthorBylineBar.jsx';
import { setPageMeta } from '@/utils/seo.js';
import { addWebApplicationSchema } from '@/utils/structuredData.js';

function CompoundInterestPage() {
  const [results, setResults] = useState(null);
  const { currencyCode } = useCurrency();

  useEffect(() => {
    // Reset state on mount
    setResults(null);
    
    setPageMeta(
      'Compound Interest Calculator | SmartMoneyTools',
      'Calculate compound interest accurately. See how your investments grow over time with detailed charts and year-by-year tables.',
      'https://smartmoney-tools.com/compound-interest'
    );
    addWebApplicationSchema(
      'Compound Interest Calculator',
      'https://smartmoney-tools.com/compound-interest',
      'Free compound interest calculator to see how your money grows over time with detailed amortization charts.'
    );
  }, []);

  const handleResultsChange = (newResults) => {
    setResults(newResults);
  };

  return (
    <div className="flex flex-col w-full">
      <section className="bg-primary text-primary-foreground py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-4xl mx-auto text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight text-balance" style={{ letterSpacing: '-0.02em' }}>
              Compound Interest Calculator
            </h1>
            <p className="text-xl text-primary-foreground/90 leading-relaxed max-w-3xl mx-auto">
              Model your long-term wealth accumulation and see how time accelerates your investment returns.
            </p>
            <AuthorBylineBar variant="hero" />
          </motion.div>
        </div>
      </section>

      <div className="bg-background border-b border-border/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <Breadcrumb items={[{ label: 'Compound Interest Calculator' }]} />
        </div>
      </div>

      <div className="bg-background border-b border-border/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-3 max-w-7xl">
          <AuthorAttribution lastReviewedDate="2026-09-11" showByline={false} />
        </div>
      </div>

      <section className="py-8 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            <div className="lg:col-span-2 space-y-8">
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                <CalculatorCard
                  title="Configure Your Parameters"
                  description="Input your starting balance, contribution plan, and expected return rate."
                >
                  <CompoundInterestCalculator onResultsChange={handleResultsChange} />
                </CalculatorCard>
              </motion.div>

              {results && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="space-y-8"
                >
                  <DisclaimerBanner />

                  <ResultsCard
                    results={[
                      {
                        label: 'Final Balance',
                        value: formatCurrency(results.finalBalance, currencyCode),
                        subtitle: 'Total portfolio value at term completion'
                      },
                      {
                        label: 'Total Principal',
                        value: formatCurrency(results.totalContributions, currencyCode),
                        subtitle: 'Your out-of-pocket contributions'
                      },
                      {
                        label: 'Interest Earned',
                        value: formatCurrency(results.totalInterest, currencyCode),
                        subtitle: 'Profits generated from compounding'
                      }
                    ]}
                  />

                  <CalculatorCard title="Portfolio Growth Trajectory">
                    <GrowthChart data={results.yearlyData} currencyCode={currencyCode} />
                  </CalculatorCard>

                  <CalculatorCard title="Annual Breakdown Table">
                    <YearByYearTable data={results.yearlyData} currencyCode={currencyCode} />
                  </CalculatorCard>
                </motion.div>
              )}

            </div>

          </div>
          <HowWeCalculateThis region="UK" />
        </div>
      </section>

      <section className="py-16 bg-muted/30 border-t border-border">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          
          <CalculatorContentSection title="What this calculator shows">
            <p>Compound interest is the mechanism by which you earn returns not only on your original investment but also on the returns it has already generated — growth on top of growth. This tool projects that exponential curve so you can see, in pounds and on a chart, how a starting balance and regular contributions turn into a much larger sum over time.</p>
            <p>It separates your <strong>total principal</strong> (the money you actually paid in) from the <strong>interest earned</strong> (what the markets or your savings account generated), making the time value of money visible rather than abstract.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Who it's for">
            <ul>
              <li><strong>Long-term investors</strong> projecting the future value of a Stocks & Shares ISA or brokerage account over decades.</li>
              <li><strong>Savers</strong> comparing how different interest rates on Cash ISAs or regular savers affect the final balance.</li>
              <li><strong>Students and educators</strong> visualising the fundamental concept of exponential growth.</li>
              <li><strong>Anyone weighing "start now vs start later"</strong> — the calculator makes the cost of delay obvious.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="What you need before you start">
            <ul>
              <li>Your <strong>starting balance</strong> — what's already invested or saved today.</li>
              <li>The <strong>regular contribution</strong> you can commit to and how often you'll make it (monthly is most common).</li>
              <li>A realistic <strong>expected annual return</strong> matched to the asset: 3–5% for cash savings, 6–8% for a diversified global equity fund over long periods. Future returns are not guaranteed.</li>
              <li>Your <strong>time horizon</strong> in years — the single biggest driver of the result.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="What each input means">
            <ul>
              <li><strong>Starting balance</strong> — the lump sum already in the account on day one.</li>
              <li><strong>Regular contribution</strong> — the fixed amount added each period. Consistency is what powers the snowball.</li>
              <li><strong>Contribution frequency</strong> — how often you add money (monthly, quarterly, annually). More frequent contributions compound slightly faster.</li>
              <li><strong>Annual return (%)</strong> — the yearly growth rate assumed for the whole term. Enter a net figure after fund charges for a realistic projection.</li>
              <li><strong>Compounding frequency</strong> — how often interest is added back to the principal. Daily compounding yields slightly more than monthly, which yields more than annual, over long horizons.</li>
              <li><strong>Time horizon (years)</strong> — how long the money stays invested. Because growth is exponential, the final years contribute the largest gains.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="How to read your results">
            <p>The three headline figures tell the story: <strong>Final Balance</strong> is the projected pot at the end; <strong>Total Principal</strong> is what you paid in; <strong>Interest Earned</strong> is the difference — the market's contribution. Over long horizons, interest usually exceeds principal, which is the whole point of compounding.</p>
            <p>The growth chart curves upward, and the steepness in the later years is the compounding effect accelerating. The year-by-year table lets you check any point in the journey — useful for matching a projection to a specific life event, like the year a child starts university. Remember the figure is nominal; for purchasing power, subtract inflation from your return rate and re-run.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="The maths behind it">
            <p>Compound interest uses the formula <code>A = P(1 + r/n)^(nt)</code>, where A is the final amount, P the principal, r the annual rate, n the compounding periods per year, and t the years. Regular contributions add a future-value-of-a-series calculation on top. The frequency of compounding matters because interest added to the principal sooner starts earning its own interest sooner.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Worked example">
            <p>An investor using their annual ISA allowance:</p>
            <ul>
              <li><strong>Initial Investment:</strong> £10,000</li>
              <li><strong>Monthly Contribution:</strong> £500</li>
              <li><strong>Annual Return:</strong> 6% (a conservative estimate for a diversified global index fund)</li>
              <li><strong>Time Horizon:</strong> 20 years</li>
            </ul>
            <p>After 20 years, total out-of-pocket contributions are £130,000, but the projected final balance is over <strong>£264,000</strong>. Compound interest alone generated more than £134,000 — slightly more than the investor actually put in. Delaying the start by five years would cut roughly a third off that final figure.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Assumptions and exclusions">
            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">Assumptions</h3>
            <ul>
              <li>A fixed annual interest rate throughout — real markets are volatile, with up and down years.</li>
              <li>Contributions made at the end of each compounding period, consistently and without withdrawal.</li>
              <li>Interest compounded at the selected frequency (daily / monthly / annually).</li>
              <li>Gross returns shown before tax and fees; an ISA or SIPP wrapper can eliminate tax on gains.</li>
            </ul>
            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">What is not included</h3>
            <ul>
              <li>Investment fees or platform charges (typically 0.15%–0.75% annual fund expense ratios) — enter a net return to account for these.</li>
              <li>Inflation adjustment — for real purchasing power, use the real return (nominal rate minus inflation).</li>
              <li>Tax on interest or gains outside an ISA or SIPP.</li>
              <li>Sequence-of-returns risk for market-based investments — a bad early decade is far more damaging than the smooth average suggests.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Common mistakes to avoid">
            <ul>
              <li><strong>Underestimating the time horizon.</strong> The most explosive growth happens in the later years. Delaying investing by five years can cut your final portfolio value dramatically.</li>
              <li><strong>Ignoring inflation.</strong> A 6% return with 3% inflation is only a 3% real return in purchasing power.</li>
              <li><strong>Not accounting for fees.</strong> A 1.5% annual fee turns a 6% return into 4.5%, which over decades drastically reduces the compounding effect.</li>
              <li><strong>Assuming smooth returns.</strong> The calculator shows a tidy curve; real markets lurch. Stay invested through the dips to capture the average.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Sensible next steps">
            <ul>
              <li>Run the same numbers twice — once with your realistic return, once with a pessimistic one — to see the range of outcomes.</li>
              <li>If you're investing, use a tax-advantaged wrapper (ISA, SIPP) so gains aren't eroded by tax. See our <Link to="/guides/tax-free-savings" className="text-primary hover:underline">Tax-Free Savings guide</Link>.</li>
              <li>Automate your monthly contribution via standing order so compounding continues without you having to remember.</li>
              <li>Pair this with the <Link to="/savings-goal-calculator" className="text-primary hover:underline">Savings Goal Calculator</Link> to work backwards from a target amount.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Frequently Asked Questions">
            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">Does compounding frequency really matter?</h3>
            <p className="mb-4">Yes, though the impact depends on the timeline and balance. Daily compounding generates slightly higher returns than monthly, which generates more than annual. Over decades, frequent compounding adds a noticeable boost.</p>
            
            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">What is a realistic interest rate to use?</h3>
            <p className="mb-4">Historically, the global stock market has returned about 7–9% annually on average over long periods, before inflation. High-yield cash savings accounts typically offer 3–5% during high-rate environments. Choose a rate that aligns with the specific asset class you are investing in.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Related calculators and guides">
            <ul>
              <li><Link to="/savings-goal-calculator" className="text-primary hover:underline">Savings Goal Calculator</Link>: Work backward to find the monthly deposit needed to hit a target.</li>
              <li><Link to="/pensions-calculator" className="text-primary hover:underline">Pensions Calculator</Link>: Apply compounding specifically to your retirement planning.</li>
              <li><Link to="/guides/compound-interest-monthly-deposits" className="text-primary hover:underline">Compound Interest Monthly Deposits Guide</Link>: How regular deposits create exponential wealth.</li>
              <li><Link to="/guides/tax-free-savings" className="text-primary hover:underline">Tax-Free Savings (ISAs) Guide</Link>: Shielding your compounded gains from tax.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Sources and references">
            <p className="text-sm bg-primary/5 p-3 rounded-lg border border-primary/20 mb-4">SmartMoneyTools checks statutory rates and thresholds against official government publications. Results are estimates for educational purposes and may not reflect every individual circumstance. <strong>Last reviewed: 11 September 2026.</strong></p>
            <p>The compounding formulas used are standard financial mathematics. Context and figures informed by:</p>
            <ul>
              <li><a href="https://www.moneyhelper.org.uk/en/savings/types-of-savings/savings-and-isa-accounts" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">MoneyHelper – Savings and ISA accounts</a></li>
              <li><a href="https://www.fca.org.uk/consumers/investments" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Financial Conduct Authority (FCA) – Investments</a></li>
              <li><a href="https://www.bankofengland.co.uk/monetary-policy/inflation" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Bank of England – Inflation data</a></li>
            </ul>
          </CalculatorContentSection>
          
          <div className="mt-12 pt-8 border-t border-border text-center">
            <p className="text-muted-foreground text-sm">
              Want to know exactly how we calculate these numbers? <Link to="/calculation-methodology" className="text-primary hover:underline font-medium">See our calculation methodology</Link>.
            </p>
          </div>

        </div>
      </section>
    </div>
  );
}

export default CompoundInterestPage;
