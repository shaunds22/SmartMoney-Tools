import React from 'react';
import PageSeo from '@/components/PageSeo.jsx';
import { Link } from 'react-router-dom';
import Breadcrumb from '@/components/Breadcrumb.jsx';

function TermsPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <PageSeo
        title="Terms of Use | SmartMoneyTools"
        description="Read the Terms of Use for SmartMoneyTools. Our free financial calculators are for educational and informational purposes only and do not constitute professional financial advice."
        path="/terms"
      />

      <section className="bg-primary text-primary-foreground py-12 border-b border-primary/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">
          <h1 className="text-4xl md:text-5xl font-extrabold mb-4 leading-tight" style={{ letterSpacing: '-0.02em' }}>
            Terms of Use
          </h1>
          <p className="text-lg text-primary-foreground/85">
            Please read these terms carefully before using SmartMoneyTools. By using our website you agree to these terms.
          </p>
        </div>
      </section>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl pt-6 pb-0">
        <Breadcrumb items={[{ label: 'Terms of Use' }]} />
      </div>

      <main className="flex-grow py-10 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">

          <div className="bg-muted/40 border border-border rounded-xl px-6 py-4 mb-10 text-sm text-muted-foreground">
            <strong className="text-foreground">Effective date:</strong> 6 May 2026 &nbsp;|&nbsp; <strong className="text-foreground">Last reviewed:</strong> 6 August 2026
          </div>

          <div className="prose prose-slate max-w-none text-muted-foreground prose-headings:text-foreground prose-a:text-primary hover:prose-a:text-primary/80 prose-strong:text-foreground space-y-2">

            {/* 1 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">1. Introduction</h2>
            <p>
              Welcome to SmartMoneyTools (<strong>"SmartMoneyTools"</strong>, <strong>"we"</strong>, <strong>"us"</strong>, or <strong>"our"</strong>). We operate the website at <a href="https://smartmoney-tools.com" className="text-primary hover:underline">smartmoney-tools.com</a> (the <strong>"Website"</strong>), which provides free online financial calculators and educational guides covering topics such as income tax, mortgages, pensions, savings, debt management, and budgeting.
            </p>
            <p>
              These Terms of Use (<strong>"Terms"</strong>) set out the rules and conditions that apply to your access to and use of the Website. They form a legally binding agreement between you and SmartMoneyTools.
            </p>

            {/* 2 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">2. Acceptance of Terms</h2>
            <p>
              By accessing or using this Website in any way — including browsing, running a calculation, or reading a guide — you confirm that you have read, understood, and agree to be bound by these Terms and our <Link to="/privacy" className="text-primary hover:underline">Privacy Policy</Link> and <Link to="/cookie-policy" className="text-primary hover:underline">Cookie Policy</Link>.
            </p>
            <p>
              If you do not agree to these Terms, you must stop using the Website immediately.
            </p>

            {/* 3 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">3. About SmartMoneyTools</h2>
            <p>
              SmartMoneyTools is a free-to-use personal finance website aimed at individuals based primarily in the United Kingdom and the United States. We provide self-service calculator tools and plain-English educational guides to help users understand financial concepts and estimate figures such as take-home pay, mortgage repayments, pension projections, and compound interest growth.
            </p>
            <p>
              SmartMoneyTools is not a financial services firm, mortgage broker, tax adviser, pensions adviser, or investment firm, and is not authorised or regulated by the Financial Conduct Authority (FCA) or any other regulatory body.
            </p>

            {/* 4 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">4. Educational and Informational Use Only</h2>
            <p>
              All content published on this Website — including calculator outputs, results, tables, charts, articles, and guides — is provided <strong>solely for educational and general informational purposes</strong>. The Website is designed to help you understand financial concepts and explore illustrative scenarios based on your own inputs.
            </p>
            <p>
              Nothing on this Website constitutes, or should be treated as, professional financial, tax, mortgage, pensions, legal, or investment advice of any kind. Calculator results are mathematical estimates based on the inputs you provide and publicly available statutory data; they do not account for your individual circumstances.
            </p>

            {/* 5 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">5. No Financial, Tax, Mortgage, Pension, Legal, or Investment Advice</h2>
            <p>
              <strong>We do not provide financial advice.</strong> The information and outputs provided by this Website are not a substitute for personalised professional advice. Before making any significant financial decision — including but not limited to purchasing property, changing pension contributions, taking out a loan, restructuring debt, or making investments — you should seek advice from an appropriately qualified and regulated professional, such as:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>A <strong>financial adviser</strong> authorised by the Financial Conduct Authority (FCA)</li>
              <li>A qualified <strong>accountant or tax adviser</strong> (e.g. a member of ICAEW, ACCA, or CIOT)</li>
              <li>A <strong>mortgage broker</strong> regulated by the FCA</li>
              <li>A qualified <strong>pensions adviser</strong> or actuary</li>
              <li>A <strong>solicitor or legal adviser</strong> regulated by the Solicitors Regulation Authority (SRA)</li>
            </ul>
            <p className="mt-4">
              Free, impartial guidance is also available from organisations such as <a href="https://www.moneyhelper.org.uk" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">MoneyHelper</a> (formerly the Money Advice Service), <a href="https://www.pensionsadvisoryservice.org.uk" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">The Pensions Advisory Service</a>, and <a href="https://www.citizensadvice.org.uk" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Citizens Advice</a>.
            </p>

            {/* 6 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">6. Calculator Accuracy and Limitations</h2>
            <p>
              Our calculators use publicly available statutory data (such as HMRC tax bands, National Insurance thresholds, and IRS withholding tables) and standard mathematical formulas. Whilst we make every reasonable effort to keep our figures up to date and accurate, you should be aware of the following limitations:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li><strong>Estimates only:</strong> All results are estimates. They may differ from figures produced by HMRC, your employer's payroll system, your mortgage lender, or any other official source.</li>
              <li><strong>Simplified assumptions:</strong> Calculators cannot replicate the full complexity of your personal tax position, which may include tax code adjustments, benefits in kind, multiple income sources, or tapering reliefs.</li>
              <li><strong>Data lag:</strong> Tax rates, thresholds, and statutory limits change each tax year. There may be a short period after a Budget announcement or Finance Act where our calculators have not yet been updated.</li>
              <li><strong>No guarantee of completeness:</strong> Calculators do not account for all possible scenarios; features such as complex pension arrangements, share schemes, non-domiciled status, or unusual tax situations are outside their scope.</li>
              <li><strong>Input-dependent:</strong> The accuracy of any result depends entirely on the accuracy and completeness of the information you enter.</li>
            </ul>
            <p className="mt-4">
              We review our statutory data regularly and publish the tax year and last-reviewed date on each calculator page. If you believe a figure is incorrect, please <Link to="/contact" className="text-primary hover:underline">contact us</Link>.
            </p>

            {/* 7 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">7. User Responsibilities</h2>
            <p>By using the Website, you agree to:</p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>Verify calculator results against official sources (such as HMRC's own tools or your payslip) before relying on them.</li>
              <li>Seek qualified professional advice before making significant financial decisions.</li>
              <li>Ensure any information you enter is accurate; results based on incorrect inputs will be unreliable.</li>
              <li>Accept full responsibility for any decisions you make based on information obtained from this Website.</li>
              <li>Not use the Website for any unlawful purpose.</li>
            </ul>

            {/* 8 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">8. Acceptable Use</h2>
            <p>You must not use the Website in any way that:</p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>Violates any applicable law or regulation.</li>
              <li>Involves the use of automated scripts, bots, crawlers, or scrapers to extract, copy, or replicate content, calculator logic, or data at scale without our prior written permission.</li>
              <li>Attempts to reverse-engineer, decompile, or reproduce our calculation algorithms or source code.</li>
              <li>Embeds our calculators or pages in a third-party application or website via iframes or similar techniques without our prior written consent.</li>
              <li>Disrupts or damages the performance or availability of the Website or its underlying infrastructure.</li>
              <li>Misrepresents the source or nature of calculator results (for example, presenting our estimates as official HMRC figures).</li>
            </ul>
            <p className="mt-4">
              We reserve the right to block access to the Website for any user who breaches these acceptable use rules.
            </p>

            {/* 9 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">9. Intellectual Property</h2>
            <p>
              All content on this Website — including text, guides, calculator interfaces, graphics, logos, data arrangements, and the specific implementation of calculation logic — is the intellectual property of SmartMoneyTools and is protected by copyright and other applicable laws.
            </p>
            <p>
              You may read and use the content for your own personal, non-commercial purposes. You must not reproduce, republish, distribute, sell, create derivative works from, or commercially exploit any part of this Website without our prior written consent.
            </p>
            <p>
              Brief quotation of our content for commentary, criticism, or educational purposes, with a clear attribution and link to the source page, is permitted under fair dealing principles.
            </p>

            {/* 10 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">10. Third-Party Links and Sources</h2>
            <p>
              Our guides and calculator source tables include links to third-party websites such as HMRC, GOV.UK, the IRS, MoneyHelper, and other official or reputable sources. These links are provided for convenience and reference only.
            </p>
            <p>
              SmartMoneyTools does not endorse, control, or take responsibility for the content, accuracy, or availability of any third-party website. Accessing a third-party website is entirely at your own risk and subject to that website's own terms and privacy policy.
            </p>

            {/* 11 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">11. Advertising and Monetisation</h2>
            <p>
              SmartMoneyTools uses Google AdSense to display third-party advertising on the Website. This allows us to provide our calculators and guides free of charge. Advertising is served based on cookies and tracking technologies operated by Google and its advertising partners; these are outside our direct control.
            </p>
            <p>
              We do not endorse any product or service advertised on this Website. Advertisements are served automatically based on page content and user data held by Google's advertising platform.
            </p>
            <p>
              For more information on how we use cookies and advertising technology, please read our <Link to="/cookie-policy" className="text-primary hover:underline">Cookie Policy</Link>.
            </p>

            {/* 12 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">12. Limitation of Liability</h2>
            <p>
              To the fullest extent permitted by applicable law, SmartMoneyTools and its owners, contributors, and operators shall not be liable for:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>Any financial loss, loss of profits, loss of data, or any indirect, incidental, consequential, or special damages arising from your use of, or reliance on, the Website or any calculator result.</li>
              <li>Any inaccuracy or omission in the content of this Website, including outdated statutory rates or thresholds.</li>
              <li>Any decision you make — financial or otherwise — based on information obtained from this Website.</li>
              <li>Interruptions to or unavailability of the Website.</li>
              <li>Any content, information, or advice obtained from third-party websites linked from this Website.</li>
            </ul>
            <p className="mt-4">
              Nothing in these Terms limits liability for death or personal injury caused by negligence, fraud or fraudulent misrepresentation, or any other liability that cannot be excluded under English law.
            </p>

            {/* 13 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">13. Changes to the Website and Terms</h2>
            <p>
              We may update, modify, or withdraw any part of the Website — including calculator functionality, guides, and statutory data — at any time without notice.
            </p>
            <p>
              We may also update these Terms from time to time to reflect changes in our practices, new legislation, or other operational requirements. The effective date at the top of this page will be updated when we make material changes. Your continued use of the Website after any change constitutes your acceptance of the updated Terms.
            </p>
            <p>
              We recommend bookmarking this page and reviewing it periodically.
            </p>

            {/* 14 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">14. Contact Details</h2>
            <p>
              If you have any questions about these Terms, wish to report an inaccuracy in a calculator, or need to contact us for any other reason, please get in touch:
            </p>
            <ul className="list-none pl-0 mt-3 space-y-1">
              <li><strong>Email:</strong> <a href="mailto:support@smartmoney-tools.com" className="text-primary hover:underline">support@smartmoney-tools.com</a></li>
              <li><strong>Contact form:</strong> <Link to="/contact" className="text-primary hover:underline">smartmoney-tools.com/contact</Link></li>
            </ul>
            <p className="mt-4">
              These Terms are governed by the laws of England and Wales. Any disputes arising from your use of the Website shall be subject to the exclusive jurisdiction of the courts of England and Wales.
            </p>

            <div className="mt-12 pt-8 border-t border-border text-sm text-muted-foreground">
              <p>
                For related policies, see our <Link to="/privacy" className="text-primary hover:underline">Privacy Policy</Link>, <Link to="/cookie-policy" className="text-primary hover:underline">Cookie Policy</Link>, and <Link to="/financial-disclaimer" className="text-primary hover:underline">Financial Disclaimer</Link>.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default TermsPage;
