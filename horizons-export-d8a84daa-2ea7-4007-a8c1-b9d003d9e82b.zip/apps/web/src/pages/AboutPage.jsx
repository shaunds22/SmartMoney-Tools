import React from 'react';
import PageSeo from '@/components/PageSeo.jsx';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Separator } from '@/components/ui/separator';
import { 
  Calculator, 
  Target, 
  CheckCircle, 
  ShieldAlert, 
  Mail, 
  Globe,
  DollarSign,
  RefreshCw,
  AlertCircle,
  BookOpen,
  User
} from 'lucide-react';

const sections = [
  { id: 'who-operates', title: '1. Who Operates SmartMoneyTools', icon: <Globe className="w-5 h-5" /> },
  { id: 'purpose', title: '2. Purpose and Mission', icon: <Target className="w-5 h-5" /> },
  { id: 'why-created', title: '3. Why the Calculators Were Created', icon: <Calculator className="w-5 h-5" /> },
  { id: 'data-verification', title: '4. How Calculator Data Is Verified', icon: <CheckCircle className="w-5 h-5" /> },
  { id: 'review-frequency', title: '5. How Often Statutory Values Are Reviewed', icon: <RefreshCw className="w-5 h-5" /> },
  { id: 'corrections', title: '6. How Corrections Are Handled', icon: <AlertCircle className="w-5 h-5" /> },
  { id: 'funding', title: '7. How the Website Is Funded', icon: <DollarSign className="w-5 h-5" /> },
  { id: 'limitations', title: '8. Limitations and Disclaimer', icon: <ShieldAlert className="w-5 h-5" /> },
  { id: 'contact', title: '9. Contact', icon: <Mail className="w-5 h-5" /> },
];

export default function AboutPage() {
  return (
    <div className="flex flex-col w-full bg-background">
      <PageSeo
        title="About SmartMoneyTools | Free Financial Calculators"
        description="Learn about SmartMoneyTools — an independent educational calculator publisher. Who operates it, how statutory rates are verified, and how the site is funded."
        path="/about"
      />

      <section className="bg-primary text-primary-foreground py-16 lg:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-4xl mx-auto text-center"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 leading-tight text-balance">
              About SmartMoneyTools
            </h1>
            <p className="text-xl md:text-2xl text-primary-foreground/90 leading-relaxed max-w-3xl mx-auto font-medium">
              An independent educational calculator publisher providing free, accurate financial tools for UK and US users.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-12 lg:py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
          <div className="flex flex-col lg:flex-row gap-12 items-start">
            
            <aside className="w-full lg:w-1/4 lg:sticky lg:top-24 hidden lg:block border rounded-2xl bg-card p-6 shadow-sm">
              <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-6">Contents</h3>
              <nav className="space-y-1">
                {sections.map((section) => (
                  <a
                    key={section.id}
                    href={`#${section.id}`}
                    className="flex items-center gap-3 py-2.5 px-3 text-sm font-medium rounded-lg text-foreground hover:bg-muted hover:text-primary transition-colors"
                  >
                    <span className="text-muted-foreground">{section.icon}</span>
                    {section.title}
                  </a>
                ))}
              </nav>
            </aside>

            <div className="w-full lg:w-3/4 prose prose-slate dark:prose-invert max-w-none prose-headings:scroll-mt-28 prose-headings:font-bold prose-h2:text-3xl prose-h2:border-b prose-h2:pb-4 prose-h2:mb-6 prose-p:leading-relaxed prose-li:leading-relaxed">

              <div className="not-prose bg-muted/40 border border-border rounded-xl px-6 py-4 mb-10 text-sm text-muted-foreground">
                SmartMoneyTools is an independent educational calculator publisher. We are not regulated financial advisers. Statutory rates are checked against official government publications and calculator outputs are tested using worked examples before publication.
              </div>

              <div id="who-operates" className="mb-16">
                <h2 className="flex items-center gap-3">
                  <Globe className="w-8 h-8 text-primary" />
                  1. Who Operates SmartMoneyTools
                </h2>
                <p>
                  SmartMoneyTools is an independent educational website. It is operated and written by{' '}
                  <Link to="/author/shaun-da-silva" className="text-primary hover:underline font-medium">Shaun Da Silva</Link>, a Financial Consultant with over 20 years&rsquo; experience in the financial sector and a BTech in Information Systems. Shaun researches, writes, and maintains every calculator and guide on the site. The site is not owned by a bank, insurance company, financial advisory firm, or any other regulated financial services business.
                </p>
                <p>
                  SmartMoneyTools is <strong>not authorised or regulated by the Financial Conduct Authority (FCA)</strong> or any other financial regulatory body. Shaun does not hold a regulated financial-advice qualification, and we do not provide personalised financial advice. The calculators and guides are educational tools, not regulated financial advice.
                </p>
                <p>
                  We do not claim to hold any business registrations, professional awards, or regulatory authorisations beyond what is required to operate a website in the United Kingdom.
                </p>
              </div>

              <div id="purpose" className="mb-16">
                <h2 className="flex items-center gap-3">
                  <Target className="w-8 h-8 text-primary" />
                  2. Purpose and Mission
                </h2>
                <p>
                  SmartMoneyTools provides free, browser-based financial calculators and educational guides for everyday personal finance decisions. The primary audience is UK residents, though several tools (the US Salary Calculator and US Retirement Calculator) are built for US users.
                </p>
                <p>
                  Our purpose is simple: to translate complex statutory tax formulas, pension growth mathematics, and mortgage amortization calculations into plain English and instant, accurate results — without requiring users to create an account, provide personal data, or pay anything.
                </p>
                <p>
                  We believe access to accurate financial mathematics should not require an expensive professional consultation for every routine question. We are not a substitute for regulated professional advice, but we aim to help users arrive at those conversations better informed.
                </p>
              </div>

              <div id="why-created" className="mb-16">
                <h2 className="flex items-center gap-3">
                  <Calculator className="w-8 h-8 text-primary" />
                  3. Why the Calculators Were Created
                </h2>
                <p>
                  Most free online financial calculators fall into one of two categories: overly simplified tools that ignore National Insurance, student loans, and pension deductions; or lead-generation tools designed to funnel users toward paid financial products.
                </p>
                <p>
                  SmartMoneyTools was built to provide a middle ground: calculators that are accurate enough to be genuinely useful for planning purposes, presented clearly without pressure to purchase or enquire about any product. Our UK Salary Calculator, for example, applies the full PAYE calculation sequence — income tax, National Insurance, pension contributions, and student loan deductions — in the correct statutory order, with support for all student loan plans and all four nations' tax rules.
                </p>
                <p>
                  We built these tools because we used them ourselves and could not find good free versions that were regularly maintained and transparent about their methodology.
                </p>
              </div>

              <div id="data-verification" className="mb-16">
                <h2 className="flex items-center gap-3">
                  <CheckCircle className="w-8 h-8 text-primary" />
                  4. How Calculator Data Is Verified
                </h2>
                <p>
                  Before any calculator is published or updated, Shaun checks the underlying statutory data against official primary sources. For UK calculators, this means GOV.UK, HMRC publications, and The Pensions Regulator. For US calculators, this means IRS publications (including Publication 15-T for withholding tables) and SSA announcements.
                </p>
                <p>
                  After updating rates or formulas, Shaun tests each calculator against known worked examples &mdash; either examples published by HMRC, GOV.UK, or IRS, or manually calculated examples verified against the primary source. A rate change is not published or deployed until the calculator output matches the expected result for at least three test cases across different income levels.
                </p>
                <p>
                  We publish our data sources in a source table on each calculator page, with direct links to the relevant official pages, so users can independently verify the figures we use.
                </p>
                <p>
                  The guides follow the same process: each article is researched against the same primary sources, the statutory figures it cites are checked before publication, and every guide page carries a visible byline linking to the author profile and a &ldquo;Last updated&rdquo; date that is refreshed whenever the content is materially changed.
                </p>
              </div>

              <div id="review-frequency" className="mb-16">
                <h2 className="flex items-center gap-3">
                  <RefreshCw className="w-8 h-8 text-primary" />
                  5. How Often Statutory Values Are Reviewed
                </h2>
                <p>Our review schedule is:
                </p>
                <ul>
                  <li><strong>Annually (April):</strong> All UK calculators are reviewed and updated for the new tax year (6 April). This includes income tax bands, National Insurance thresholds, student loan repayment thresholds, pension annual allowance, and auto-enrolment qualifying earnings bands.</li>
                  <li><strong>Annually (January):</strong> All US calculators are reviewed for IRS inflation adjustments to standard deductions, tax brackets, FICA wage bases, and retirement contribution limits.</li>
                  <li><strong>Ad-hoc:</strong> When the UK Chancellor announces emergency changes (for example, a mid-year National Insurance rate cut), or when the IRS issues corrections, we update the affected calculator as promptly as possible — typically within 24–48 hours of the official announcement.</li>
                  <li><strong>Ongoing:</strong> When users report errors, we investigate and correct them following our <Link to="/corrections-policy">Corrections Policy</Link>.</li>
                </ul>
                <p>
                  Every calculator and guide page carries a "Last reviewed" date in the author attribution bar. This date is updated whenever a material change is made.
                </p>
              </div>

              <div id="corrections" className="mb-16">
                <h2 className="flex items-center gap-3">
                  <AlertCircle className="w-8 h-8 text-primary" />
                  6. How Corrections Are Handled
                </h2>
                <p>
                  When we identify or receive a report of an error, we investigate it, verify it against official sources, correct it promptly, and update the revision date. We do not silently delete or backdate content. For material errors, we add a correction note near the affected content.
                </p>
                <p>
                  Full details of our error investigation process, timelines, and disclosure procedures are set out in our <Link to="/corrections-policy">Corrections Policy</Link>. There is a "Report an error" link at the top of every calculator page. You can also report errors via our <Link to="/contact">contact form</Link> or by emailing <a href="mailto:support@smartmoney-tools.com">support@smartmoney-tools.com</a>.
                </p>
              </div>

              <div id="funding" className="mb-16">
                <h2 className="flex items-center gap-3">
                  <DollarSign className="w-8 h-8 text-primary" />
                  7. How the Website Is Funded
                </h2>
                <p>
                  SmartMoneyTools is funded through display advertising served by <strong>Google AdSense</strong>. When you visit a page, Google's advertising platform may display contextual or interest-based advertisements. We earn a small amount of revenue when users view or interact with these advertisements.
                </p>
                <p>
                  <strong>Advertisers do not influence our calculator formulas, methodology, editorial conclusions, or coverage decisions.</strong> No advertiser has any input into how we calculate income tax, National Insurance, mortgage repayments, or any other figure. No editorial content has ever been written, modified, or removed at an advertiser's request. There is no paid content on this website disguised as editorial content.
                </p>
                <p>
                  SmartMoneyTools does not currently use affiliate links. If this changes in the future, affiliate links will be clearly disclosed near each relevant link. Our full advertising transparency statement is at <Link to="/advertising-disclosure">Advertising Disclosure</Link>.
                </p>
              </div>

              <div id="limitations" className="mb-16">
                <h2 className="flex items-center gap-3">
                  <ShieldAlert className="w-8 h-8 text-primary" />
                  8. Limitations and Disclaimer
                </h2>
                <p>
                  Our calculators produce estimates, not guaranteed figures. They use simplified assumptions and standardised statutory rules. Your actual tax, pay, mortgage payment, or pension projection may differ because of factors specific to your circumstances that we cannot model — for example, a personalised tax code, a non-standard pension arrangement, or a lender's proprietary stress-testing criteria.
                </p>
                <p>
                  <strong>SmartMoneyTools does not provide financial advice.</strong> Nothing on this website constitutes regulated financial, tax, mortgage, pensions, legal, or investment advice. You should seek advice from a qualified, regulated professional before making significant financial decisions.
                </p>
                <p>
                  See our <Link to="/financial-disclaimer">Financial Disclaimer</Link> and <Link to="/calculation-methodology">Calculation Methodology</Link> for full details of our limitations and the assumptions each calculator uses.
                </p>
              </div>

              <Separator className="my-12" />

              <div id="contact" className="mb-8">
                <h2 className="flex items-center gap-3">
                  <Mail className="w-8 h-8 text-primary" />
                  9. Contact
                </h2>
                <p>
                  For general enquiries, error reports, accessibility feedback, or advertising questions:
                </p>
                <ul>
                  <li><strong>Email:</strong> <a href="mailto:support@smartmoney-tools.com">support@smartmoney-tools.com</a></li>
                  <li><strong>Contact form:</strong> <Link to="/contact">smartmoney-tools.com/contact</Link></li>
                </ul>
                <p>
                  We aim to respond to all legitimate enquiries within 48 hours.
                </p>
                <div className="not-prose mt-8 flex flex-wrap gap-3">
                  <Link to="/editorial-policy" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-muted hover:bg-muted/80 text-sm font-medium text-foreground transition-colors"><BookOpen className="w-4 h-4"/>Editorial Policy</Link>
                  <Link to="/corrections-policy" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-muted hover:bg-muted/80 text-sm font-medium text-foreground transition-colors"><AlertCircle className="w-4 h-4"/>Corrections Policy</Link>
                  <Link to="/calculation-methodology" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-muted hover:bg-muted/80 text-sm font-medium text-foreground transition-colors"><Calculator className="w-4 h-4"/>Methodology</Link>
                  <Link to="/advertising-disclosure" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-muted hover:bg-muted/80 text-sm font-medium text-foreground transition-colors"><DollarSign className="w-4 h-4"/>Advertising Disclosure</Link>
                  <Link to="/accessibility" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-muted hover:bg-muted/80 text-sm font-medium text-foreground transition-colors"><CheckCircle className="w-4 h-4"/>Accessibility</Link>
                  <Link to="/about/team" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-muted hover:bg-muted/80 text-sm font-medium text-foreground transition-colors"><User className="w-4 h-4"/>Our Team</Link>
                </div>
              </div>

            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
