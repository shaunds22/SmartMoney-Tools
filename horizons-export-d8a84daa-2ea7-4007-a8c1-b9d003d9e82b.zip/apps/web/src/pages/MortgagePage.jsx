import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import CalculatorCard from '@/components/CalculatorCard.jsx';
import ResultsCard from '@/components/ResultsCard.jsx';
import MortgageCalculator from '@/components/MortgageCalculator.jsx';
import PaymentBreakdownChart from '@/components/PaymentBreakdownChart.jsx';
import AmortizationChart from '@/components/AmortizationChart.jsx';
import AmortizationTable from '@/components/AmortizationTable.jsx';
import DisclaimerBanner from '@/components/DisclaimerBanner.jsx';
import HowWeCalculateThis from '@/components/HowWeCalculateThis.jsx';
import CalculatorContentSection from '@/components/CalculatorContentSection.jsx';
import useCurrency from '@/hooks/useCurrency.js';
import formatCurrency from '@/utils/formatCurrency.js';
import Breadcrumb from '@/components/Breadcrumb.jsx';
import AuthorAttribution from '@/components/AuthorAttribution.jsx';
import AuthorBylineBar from '@/components/AuthorBylineBar.jsx';
import { setPageMeta } from '@/utils/seo.js';
import { addWebApplicationSchema } from '@/utils/structuredData.js';

function MortgagePage() {
  const [results, setResults] = useState(null);
  const { currencyCode } = useCurrency();

  useEffect(() => {
    // Reset state on mount
    setResults(null);

    setPageMeta(
      'UK Mortgage Repayment Calculator | SmartMoneyTools',
      'Free UK mortgage calculator. Estimate your monthly mortgage payment, deposit, loan-to-value, total interest and total repaid, with optional Council Tax, buildings insurance and leasehold costs.',
      'https://smartmoney-tools.com/mortgage'
    );
    addWebApplicationSchema(
      'UK Mortgage Calculator',
      'https://smartmoney-tools.com/mortgage',
      'Free UK mortgage repayment and interest-only calculator estimating monthly payments, loan-to-value, total interest and total amount repaid.'
    );
  }, []);

  const handleResultsChange = (newResults) => {
    setResults(newResults);
  };

  const isInterestOnly = results?.repaymentType === 'interest-only';

  const resultRows = results
    ? [
        {
          label: 'Monthly mortgage payment',
          value: formatCurrency(results.monthlyMortgagePayment, currencyCode),
          subtitle: isInterestOnly ? 'Interest only — capital repaid at end of term' : 'Capital & interest (repayment mortgage)',
        },
        {
          label: 'Mortgage amount',
          value: formatCurrency(results.mortgageAmount, currencyCode),
          subtitle: `Property value minus deposit · ${results.ltv.toFixed(1)}% LTV`,
        },
        {
          label: 'Total interest',
          value: formatCurrency(results.totalInterest, currencyCode),
          subtitle: isInterestOnly ? 'Interest paid over the full term' : 'Interest paid over the full term',
        },
        {
          label: 'Total amount repaid',
          value: formatCurrency(results.totalRepaid, currencyCode),
          subtitle: isInterestOnly ? 'Interest plus the capital returned at the end' : 'All monthly payments over the term',
        },
        {
          label: 'Estimated monthly housing cost',
          value: formatCurrency(results.monthlyHousingCost, currencyCode),
          subtitle: 'Council Tax, insurance & leasehold costs — separate from the mortgage',
        },
        {
          label: 'Total monthly cost',
          value: formatCurrency(results.totalMonthlyCost, currencyCode),
          subtitle: 'Mortgage payment plus estimated housing costs',
        },
      ]
    : [];

  return (
    <div className="flex flex-col w-full">
      <section className="bg-primary text-primary-foreground py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-4xl mx-auto text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight" style={{ letterSpacing: '-0.02em' }}>
              UK Mortgage Repayment Calculator
            </h1>
            <p className="text-xl text-primary-foreground/90 leading-relaxed max-w-3xl mx-auto">
              Estimate your monthly mortgage payment, deposit, loan-to-value, total interest and total amount repaid —
              with optional Council Tax, buildings insurance and leasehold costs shown separately.
            </p>
            <AuthorBylineBar variant="hero" />
          </motion.div>
        </div>
      </section>

      <div className="bg-background border-b border-border/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <Breadcrumb items={[{ label: 'Mortgage Calculator' }]} />
        </div>
      </div>

      <div className="bg-background border-b border-border/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-3 max-w-7xl">
          <AuthorAttribution lastReviewedDate="2026-11-02" showByline={false} />
        </div>
      </div>

      <section className="py-8 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                <CalculatorCard
                  title="Your mortgage details"
                  description="Enter your property value, deposit, rate and term. Optional housing costs are totalled separately."
                >
                  <MortgageCalculator onResultsChange={handleResultsChange} />
                </CalculatorCard>
              </motion.div>

              {results && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="space-y-8"
                >
                  <DisclaimerBanner />

                  <ResultsCard results={resultRows} />

                  <CalculatorCard title="Monthly cost breakdown">
                    <PaymentBreakdownChart data={results} currencyCode={currencyCode} />
                  </CalculatorCard>

                  <CalculatorCard title="Loan amortisation timeline">
                    <AmortizationChart data={results.yearlyData} currencyCode={currencyCode} />
                  </CalculatorCard>

                  <CalculatorCard title="Detailed annual schedule">
                    <AmortizationTable data={results.amortizationData} currencyCode={currencyCode} />
                  </CalculatorCard>
                </motion.div>
              )}

            </div>
          </div>
          <HowWeCalculateThis region="UK" />
        </div>
      </section>

      <section className="py-16 bg-muted/30 border-t border-border">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">

          <CalculatorContentSection title="A UK-focused mortgage calculator">
            <p>This calculator is built for the UK mortgage market. It works out your monthly mortgage payment from the property value, your deposit, the interest rate and the mortgage term, and lets you choose between a <strong>repayment</strong> mortgage (capital and interest) and an <strong>interest-only</strong> mortgage. It then shows your loan-to-value (LTV), total interest and the total amount you would repay over the term.</p>
            <p>Optional monthly housing costs — Council Tax, buildings insurance, service charge, ground rent and an estimated maintenance allowance — are added up separately into an <strong>estimated monthly housing cost</strong>. This is shown alongside your mortgage payment, never mixed into it, so you can see the mortgage itself and the wider cost of running the home. Council Tax is a local authority charge for services; it is <em>not</em> a property tax in the US sense and is not described that way here.</p>
            <p className="bg-primary/5 p-4 rounded-lg border border-primary/20 text-sm">
              <strong>This is an estimate, not a mortgage offer.</strong> The figures are for planning and education only. A real lender's offer depends on a full affordability assessment, your credit history, the property and the product available at the time. See <a href="https://www.moneyhelper.org.uk/en/homes/buying-a-home" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">MoneyHelper – Buying a home</a> for impartial guidance.
            </p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Who it's for">
            <ul>
              <li><strong>First-time buyers</strong> working out what deposit they need and what monthly payment a given property price implies.</li>
              <li><strong>Remortgagers</strong> approaching the end of a fixed rate who need to model new payments at current rates.</li>
              <li><strong>Homeowners</strong> considering overpayments to see how extra monthly cash shortens the term and cuts interest.</li>
              <li><strong>Leasehold flat buyers</strong> who need to factor service charge and ground rent into the monthly cost of living there.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="What you need before you start">
            <ul>
              <li>The <strong>property value</strong> (purchase price or valuation) and the <strong>deposit</strong> you have saved. The difference is the mortgage amount.</li>
              <li>The <strong>interest rate</strong> you're being offered, and the <strong>term</strong> (typically 25–35 years in the UK).</li>
              <li>A view on <strong>repayment type</strong>: a repayment mortgage clears the loan by the end of the term; an interest-only mortgage pays only interest and repays the capital as a lump sum at the end.</li>
              <li>An estimate of monthly <strong>Council Tax</strong> and <strong>buildings insurance</strong>, plus <strong>service charge</strong> and <strong>ground rent</strong> if the property is leasehold.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="What each input means">
            <ul>
              <li><strong>Property value</strong> — the purchase price or current valuation.</li>
              <li><strong>Deposit</strong> — the cash you put down upfront. A bigger deposit means a smaller loan and usually a lower interest rate.</li>
              <li><strong>Mortgage amount</strong> — property value minus deposit; the sum you're borrowing.</li>
              <li><strong>Interest rate</strong> — the annual rate on the mortgage. The calculator assumes it stays fixed for the whole term; in reality most UK fixes last 2–5 years.</li>
              <li><strong>Mortgage term</strong> — how long you take to repay. Longer terms lower the monthly payment but sharply increase total interest.</li>
              <li><strong>Repayment type</strong> — repayment (capital and interest each month) or interest-only (interest monthly, capital repaid at the end).</li>
              <li><strong>Council Tax, buildings insurance, service charge, ground rent, maintenance</strong> — optional monthly housing costs, totalled separately from the mortgage payment.</li>
              <li><strong>Extra monthly overpayment</strong> — an optional overpayment applied to capital on a repayment mortgage, reducing the term and total interest.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="How to read your results">
            <p>The <strong>Monthly mortgage payment</strong> is the mortgage itself — capital and interest for a repayment mortgage, or interest only for an interest-only mortgage. The <strong>Estimated monthly housing cost</strong> is the separate total of your Council Tax, buildings insurance and any leasehold costs. The <strong>Total monthly cost</strong> adds the two together so you can compare the whole picture against your monthly budget.</p>
            <p><strong>Total interest</strong> is often the most sobering figure: over a 25-year term it can approach the original loan amount, which is why shorter terms and overpayments matter so much. The amortisation chart shows how each payment splits between interest and capital over time. Early on, most of each payment is interest; only in the later years does capital dominate — so overpayments made early in the mortgage save far more interest than the same overpayment made near the end.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Worked example — repayment mortgage">
            <p>A typical UK purchase:</p>
            <ul>
              <li><strong>Property value:</strong> £250,000</li>
              <li><strong>Deposit:</strong> £25,000 (10% deposit, 90% LTV)</li>
              <li><strong>Mortgage amount:</strong> £225,000</li>
              <li><strong>Interest rate:</strong> 5.5% (illustrative 2-year fix for 90% LTV)</li>
              <li><strong>Term:</strong> 25 years</li>
              <li><strong>Repayment type:</strong> Repayment (capital &amp; interest)</li>
            </ul>
            <p>Using the standard amortisation formula, the monthly mortgage payment is <strong>£1,381.69</strong>. Over 25 years the total amount repaid is <strong>£414,507</strong>, of which <strong>£189,507</strong> is interest. Adding a typical £150 Council Tax and £25 buildings insurance gives an estimated monthly housing cost of £175, so the total monthly cost is roughly <strong>£1,556.69</strong>.</p>
            <p className="text-sm text-muted-foreground">The 5.5% rate is an illustrative figure for a 90% LTV product, not a current market rate. Always check live rates with lenders or a whole-of-market broker.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Worked example — interest-only mortgage">
            <p>Same property, but on an interest-only basis:</p>
            <ul>
              <li><strong>Mortgage amount:</strong> £225,000</li>
              <li><strong>Interest rate:</strong> 5.5%</li>
              <li><strong>Term:</strong> 25 years</li>
              <li><strong>Repayment type:</strong> Interest-only</li>
            </ul>
            <p>The monthly payment is the interest only: £225,000 × 5.5% ÷ 12 = <strong>£1,031.25</strong> a month. Over 25 years that is £309,375 of interest, and you still owe the original £225,000 at the end, which must be repaid in full. So the total amount repaid is <strong>£534,375</strong> — noticeably more than the repayment mortgage, because the capital is not being reduced along the way.</p>
            <p className="text-sm text-muted-foreground">Interest-only mortgages are harder to obtain and require a credible repayment vehicle (a savings plan, investments, or the eventual sale of the property) to repay the capital. Lenders will assess this rigorously. See <a href="https://www.moneyhelper.org.uk/en/homes/buying-a-home/mortgages/interest-only-mortgages" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">MoneyHelper – Interest-only mortgages</a>.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Understanding loan-to-value (LTV)">
            <p>Loan-to-value is the mortgage amount expressed as a percentage of the property value. A £225,000 mortgage on a £250,000 property is 90% LTV. LTV is one of the main things that sets the rates available to you: a lower LTV (a bigger deposit) generally unlocks cheaper products. Typical LTV bands are 95%, 90%, 85%, 80% and 75%, with the biggest rate steps usually between 90% and 85% and again below 75%.</p>
            <p>Because LTV is just a ratio, this calculator shows it automatically from your property value and deposit. Saving a larger deposit doesn't only reduce the amount you borrow — it can move you into a cheaper LTV band, which lowers the rate on the whole loan.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Mortgage affordability versus mortgage repayment">
            <p>These two ideas are often confused but they are different:</p>
            <ul>
              <li><strong>Mortgage repayment</strong> is the arithmetic this calculator does — given a loan, a rate and a term, what is the monthly payment and total interest? It is pure maths.</li>
              <li><strong>Mortgage affordability</strong> is the lender's assessment of whether you can actually keep up those payments. UK lenders must follow the Financial Conduct Authority's <a href="https://www.fca.org.uk/consumers/mortgages" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Mortgage Conduct of Business</a> rules, which look at your income, outgoings, credit history and stress-test whether you could still afford the mortgage if interest rates rose.</li>
            </ul>
            <p>A mortgage you can <em>calculate</em> is not necessarily a mortgage a lender will <em>offer</em>. Two people with identical incomes can be offered very different maximum loans depending on their existing commitments, dependants, credit file and the lender's own appetite.</p>
            <p className="bg-warning/10 p-4 rounded-lg border border-warning/30 text-sm">
              <strong>Lender affordability assessments vary.</strong> Each lender applies its own income multiples, stress tests and affordability models, and these change over time. The maximum a lender will offer is not a single published number — speak to a lender or a whole-of-market mortgage broker for a figure based on your circumstances. <a href="https://www.moneyhelper.org.uk/en/homes/buying-a-home/mortgages/how-much-can-i-borrow" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">MoneyHelper – How much can I borrow?</a>
            </p>
          </CalculatorContentSection>

          <CalculatorContentSection title="The maths behind it">
            <p>For a repayment mortgage, the monthly payment uses the standard amortisation formula <code>M = P [ i(1 + i)^n ] / [ (1 + i)^n - 1 ]</code>, where M is the monthly payment, P the mortgage amount (principal), i the monthly interest rate (annual ÷ 12), and n the number of months. Total interest is then <code>(M × n) − P</code>, and the total amount repaid is <code>M × n</code>.</p>
            <p>For an interest-only mortgage, the monthly payment is simply <code>P × i</code> (the interest on the capital), total interest is <code>P × i × n</code>, and the total amount repaid is the interest plus the original capital returned at the end of the term.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Assumptions and exclusions">
            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">Assumptions</h3>
            <ul>
              <li>A fixed interest rate for the entire modelled term — most UK fixes last 2–5 years before reverting to a higher Standard Variable Rate (SVR).</li>
              <li>Regular monthly payments made on time throughout the full term.</li>
              <li>No early repayment charges on modelled overpayments (most lenders allow up to 10% of the balance per year penalty-free).</li>
              <li>Council Tax, insurance and leasehold costs assumed constant, with no inflationary increase.</li>
              <li>For interest-only, the capital is assumed repaid in full at the end of the term from a separate repayment vehicle not modelled here.</li>
            </ul>
            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">What is not included</h3>
            <ul>
              <li>Stamp Duty Land Tax (SDLT), or Land Transaction Tax (LTT) in Wales and Land and Buildings Transaction Tax (LBTT) in Scotland — first-time buyers in England and Northern Ireland get relief up to £300,000. Check <a href="https://www.gov.uk/stamp-duty-land-tax" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Stamp Duty Land Tax</a>.</li>
              <li>Lender arrangement and product fees (often £999–£1,499).</li>
              <li>Solicitor, surveyor and valuation fees.</li>
              <li>Lender stress-test calculations.</li>
              <li>Life insurance, critical illness or income protection premiums.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Common mistakes to avoid">
            <ul>
              <li><strong>Forgetting Stamp Duty.</strong> You need separate cash for SDLT — first-time buyers get relief, but it still catches people out. Check <a href="https://www.gov.uk/stamp-duty-land-tax" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Stamp Duty</a>.</li>
              <li><strong>Ignoring arrangement fees.</strong> The cheapest rate often carries a £999+ fee; adding it to the loan increases your balance and the interest you pay.</li>
              <li><strong>Confusing affordability with repayment.</strong> A low monthly payment doesn't mean a lender will offer you the loan — see the section above.</li>
              <li><strong>Stretching to the maximum.</strong> Borrowing the absolute maximum a lender offers leaves no buffer for rate rises or life events.</li>
              <li><strong>Fixing for too short a period</strong> if rates are rising. A 2-year fix can leave you exposed to a much higher rate soon after.</li>
              <li><strong>Underestimating leasehold costs.</strong> Service charges and ground rent on flats can rise sharply and are separate from your mortgage payment.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Sensible next steps">
            <ul>
              <li>Get an Agreement in Principle (AIP) from a lender before house-hunting — it shows sellers and agents you're serious and gives an indicative borrowing figure. See <a href="https://www.moneyhelper.org.uk/en/homes/buying-a-home/mortgages/mortgage-agreement-in-principle" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">MoneyHelper – Agreement in Principle</a>.</li>
              <li>Compare the total cost of a mortgage, not just the monthly payment: a slightly higher rate over a shorter term can cost less overall.</li>
              <li>If you're remortgaging, start shopping for a new deal three to six months before your fix ends to avoid slipping onto the SVR.</li>
              <li>Read our <Link to="/guides/mortgage-comprehensive" className="text-primary hover:underline">Comprehensive Mortgage Guide</Link> and, for first-time buyers, the <Link to="/guides/mortgage-affordability-first-time-buyers" className="text-primary hover:underline">affordability guide</Link>.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Frequently Asked Questions">
            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">What is the difference between a repayment and an interest-only mortgage?</h3>
            <p className="mb-4">On a <strong>repayment</strong> mortgage, each monthly payment covers both interest and a slice of the capital, so the loan is fully cleared by the end of the term. On an <strong>interest-only</strong> mortgage, each monthly payment covers only the interest, and the original loan amount must be repaid in full at the end — usually from a separate savings or investment plan. Interest-only mortgages have lower monthly payments but cost more in total and carry more risk.</p>

            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">Should I choose a fixed or variable rate?</h3>
            <p className="mb-4">Fixed rates provide payment certainty for a set period (usually 2, 5 or 10 years), protecting you from rate hikes. Variable or tracker rates move with the Bank of England base rate; they can be cheaper initially but carry the risk of payments increasing. <a href="https://www.moneyhelper.org.uk/en/homes/buying-a-home/mortgages/types-of-mortgage-interest-rates" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">MoneyHelper – Types of mortgage interest rates</a> explains the options.</p>

            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">What happens when my fixed term ends?</h3>
            <p className="mb-4">You will automatically move to your lender's Standard Variable Rate (SVR), which is typically much higher than fixed rates. Most borrowers remortgage to a new fixed deal shortly before their current one expires to avoid this.</p>

            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">Can I pay my mortgage off early?</h3>
            <p className="mb-4">Yes, but check your terms. Most fixed-rate mortgages allow you to overpay by up to 10% of the outstanding balance per year without penalty. Exceeding this usually triggers an Early Repayment Charge (ERC). See our <Link to="/guides/mortgage-overpayments" className="text-primary hover:underline">Mortgage Overpayments Guide</Link>.</p>

            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">Is Council Tax the same as property tax?</h3>
            <p className="mb-4">No. Council Tax is a local authority charge that funds local services such as refuse collection, policing and roads. It is based on the property's valuation band, not on a percentage of the property's value, so it is not equivalent to US-style property tax. See <a href="https://www.gov.uk/council-tax" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Council Tax</a>.</p>

            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">Is this calculator a mortgage offer?</h3>
            <p>No. It produces an estimate for planning purposes only. A real mortgage offer depends on a full lender affordability assessment, your credit history, the property and the products available at the time.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Related calculators and guides">
            <ul>
              <li><Link to="/budget-planner" className="text-primary hover:underline">Budget Planner</Link>: Ensure your new mortgage payment fits comfortably within your monthly budget.</li>
              <li><Link to="/savings-goal-calculator" className="text-primary hover:underline">Savings Goal Calculator</Link>: Plan how long it will take to save your required house deposit.</li>
              <li><Link to="/guides/mortgage-comprehensive" className="text-primary hover:underline">Comprehensive Mortgage Guide</Link>: Navigating the UK property market in depth.</li>
              <li><Link to="/guides/mortgage-overpayments" className="text-primary hover:underline">Mortgage Overpayments Guide</Link>: How overpayments strip years off your term.</li>
              <li><Link to="/guides/mortgage-affordability-first-time-buyers" className="text-primary hover:underline">Mortgage Affordability for First-Time Buyers</Link>: How much a lender will actually offer.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Sources and references">
            <p className="text-sm bg-primary/5 p-3 rounded-lg border border-primary/20 mb-4">SmartMoneyTools checks statutory rates and thresholds against official government publications. The interest rates used in examples are illustrative, not current market rates. Results are estimates for educational purposes and may not reflect every individual circumstance. <strong>Last reviewed: 2 November 2026.</strong></p>
            <p>Guidance aligns with:</p>
            <ul>
              <li><a href="https://www.moneyhelper.org.uk/en/homes/buying-a-home" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">MoneyHelper – Buying a home</a></li>
              <li><a href="https://www.moneyhelper.org.uk/en/homes/buying-a-home/mortgages/how-much-can-i-borrow" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">MoneyHelper – How much can I borrow?</a></li>
              <li><a href="https://www.moneyhelper.org.uk/en/homes/buying-a-home/mortgages/interest-only-mortgages" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">MoneyHelper – Interest-only mortgages</a></li>
              <li><a href="https://www.fca.org.uk/consumers/mortgages" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Financial Conduct Authority (FCA) – Mortgages</a></li>
              <li><a href="https://www.gov.uk/stamp-duty-land-tax" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Stamp Duty Land Tax</a></li>
              <li><a href="https://www.gov.uk/council-tax" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Council Tax</a></li>
              <li><a href="https://landregistry.data.gov.uk/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">HM Land Registry – UK House Price Index</a></li>
            </ul>
          </CalculatorContentSection>

          <div className="mt-12 pt-8 border-t border-border text-center">
            <p className="text-muted-foreground text-sm">
              Want to know exactly how we calculate these numbers? <Link to="/calculation-methodology" className="text-primary hover:underline font-medium">See our calculation methodology</Link>.
            </p>
          </div>

        </div>
      </section>
    </div>
  );
}

export default MortgagePage;
