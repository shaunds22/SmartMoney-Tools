import React, { useEffect } from 'react';
import { setPageMeta } from '@/utils/seo.js';

function DisclaimerPage() {
  useEffect(() => {
    setPageMeta(
      'Financial Disclaimer | SmartMoneyTools',
      'Important legal disclaimer regarding the accuracy and limitations of our financial calculators and guides.',
      'https://smartmoney-tools.com/disclaimer'
    );
  }, []);

  return (
    <div className="min-h-screen flex flex-col">

      <main className="flex-grow py-16 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">
          <h1 className="text-4xl font-bold text-foreground mb-8">Financial Disclaimer</h1>
          
          <div className="prose prose-slate max-w-none text-muted-foreground space-y-6">
            <div className="bg-primary/5 p-6 rounded-xl border border-primary/20 text-foreground font-medium text-lg leading-relaxed mb-8">
              SmartMoneyTools provides algorithmic calculators and written guides strictly for educational, illustrative, and informational purposes.
            </div>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">We Are Not Advisors</h2>
            <p>
              The creators, developers, and authors of SmartMoneyTools are not certified financial planners (CFP), licensed mortgage brokers, attorneys, or tax professionals. Nothing published on this domain constitutes a recommendation to buy, sell, or hold any security, or to adopt any specific investment strategy or loan product.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">Calculations Are Estimates</h2>
            <p>
              Our tools process user-supplied parameters through standard mathematical formulas. However, these projections are purely theoretical. In the real world, calculations are impacted by numerous factors that our tools cannot predict, including:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Changing variable interest rates.</li>
              <li>Sudden fluctuations in Council Tax bands or insurance premiums.</li>
              <li>Unforeseen maintenance costs, lender arrangement fees, or conveyancing costs.</li>
              <li>Market volatility affecting the principal value of investments.</li>
            </ul>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">No Guarantees of Performance</h2>
            <p>
              When utilizing our compound interest or investment tools, the rate of return you select is hypothetical. <strong>Past performance of financial markets is never a guarantee of future results.</strong> Projections do not automatically account for capital gains taxes or inflation unless specifically factored into the rate by the user.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">Consult Professionals</h2>
            <p>
              Any financial decision—whether it is securing a mortgage, investing capital, or restructuring debt—carries inherent risk. You should always consult with qualified, licensed professionals who understand your specific financial situation before executing binding contracts or committing funds.
            </p>
          </div>
        </div>
      </main>

    </div>
  );
}

export default DisclaimerPage;