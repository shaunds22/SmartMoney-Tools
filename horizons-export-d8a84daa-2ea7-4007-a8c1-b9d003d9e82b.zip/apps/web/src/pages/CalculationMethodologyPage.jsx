import React from 'react';
import PageSeo from '@/components/PageSeo.jsx';
import { Link } from 'react-router-dom';
import Breadcrumb from '@/components/Breadcrumb.jsx';

const sections = [
  { id: 'overview', title: '1. Overview' },
  { id: 'principles', title: '2. Our Calculation Principles' },
  { id: 'data-sources', title: '3. Data Sources' },
  { id: 'uk-tax-salary', title: '4. UK Tax and Salary Calculations' },
  { id: 'mortgage', title: '5. Mortgage Calculations' },
  { id: 'compound-interest', title: '6. Compound Interest and Savings' },
  { id: 'pension', title: '7. Pension Projection Calculations' },
  { id: 'debt-repayment', title: '8. Debt Repayment Calculations' },
  { id: 'self-employed', title: '9. Self-Employed Tax Calculations' },
  { id: 'assumptions', title: '10. Assumptions and Simplifications' },
  { id: 'rounding', title: '11. Rounding and Displayed Results' },
  { id: 'update-schedule', title: '12. Update Schedule' },
  { id: 'testing', title: '13. Testing and Quality Assurance' },
  { id: 'known-limitations', title: '14. Known Limitations' },
  { id: 'reporting-errors', title: '15. Reporting Errors' },
  { id: 'contact', title: '16. Contact Details' },
];

export default function CalculationMethodologyPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageSeo
        title="Calculation Methodology | SmartMoneyTools"
        description="Learn exactly how SmartMoneyTools builds, tests, and maintains its financial calculators. Full methodology covering UK tax, mortgage, pensions, savings, debt, and self-employed calculations."
        path="/calculation-methodology"
      />

      <section className="bg-primary text-primary-foreground py-12 border-b border-primary/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-5xl">
          <h1 className="text-4xl md:text-5xl font-extrabold mb-4 leading-tight" style={{ letterSpacing: '-0.02em' }}>
            Calculation Methodology
          </h1>
          <p className="text-lg text-primary-foreground/85 max-w-3xl">
            Full transparency on how our financial calculators are built, what data they use, and how we keep them accurate and up to date.
          </p>
        </div>
      </section>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-5xl pt-6 pb-0">
        <Breadcrumb items={[{ label: 'Calculation Methodology' }]} />
      </div>

      <main className="flex-grow py-10 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-5xl">
          <div className="flex flex-col lg:flex-row gap-12 items-start">

            {/* Sidebar TOC */}
            <aside className="hidden lg:block w-72 flex-shrink-0 sticky top-24">
              <div className="border rounded-2xl bg-card p-6 shadow-sm">
                <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-4">Table of Contents</h3>
                <nav className="space-y-0.5">
                  {sections.map((s) => (
                    <a
                      key={s.id}
                      href={`#${s.id}`}
                      className="block py-1.5 px-3 text-sm rounded-lg text-muted-foreground hover:text-primary hover:bg-muted transition-colors"
                    >
                      {s.title}
                    </a>
                  ))}
                </nav>
              </div>
            </aside>

            {/* Main Content */}
            <div className="flex-1 prose prose-slate dark:prose-invert max-w-none prose-headings:scroll-mt-28 prose-headings:font-bold prose-h2:text-2xl prose-h2:border-b prose-h2:pb-3 prose-h2:mb-5 prose-p:leading-relaxed prose-li:leading-relaxed">

              {/* 1 */}
              <div id="overview" className="mb-12">
                <h2>1. Overview</h2>
                <p>
                  This page explains how SmartMoneyTools builds, tests, and maintains its financial calculators. Our goal is complete transparency: we want every user to understand the logic behind our results, the assumptions we make, and the limitations that apply.
                </p>
                <p>
                  SmartMoneyTools provides free financial calculators and educational guides for personal finance topics including UK tax, mortgages, pensions, savings, debt repayment, and self-employment. Our calculators are <strong>educational tools</strong>. All results are estimates produced by applying standard mathematical formulas to the inputs you provide. They are not guarantees of actual financial outcomes and should not be treated as professional financial, tax, or legal advice. See our <Link to="/financial-disclaimer">Financial Disclaimer</Link> for full details.
                </p>
              </div>

              {/* 2 */}
              <div id="principles" className="mb-12">
                <h2>2. Our Calculation Principles</h2>
                <p>We build every calculator with the following principles in mind:</p>
                <ul>
                  <li><strong>Accuracy first.</strong> We base every calculation on current statutory data from official UK and US government sources. We do not invent figures or use estimates where official rates exist.</li>
                  <li><strong>Transparency.</strong> We clearly disclose the assumptions each calculator makes. Where our calculators simplify complex rules, we say so and explain why.</li>
                  <li><strong>Tested with worked examples.</strong> Before publication, every calculator is cross-checked against official worked examples published by HMRC, the FCA, and other authoritative bodies.</li>
                  <li><strong>Regular statutory updates.</strong> Calculators are updated annually following each UK Budget and each US tax year update. Emergency updates are deployed promptly when legislation changes mid-year.</li>
                  <li><strong>Clear disclosure of limitations.</strong> We do not overstate what our calculators can do. Where individual circumstances are too complex to model, we say so and recommend professional advice.</li>
                </ul>
              </div>

              {/* 3 */}
              <div id="data-sources" className="mb-12">
                <h2>3. Data Sources</h2>
                <p>All numerical constants, thresholds, and legislative rules used in our calculators are sourced from authoritative primary sources. We do not rely on secondary or unofficial publications for statutory rates.</p>
                <p>Our primary sources include:</p>
                <ul>
                  <li><strong>GOV.UK</strong> — tax bands, National Insurance thresholds, benefit rates, and government policy.</li>
                  <li><strong>HM Revenue & Customs (HMRC)</strong> — Income Tax, National Insurance, PAYE, and self-assessment rules.</li>
                  <li><strong>Financial Conduct Authority (FCA)</strong> — consumer finance guidance, mortgage rules, and investment regulation.</li>
                  <li><strong>Bank of England (BoE)</strong> — base rate history and inflation data used for contextual guidance.</li>
                  <li><strong>Student Loans Company (SLC)</strong> — repayment thresholds and interest rates for all student loan plans.</li>
                  <li><strong>The Pensions Regulator and MoneyHelper</strong> — auto-enrolment rules, pension contribution guidance, and drawdown assumptions.</li>
                  <li><strong>IRS.gov</strong> — US federal income tax brackets, standard deductions, and retirement contribution limits.</li>
                  <li><strong>SSA.gov (Social Security Administration)</strong> — US Social Security benefit estimates and retirement age rules.</li>
                </ul>
                <p>All source data is reviewed at least annually. We verify sources at each UK Budget (typically March), the start of the US tax year (January), and following any emergency legislative announcements. Where official figures have not yet been confirmed (for example, in the period between a Budget announcement and Royal Assent), we clearly label affected calculators as provisional.</p>
              </div>

              {/* 4 */}
              <div id="uk-tax-salary" className="mb-12">
                <h2>4. UK Tax and Salary Calculations</h2>
                <p>Our UK salary calculators convert gross pay to net take-home pay by applying statutory deductions in the following sequence:</p>
                <ol>
                  <li><strong>Pension contributions</strong> — deducted first if salary sacrifice is selected (reducing the taxable income base).</li>
                  <li><strong>Income Tax</strong> — applied progressively using the current Personal Allowance (standard 1257L tax code) and the Basic (20%), Higher (40%), and Additional (45%) rate bands for England and Wales. Scottish Income Tax uses the six-band Scottish system; Welsh Income Tax applies the Welsh rate.</li>
                  <li><strong>Personal Allowance taper</strong> — the allowance is reduced by £1 for every £2 of income above £100,000, creating an effective 60% marginal rate in the £100,000–£125,140 range.</li>
                  <li><strong>National Insurance (Class 1)</strong> — calculated on weekly or monthly thresholds at the primary rate, with the reduced rate applied above the Upper Earnings Limit. We use Category A rules as the default.</li>
                  <li><strong>Student Loan repayments</strong> — calculated at 9% above the applicable plan threshold (Plan 1, 2, 4, or 5) or 6% above the postgraduate threshold, depending on the plan selected by the user.</li>
                </ol>
                <p>
                  We assume a standard 1257L cumulative tax code unless the user selects otherwise. We do not currently model K codes, BR codes, emergency tax codes, or tax adjustments from previous years. Marriage Allowance and Blind Person's Allowance are not included in baseline calculations.
                </p>
                <p><strong>Sources:</strong> HMRC, GOV.UK, Student Loans Company.</p>
              </div>

              {/* 5 */}
              <div id="mortgage" className="mb-12">
                <h2>5. Mortgage Calculations</h2>
                <p>
                  Our mortgage calculator uses the standard fixed-rate amortization formula to compute the monthly repayment required to reduce the outstanding principal to zero over the specified term while covering compounding monthly interest. The formula applied is:
                </p>
                <p>
                  <code>M = P × [r(1 + r)^n] / [(1 + r)^n − 1]</code>
                </p>
                <p>
                  Where <code>M</code> is the monthly payment, <code>P</code> is the principal, <code>r</code> is the monthly interest rate (annual rate ÷ 12), and <code>n</code> is the total number of monthly payments.
                </p>
                <p>We produce a full amortization table showing the capital and interest split for each payment over the life of the loan. The total interest payable and total cost of borrowing are derived from this table.</p>
                <p>
                  Our calculator does not account for: arrangement fees or broker fees; lender-specific affordability stress tests (typically +3% above the initial rate); early repayment charges; variable rate changes mid-term; mortgage indemnity guarantees; or buildings and contents insurance.
                </p>
                <p><strong>Sources:</strong> FCA, Bank of England base rate guidance, standard amortization formulas.</p>
              </div>

              {/* 6 */}
              <div id="compound-interest" className="mb-12">
                <h2>6. Compound Interest and Savings Calculations</h2>
                <p>
                  Our compound interest and savings calculators use the Future Value of an Annuity formula to project the growth of an initial lump sum plus regular contributions at a given interest rate and compounding frequency:
                </p>
                <p>
                  <code>FV = P(1 + r/n)^(nt) + PMT × [((1 + r/n)^(nt) − 1) / (r/n)]</code>
                </p>
                <p>
                  Where <code>P</code> is the initial principal, <code>r</code> is the annual interest rate, <code>n</code> is the number of compounding periods per year, <code>t</code> is the number of years, and <code>PMT</code> is the regular contribution per period.
                </p>
                <p>
                  We assume contributions are made at the end of each period (ordinary annuity). Where an inflation adjustment is shown, we deflate nominal results using the user-supplied inflation rate to express outcomes in today's purchasing power. Our calculators display gross returns; we do not automatically deduct tax on savings interest, as this depends on each individual's Personal Savings Allowance and ISA usage.
                </p>
                <p><strong>Sources:</strong> Bank of England historical rate data, FCA consumer guidance, standard financial mathematics.</p>
              </div>

              {/* 7 */}
              <div id="pension" className="mb-12">
                <h2>7. Pension Projection Calculations</h2>
                <p>
                  Our pension calculators model Defined Contribution (DC) schemes only. We do not model Defined Benefit (DB) or final salary schemes, as these require scheme-specific actuarial data.
                </p>
                <p>The projection process:</p>
                <ol>
                  <li>The current pot value and annual contributions (employee plus employer) are compounded at the assumed annual growth rate over the years to retirement.</li>
                  <li>Basic rate tax relief (20%) is added to personal contributions where applicable.</li>
                  <li>The projected nominal pot is then deflated by the assumed inflation rate to produce a real-terms (today's money) estimate.</li>
                  <li>A sustainable annual withdrawal income is estimated using the widely cited 4% drawdown rule as a reference point only — users should treat this as illustrative, not prescriptive.</li>
                </ol>
                <p>
                  We do not account for: Lifetime Allowance or Annual Allowance limits (which vary by individual circumstances); drawdown charges or annuity conversion costs; State Pension entitlement; investment fund charges; or pension scheme-specific rules. Growth rates and inflation rates used are user-configurable; our defaults are illustrative only.
                </p>
                <p><strong>Sources:</strong> FCA, The Pensions Regulator, MoneyHelper, Pension Protection Fund guidance.</p>
              </div>

              {/* 8 */}
              <div id="debt-repayment" className="mb-12">
                <h2>8. Debt Repayment Calculations</h2>
                <p>
                  Our debt calculators project payoff timelines by applying minimum payments plus any additional monthly contributions against outstanding balances. Interest accrues monthly based on the annual percentage rate (APR) provided:
                </p>
                <p>
                  <code>Monthly interest = Balance × (APR / 12)</code>
                </p>
                <p>
                  The <strong>Debt Snowball method</strong> prioritises the debt with the smallest balance first, redirecting freed-up payments to the next balance once each debt is cleared. The <strong>Debt Avalanche method</strong> prioritises the debt with the highest interest rate first, minimising total interest paid.
                </p>
                <p>
                  Our calculators assume no new debt is added during the repayment period, interest rates remain static throughout, and minimum payments remain constant. We do not account for: missed payment penalties; balance transfer fees; early settlement charges; or credit score impacts.
                </p>
                <p><strong>Sources:</strong> FCA consumer credit guidance, standard amortization mathematics, lender APR disclosure rules.</p>
              </div>

              {/* 9 */}
              <div id="self-employed" className="mb-12">
                <h2>9. Self-Employed Tax Calculations</h2>
                <p>
                  Our self-employed tax calculator computes the tax and National Insurance payable on trading profits after accounting for allowable business expenses and the Trading Allowance (£1,000 per tax year).
                </p>
                <p>Deductions are applied in the following sequence:</p>
                <ol>
                  <li><strong>Trading Allowance or allowable expenses</strong> — whichever the user selects reduces gross trading income to net profit.</li>
                  <li><strong>Class 4 National Insurance</strong> — charged at 6% on profits between the Lower Profits Limit and Upper Profits Limit, and 2% on profits above the Upper Profits Limit (2026/27 rates).</li>
                  <li><strong>Class 2 National Insurance</strong> — a flat-rate weekly contribution for profits above the Small Profits Threshold; this may be nil where profits are below the threshold or where exemption applies.</li>
                  <li><strong>Income Tax</strong> — calculated on taxable profit (after the Personal Allowance) at the standard progressive rates.</li>
                </ol>
                <p>
                  We also display the VAT registration threshold as a reference point. We do not calculate VAT liability; VAT accounting is complex and scheme-specific. Corporation Tax is referenced in guidance content only — our calculators assume sole trader status, not limited company structures.
                </p>
                <p><strong>Sources:</strong> HMRC, GOV.UK self-assessment guidance.</p>
              </div>

              {/* 10 */}
              <div id="assumptions" className="mb-12">
                <h2>10. Assumptions and Simplifications</h2>
                <p>To make our calculators fast, accessible, and broadly applicable, we apply the following standard assumptions:</p>
                <ul>
                  <li>A standard 1257L cumulative tax code (UK salary calculators).</li>
                  <li>Income is earned evenly across all 12 months (no seasonal variation or one-off bonuses unless explicitly entered).</li>
                  <li>Interest rates, tax thresholds, and allowances remain static throughout the projection period.</li>
                  <li>Contributions are made consistently throughout each year with no gaps.</li>
                  <li>Investment returns are applied at a constant annual rate (no market volatility modelling).</li>
                  <li>Inflation is applied at a constant annual rate.</li>
                  <li>All results are in nominal terms unless an inflation-adjusted view is explicitly selected.</li>
                  <li>UK calculators use England and Wales tax rules unless the user selects Scotland or Wales.</li>
                </ul>
                <p>
                  Where these assumptions do not apply to your situation — for example, if you have a non-standard tax code, receive irregular income, or hold multiple pension pots — our results may differ materially from your actual financial position. We recommend consulting a qualified professional in these cases.
                </p>
              </div>

              {/* 11 */}
              <div id="rounding" className="mb-12">
                <h2>11. Rounding and Displayed Results</h2>
                <p>
                  All monetary results are rounded to the nearest penny (two decimal places) before display. Percentages are displayed to two decimal places. Intermediate calculations use full floating-point precision; rounding is applied only to the final displayed figure.
                </p>
                <p>
                  Rounding can cause minor discrepancies in multi-step calculations — for example, a displayed monthly figure multiplied by 12 may differ by a few pence from the displayed annual figure due to mid-calculation rounding. Over long projection periods (10–40 years), these rounding differences can accumulate into small but visible variances.
                </p>
                <p>
                  Our displayed results are intended to give you an accurate order-of-magnitude estimate. For binding financial decisions, always obtain a precise figure directly from the relevant institution (for example, a formal mortgage offer from your lender, or a P60 from your employer).
                </p>
              </div>

              {/* 12 */}
              <div id="update-schedule" className="mb-12">
                <h2>12. Update Schedule</h2>
                <p>We follow a structured update schedule to keep our calculators aligned with current legislation:</p>
                <ul>
                  <li><strong>Annual UK tax year update (April):</strong> All UK salary, tax, NI, student loan, pension, and self-employment calculators are updated to reflect the new tax year rates and thresholds, typically taking effect from 6 April each year.</li>
                  <li><strong>Post-Budget update (March/Autumn):</strong> Following each UK Autumn Statement and Spring Budget, we review all affected calculators and update provisional figures to confirmed ones.</li>
                  <li><strong>Annual US tax year update (January):</strong> US salary and retirement calculators are updated to reflect new IRS tax brackets, standard deductions, and contribution limits.</li>
                  <li><strong>Quarterly environmental review:</strong> We check default interest rate placeholders (for example, in mortgage and savings calculators) against the current Bank of England base rate environment.</li>
                  <li><strong>Emergency updates:</strong> Deployed immediately in response to mid-year legislative changes (for example, changes to National Insurance rates announced outside of the main Budget cycle).</li>
                </ul>
                <p>
                  Each calculator page displays the tax year or data version it is based on. If you suspect a calculator has not been updated following a recent legislative change, please <Link to="/contact">contact us</Link>.
                </p>
              </div>

              {/* 13 */}
              <div id="testing" className="mb-12">
                <h2>13. Testing and Quality Assurance</h2>
                <p>Before any calculator is published or updated, it passes through the following QA stages:</p>
                <ol>
                  <li><strong>Worked example validation:</strong> Results are compared against published worked examples from HMRC, GOV.UK, and other official sources. The calculator must produce the same output (within rounding tolerance) as the official example.</li>
                  <li><strong>Boundary value testing:</strong> We test inputs at the boundaries of each threshold — for example, income exactly at the Personal Allowance limit, the Higher Rate threshold, and the £100,000 taper point — to verify the correct tax band transitions.</li>
                  <li><strong>Edge case testing:</strong> We test unusual but valid inputs, including zero income, very high income, zero interest rates, and maximum repayment terms.</li>
                  <li><strong>Cross-calculator consistency:</strong> Where the same figure appears in multiple calculators (for example, the National Insurance threshold), we verify that the figure is consistent across all tools.</li>
                  <li><strong>Source verification:</strong> Every statutory rate and threshold is checked against the official primary source (HMRC, GOV.UK, the IRS, or the SSA) before publication, and the page's "Last reviewed" date is updated whenever a material change is made.</li>
                </ol>
                <p>
                  We also compare our outputs against official HMRC tax calculators, the Government's mortgage calculator tools, and MoneyHelper resources periodically as an independent sanity check.
                </p>
              </div>

              {/* 14 */}
              <div id="known-limitations" className="mb-12">
                <h2>14. Known Limitations</h2>
                <p>Our calculators do not currently account for the following factors. Where these apply to your situation, our results may be materially different from your actual position:</p>
                <ul>
                  <li><strong>Non-standard tax codes</strong> — emergency codes (W1/M1), K codes, BR codes, and codes adjusted for previous underpayments.</li>
                  <li><strong>Benefits in kind</strong> — company cars, private medical insurance, and other employer-provided benefits that affect taxable income.</li>
                  <li><strong>Marriage Allowance and Blind Person's Allowance</strong> — not included in baseline salary calculations.</li>
                  <li><strong>Multiple income sources</strong> — second jobs, rental income, dividends, and capital gains are not combined in our salary calculators.</li>
                  <li><strong>Variable rate mortgages</strong> — we model fixed-rate repayments only; tracker and variable rate changes mid-term are not projected.</li>
                  <li><strong>Pension annual allowance and lifetime allowance tapering</strong> — not applied automatically; these depend on individual circumstances.</li>
                  <li><strong>Investment charges and platform fees</strong> — not deducted from savings or pension projections.</li>
                  <li><strong>Regional variations within England</strong> — local authority rates (council tax, business rates) are not modelled.</li>
                  <li><strong>Complex self-employment structures</strong> — limited company directors, partnerships, and IR35 status are outside scope.</li>
                  <li><strong>Changing legislation</strong> — projections extending 20–40 years into the future cannot account for future tax law changes, rate revisions, or policy shifts.</li>
                </ul>
                <p>
                  For complex financial situations, we strongly recommend consulting a qualified financial adviser, accountant, mortgage broker, or pensions specialist. Free guidance is also available from <a href="https://www.moneyhelper.org.uk" target="_blank" rel="noopener noreferrer">MoneyHelper</a> and <a href="https://www.citizensadvice.org.uk" target="_blank" rel="noopener noreferrer">Citizens Advice</a>.
                </p>
              </div>

              {/* 15 */}
              <div id="reporting-errors" className="mb-12">
                <h2>15. Reporting Errors</h2>
                <p>
                  We take calculation accuracy extremely seriously. If you believe you have found an error in one of our calculators — whether a formula bug, an outdated threshold, or a result that does not match official guidance — please report it to us.
                </p>
                <p>To help us investigate efficiently, please provide:</p>
                <ul>
                  <li>The URL of the calculator page where you found the issue.</li>
                  <li>The inputs you entered (for example: gross salary, tax code, pension contribution %).</li>
                  <li>The result our calculator produced.</li>
                  <li>The result you expected, and the source you used to verify it (for example, a link to an HMRC page or your payslip).</li>
                </ul>
                <p>
                  Our team aims to acknowledge all calculation error reports within 48 hours and to investigate and resolve confirmed errors promptly. We document significant corrections as part of our ongoing commitment to transparency.
                </p>
                <p>
                  Report errors via our <Link to="/contact">Contact page</Link> or by emailing <a href="mailto:support@smartmoney-tools.com">support@smartmoney-tools.com</a>. For our full correction process, see our <Link to="/editorial-policy">Editorial Policy</Link>.
                </p>
              </div>

              {/* 16 */}
              <div id="contact" className="mb-12">
                <h2>16. Contact Details</h2>
                <p>For questions about our calculation methodology, to report an error, or to provide feedback:</p>
                <ul>
                  <li><strong>Email:</strong> <a href="mailto:support@smartmoney-tools.com">support@smartmoney-tools.com</a></li>
                  <li><strong>Contact form:</strong> <Link to="/contact">smartmoney-tools.com/contact</Link></li>
                </ul>
                <p>
                  For related policies, see our <Link to="/financial-disclaimer">Financial Disclaimer</Link> and <Link to="/editorial-policy">Editorial Policy</Link>.
                </p>
              </div>

            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
