import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import {
  User,
  Briefcase,
  GraduationCap,
  BookOpen,
  CheckCircle,
  RefreshCw,
  AlertCircle,
  Mail,
  ShieldAlert,
  Linkedin,
} from 'lucide-react';
import PageSeo from '@/components/PageSeo.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';
import { AUTHOR, personSchema } from '@/data/author.js';

export default function AuthorProfilePage() {
  const schema = personSchema();

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <PageSeo
        path={AUTHOR.profilePath}
        type="profile"
      />

      <Helmet>
        <script type="application/ld+json">{JSON.stringify(schema)}</script>
      </Helmet>

      <section className="bg-primary py-16 text-primary-foreground lg:py-20">
        <div className="container mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-2xl bg-primary-foreground/15">
              <User className="h-10 w-10" />
            </div>
            <h1 className="mb-3 text-4xl font-extrabold leading-tight md:text-5xl" style={{ letterSpacing: '-0.02em' }}>
              {AUTHOR.name}
            </h1>
            <p className="text-xl text-primary-foreground/90">{AUTHOR.role}</p>
            <a
              href="https://www.linkedin.com/in/shaun-da-silva-748b91a2/"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 inline-flex items-center gap-2 rounded-lg bg-primary-foreground/15 px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary-foreground/25"
            >
              <Linkedin className="h-4 w-4" /> Connect on LinkedIn
            </a>
          </motion.div>
        </div>
      </section>

      <div className="container mx-auto max-w-4xl px-4 pt-6 sm:px-6 lg:px-8">
        <Breadcrumb items={[{ label: 'Authors', href: '/guides' }, { label: AUTHOR.name }]} />
      </div>

      <main className="flex-grow py-10 lg:py-14">
        <div className="container mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="prose prose-lg prose-slate max-w-none text-muted-foreground prose-headings:text-foreground prose-a:text-primary hover:prose-a:text-primary/80 prose-strong:text-foreground">
            <p className="text-lg leading-relaxed">{AUTHOR.longDescription}</p>

            <h2 className="flex items-center gap-3">
              <Briefcase className="h-7 w-7 text-primary" /> Background
            </h2>
            <ul>
              <li><strong>Role:</strong> {AUTHOR.role}</li>
              <li><strong>Experience:</strong> {AUTHOR.experience}</li>
              <li><strong>Qualification:</strong> {AUTHOR.qualification}</li>
            </ul>
            <p>
              Shaun writes and maintains the calculators and guides on SmartMoneyTools. He is the
              person who researches each topic, checks statutory rates against official government
              publications, and tests calculator outputs against worked examples before a page is
              published or updated.
            </p>

            <h2 className="flex items-center gap-3">
              <BookOpen className="h-7 w-7 text-primary" /> What Shaun does at SmartMoneyTools
            </h2>
            <ul>
              <li><strong>Researches</strong> every calculator and guide against primary sources &mdash; GOV.UK, HMRC, The Pensions Regulator and MoneyHelper for UK content, and the IRS and SSA for US content.</li>
              <li><strong>Checks</strong> statutory rates, thresholds and allowances against those sources and links to them on each page so visitors can verify the figures independently.</li>
              <li><strong>Tests</strong> each calculator with worked examples before publication or after any rate change, so the output matches the expected result.</li>
              <li><strong>Maintains</strong> the tools on a review schedule &mdash; UK calculators each April for the new tax year, US calculators each January for IRS inflation adjustments, and ad-hoc updates when statutory changes are announced.</li>
              <li><strong>Corrects</strong> errors promptly when they are identified, updates the &ldquo;Last updated&rdquo; date, and discloses significant corrections. See the <Link to="/corrections-policy">Corrections Policy</Link>.</li>
            </ul>

            <h2 className="flex items-center gap-3">
              <GraduationCap className="h-7 w-7 text-primary" /> Use of AI-assisted drafting
            </h2>
            <p>
              Shaun uses AI tools to help structure articles and draft calculator code. Every
              AI-assisted draft is reviewed, fact-checked against official sources, and tested by
              Shaun before it is published. No content is published automatically. Full details are
              in the <Link to="/editorial-policy">Editorial Policy</Link>.
            </p>

            <div className="not-prose my-8 flex items-start gap-3 rounded-xl border border-border bg-muted/40 px-5 py-4">
              <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
              <p className="text-sm leading-relaxed text-muted-foreground">
                SmartMoneyTools is an independent educational website. It is <strong className="text-foreground">not authorised or regulated by the Financial Conduct Authority</strong> or any other financial regulatory body, and nothing on this site is regulated financial advice. Shaun does not hold a regulated financial-advice qualification, and the calculators and guides are provided for educational and informational purposes only.
              </p>
            </div>

            <h2 className="flex items-center gap-3">
              <Mail className="h-7 w-7 text-primary" /> Contact
            </h2>
            <p>
              To report an error, suggest a correction, or send feedback, email{' '}
              <a href="mailto:support@smartmoney-tools.com">support@smartmoney-tools.com</a> or use
              the <Link to="/contact">contact form</Link>.
            </p>
            <p>
              You can also connect with Shaun on{' '}
              <a href="https://www.linkedin.com/in/shaun-da-silva-748b91a2/" target="_blank" rel="noopener noreferrer">LinkedIn</a>.
            </p>
          </div>

          <div className="mt-12 flex flex-wrap gap-3 border-t border-border pt-8 not-prose">
            <Link to="/guides" className="inline-flex items-center gap-2 rounded-lg bg-muted px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted/80">
              <BookOpen className="h-4 w-4" /> Browse the guides
            </Link>
            <Link to="/editorial-policy" className="inline-flex items-center gap-2 rounded-lg bg-muted px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted/80">
              <CheckCircle className="h-4 w-4" /> Editorial Policy
            </Link>
            <Link to="/corrections-policy" className="inline-flex items-center gap-2 rounded-lg bg-muted px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted/80">
              <AlertCircle className="h-4 w-4" /> Corrections Policy
            </Link>
            <Link to="/calculation-methodology" className="inline-flex items-center gap-2 rounded-lg bg-muted px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted/80">
              <RefreshCw className="h-4 w-4" /> Calculation Methodology
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}
