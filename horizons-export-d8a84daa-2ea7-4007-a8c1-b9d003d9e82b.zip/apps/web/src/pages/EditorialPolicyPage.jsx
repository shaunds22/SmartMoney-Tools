import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { setPageMeta } from '@/utils/seo.js';
import { Target, User, CheckCircle, Bot, Search, RefreshCw, AlertTriangle, ShieldCheck, Scale, Mail } from 'lucide-react';

export default function EditorialPolicyPage() {
  useEffect(() => {
    setPageMeta(
      'Editorial Policy | SmartMoneyTools',
      'Read the SmartMoneyTools Editorial Policy to learn about our commitment to accuracy, human review, fact-checking, and editorial independence.',
      'https://smartmoney-tools.com/editorial-policy'
    );
  }, []);

  const sections = [
    { id: 'our-mission', title: '1. Our Mission', icon: <Target className="w-5 h-5" /> },
    { id: 'who-creates-content', title: '2. Who Creates Our Content', icon: <User className="w-5 h-5" /> },
    { id: 'human-review', title: '3. Review & Quality Checks', icon: <CheckCircle className="w-5 h-5" /> },
    { id: 'ai-assisted-drafting', title: '4. Use of AI-Assisted Drafting', icon: <Bot className="w-5 h-5" /> },
    { id: 'sources-fact-checking', title: '5. Sources & Fact-Checking', icon: <Search className="w-5 h-5" /> },
    { id: 'update-policy', title: '6. Update Policy', icon: <RefreshCw className="w-5 h-5" /> },
    { id: 'corrections-policy', title: '7. Corrections Policy', icon: <AlertTriangle className="w-5 h-5" /> },
    { id: 'independence-advertising', title: '8. Independence & Advertising', icon: <ShieldCheck className="w-5 h-5" /> },
    { id: 'financial-disclaimer', title: '9. Financial Advice Disclaimer', icon: <Scale className="w-5 h-5" /> },
    { id: 'contact-details', title: '10. Contact Details', icon: <Mail className="w-5 h-5" /> },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-primary text-primary-foreground py-16 lg:py-24">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="max-w-4xl mx-auto text-center"
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 leading-tight text-balance" style={{ letterSpacing: '-0.02em' }}>
                Editorial Policy
              </h1>
              <p className="text-xl md:text-2xl text-primary-foreground/90 leading-relaxed max-w-3xl mx-auto font-medium">
                Our commitment to accuracy, transparency, and editorial independence in everything we publish.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Content Section with Sidebar TOC */}
        <section className="py-12 lg:py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
            <div className="flex flex-col lg:flex-row gap-12 items-start">

              {/* Sidebar TOC - Sticky on Desktop */}
              <aside className="w-full lg:w-1/4 lg:sticky lg:top-24 hidden lg:block border rounded-2xl bg-card p-6 shadow-sm">
                <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-6">Table of Contents</h3>
                <nav className="space-y-1">
                  {sections.map((section) => (
                    <a
                      key={section.id}
                      href={`#${section.id}`}
                      className="flex items-center gap-3 py-2.5 px-3 text-sm font-medium rounded-lg text-foreground hover:bg-muted hover:text-primary transition-colors"
                    >
                      <span className="text-muted-foreground">{section.icon}</span>
                      {section.title}
                    </a>
                  ))}
                </nav>
              </aside>

              {/* Main Content */}
              <div className="w-full lg:w-3/4 prose prose-slate dark:prose-invert max-w-none prose-headings:scroll-mt-28 prose-headings:font-bold prose-h2:text-3xl prose-h2:border-b prose-h2:pb-4 prose-h2:mb-6 prose-p:leading-relaxed prose-li:leading-relaxed">

                <div id="our-mission" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <Target className="w-8 h-8 text-primary" />
                    1. Our Mission
                  </h2>
                  <p>
                    SmartMoneyTools exists to help people make better-informed everyday financial decisions by providing free, accurate, browser-based calculators and clear, jargon-free educational guides. We believe robust financial mathematics should not be locked behind paywalls or obscured by complex terminology.
                  </p>
                  <p>
                    We publish our underlying methodologies openly, link to the official sources behind every statutory figure, and keep the tools maintained as tax rules and allowances change. We remain independent: no advertiser, sponsor, or partner influences the calculators we build, the formulas we use, or the guides we publish.
                  </p>
                </div>

                <div id="who-creates-content" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <User className="w-8 h-8 text-primary" />
                    2. Who Creates Our Content
                  </h2>
                  <p>
                    Every calculator and guide on SmartMoneyTools is written and maintained by{' '}
                    <Link to="/author/shaun-da-silva" className="text-primary hover:underline font-medium">Shaun Da Silva</Link>, a Financial Consultant with over 20 years&rsquo; experience in the financial sector and a BTech in Information Systems. Shaun researches each topic, checks the statutory figures, writes the content, and tests the calculators.
                  </p>
                  <p>
                    This is a small, single-author operation rather than a large editorial desk. We state this plainly because trust depends on knowing who is behind the numbers. Shaun monitors updates from HM Revenue &amp; Customs (HMRC), GOV.UK, The Pensions Regulator, the Internal Revenue Service (IRS), and the Social Security Administration (SSA) so that statutory changes are reflected promptly.
                  </p>
                  <p>
                    SmartMoneyTools is <strong>not authorised or regulated by the Financial Conduct Authority (FCA)</strong> or any other financial regulatory body, and the content is not regulated financial advice. See section 9 and our <Link to="/financial-disclaimer" className="text-primary hover:underline">Financial Disclaimer</Link>.
                  </p>
                </div>

                <div id="human-review" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <CheckCircle className="w-8 h-8 text-primary" />
                    3. Review and Quality Checks
                  </h2>
                  <p>
                    Before any calculator or guide is published or updated, Shaun reviews it. The review checks that every statutory rate, threshold, and allowance matches an official primary source, and that the surrounding text describes the rule accurately and in plain English.
                  </p>
                  <p>
                    For interactive calculators, the calculation logic is tested against known worked examples &mdash; either examples published by HMRC, GOV.UK, or the IRS, or manually calculated examples verified against the primary source. A rate change is not published until the calculator output matches the expected result for at least three test cases across different income levels.
                  </p>
                  <p>
                    A &ldquo;Last reviewed&rdquo; or &ldquo;Last updated&rdquo; date is shown on each page and is refreshed whenever a material change is made. We do not label a page as independently &ldquo;reviewed by&rdquo; a second person unless a genuine, page-specific review has taken place; where no such review record exists, no reviewer byline is shown.
                  </p>
                </div>

                <div id="ai-assisted-drafting" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <Bot className="w-8 h-8 text-primary" />
                    4. Use of AI-Assisted Drafting
                  </h2>
                  <p>
                    In the interest of transparency: Shaun uses AI tools to help structure articles, draft calculator code, and summarise dense regulatory text. This speeds up the drafting stage.
                  </p>
                  <p>
                    AI can hallucinate figures and produce outdated or inaccurate financial data, so our policy is absolute: <strong>no content is published without human review.</strong> Every AI-assisted draft is fact-checked against official sources, tested where it involves calculations, and edited by Shaun before publication. AI is an assistant, not the author of record &mdash; the byline on every guide names Shaun Da Silva.
                  </p>
                </div>

                <div id="sources-fact-checking" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <Search className="w-8 h-8 text-primary" />
                    5. Sources and Fact-Checking Standards
                  </h2>
                  <p>
                    We rely on authoritative primary sources for statutory data and legislative rules. For UK content these include GOV.UK, HM Revenue &amp; Customs (HMRC), The Pensions Regulator, and MoneyHelper. For US content these include the Internal Revenue Service (IRS) and the Social Security Administration (SSA).
                  </p>
                  <p>
                    When sources conflict (for example, a news summary versus an official HMRC document), the primary government publication always takes precedence. Wherever feasible we link directly to the official source so users can verify the information themselves. Source tables with direct links appear on each calculator page.
                  </p>
                  <p>
                    We periodically re-check existing content to confirm links remain active and figures remain aligned with the latest statutory guidance. Any deviation discovered triggers our correction procedure.
                  </p>
                </div>

                <div id="update-policy" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <RefreshCw className="w-8 h-8 text-primary" />
                    6. Update Policy
                  </h2>
                  <p>
                    Financial information decays, so we maintain a structured update schedule:
                  </p>
                  <ul>
                    <li><strong>Annually (April):</strong> UK calculators are reviewed and updated for the new tax year (6 April) &mdash; income tax bands, National Insurance thresholds, student loan repayment thresholds, pension annual allowance, and auto-enrolment qualifying earnings bands.</li>
                    <li><strong>Annually (January):</strong> US calculators are reviewed for IRS inflation adjustments to standard deductions, tax brackets, FICA wage bases, and retirement contribution limits.</li>
                    <li><strong>Ad-hoc:</strong> When emergency changes are announced (for example, a mid-year National Insurance rate cut or an IRS correction), the affected calculator is updated as promptly as possible &mdash; typically within 24&ndash;48 hours of the official announcement.</li>
                    <li><strong>Ongoing:</strong> User-reported errors are investigated and corrected under our <Link to="/corrections-policy" className="text-primary hover:underline">Corrections Policy</Link>.</li>
                  </ul>
                  <p>
                    When a calculator or guide receives a significant update, the &ldquo;Last reviewed&rdquo; or &ldquo;Last updated&rdquo; date on that page is refreshed so visitors can see how current the content is.
                  </p>
                </div>

                <div id="corrections-policy" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <AlertTriangle className="w-8 h-8 text-primary" />
                    7. Corrections Policy
                  </h2>
                  <p>
                    Despite careful checking, errors can occur. When they do, we act quickly. We encourage users to tell us if they spot a discrepancy in a calculation or a factual error in a guide.
                  </p>
                  <p>
                    On receiving a report, Shaun acknowledges it and investigates within 2 business days, verifying the claim against primary sources and re-running the calculator with the reported inputs. If an error is confirmed, it is corrected promptly, the revision date is updated, and &mdash; where the error was significant &mdash; a correction note is added near the affected content. We do not silently delete or backdate material errors. Full timelines and disclosure procedures are in our <Link to="/corrections-policy" className="text-primary hover:underline">Corrections Policy</Link>.
                  </p>
                </div>

                <div id="independence-advertising" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <ShieldCheck className="w-8 h-8 text-primary" />
                    8. Independence and Advertising Policy
                  </h2>
                  <p>
                    SmartMoneyTools operates with editorial independence. There is a strict separation between editorial content and advertising. No advertiser, sponsor, or partner influences the calculators we build, the formulas we use, or the guides we publish.
                  </p>
                  <p>
                    The site is funded through display advertising served by Google AdSense. Advertisers have no input into calculator formulas, methodology, editorial conclusions, or coverage decisions, and no editorial content has ever been written, modified, or removed at an advertiser&rsquo;s request. If affiliate links are introduced in future, they will be clearly disclosed near each relevant link. See our <Link to="/advertising-disclosure" className="text-primary hover:underline">Advertising Disclosure</Link> for full details.
                  </p>
                </div>

                <div id="financial-disclaimer" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <Scale className="w-8 h-8 text-primary" />
                    9. Financial Advice Disclaimer
                  </h2>
                  <p>
                    <strong>SmartMoneyTools does not provide financial advice.</strong> All content, calculators, and guides are provided strictly for educational and informational purposes. We are not regulated by the Financial Conduct Authority (FCA) to provide personalised advice, and nothing on this site is regulated financial advice.
                  </p>
                  <p>
                    Calculator outputs are estimates based on standardised mathematical formulas; they are not guarantees of future performance or exact tax liabilities. Individual circumstances vary because of complex tax codes, personal arrangements, and market conditions. We urge every user to consult a qualified, FCA-regulated financial adviser, accountant, or legal professional before making significant financial decisions. See our <Link to="/financial-disclaimer" className="text-primary hover:underline">Financial Disclaimer</Link>.
                  </p>
                </div>

                <div id="contact-details" className="mb-8">
                  <h2 className="flex items-center gap-3">
                    <Mail className="w-8 h-8 text-primary" />
                    10. Contact Details for Corrections or Feedback
                  </h2>
                  <p>
                    We welcome your input. Whether you have spotted a typo, suspect a calculation error, or wish to suggest a new feature, please reach out.
                  </p>
                  <ul>
                    <li><strong>Email for Corrections &amp; Feedback:</strong> <a href="mailto:support@smartmoney-tools.com" className="text-primary hover:underline">support@smartmoney-tools.com</a></li>
                    <li><strong>Contact Form:</strong> Use our <Link to="/contact" className="text-primary hover:underline">Contact Page</Link> &mdash; select &ldquo;Calculation Issue / Bug Report&rdquo;.</li>
                    <li><strong>Corrections Policy:</strong> See our full <Link to="/corrections-policy" className="text-primary hover:underline">Corrections Policy</Link> for timelines and investigation procedures.</li>
                  </ul>
                  <p>
                    When reporting an error, please include the specific inputs you used and the URL of the page. We aim to acknowledge all reports within 2 business days. For details on how we handle your data when you contact us, see our <Link to="/privacy" className="text-primary hover:underline">Privacy Policy</Link>.
                  </p>
                </div>

              </div>
            </div>
          </div>
        </section>
      </main>

    </div>
  );
}
