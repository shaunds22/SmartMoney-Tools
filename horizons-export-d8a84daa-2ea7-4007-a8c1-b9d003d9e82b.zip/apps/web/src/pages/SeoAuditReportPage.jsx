/**
 * INTERNAL ADMIN PAGE — NOT publicly linked from navigation or sitemap.
 * Access by navigating directly to /seo-audit-report
 * Contains the SEO, redirect, canonical, and indexability audit for SmartMoneyTools.com
 */
import React from 'react';
import { Helmet } from 'react-helmet';

const LAST_UPDATED = '2026-09-29';
const BASE = 'https://smartmoney-tools.com';

const pages = [
  { path: '/', title: 'Homepage', canonical: `${BASE}/`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/uk-salary-calculator', title: 'UK Salary Calculator', canonical: `${BASE}/uk-salary-calculator`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/us-salary-calculator', title: 'US Salary Calculator', canonical: `${BASE}/us-salary-calculator`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/us-retirement-calculator', title: 'US Retirement Calculator', canonical: `${BASE}/us-retirement-calculator`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/compound-interest', title: 'Compound Interest Calculator', canonical: `${BASE}/compound-interest`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/mortgage', title: 'Mortgage Calculator', canonical: `${BASE}/mortgage`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/pensions-calculator', title: 'Pensions Calculator', canonical: `${BASE}/pensions-calculator`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/budget-planner', title: 'Budget Planner', canonical: `${BASE}/budget-planner`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/self-employed-tax-calculator', title: 'Self-Employed Tax Calculator', canonical: `${BASE}/self-employed-tax-calculator`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/debt-snowball-calculator', title: 'Debt Snowball Calculator', canonical: `${BASE}/debt-snowball-calculator`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/savings-goal-calculator', title: 'Savings Goal Calculator', canonical: `${BASE}/savings-goal-calculator`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/about', title: 'About', canonical: `${BASE}/about`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/contact', title: 'Contact', canonical: `${BASE}/contact`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/faq', title: 'FAQ', canonical: `${BASE}/faq`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/privacy', title: 'Privacy Policy', canonical: `${BASE}/privacy`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/terms', title: 'Terms of Use', canonical: `${BASE}/terms`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/financial-disclaimer', title: 'Financial Disclaimer', canonical: `${BASE}/financial-disclaimer`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/cookie-policy', title: 'Cookie Policy', canonical: `${BASE}/cookie-policy`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/editorial-policy', title: 'Editorial Policy', canonical: `${BASE}/editorial-policy`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/calculation-methodology', title: 'Calculation Methodology', canonical: `${BASE}/calculation-methodology`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/corrections-policy', title: 'Corrections Policy', canonical: `${BASE}/corrections-policy`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/advertising-disclosure', title: 'Advertising Disclosure', canonical: `${BASE}/advertising-disclosure`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/accessibility', title: 'Accessibility Statement', canonical: `${BASE}/accessibility`, inSitemap: true, httpStatus: 200, indexed: true },
  { path: '/guides', title: 'Guides Index', canonical: `${BASE}/guides`, inSitemap: true, httpStatus: 200, indexed: true },
];

const redirects = [
  { from: 'http://smartmoney-tools.com/*', to: 'https://smartmoney-tools.com/*', type: 301, status: 'ACTIVE — hosting platform HTTPS redirect (verified live)' },
  { from: 'http://www.smartmoney-tools.com/*', to: 'https://smartmoney-tools.com/*', type: 301, status: 'ACTIVE — generated dist .htaccess (tools/prerender.js, wired into npm build)' },
  { from: 'https://www.smartmoney-tools.com/*', to: 'https://smartmoney-tools.com/*', type: 301, status: 'ACTIVE — generated dist .htaccess (tools/prerender.js, wired into npm build)' },
  { from: '/*/', to: '/*', type: 301, status: 'ACTIVE — generated dist .htaccess trailing-slash redirect (query strings preserved)' },
  { from: '/methodology', to: '/calculation-methodology', type: 301, status: 'ACTIVE — 301 in generated dist .htaccess + React Router Navigate fallback' },
  { from: '/disclaimer', to: '/financial-disclaimer', type: 301, status: 'ACTIVE — 301 in generated dist .htaccess + React Router Navigate fallback' },
];

export default function SeoAuditReportPage() {
  return (
    <div className="min-h-screen bg-background p-8">
      <Helmet>
        <title>SEO Audit Report (Internal) | SmartMoneyTools</title>
        <meta name="robots" content="noindex, nofollow" />
      </Helmet>

      <div className="max-w-7xl mx-auto">
        <div className="mb-8 p-4 bg-amber-50 border border-amber-200 rounded-xl">
          <p className="text-amber-800 font-semibold">INTERNAL ADMIN PAGE — Not indexed, not publicly linked</p>
          <p className="text-amber-700 text-sm mt-1">Last updated: {LAST_UPDATED}</p>
        </div>

        <h1 className="text-3xl font-bold mb-2">SEO Audit Report</h1>
        <p className="text-muted-foreground mb-8">Canonical URL, indexability, and sitemap audit for smartmoney-tools.com</p>

        {/* Redirect Status */}
        <section className="mb-10">
          <h2 className="text-xl font-bold mb-4 border-b pb-2">1. Redirect Configuration</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-muted">
                  <th className="text-left p-3 border">From</th>
                  <th className="text-left p-3 border">To</th>
                  <th className="text-left p-3 border">Type</th>
                  <th className="text-left p-3 border">Status</th>
                </tr>
              </thead>
              <tbody>
                {redirects.map((r, i) => (
                  <tr key={i} className={r.status.startsWith('PENDING') ? 'bg-red-50' : 'bg-green-50'}>
                    <td className="p-3 border font-mono text-xs">{r.from}</td>
                    <td className="p-3 border font-mono text-xs">{r.to}</td>
                    <td className="p-3 border">{r.type}</td>
                    <td className="p-3 border text-xs">{r.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
            <h3 className="font-bold text-red-800 mb-2">Action Required: HTTP/www Redirects</h3>
            <p className="text-red-700 text-sm mb-3">
              The <code className="bg-red-100 px-1 rounded">public/.htaccess</code> file is read-only in this environment.
              The following redirect rules must be added manually via Hostinger's File Manager or hPanel:
            </p>
            <pre className="bg-white border border-red-200 rounded p-3 text-xs overflow-x-auto">{`# Add to public/.htaccess BEFORE existing RewriteRules

RewriteEngine On

# HTTP to HTTPS redirect (all domains)
RewriteCond %{HTTPS} off
RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# www to non-www redirect (HTTPS)
RewriteCond %{HTTP_HOST} ^www\\.smartmoney-tools\\.com [NC]
RewriteRule ^ https://smartmoney-tools.com%{REQUEST_URI} [L,R=301]`}</pre>
          </div>
        </section>

        {/* Page Audit Table */}
        <section className="mb-10">
          <h2 className="text-xl font-bold mb-4 border-b pb-2">2. Page Canonical & Indexability Audit</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-muted">
                  <th className="text-left p-3 border">Page</th>
                  <th className="text-left p-3 border">Path</th>
                  <th className="text-left p-3 border">HTTP Status</th>
                  <th className="text-left p-3 border">Canonical URL</th>
                  <th className="text-left p-3 border">In Sitemap</th>
                  <th className="text-left p-3 border">Indexed</th>
                </tr>
              </thead>
              <tbody>
                {pages.map((p, i) => (
                  <tr key={i} className={i % 2 === 0 ? '' : 'bg-muted/30'}>
                    <td className="p-3 border font-medium">{p.title}</td>
                    <td className="p-3 border font-mono text-xs">{p.path}</td>
                    <td className="p-3 border">
                      <span className="inline-block px-2 py-0.5 rounded-full bg-green-100 text-green-800 text-xs font-medium">{p.httpStatus}</span>
                    </td>
                    <td className="p-3 border font-mono text-xs">{p.canonical}</td>
                    <td className="p-3 border">
                      <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${p.inSitemap ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                        {p.inSitemap ? 'Yes' : 'No'}
                      </span>
                    </td>
                    <td className="p-3 border">
                      <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${p.indexed ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
                        {p.indexed ? 'Yes' : 'Excluded'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* GSC Instructions */}
        <section className="mb-10">
          <h2 className="text-xl font-bold mb-4 border-b pb-2">3. Google Search Console Configuration</h2>
          <div className="space-y-4 text-sm">
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h3 className="font-bold mb-2">Domain Property Setup</h3>
              <p className="mb-2">In Google Search Console, add a <strong>Domain property</strong> (not URL-prefix):</p>
              <ul className="list-disc pl-5 space-y-1">
                <li>Go to <a href="https://search.google.com/search-console" target="_blank" rel="noopener noreferrer" className="text-blue-700 underline">search.google.com/search-console</a></li>
                <li>Click <strong>"Add property"</strong></li>
                <li>Select <strong>"Domain"</strong> tab</li>
                <li>Enter: <code className="bg-blue-100 px-1 rounded font-mono">smartmoney-tools.com</code> (no https://, no www, no trailing slash)</li>
                <li>Click <strong>Continue</strong></li>
                <li>Google will display a <strong>TXT record</strong> to add to your DNS</li>
              </ul>
            </div>

            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h3 className="font-bold mb-2">Adding the DNS TXT Record (Hostinger)</h3>
              <ol className="list-decimal pl-5 space-y-1">
                <li>Log in to <strong>Hostinger hPanel</strong></li>
                <li>Navigate to <strong>Domains → DNS / Name Servers → DNS Zone Editor</strong></li>
                <li>Click <strong>Add New Record</strong></li>
                <li>Set <strong>Type</strong> to <code className="bg-blue-100 px-1 rounded">TXT</code></li>
                <li>Set <strong>Name/Host</strong> to <code className="bg-blue-100 px-1 rounded">@</code> (root domain)</li>
                <li>Paste the verification string from Google Search Console into the <strong>Value/Content</strong> field</li>
                <li>Set <strong>TTL</strong> to <code className="bg-blue-100 px-1 rounded">3600</code> (or leave as default)</li>
                <li>Click <strong>Save</strong></li>
                <li>Return to Google Search Console and click <strong>Verify</strong> (DNS propagation can take up to 48 hours)</li>
              </ol>
            </div>
          </div>
        </section>

        {/* SEO Implementation Summary */}
        <section className="mb-10">
          <h2 className="text-xl font-bold mb-4 border-b pb-2">4. SEO Implementation Summary</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            {[
              { item: 'Canonical tags — all Helmet-based pages', status: 'COMPLETE', note: 'AboutPage, PrivacyPage, TermsPage, FinancialDisclaimer, CalculationMethodology, FAQPage, CookiePolicy, CorrectionsPolicy, AdvertisingDisclosure, AccessibilityStatement' },
              { item: 'Canonical tags — calculator/tool pages', status: 'COMPLETE', note: 'Set via setPageMeta() with canonical param on all 11 calculator pages' },
              { item: 'Open Graph tags — index.html defaults', status: 'COMPLETE', note: 'Default og:title, og:description, og:url, og:image, og:type, og:site_name added' },
              { item: 'Open Graph tags — per-page (setPageMeta pages)', status: 'COMPLETE', note: 'setPageMeta() now injects OG + Twitter tags dynamically for all calculator pages' },
              { item: 'Open Graph tags — Helmet pages', status: 'COMPLETE', note: 'PageSeo component renders full OG + Twitter + canonical via react-helmet' },
              { item: 'Twitter Card tags', status: 'COMPLETE', note: 'summary_large_image on all pages via setPageMeta + PageSeo' },
              { item: 'Structured data — WebSite schema', status: 'COMPLETE', note: 'In index.html and injected via addWebSiteSchema()' },
              { item: 'Structured data — Organization schema', status: 'COMPLETE', note: 'In index.html and injected via addOrganizationSchema()' },
              { item: 'Structured data — WebApplication schema', status: 'COMPLETE', note: 'Injected per calculator page via addWebApplicationSchema()' },
              { item: 'XML Sitemap — correct HTTPS non-www URLs', status: 'COMPLETE', note: 'sitemap.xml at /sitemap.xml uses https://smartmoney-tools.com/ format throughout' },
              { item: 'robots.txt — sitemap declaration', status: 'COMPLETE', note: 'Sitemap: https://smartmoney-tools.com/sitemap.xml present in robots.txt' },
              { item: 'HTTP → HTTPS redirect', status: 'PENDING', note: 'Requires .htaccess edit — file is read-only. See redirect rules above.' },
              { item: 'www → non-www redirect', status: 'PENDING', note: 'Requires .htaccess edit — file is read-only. See redirect rules above.' },
              { item: 'Internal links — React Router relative paths', status: 'COMPLETE', note: 'All internal links use React Router <Link to="/path"> which resolve to the correct domain' },
            ].map((row, i) => (
              <div key={i} className={`p-3 rounded-lg border text-sm ${row.status === 'COMPLETE' ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium">{row.item}</span>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${row.status === 'COMPLETE' ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800'}`}>{row.status}</span>
                </div>
                <p className="text-xs text-muted-foreground">{row.note}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
