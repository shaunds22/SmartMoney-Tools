import React from 'react';
import PageSeo from '@/components/PageSeo.jsx';
import { motion } from 'framer-motion';
import FAQAccordion from '@/components/FAQAccordion.jsx';

function FAQPage() {
  const generalFaqs = [
    {
      question: 'Are the calculators on SmartMoneyTools really free?',
      answer: 'Yes. We will never charge a subscription fee, gate features behind a paywall, or force you to hand over your email address to view a calculation. SmartMoneyTools is free to use and may be funded by advertising. Advertisers have no influence over our calculator formulas, methodology or editorial content.'
    },
    {
      question: 'Is my financial data kept private?',
      answer: 'Absolutely. We architected SmartMoneyTools to perform all mathematical operations client-side (directly in your web browser). We do not send your salaries, loan balances, or savings goals to our servers.'
    },
    {
      question: 'How accurate are the results?',
      answer: 'We utilize standard algorithms accepted by the financial industry. However, they are mathematically "perfect" estimates that cannot account for real-world nuances like sudden tax hikes or variable rate adjustments. Always use them as a planning baseline, not a guarantee.'
    }
  ];

  const compoundInterestFaqs = [
    {
      question: 'What exactly is compound interest?',
      answer: 'Compound interest means you earn interest on your original deposit, plus you earn interest on the interest that has already accumulated. It causes your balance to grow exponentially rather than linearly.'
    },
    {
      question: 'Why does the frequency of compounding matter?',
      answer: 'If interest compounds daily, yesterday\'s interest starts earning new interest today. Over short periods, it\'s negligible, but over 30 years, daily compounding significantly outpaces annual compounding.'
    },
    {
      question: 'What is a safe estimated return rate for the stock market?',
      answer: 'While past performance is no guarantee of future results, the S&P 500 has historically returned an average of about 10% per year before inflation (or 7% adjusted for inflation) over long multi-decade periods.'
    }
  ];

  const mortgageFaqs = [
    {
      question: 'What is the difference between a repayment and an interest-only mortgage?',
      answer: 'On a repayment mortgage, each monthly payment covers interest and a slice of the capital, so the loan is fully cleared by the end of the term. On an interest-only mortgage, each monthly payment covers only the interest, and the original loan must be repaid in full at the end — usually from a separate savings or investment plan.'
    },
    {
      question: 'What is loan-to-value (LTV)?',
      answer: 'LTV is the mortgage amount expressed as a percentage of the property value. A £180,000 mortgage on a £200,000 property is 90% LTV. A lower LTV (a bigger deposit) generally unlocks cheaper mortgage rates.'
    },
    {
      question: 'How do extra payments affect my mortgage?',
      answer: 'Because repayment mortgages are heavily front-loaded with interest, making extra capital payments early in the loan prevents that capital from generating interest for the rest of the term. Even small extra payments can shave years off your timeline. Most UK lenders allow overpayments of up to 10% of the balance per year penalty-free.'
    }
  ];

  return (
    <>
      <PageSeo
        title="Frequently Asked Questions | SmartMoneyTools"
        description="Find comprehensive answers about our free financial calculators, compound interest and mortgage formulas, accuracy standards and privacy practices."
        path="/faq"
      />

      <div className="flex flex-col w-full">
        <section className="bg-primary text-primary-foreground py-16">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="max-w-4xl mx-auto text-center"
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight" style={{ letterSpacing: '-0.02em' }}>
                Frequently Asked Questions
              </h1>
              <p className="text-xl text-primary-foreground/90 leading-relaxed max-w-3xl mx-auto">
                Answers to common questions regarding our methodologies, tools, and privacy standards.
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-20 bg-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
              
              <div className="lg:col-span-2 space-y-16">
                
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  viewport={{ once: true }}
                >
                  <h2 className="text-3xl md:text-4xl font-semibold text-foreground mb-8">
                    Site & Privacy
                  </h2>
                  <FAQAccordion faqItems={generalFaqs} />
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  viewport={{ once: true }}
                >
                  <h2 className="text-3xl md:text-4xl font-semibold text-foreground mb-8">
                    Compound Interest
                  </h2>
                  <FAQAccordion faqItems={compoundInterestFaqs} />
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  viewport={{ once: true }}
                >
                  <h2 className="text-3xl md:text-4xl font-semibold text-foreground mb-8">
                    Mortgages & Housing
                  </h2>
                  <FAQAccordion faqItems={mortgageFaqs} />
                </motion.div>

                {/* Help / Contact Section */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  viewport={{ once: true }}
                  className="mt-12 bg-muted/50 p-8 rounded-xl border border-border text-center"
                >
                  <h3 className="text-xl font-bold text-foreground mb-3">Still have questions?</h3>
                  <p className="text-muted-foreground">
                    Our support team is here to help. Reach out to us anytime at{' '}
                    <a href="mailto:support@smartmoney-tools.com" className="text-primary hover:underline font-medium">
                      support@smartmoney-tools.com
                    </a>.
                  </p>
                </motion.div>
              </div>

            </div>
          </div>
        </section>
      </div>
    </>
  );
}

export default FAQPage;