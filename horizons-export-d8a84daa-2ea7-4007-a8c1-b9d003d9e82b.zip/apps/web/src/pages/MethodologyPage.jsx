import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { setPageMeta } from '@/utils/seo.js';
import { BookOpen, FileText, CheckCircle, ShieldAlert, GitMerge, Calculator, Scale, AlertTriangle, MessageSquare } from 'lucide-react';

export default function MethodologyPage() {
  useEffect(() => {
    setPageMeta(
      'Calculation Methodology | SmartMoneyTools',
      'Learn exactly how SmartMoneyTools calculates estimates for mortgages, salary, pensions, savings, and debt using UK financial rules and standard formulas.',
      'https://smartmoney-tools.com/methodology'
    );
  }, []);

  const sections = [
    { id: 'approach', title: '1. Our Calculation Approach', icon: <Calculator className="w-5 h-5" /> },
    { id: 'tax-years', title: '2. UK Tax Year Assumptions', icon: <FileText className="w-5 h-5" /> },
    { id: 'methodologies', title: '3. Specific Methodologies', icon: <GitMerge className="w-5 h-5" /> },
    { id: 'data-sources', title: '4. Data Sources', icon: <CheckCircle className="w-5 h-5" /> },
    { id: 'updates', title: '5. Update Frequency', icon: <BookOpen className="w-5 h-5" /> },
    { id: 'limitations', title: '6. Accuracy Limitations', icon: <ShieldAlert className="w-5 h-5" /> },
    { id: 'differences', title: '7. Why Results May Differ', icon: <Scale className="w-5 h-5" /> },
    { id: 'feedback', title: '8. Corrections & Feedback', icon: <MessageSquare className="w-5 h-5" /> },
    { id: 'disclaimer', title: '9. Financial Disclaimer', icon: <AlertTriangle className="w-5 h-5" /> },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-primary text-primary-foreground py-16 lg:py-24">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="max-w-4xl mx-auto text-center"
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 leading-tight text-balance" style={{ letterSpacing: '-0.02em' }}>
                Calculation Methodology
              </h1>
              <p className="text-xl md:text-2xl text-primary-foreground/90 leading-relaxed max-w-3xl mx-auto font-medium">
                Transparency is at the core of what we do. Read exactly how our calculators process your data, the formulas we use, and the assumptions we make.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Content Section with Sidebar TOC */}
        <section className="py-12 lg:py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
            <div className="flex flex-col lg:flex-row gap-12 items-start">
              
              {/* Sidebar TOC - Sticky on Desktop */}
              <aside className="w-full lg:w-1/4 lg:sticky lg:top-24 hidden lg:block border rounded-2xl bg-card p-6 shadow-sm">
                <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-6">Table of Contents</h3>
                <nav className="space-y-1">
                  {sections.map((section) => (
                    <a
                      key={section.id}
                      href={`#${section.id}`}
                      className="flex items-center gap-3 py-2.5 px-3 text-sm font-medium rounded-lg text-foreground hover:bg-muted hover:text-primary transition-colors"
                    >
                      <span className="text-muted-foreground">{section.icon}</span>
                      {section.title}
                    </a>
                  ))}
                </nav>
              </aside>

              {/* Main Content */}
              <div className="w-full lg:w-3/4 prose prose-slate dark:prose-invert max-w-none prose-headings:scroll-mt-28 prose-headings:font-bold prose-h2:text-3xl prose-h2:border-b prose-h2:pb-4 prose-h2:mb-6 prose-p:leading-relaxed prose-li:leading-relaxed">
                
                <div id="approach" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <Calculator className="w-8 h-8 text-primary" />
                    1. Our Calculation Approach
                  </h2>
                  <p>
                    At SmartMoneyTools, our philosophy is grounded in accuracy, clarity, and user empowerment. We build calculators that translate complex financial formulas and opaque tax codes into plain English and actionable numbers. Our commitment to accuracy means we do not invent proprietary math; we rely strictly on standardized financial mathematics and official UK statutory rules to drive our logic.
                  </p>
                  <p>
                    Before any calculator is published, it undergoes rigorous testing against official examples provided by HM Revenue & Customs (HMRC), the Financial Conduct Authority (FCA), and major UK financial institutions. We prioritize user-focused design by clearly separating mandatory inputs from optional edge-cases, ensuring that both novices and finance professionals can use our tools effectively.
                  </p>
                  <p>
                    However, financial planning inherently requires estimates. Future inflation rates, lifetime stock market returns, and shifting political landscapes mean that multi-decade projections (like pensions or compound interest) are mathematically precise but practically uncertain. We use baseline estimates to provide a realistic roadmap, but emphasize that these tools are for educational planning, not absolute prophecy.
                  </p>
                </div>

                <div id="tax-years" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <FileText className="w-8 h-8 text-primary" />
                    2. How We Handle UK Tax Year Assumptions
                  </h2>
                  <p>
                    The UK tax year runs from 6 April of one year to 5 April of the following year. This unique alignment requires careful handling in our salary and tax calculators. Unless explicitly stated otherwise via a toggle or dropdown, our calculators default to the current active UK tax year parameters (currently aligned with the 2024/25 or upcoming 2025/26 guidelines depending on the tool).
                  </p>
                  <p>
                    During tax year transitions (typically between the Spring Budget and 6 April), we actively update our database to reflect the impending changes while clearly labeling which tax year is being calculated. We do not blend tax years; calculations are assumed to occur within a single, static 12-month regulatory environment.
                  </p>
                  <p>
                    When assumptions don't apply—such as for highly specific historical data queries or individuals with non-standard tax codes (e.g., K codes, BR codes)—our simplified models may over- or under-estimate tax burdens. We assume a standard 1257L tax code across most tools unless customized by the user. Seasonal variations in income (like ad-hoc bonuses) are smoothed across 12 months for average monthly projections, which may slightly alter exact National Insurance deductions in the specific month the bonus is paid.
                  </p>
                </div>

                <div id="methodologies" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <GitMerge className="w-8 h-8 text-primary" />
                    3. Specific Calculator Methodologies
                  </h2>
                  
                  <h3 className="text-xl mt-8">A) Salary & Income Calculations</h3>
                  <p>
                    Our UK Salary Calculator processes Gross to Net pay by applying deductions in a strict HMRC-compliant sequence: Pension Contributions (if Salary Sacrifice is selected), Income Tax, National Insurance, and Student Loan Repayments. We support regional variations, automatically applying the distinct six-band Scottish Income Tax system or the Welsh rate of Income Tax when those regions are selected. For self-employment, we calculate trading profit before applying Class 4 NI and Income Tax. Marriage Allowance is generally excluded from baseline estimates to avoid overcomplicating standard use cases.
                  </p>

                  <h3 className="text-xl mt-8">B) Tax Calculations</h3>
                  <p>
                    Tax is calculated progressively. The standard Personal Allowance (£12,570) is deducted from gross taxable income first. The remainder is apportioned into Basic (20%), Higher (40%), and Additional (45%) rate bands. Crucially, we implement the Personal Allowance taper, reducing the allowance by £1 for every £2 earned above £100,000, simulating the effective 60% marginal tax rate trap. Capital gains and dividend allowances are calculated separately in specific investment tools, utilizing their distinct tax-free thresholds and lower rate bands.
                  </p>

                  <h3 className="text-xl mt-8">C) National Insurance</h3>
                  <p>
                    National Insurance (NI) is calculated based on weekly or monthly thresholds, not purely on an annual basis. For employees, Class 1 NI is calculated at the primary threshold (currently 8% for main rate earnings and 2% above the upper earnings limit). For the self-employed, we calculate Class 4 NI on annual profits above the lower profits limit. We currently assume standard Category A letter rules and do not automatically apply age-related relief (e.g., reaching State Pension age) unless explicitly configured by the user.
                  </p>

                  <h3 className="text-xl mt-8">D) Pension Calculations</h3>
                  <p>
                    Pension projections are modeled exclusively for Defined Contribution (DC) schemes. We calculate the future value of the pot by compounding initial balances and ongoing contributions (both employer and employee) at an estimated annual growth rate. We automatically add basic rate tax relief (20%) to private contributions if applicable. Our models subtract an estimated inflation rate to provide outputs in "today's money," helping users understand real purchasing power. We use the "4% rule" to estimate sustainable drawdown income at retirement.
                  </p>

                  <h3 className="text-xl mt-8">E) Student Loan Calculations</h3>
                  <p>
                    Student loan deductions are calculated at 9% for undergraduate plans (Plan 1, Plan 2, Plan 4, Plan 5) and 6% for Postgraduate loans, applied only to income strictly above the respective statutory thresholds. Our tools assume these thresholds remain static for the current tax year and do not project future threshold freezes or unfreezes. We do not model the 30- or 40-year statutory write-off provisions in our basic take-home pay calculators.
                  </p>

                  <h3 className="text-xl mt-8">F) Mortgage Calculations</h3>
                  <p>
                    Mortgage payments are calculated using standard fixed-rate amortisation formulas. For a repayment mortgage, the core equation determines the exact monthly payment required to reduce the principal to zero over the specified term while covering compounding monthly interest. For an interest-only mortgage, the monthly payment is the interest on the capital (principal × monthly rate), with the capital repaid in full at the end of the term. Optional monthly housing costs — Council Tax, buildings insurance, service charge, ground rent and an estimated maintenance allowance — are totalled separately into an estimated monthly housing cost and shown alongside the mortgage payment, never added into it. We do not account for variable rate fluctuations mid-term, early repayment charges, or the affordability stress-testing logic used internally by individual lenders.
                  </p>

                  <h3 className="text-xl mt-8">G) Savings Calculations</h3>
                  <p>
                    Savings calculators utilize the future value of an annuity formula to model compound interest. We assume interest is compounded at the frequency selected by the user (usually monthly or annually) and that regular deposits are made at the end of each period. These tools project gross returns; we do not automatically deduct tax on savings interest (as this depends on the individual's Personal Savings Allowance and ISA utilization) unless specifically requested in the tool.
                  </p>

                  <h3 className="text-xl mt-8">H) Debt Calculations</h3>
                  <p>
                    Debt calculators, such as our Debt Snowball tool, project payoff timelines by strictly applying minimum payments plus user-defined extra contributions to specific balances. Interest is assumed to accrue monthly based on the provided APR. The Snowball method sorts debts by balance (smallest first), while the Avalanche method sorts by interest rate (highest first). We assume no new debt is added to the balances during the payoff period.
                  </p>
                </div>

                <div id="data-sources" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <CheckCircle className="w-8 h-8 text-primary" />
                    4. Data Sources
                  </h2>
                  <p>
                    To ensure the highest level of accuracy, our underlying constants and rules are sourced directly from authoritative UK bodies:
                  </p>
                  <ul>
                    <li><strong>HM Revenue & Customs (HMRC) & GOV.UK:</strong> For all Income Tax bands, National Insurance thresholds, Personal Allowances, and tax relief rules.</li>
                    <li><strong>Student Loans Company (SLC):</strong> For exact repayment thresholds, plan classifications, and interest rate parameters.</li>
                    <li><strong>Financial Conduct Authority (FCA) & MoneyHelper:</strong> For standardized assumptions regarding pension growth, inflation estimates, and consumer financial guidance.</li>
                    <li><strong>Bank of England (BoE):</strong> For historical context on base rates and inflation metrics used in our guides.</li>
                    <li><strong>Office for National Statistics (ONS):</strong> For average household spending data used to calibrate our Budget Planner default categories.</li>
                  </ul>
                  <p>
                    We validate our core data annually following the Chancellor's Spring Budget and Autumn Statement. While we monitor market data providers and financial institutions for trends (such as average mortgage rates), hardcoded variables rely exclusively on government statute.
                  </p>
                </div>

                <div id="updates" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <BookOpen className="w-8 h-8 text-primary" />
                    5. Update Frequency
                  </h2>
                  <p>
                    Our tools operate on a scheduled maintenance cycle. Major updates to tax logic, salary calculators, and pension rules occur annually, directly following the publication of final legislation for the upcoming UK tax year (typically implemented in late March, ready for 6 April). 
                  </p>
                  <p>
                    We conduct quarterly reviews for environmental variables, such as adjusting default interest rate placeholders in our mortgage and savings calculators to better reflect the current Bank of England base rate environment. Ad-hoc updates are pushed immediately if emergency legislative changes (such as mid-year National Insurance cuts) are announced. 
                  </p>
                </div>

                <div id="limitations" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <ShieldAlert className="w-8 h-8 text-primary" />
                    6. Accuracy Limitations
                  </h2>
                  <p>
                    All results generated by SmartMoneyTools must be strictly interpreted as estimates. To make our tools fast and user-friendly, we employ simplified assumptions. We use standard rounding (typically to the nearest penny or pound), which can compound into minor discrepancies over 30-year projections.
                  </p>
                  <p>
                    Our standard calculators cannot capture the infinite variety of individual tax circumstances. We do not account for historical tax underpayments, complex benefit-in-kind taxation (like company cars), marriage allowances, or blind person's allowances unless a specific toggle is provided. Furthermore, long-term models regarding investments and mortgages cannot predict market volatility, future interest rate hikes, or changes in UK legislation. If you require absolute certainty, professional financial advice is mandatory.
                  </p>
                </div>

                <div id="differences" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <Scale className="w-8 h-8 text-primary" />
                    7. Why Results May Differ
                  </h2>
                  <p>
                    Users occasionally find slight variances between our calculators and official documentation (like a payslip or a bank's mortgage offer). This happens for several reasons:
                  </p>
                  <ul>
                    <li><strong>Payroll System Variations:</strong> Different payroll software may handle rounding, cumulative National Insurance, or mid-year bonuses slightly differently month-to-month.</li>
                    <li><strong>Bank Affordability Criteria:</strong> A mortgage calculator provides the mathematical repayment cost. However, banks use proprietary stress tests (e.g., adding 3% to the interest rate to test affordability) which may result in them offering you a lower loan amount than our calculator suggests you can afford.</li>
                    <li><strong>Tax Code Variations:</strong> If your payslip has an emergency tax code (e.g., 1257 W1/M1) or adjusts for past owed tax, our standard 1257L cumulative assumption will not match your real-world deductions perfectly.</li>
                    <li><strong>Timing Differences:</strong> Compound interest results change dramatically depending on whether contributions are credited at the beginning or the end of the month. We document our specific timing assumptions, but your bank's methodology may differ.</li>
                  </ul>
                </div>

                <div id="feedback" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <MessageSquare className="w-8 h-8 text-primary" />
                    8. Corrections and Feedback
                  </h2>
                  <p>
                    We are dedicated to continuous improvement. If you discover a bug, a calculation discrepancy, or a piece of outdated legislation in our tools, we want to hear about it.
                  </p>
                  <p>
                    Users can report issues directly via our <Link to="/contact" className="text-primary hover:underline">Contact Page</Link>. Please include the specific inputs you used, the result you received, and the result you expected. Our engineering and content team aims to review and verify all calculation-related reports within 48 hours. Validated corrections are deployed rapidly via our continuous integration pipeline.
                  </p>
                </div>

                <div id="disclaimer" className="mb-16">
                  <h2 className="flex items-center gap-3">
                    <AlertTriangle className="w-8 h-8 text-primary" />
                    9. Financial Disclaimer
                  </h2>
                  <p>
                    The information and calculations provided on SmartMoneyTools.com are for educational, informational, and illustrative purposes only. <strong>Nothing on this website constitutes regulated financial advice, investment advice, legal advice, or tax advice.</strong>
                  </p>
                  <p>
                    While we strive to ensure our calculators are built upon robust formulas and current statutory data, we accept no liability for any errors, omissions, or financial actions taken based on our estimates. Individual financial circumstances are highly complex and subject to change. Past performance of investments is never an indicator of future results.
                  </p>
                  <p>
                    We strongly recommend consulting with an independent, qualified financial adviser (IFA) registered with the Financial Conduct Authority (FCA) before making significant financial decisions, executing trades, or entering into legal contracts such as mortgages or loans.
                  </p>
                </div>

                <div className="mt-12 pt-8 border-t border-border text-center not-prose">
                  <p className="text-muted-foreground text-sm">
                    Learn how we ensure accuracy and quality. <Link to="/editorial-policy" className="text-primary hover:underline font-medium">Read our editorial policy</Link>.
                  </p>
                </div>

              </div>
            </div>
          </div>
        </section>
      </main>

    </div>
  );
}