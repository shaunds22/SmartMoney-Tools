import React from 'react';
import PageSeo from '@/components/PageSeo.jsx';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { DollarSign, ShieldCheck, ExternalLink, Cookie } from 'lucide-react';
import Breadcrumb from '@/components/Breadcrumb.jsx';

export default function AdvertisingDisclosure() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageSeo
        title="Advertising Disclosure | SmartMoneyTools"
        description="How SmartMoneyTools is funded through advertising, our advertiser independence commitment, and how ads are selected."
        path="/advertising-disclosure"
      />

      <section className="bg-primary text-primary-foreground py-12 border-b border-primary/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <h1 className="text-4xl md:text-5xl font-extrabold mb-4 leading-tight" style={{ letterSpacing: '-0.02em' }}>
              Advertising Disclosure
            </h1>
            <p className="text-lg text-primary-foreground/85">
              How SmartMoneyTools is funded, how ads are selected, and how we keep advertising completely separate from our calculators and editorial content.
            </p>
          </motion.div>
        </div>
      </section>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl pt-6 pb-0">
        <Breadcrumb items={[{ label: 'Advertising Disclosure' }]} />
      </div>

      <main className="flex-grow py-10 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">

          <div className="bg-primary/5 border border-primary/20 rounded-xl px-6 py-4 mb-10">
            <p className="text-sm text-foreground leading-relaxed font-medium">
              SmartMoneyTools may be funded through advertising. Advertisers do not influence our calculator formulas, methodology, editorial conclusions, or coverage decisions.
            </p>
          </div>

          <div className="prose prose-slate max-w-none text-muted-foreground prose-headings:text-foreground prose-a:text-primary hover:prose-a:text-primary/80 prose-strong:text-foreground space-y-2">

            <h2 className="flex items-center gap-3 text-2xl font-semibold text-foreground mt-10 mb-4">
              <DollarSign className="w-6 h-6 text-primary shrink-0" /> 1. How SmartMoneyTools Is Funded
            </h2>
            <p>
              SmartMoneyTools is a free-to-use educational calculator platform. To cover the costs of hosting, development, and editorial maintenance, the website may display third-party advertisements served via <strong>Google AdSense</strong>. No subscription fees, paywalls, or paid-for calculator results are used.
            </p>
            <p>
              All of our calculators are, and will remain, completely free. We do not require registration, email sign-up, or any personal data submission to use any calculator on this website.
            </p>

            <h2 className="flex items-center gap-3 text-2xl font-semibold text-foreground mt-10 mb-4">
              <ShieldCheck className="w-6 h-6 text-primary shrink-0" /> 2. Advertiser Independence Statement
            </h2>
            <p>
              There is a strict and permanent separation between our advertising operations and our editorial content:
            </p>
            <ul>
              <li><strong>No advertiser influences our calculator formulas.</strong> The mathematical logic behind every calculator is based solely on official statutory sources (HMRC, GOV.UK, IRS). No advertiser has any input into these calculations, and no formula has ever been altered at an advertiser's request.</li>
              <li><strong>No advertiser influences our editorial conclusions.</strong> Our guides, methodology pages, and educational content are written and reviewed exclusively on the basis of accuracy and usefulness. We do not accept payment to include, exclude, or modify any editorial content.</li>
              <li><strong>No advertiser influences our coverage decisions.</strong> We do not accept paid placements disguised as editorial content. We do not write guides about specific financial products in exchange for payment.</li>
              <li><strong>We do not sell featured placement</strong> in our calculator results, recommendation lists, or guide comparisons.</li>
            </ul>

            <h2 className="flex items-center gap-3 text-2xl font-semibold text-foreground mt-10 mb-4">
              <ExternalLink className="w-6 h-6 text-primary shrink-0" /> 3. How Advertisements Are Selected
            </h2>
            <p>
              Advertisements are served automatically by <strong>Google AdSense</strong>. Google's advertising platform selects and displays ads based on:
            </p>
            <ul>
              <li>The content of the page being viewed.</li>
              <li>Your browser's cookies, browsing history, and interests (if you have not opted out of personalised advertising).</li>
              <li>Your general geographic location.</li>
            </ul>
            <p>
              We do not manually select, approve, or negotiate individual advertisements. We use Google's category-blocking tools to exclude certain ad categories (for example, we block predatory lending and gambling advertisements where possible), but we cannot guarantee that every advertisement displayed on this site will be appropriate for all audiences.
            </p>
            <p>
              If you see an advertisement that you consider offensive, misleading, or inappropriate, please <Link to="/contact">contact us</Link> with the page URL and a screenshot and we will investigate.
            </p>

            <h2 className="flex items-center gap-3 text-2xl font-semibold text-foreground mt-10 mb-4">
              <ExternalLink className="w-6 h-6 text-primary shrink-0" /> 4. Affiliate Links
            </h2>
            <p>
              SmartMoneyTools does not currently use affiliate links. If this changes in the future, any affiliate link will be clearly labelled with a disclosure notice close to the relevant link, such as:
            </p>
            <blockquote className="border-l-4 border-primary/40 pl-4 italic text-muted-foreground text-sm">
              "This is an affiliate link. SmartMoneyTools may earn a commission if you click through and make a purchase, at no extra cost to you. This does not influence our editorial assessment."
            </blockquote>
            <p>
              We will never allow commission potential to influence which products or services we recommend or describe positively.
            </p>

            <h2 className="flex items-center gap-3 text-2xl font-semibold text-foreground mt-10 mb-4">
              <Cookie className="w-6 h-6 text-primary shrink-0" /> 5. Third-Party Advertising Vendors and Privacy
            </h2>
            <p>
              Google AdSense and its advertising partners may place cookies and collect certain data when you visit this site, including:
            </p>
            <ul>
              <li>Your IP address (used for geographic targeting and fraud prevention).</li>
              <li>Your device type, browser, and operating system.</li>
              <li>Pages you visit on this site and your interaction with advertisements.</li>
              <li>Interests and browsing behaviour from across the web (for personalised ads, if you have not opted out).</li>
            </ul>
            <p>
              <strong>SmartMoneyTools does not sell your personal data.</strong> The data collected by Google's advertising system is governed by <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer">Google's Privacy Policy</a>. You can manage your Google advertising preferences at <a href="https://adssettings.google.com" target="_blank" rel="noopener noreferrer">adssettings.google.com</a>.
            </p>
            <p>
              For more information about cookies used on this site, see our <Link to="/cookie-policy">Cookie Policy</Link>.
            </p>
            <p>
              For full details of how we handle personal data, see our <Link to="/privacy">Privacy Policy</Link>.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">6. Ad Placement Policy</h2>
            <p>
              We follow a conservative advertising placement strategy to ensure that advertisements never interfere with calculator functionality or dominate page content:
            </p>
            <ul>
              <li>At most one advertisement near the upper content area of a page.</li>
              <li>At most one advertisement after calculator results or within a long guide.</li>
              <li>At most one advertisement near the end of a substantial article.</li>
            </ul>
            <p>We do not place advertisements:</p>
            <ul>
              <li>Between an input label and its form field.</li>
              <li>Directly beside Calculate, Reset, or Download buttons.</li>
              <li>Inside calculator results panels.</li>
              <li>In a way that could be mistaken for navigation.</li>
              <li>In two adjacent advertisement blocks.</li>
            </ul>

            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">7. Contact Regarding Advertising</h2>
            <p>
              For advertising-related enquiries — including questions about our ad policies, complaints about specific advertisements, or enquiries about sponsorship opportunities — please contact:
            </p>
            <ul>
              <li><strong>Email:</strong> <a href="mailto:support@smartmoney-tools.com">support@smartmoney-tools.com</a> (subject: "Advertising Enquiry")</li>
              <li><strong>Contact form:</strong> <Link to="/contact">smartmoney-tools.com/contact</Link> — select "Billing / Advertising"</li>
            </ul>

            <div className="mt-12 pt-8 border-t border-border text-sm text-muted-foreground">
              <p>Related policies: <Link to="/privacy">Privacy Policy</Link> · <Link to="/cookie-policy">Cookie Policy</Link> · <Link to="/editorial-policy">Editorial Policy</Link></p>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
}
