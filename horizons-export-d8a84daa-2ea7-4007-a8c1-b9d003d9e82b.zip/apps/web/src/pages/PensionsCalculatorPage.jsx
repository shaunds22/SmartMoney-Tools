import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import DisclaimerBanner from '@/components/DisclaimerBanner.jsx';
import HowWeCalculateThis from '@/components/HowWeCalculateThis.jsx';
import CalculatorContentSection from '@/components/CalculatorContentSection.jsx';
import { Link } from 'react-router-dom';
import { setPageMeta } from '@/utils/seo.js';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend } from 'recharts';
import useCurrency from '@/hooks/useCurrency.js';
import AuthorAttribution from '@/components/AuthorAttribution.jsx';

export default function PensionsCalculatorPage() {
  const { currency } = useCurrency();
  const [age, setAge] = useState(30);
  const [retireAge, setRetireAge] = useState(65);
  const [balance, setBalance] = useState(10000);
  const [contribution, setContribution] = useState(500);
  const [freq, setFreq] = useState('Monthly');
  const [returnRate, setReturnRate] = useState(5);
  const [inflation, setInflation] = useState(2);
  const [results, setResults] = useState(null);

  useEffect(() => {
    // Reset state on mount to ensure clean slate
    setAge(30);
    setRetireAge(65);
    setBalance(10000);
    setContribution(500);
    setFreq('Monthly');
    setReturnRate(5);
    setInflation(2);
    setResults(null);
    
    setPageMeta('Pensions Calculator | SmartMoneyTools', 'Calculate your retirement income and pension pot value.', 'https://smartmoney-tools.com/pensions-calculator');
  }, []);

  useEffect(() => {
    const years = Math.max(0, retireAge - age);
    let periodsPerYear = freq === 'Monthly' ? 12 : freq === 'Quarterly' ? 4 : 1;
    let ratePerPeriod = (returnRate / 100) / periodsPerYear;
    let totalPeriods = years * periodsPerYear;
    let fvBalance = balance * Math.pow(1 + ratePerPeriod, totalPeriods);
    let fvContrib = 0;
    
    if (ratePerPeriod > 0) {
      fvContrib = contribution * ((Math.pow(1 + ratePerPeriod, totalPeriods) - 1) / ratePerPeriod);
    } else {
      fvContrib = contribution * totalPeriods;
    }

    let totalValue = fvBalance + fvContrib;
    let realReturnRate = ((1 + returnRate/100) / (1 + inflation/100)) - 1;
    let realRatePerPeriod = realReturnRate / periodsPerYear;
    let realFvBalance = balance * Math.pow(1 + realRatePerPeriod, totalPeriods);
    let realFvContrib = ratePerPeriod > 0 ? contribution * ((Math.pow(1 + realRatePerPeriod, totalPeriods) - 1) / realRatePerPeriod) : contribution * totalPeriods;
    let inflationAdjustedValue = realFvBalance + realFvContrib;
    
    let totalContributions = balance + (contribution * totalPeriods);
    let growth = totalValue - totalContributions;

    setResults({
      totalValue,
      inflationAdjustedValue,
      annualIncome: inflationAdjustedValue * 0.04,
      totalContributions,
      growth,
      years
    });
  }, [age, retireAge, balance, contribution, freq, returnRate, inflation]);

  const chartData = results ? [
    { name: 'Contributions', value: results.totalContributions },
    { name: 'Growth', value: Math.max(0, results.growth) }
  ] : [];

  return (
    <div className="flex flex-col w-full bg-background py-12">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="mb-4">
          <span className="inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-sm font-medium text-primary border border-primary/20">Tax Year: 2026/27 · Last reviewed: 11 September 2026</span>
        </div>
        <h1 className="text-4xl font-extrabold mb-4 text-balance">Pensions Calculator</h1>
        <AuthorAttribution lastReviewedDate="2026-09-11" />
        <div className="grid md:grid-cols-12 gap-8 mb-12">
          <div className="md:col-span-4 space-y-6 bg-card p-6 rounded-2xl border shadow-sm">
            <div>
              <Label>Current Age</Label>
              <Input type="number" value={age} onChange={(e) => setAge(Number(e.target.value))} />
            </div>
            <div>
              <Label>Retirement Age</Label>
              <Input type="number" value={retireAge} onChange={(e) => setRetireAge(Number(e.target.value))} />
            </div>
            <div>
              <Label>Current Pension Balance ({currency.symbol})</Label>
              <Input type="number" value={balance} onChange={(e) => setBalance(Number(e.target.value))} />
            </div>
            <div>
              <Label>Contribution Amount ({currency.symbol})</Label>
              <Input type="number" value={contribution} onChange={(e) => setContribution(Number(e.target.value))} />
            </div>
            <div>
              <Label>Contribution Frequency</Label>
              <Select value={freq} onValueChange={setFreq}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Monthly">Monthly</SelectItem>
                  <SelectItem value="Quarterly">Quarterly</SelectItem>
                  <SelectItem value="Annual">Annual</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Expected Return (%)</Label>
              <Input type="number" value={returnRate} onChange={(e) => setReturnRate(Number(e.target.value))} />
            </div>
            <div>
              <Label>Inflation Rate (%)</Label>
              <Input type="number" value={inflation} onChange={(e) => setInflation(Number(e.target.value))} />
            </div>
          </div>
          <div className="md:col-span-8 bg-card p-6 rounded-2xl border shadow-sm flex flex-col">
            {results && (
              <>
                <h2 className="text-2xl font-bold mb-6">Retirement Projection</h2>
                <div className="grid grid-cols-2 gap-4 mb-8">
                  <div className="bg-[hsl(var(--calc-result-bg))] p-4 rounded-xl">
                    <p className="text-muted-foreground text-sm">Nominal Value</p>
                    <p className="text-3xl font-bold">{currency.symbol}{results.totalValue.toLocaleString(undefined, {maximumFractionDigits:0})}</p>
                  </div>
                  <div className="bg-[hsl(var(--calc-result-bg))] p-4 rounded-xl">
                    <p className="text-muted-foreground text-sm">Inflation Adjusted (Today's Money)</p>
                    <p className="text-3xl font-bold text-primary">{currency.symbol}{results.inflationAdjustedValue.toLocaleString(undefined, {maximumFractionDigits:0})}</p>
                  </div>
                  <div className="bg-[hsl(var(--calc-result-bg))] p-4 rounded-xl">
                    <p className="text-muted-foreground text-sm">Est. Annual Income (4% Rule)</p>
                    <p className="text-2xl font-semibold">{currency.symbol}{results.annualIncome.toLocaleString(undefined, {maximumFractionDigits:0})}</p>
                  </div>
                  <div className="bg-[hsl(var(--calc-result-bg))] p-4 rounded-xl">
                    <p className="text-muted-foreground text-sm">Years to Grow</p>
                    <p className="text-2xl font-semibold">{results.years} years</p>
                  </div>
                </div>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={chartData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={80}>
                        <Cell fill="hsl(var(--primary))" />
                        <Cell fill="hsl(var(--calc-chart-2))" />
                      </Pie>
                      <RechartsTooltip formatter={(value) => `${currency.symbol}${value.toLocaleString(undefined, {maximumFractionDigits:0})}`} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </>
            )}
          </div>
        </div>

        <HowWeCalculateThis region="UK" />

        <DisclaimerBanner />

        <div className="mt-16 max-w-4xl mx-auto">
          <CalculatorContentSection title="What this calculator estimates">
            <p>This tool projects the future value of a Defined Contribution (DC) pension pot — the kind built up through workplace auto-enrolment or a personal pension such as a SIPP. Enter your current age, existing pot, and ongoing contributions, and it forecasts two figures: the <strong>nominal value</strong> (the raw pound figure on a future statement) and the <strong>inflation-adjusted value</strong> (what that pot can buy in today's money). It also applies the widely cited 4% rule to suggest a sustainable annual drawdown income.</p>
            <p>It does <em>not</em> add the UK State Pension, calculate tax on withdrawals, or value a final-salary (Defined Benefit) scheme — those are separate and explained under assumptions below.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Who it is designed for">
            <ul>
              <li><strong>Employees</strong> checking whether their auto-enrolment contributions are on track for a comfortable retirement.</li>
              <li><strong>Self-employed people</strong> who have no employer match and must fund a SIPP themselves.</li>
              <li><strong>Mid-career savers</strong> weighing up whether to increase contributions or delay retirement.</li>
              <li><strong>Younger savers</strong> wanting to see how decades of compound growth turn small, regular payments into a meaningful pot.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="What you need before you start">
            <p>Gather a few figures first so the projection is realistic rather than a guess:</p>
            <ul>
              <li>Your latest pension statement — the current pot value, including any old workplace pensions you may have kept with former employers.</li>
              <li>The combined employee <em>plus</em> employer contribution if you're in a workplace scheme (auto-enrolment minimums are 5% employee / 3% employer of qualifying earnings).</li>
              <li>The age you realistically expect to stop working and start drawing the pot.</li>
              <li>A sensible expected return — typically 4–6% for a balanced pension fund, lower for cash-heavy funds.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="What each input means">
            <ul>
              <li><strong>Current Age</strong> — your age today; together with Retirement Age it sets how long your money has to grow.</li>
              <li><strong>Retirement Age</strong> — the age at which you stop contributing and start drawing. Remember the normal minimum pension age is 55, rising to 57 in 2028.</li>
              <li><strong>Current Pension Balance</strong> — the total across all your DC pots today, in {currency.symbol}.</li>
              <li><strong>Contribution Amount</strong> — the regular amount paid in. For workplace pensions, include both your deduction and your employer's contribution — that "free money" matters.</li>
              <li><strong>Contribution Frequency</strong> — how often that amount goes in: monthly, quarterly, or annually.</li>
              <li><strong>Expected Return (%)</strong> — the annualised investment growth you assume, before charges. Pension default funds have returned roughly 5–7% over long periods, but future returns are not guaranteed.</li>
              <li><strong>Inflation Rate (%)</strong> — used to convert the nominal pot into today's purchasing power. The Bank of England target is 2%.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="How to read your results">
            <p>The <strong>Nominal Value</strong> is the headline number you'd see on a statement at retirement — useful, but misleading on its own because money loses purchasing power over time. The <strong>Inflation Adjusted</strong> figure is the one to plan with: it tells you what that pot is worth in today's terms. The <strong>Estimated Annual Income</strong> applies the 4% rule to the inflation-adjusted pot, giving a rough sustainable first-year withdrawal. Add your expected State Pension (around {currency.symbol}12,547.60/year for the full new State Pension in 2026/27) to this figure for a fuller retirement income picture. The pie chart splits your pot into money you paid in versus growth the markets generated — over long horizons, growth usually dominates, which is why starting early matters so much.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Worked example">
            <p>A 35-year-old planning to retire at 65, with a {currency.symbol}25,000 pot, {currency.symbol}400 combined monthly contributions, 6% expected return, and 2.5% inflation.</p>
            <ul>
              <li><strong>Current Pension Pot:</strong> {currency.symbol}25,000</li>
              <li><strong>Monthly Contribution:</strong> {currency.symbol}400 (Combined employee + employer)</li>
              <li><strong>Expected Return:</strong> 6%</li>
              <li><strong>Inflation Rate:</strong> 2.5%</li>
            </ul>
            <p>By age 65, their nominal pension pot would be over <strong>{currency.symbol}540,000</strong>. However, adjusted for 2.5% inflation, the purchasing power of that pot in today's money is roughly <strong>{currency.symbol}260,000</strong>. Using the 4% rule, this pot would generate an annual income of about <strong>{currency.symbol}10,400</strong> in today's money, which would be added to their State Pension.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Assumptions and exclusions">
            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">Key assumptions</h3>
            <ul>
              <li>Defined Contribution (DC) pension only — not Defined Benefit / final salary.</li>
              <li>A smooth, constant investment return every year. Real markets are volatile, with up and down years.</li>
              <li>Constant inflation rate throughout.</li>
              <li>Sustainable drawdown modelled at a 4% initial withdrawal rate.</li>
              <li>Contributions continue unchanged until the retirement age you set.</li>
              <li>Pension Annual Allowance: {currency.symbol}60,000 or 100% of earnings (2026/27). Lifetime Allowance abolished April 2024.</li>
            </ul>
            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">What is not included</h3>
            <ul>
              <li>UK State Pension (full new State Pension: approx. {currency.symbol}12,547.60/year for 2026/27).</li>
              <li>Tax-free cash lump sum (Pension Commencement Lump Sum — up to {currency.symbol}268,275).</li>
              <li>Income tax on pension withdrawals in retirement.</li>
              <li>Annuity pricing or guarantees.</li>
              <li>Pension fund charges, which reduce real returns.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Common mistakes to avoid">
            <ul>
              <li><strong>Looking only at the nominal figure.</strong> A {currency.symbol}1,000,000 pot in 30 years buys far less than {currency.symbol}1,000,000 buys today. Always plan with the inflation-adjusted number.</li>
              <li><strong>Forgetting employer contributions.</strong> Entering only your own 5% understates the pot by a third or more. Always include the employer match.</li>
              <li><strong>Opting out of auto-enrolment.</strong> You forfeit employer contributions and government tax relief — effectively a pay cut.</li>
              <li><strong>Underestimating how long you'll live.</strong> Many plan for a 15-year retirement; average life expectancies mean your pot may need to last 25–30 years.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Sensible next steps">
            <ul>
              <li>Log in to your pension provider's portal and confirm your current pot value and contribution rate — old pots can be consolidated, though check for exit fees first.</li>
              <li>If your projection falls short, the cheapest lever is usually increasing your contribution by 1–2% of salary, ideally via salary sacrifice if your employer offers it.</li>
              <li>Get a free State Pension forecast from the <a href="https://www.gov.uk/check-state-pension" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK Check State Pension</a> service and add it to the income shown here.</li>
              <li>For a full retirement plan, consider speaking with a regulated financial adviser — find one at <a href="https://www.moneyhelper.org.uk/en/pensions-and-retirement/pensions-and-retirement" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">MoneyHelper</a>.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Related guides and calculators">
            <ul>
              <li><Link to="/compound-interest" className="text-primary hover:underline">Compound Interest Calculator</Link>: Explore the maths behind your pension's growth in more detail.</li>
              <li><Link to="/uk-salary-calculator" className="text-primary hover:underline">UK Salary Calculator</Link>: See how increasing pension contributions affects your current take-home pay via tax relief.</li>
              <li><Link to="/guides/pension-planning" className="text-primary hover:underline">Pension Planning Guide</Link>: Comprehensive strategies for a secure retirement.</li>
              <li><Link to="/guides/workplace-pensions" className="text-primary hover:underline">Workplace Pensions Guide</Link>: Understand auto-enrolment, employer contributions, and tax relief.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Sources and references">
            <p className="text-sm bg-primary/5 p-3 rounded-lg border border-primary/20 mb-4">SmartMoneyTools checks statutory rates and thresholds against official government publications. Results are estimates for educational purposes and may not reflect every individual circumstance. <strong>Last reviewed: 11 September 2026.</strong></p>
            <div className="overflow-x-auto">
              <table className="w-full text-sm border-collapse">
                <thead><tr className="bg-muted text-left"><th className="p-2 font-semibold border border-border">Data Item</th><th className="p-2 font-semibold border border-border">Value</th><th className="p-2 font-semibold border border-border">Period</th><th className="p-2 font-semibold border border-border">Source</th></tr></thead>
                <tbody>
                  <tr><td className="p-2 border border-border">Annual Allowance</td><td className="p-2 border border-border">£60,000</td><td className="p-2 border border-border">2026/27</td><td className="p-2 border border-border"><a href="https://www.gov.uk/tax-on-your-private-pension/annual-allowance" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK</a></td></tr>
                  <tr><td className="p-2 border border-border">Lifetime Allowance</td><td className="p-2 border border-border">Abolished</td><td className="p-2 border border-border">From Apr 2024</td><td className="p-2 border border-border"><a href="https://www.gov.uk/guidance/pension-schemes-protect-your-lifetime-allowance" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK</a></td></tr>
                  <tr><td className="p-2 border border-border">PCLS cap</td><td className="p-2 border border-border">£268,275</td><td className="p-2 border border-border">2026/27</td><td className="p-2 border border-border"><a href="https://www.gov.uk/tax-on-your-private-pension/pension-commencement-lump-sum" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK</a></td></tr>
                  <tr><td className="p-2 border border-border">Normal Minimum Pension Age</td><td className="p-2 border border-border">55 (rising to 57 in 2028)</td><td className="p-2 border border-border">Current / 2028</td><td className="p-2 border border-border"><a href="https://www.gov.uk/pension-age" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK</a></td></tr>
                  <tr><td className="p-2 border border-border">Auto-enrolment minimum contribution</td><td className="p-2 border border-border">8% qualifying earnings (3% employer)</td><td className="p-2 border border-border">From Apr 2019</td><td className="p-2 border border-border"><a href="https://www.thepensionsregulator.gov.uk/en/employers/new-to-automatic-enrolment/automatic-enrolment-contribution-rates" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Pensions Regulator</a></td></tr>
                  <tr><td className="p-2 border border-border">Qualifying Earnings band</td><td className="p-2 border border-border">£6,240 – £50,270</td><td className="p-2 border border-border">2026/27</td><td className="p-2 border border-border"><a href="https://www.thepensionsregulator.gov.uk/en/employers/new-to-automatic-enrolment/automatic-enrolment-contribution-rates" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Pensions Regulator</a></td></tr>
                </tbody>
              </table>
            </div>
          </CalculatorContentSection>

          <div className="mt-12 pt-8 border-t border-border text-center">
            <p className="text-muted-foreground text-sm">
              Want to know exactly how we calculate these numbers? <Link to="/calculation-methodology" className="text-primary hover:underline font-medium">See our calculation methodology</Link>.
            </p>
          </div>

        </div>
      </div>
    </div>
  );
}
