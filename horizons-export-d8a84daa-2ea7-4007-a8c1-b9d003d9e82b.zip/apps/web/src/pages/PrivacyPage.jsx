import React from 'react';
import PageSeo from '@/components/PageSeo.jsx';
import { Link } from 'react-router-dom';

export default function PrivacyPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <PageSeo
        title="Privacy Policy | SmartMoneyTools"
        description="SmartMoneyTools Privacy Policy. How we collect, use, and protect your data including Google advertising cookies, consent management, and your rights."
        path="/privacy"
      />

      <main className="flex-grow py-16 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">
          <h1 className="text-4xl font-bold text-foreground mb-8">Privacy Policy</h1>

          <div className="prose prose-slate max-w-none text-muted-foreground space-y-6">
            <p><strong>Effective Date:</strong> 6 May 2026 &nbsp;|&nbsp; <strong>Last reviewed:</strong> 6 August 2026</p>

            <p className="text-lg font-medium text-foreground">
              SmartMoneyTools is operated and written by Shaun Da Silva, an independent Financial Consultant based in the United Kingdom. This policy explains what data we collect, how it is used, and how you can control it.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">1. Calculator Inputs — Zero Data Collection</h2>
            <p>
              All calculations performed by our tools are executed locally within your web browser using JavaScript. <strong>We do not transmit, log, or store any of the financial figures you enter into our calculators</strong> (such as salary, mortgage amount, pension balance, or tax year). These values exist only in your browser session and are discarded when you close or navigate away from the page.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">2. Contact Form Submissions</h2>
            <p>
              If you voluntarily submit a message through our <Link to="/contact" className="text-primary hover:underline">Contact page</Link>, we collect your name, email address, and the content of your message. This data is stored securely and used solely to respond to your enquiry. We do not share contact form data with third parties for marketing purposes.
            </p>
            <p>
              You may request deletion of a contact form submission by emailing <a href="mailto:support@smartmoney-tools.com" className="text-primary hover:underline">support@smartmoney-tools.com</a>.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">3. Google Advertising and Cookies</h2>
            <p>
              SmartMoneyTools uses <strong>Google AdSense</strong> to serve third-party advertisements. This allows us to keep our calculators free of charge. To serve advertisements, Google's advertising platform sets cookies in your browser and may collect the following data:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li><strong>IP address</strong> — used for approximate geographic targeting and fraud prevention.</li>
              <li><strong>Device identifiers</strong> — including browser type, operating system, screen resolution, and device model.</li>
              <li><strong>Browsing behaviour</strong> — pages you visit on this site and, if you have not opted out, your broader browsing history across the web (for personalised advertising).</li>
              <li><strong>Ad interaction data</strong> — whether you viewed or clicked an advertisement.</li>
            </ul>
            <p>
              Google may serve <strong>personalised advertisements</strong> based on your interests and browsing history, or <strong>non-personalised advertisements</strong> based solely on the content of the page you are viewing. The type of ads you see depends on your consent choices (see section 5).
            </p>
            <p>
              Google's use of advertising data is governed by <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Google's Privacy Policy</a>. Google is a third-party vendor that uses cookies to serve ads based on your prior visits to this website and other websites on the internet.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">4. Analytics</h2>
            <p>
              We may use anonymised analytics to understand how pages are used (for example, which calculators are most visited and how long users spend on guide pages). Any analytics tools used are configured to anonymise IP addresses and not to collect personally identifiable information.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">5. Consent Management and Your Choices</h2>
            <p>
              Under UK GDPR and the UK Privacy and Electronic Communications Regulations, you have the right to control whether non-essential cookies (including those used for personalised advertising) are placed on your device.
            </p>
            <p>
              When you visit SmartMoneyTools, you will be presented with a cookie consent notice offering you a genuine choice between accepting or rejecting non-essential cookies. <strong>Both options are presented with equal clarity.</strong> If you reject non-essential cookies, Google AdSense will serve non-personalised advertisements only (based on page content rather than your browsing history).
            </p>
            <p>You can also manage advertising preferences directly:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Opt out of personalised Google advertising: <a href="https://adssettings.google.com" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">adssettings.google.com</a></li>
              <li>Opt out via the IAB opt-out tool: <a href="https://www.aboutads.info/choices/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">aboutads.info/choices</a></li>
              <li>Manage cookies in your browser settings (see your browser's help documentation).</li>
            </ul>
            <p>
              To withdraw consent you have previously given, you can clear your browser's cookies for this site and revisit the page to be presented with the consent notice again.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">6. Local Storage</h2>
            <p>
              We use your browser's Local Storage (not a cookie) to save interface preferences such as your selected currency symbol and colour theme. This data never leaves your device and is not transmitted to our servers. It can be cleared by clearing your browser's site data.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">7. Data Security and Retention</h2>
            <p>
              All traffic between your browser and our servers is encrypted using HTTPS/TLS. Contact form submissions are stored securely and are retained for up to 12 months, after which they are deleted. Calculator inputs are never stored on our servers and therefore have no retention period.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">8. Data Sharing</h2>
            <p>
              We do not sell, rent, or trade personal data to third parties. Data is shared only:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>With Google AdSense, for the purpose of serving advertisements (see section 3).</li>
              <li>With our hosting provider, for the purpose of delivering the website to your browser.</li>
              <li>When legally required to do so by UK law enforcement or a court order.</li>
            </ul>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">9. Your Rights Under UK GDPR</h2>
            <p>
              You have the right to: access the personal data we hold about you; request correction of inaccurate data; request deletion of your data; object to processing; and lodge a complaint with the Information Commissioner's Office (ICO) at <a href="https://ico.org.uk" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">ico.org.uk</a>.
            </p>
            <p>
              To exercise any of these rights, contact us at <a href="mailto:support@smartmoney-tools.com" className="text-primary hover:underline">support@smartmoney-tools.com</a>.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">10. Children's Privacy</h2>
            <p>
              Our calculators and guides are intended for users aged 18 and over. We do not knowingly collect personal data from children under 13.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">11. Changes to This Policy</h2>
            <p>
              We may update this Privacy Policy from time to time. Material changes will be reflected by updating the "Last reviewed" date at the top of this page.
            </p>

            <div className="mt-10 pt-8 border-t border-border text-sm text-muted-foreground">
              <p>Related: <Link to="/cookie-policy" className="text-primary hover:underline">Cookie Policy</Link> · <Link to="/advertising-disclosure" className="text-primary hover:underline">Advertising Disclosure</Link> · <Link to="/contact" className="text-primary hover:underline">Contact Us</Link></p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
