import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Calculator, TrendingUp, Shield, Zap, PoundSterling, ArrowRight, Target, PieChart, Landmark, Coins, PiggyBank, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { setPageMeta } from '@/utils/seo.js';

function HomePage() {
  useEffect(() => {
    setPageMeta(
      'Free Financial Calculators | SmartMoneyTools',
      'Use free financial calculators for compound interest, mortgages, loans, savings and more. Plan smarter money decisions with simple online tools.',
      'https://smartmoney-tools.com/'
    );
    // Organization + WebSite schema are emitted statically in index.html
    // (so they appear in prerendered HTML). Do not re-inject client-side.
  }, []);

  const featuredCalculators = [
    { name: 'Compound Interest', path: '/compound-interest', icon: <TrendingUp className="h-7 w-7 text-primary" />, desc: 'Model long-term wealth accumulation and investment growth over decades.', bg: 'bg-primary/10' },
    { name: 'Mortgage Calculator', path: '/mortgage', icon: <Calculator className="h-7 w-7 text-accent" />, desc: 'Estimate your UK monthly mortgage payment, deposit, loan-to-value and total interest, with optional Council Tax and buildings insurance shown separately.', bg: 'bg-accent/10' },
    { name: 'UK Salary Calculator', path: '/uk-salary-calculator', icon: <PoundSterling className="h-7 w-7 text-purple-600" />, desc: 'Calculate UK take-home pay after tax, NI, pensions, and student loans.', bg: 'bg-purple-500/10' },
    { name: 'Pensions Calculator', path: '/pensions-calculator', icon: <Landmark className="h-7 w-7 text-emerald-600" />, desc: 'Project your retirement pot value and estimated annual income.', bg: 'bg-emerald-500/10' },
    { name: 'Budget Planner', path: '/budget-planner', icon: <PieChart className="h-7 w-7 text-amber-600" />, desc: 'Manage your monthly income and expenses with the zero-based budgeting method.', bg: 'bg-amber-500/10' },
    { name: 'Self-Employed Tax', path: '/self-employed-tax-calculator', icon: <Coins className="h-7 w-7 text-blue-600" />, desc: 'Estimate sole trader income tax and National Insurance liabilities.', bg: 'bg-blue-500/10' },
    { name: 'Debt Snowball', path: '/debt-snowball-calculator', icon: <Target className="h-7 w-7 text-rose-600" />, desc: 'Plan your debt-free timeline using the highly effective snowball strategy.', bg: 'bg-rose-500/10' },
    { name: 'Savings Goal', path: '/savings-goal-calculator', icon: <PiggyBank className="h-7 w-7 text-teal-600" />, desc: 'Find out exactly how much to save monthly to hit a specific financial target.', bg: 'bg-teal-500/10' }
  ];

  return (
    <div className="flex flex-col w-full">
      {/* Hero Section */}
      <section className="relative pt-24 pb-24 overflow-hidden bg-background">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/10 via-background to-background pointer-events-none"></div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-4xl mx-auto text-center"
          >
            <div className="inline-flex items-center rounded-full border border-primary/20 bg-primary/5 px-3 py-1 text-sm font-medium text-primary mb-8">
              <Zap className="mr-2 h-4 w-4" /> Fast, Free, and Private
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-foreground mb-6 leading-tight text-balance" style={{ letterSpacing: '-0.02em' }}>
              Financial Calculators Built for Clarity and Accuracy
            </h1>
            <p className="text-xl text-muted-foreground mb-10 leading-relaxed max-w-2xl mx-auto">
              Skip the complicated spreadsheets. Project your investment growth, plan your budget, and build a solid financial plan with our free, private online tools.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <Button asChild size="lg" className="text-base px-8 py-6 rounded-xl shadow-lg transition-all duration-200 hover:-translate-y-1">
                <Link to="/compound-interest">Start Calculating</Link>
              </Button>
            </div>
            <p className="text-sm text-muted-foreground flex items-center justify-center gap-2">
              <Shield className="h-4 w-4" /> 
              Committed to accuracy and transparency. <Link to="/editorial-policy" className="text-primary hover:underline font-medium">Read our editorial policy.</Link>
            </p>
          </motion.div>
        </div>
      </section>

      {/* Featured Calculators Grid */}
      <section id="calculators" className="py-24 bg-card border-y border-border scroll-mt-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Our Complete Toolkit</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Select a calculator to model your specific financial scenario.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredCalculators.map((calc, i) => (
              <motion.div
                key={calc.path}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: i * 0.05 }}
                viewport={{ once: true }}
                className="bg-background rounded-2xl p-6 shadow-sm border border-border flex flex-col h-full transition-all hover:shadow-md hover:border-primary/50"
              >
                <div className={`h-12 w-12 rounded-xl flex items-center justify-center mb-4 ${calc.bg}`}>
                  {calc.icon}
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">{calc.name}</h3>
                <p className="text-muted-foreground text-sm mb-6 flex-grow">{calc.desc}</p>
                <Link to={calc.path} className="text-primary font-medium text-sm flex items-center group mt-auto">
                  Use Tool <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Guides Hub CTA */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-5xl">
          <div className="rounded-3xl border border-border bg-card p-10 md:p-14 text-center shadow-sm">
            <BookOpen className="h-10 w-10 text-primary mx-auto mb-5" />
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Learn the Strategy Behind the Numbers</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              Every calculator is backed by a plain-English guide — covering salary, tax, pensions, savings, debt and mortgages so you can make confident, informed decisions.
            </p>
            <Button asChild size="lg" className="text-base px-8 py-6 rounded-xl shadow-lg transition-all duration-200 hover:-translate-y-1">
              <Link to="/guides">Browse the Financial Library <ArrowRight className="ml-2 h-4 w-4" /></Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}

export default HomePage;