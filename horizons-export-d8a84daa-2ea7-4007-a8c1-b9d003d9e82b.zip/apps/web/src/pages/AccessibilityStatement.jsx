import React from 'react';
import PageSeo from '@/components/PageSeo.jsx';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Eye, Keyboard, Monitor, Mail } from 'lucide-react';
import Breadcrumb from '@/components/Breadcrumb.jsx';

export default function AccessibilityStatement() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageSeo
        title="Accessibility Statement | SmartMoneyTools"
        description="SmartMoneyTools accessibility statement. Our WCAG 2.1 AA compliance commitment, known limitations, and how to report accessibility issues."
        path="/accessibility"
      />

      <section className="bg-primary text-primary-foreground py-12 border-b border-primary/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <h1 className="text-4xl md:text-5xl font-extrabold mb-4 leading-tight" style={{ letterSpacing: '-0.02em' }}>
              Accessibility Statement
            </h1>
            <p className="text-lg text-primary-foreground/85">
              SmartMoneyTools is committed to making our calculators and guides accessible to as many people as possible, regardless of disability or assistive technology.
            </p>
          </motion.div>
        </div>
      </section>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl pt-6 pb-0">
        <Breadcrumb items={[{ label: 'Accessibility Statement' }]} />
      </div>

      <main className="flex-grow py-10 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">

          <div className="bg-primary/5 border border-primary/20 rounded-xl px-6 py-4 mb-10">
            <p className="text-sm text-foreground leading-relaxed">
              <strong>Effective date:</strong> 6 May 2026 &nbsp;|&nbsp; <strong>Last reviewed:</strong> 6 August 2026
            </p>
          </div>

          <div className="prose prose-slate max-w-none text-muted-foreground prose-headings:text-foreground prose-a:text-primary hover:prose-a:text-primary/80 prose-strong:text-foreground space-y-2">

            <h2 className="flex items-center gap-3 text-2xl font-semibold text-foreground mt-10 mb-4">
              <Eye className="w-6 h-6 text-primary shrink-0" /> 1. Our Accessibility Commitment
            </h2>
            <p>
              SmartMoneyTools aims to conform to the <strong>Web Content Accessibility Guidelines (WCAG) 2.1 Level AA</strong>. These guidelines explain how to make web content more accessible to people with disabilities. Conformance with these guidelines helps make the web more usable for all users.
            </p>
            <p>
              We recognise that accessibility is an ongoing process, not a one-time task. We are actively working to improve the accessibility of our calculators, guides, and supporting pages, and we welcome feedback from users about barriers they encounter.
            </p>

            <h2 className="flex items-center gap-3 text-2xl font-semibold text-foreground mt-10 mb-4">
              <Monitor className="w-6 h-6 text-primary shrink-0" /> 2. Accessibility Features
            </h2>
            <p>Current accessibility features implemented on SmartMoneyTools include:</p>
            <ul>
              <li><strong>Semantic HTML:</strong> Pages use appropriate heading hierarchy (H1 → H2 → H3), landmark regions, and semantic elements to support screen readers.</li>
              <li><strong>Keyboard navigation:</strong> All interactive elements (buttons, form fields, dropdowns, links) are reachable and operable using a keyboard alone without requiring a mouse.</li>
              <li><strong>ARIA labels:</strong> Form inputs carry descriptive aria-label or associated label elements so screen readers can announce the purpose of each field.</li>
              <li><strong>Colour contrast:</strong> Text and interactive elements are styled to meet or exceed the WCAG AA minimum contrast ratio of 4.5:1 for normal text and 3:1 for large text.</li>
              <li><strong>Dark mode:</strong> A theme toggle is available in the site header for users who prefer reduced light or high-contrast dark interfaces.</li>
              <li><strong>Responsive design:</strong> Pages reflow correctly at viewport widths from 320px upward, supporting users who zoom or use small-screen devices.</li>
              <li><strong>Focus indicators:</strong> Visible focus outlines are displayed on interactive elements when navigating by keyboard.</li>
              <li><strong>Reduced motion:</strong> Animations on this site are suppressed for users who have enabled the "prefers-reduced-motion" system setting.</li>
              <li><strong>Alt text:</strong> Meaningful images include descriptive alt attributes; decorative images use empty alt attributes to prevent screen readers announcing them.</li>
              <li><strong>Skip navigation:</strong> We are working to add a "skip to main content" link on all pages to allow keyboard users to bypass repeated navigation.</li>
            </ul>

            <h2 className="flex items-center gap-3 text-2xl font-semibold text-foreground mt-10 mb-4">
              <Keyboard className="w-6 h-6 text-primary shrink-0" /> 3. Known Limitations
            </h2>
            <p>
              While we strive for full WCAG 2.1 AA compliance, we are aware of some current limitations:
            </p>
            <ul>
              <li><strong>Interactive charts:</strong> The Recharts data visualisations used in several calculator results panels (for example, amortization timelines and portfolio growth charts) provide visual-only output. We plan to add accessible data tables as equivalents for all charts. In the interim, numerical results are always presented in a text-based breakdown panel alongside each chart.</li>
              <li><strong>Complex dropdowns:</strong> Some multi-level navigation elements may not be fully optimised for all screen reader/browser combinations. We are auditing these.</li>
              <li><strong>Third-party advertising:</strong> Advertisements served by Google AdSense are outside our direct control and may not fully meet WCAG 2.1 standards. We report accessibility issues to Google where identified.</li>
              <li><strong>Skip navigation link:</strong> A "skip to main content" link is not yet present on all pages. This is on our improvement roadmap.</li>
            </ul>
            <p>
              We are conducting ongoing accessibility testing and intend to address these limitations progressively. We do not believe any of these limitations fundamentally prevents users from accessing calculator results or educational content.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">4. Testing and Compliance</h2>
            <p>
              We test accessibility using a combination of:
            </p>
            <ul>
              <li>Automated checks using browser developer tools and extensions.</li>
              <li>Manual keyboard-only navigation testing.</li>
              <li>Screen reader testing using NVDA on Windows and VoiceOver on macOS/iOS.</li>
              <li>Colour contrast checking using WebAIM's Contrast Checker.</li>
              <li>Mobile testing on Android and iOS at viewport widths of 320px, 375px, and 430px.</li>
            </ul>
            <p>
              We have not yet commissioned a formal third-party accessibility audit. This is on our improvement roadmap for 2026/27.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">5. How to Get Content in a Different Format</h2>
            <p>
              If you need information from SmartMoneyTools in a different format — for example, large print, audio, or an alternative file format — please contact us using the details below. We will do our best to accommodate reasonable requests within 5 business days.
            </p>

            <h2 className="flex items-center gap-3 text-2xl font-semibold text-foreground mt-10 mb-4">
              <Mail className="w-6 h-6 text-primary shrink-0" /> 6. How to Report Accessibility Issues
            </h2>
            <p>
              We welcome feedback about accessibility barriers you encounter on SmartMoneyTools. If you find content that is difficult or impossible to use with your assistive technology, please tell us:
            </p>
            <ul>
              <li><strong>Email:</strong> <a href="mailto:support@smartmoney-tools.com">support@smartmoney-tools.com</a> — use the subject line "Accessibility Feedback".</li>
              <li><strong>Contact form:</strong> <Link to="/contact">smartmoney-tools.com/contact</Link> — select "Accessibility Feedback" from the category dropdown.</li>
            </ul>
            <p>
              Please describe the accessibility barrier you encountered, the page URL, the assistive technology you are using (for example, NVDA 2024.1 on Windows 11 with Chrome 126), and what you were trying to do when you encountered the problem.
            </p>
            <p>
              We will acknowledge your report within 5 business days and aim to resolve confirmed accessibility barriers within 30 days, or provide a workaround where an immediate fix is not possible.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">7. Enforcement and Escalation</h2>
            <p>
              If you are not satisfied with our response to an accessibility complaint, you may wish to contact the <a href="https://equalityhumanrights.com" target="_blank" rel="noopener noreferrer">Equality and Human Rights Commission (EHRC)</a>, which enforces the Equality Act 2010. The EHRC provides guidance on digital accessibility rights in the UK.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">8. Our Commitment to Improvement</h2>
            <p>
              SmartMoneyTools is committed to progressively improving accessibility. Planned improvements for 2026/27 include:
            </p>
            <ul>
              <li>Adding accessible data-table equivalents for all interactive charts.</li>
              <li>Adding a "skip to main content" link to all pages.</li>
              <li>Completing a screen-reader audit of all calculator form inputs.</li>
              <li>Commissioning a formal third-party WCAG 2.1 AA accessibility audit.</li>
            </ul>
            <p>
              This statement will be updated as improvements are implemented. The "Last reviewed" date at the top of this page reflects when the statement was last substantively updated.
            </p>

            <div className="mt-12 pt-8 border-t border-border text-sm text-muted-foreground">
              <p>Related: <Link to="/contact">Contact Us</Link> · <Link to="/privacy">Privacy Policy</Link> · <Link to="/corrections-policy">Corrections Policy</Link></p>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
}
