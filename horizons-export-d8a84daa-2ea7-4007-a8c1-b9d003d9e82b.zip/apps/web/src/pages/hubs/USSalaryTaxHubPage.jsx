import React from 'react';
import TopicHub from '@/components/TopicHub.jsx';

export default function USSalaryTaxHubPage() {
  return (
    <TopicHub
      path="/hubs/us-salary-tax"
      title="US Salary & Tax"
      intro="Understand your US paycheck and plan for retirement. Federal income tax uses progressive brackets with a standard deduction, FICA takes Social Security and Medicare tax, and most states add their own income tax on top. Put your numbers in to see the real picture, then plan your 401(k) and IRA contributions."
      calculators={[
        {
          path: '/us-salary-calculator',
          title: 'US Salary Calculator 2026',
          desc: 'Estimate federal income tax, FICA (Social Security and Medicare) and take-home pay using 2026 brackets and the standard deduction.',
        },
        {
          path: '/us-retirement-calculator',
          title: 'US Retirement Calculator',
          desc: 'Project retirement income from Social Security, 401(k) and IRA balances, and see how much you need to save to hit your target.',
        },
      ]}
      chooseRightGuide={[
        {
          question: '“What will I actually take home this year?”',
          answer: 'Use the US salary calculator for federal tax and FICA.',
          link: { path: '/us-salary-calculator', text: 'US Salary Calculator 2026' },
        },
        {
          question: '“Will I have enough to retire?”',
          answer: 'Use the US retirement calculator to project Social Security and account balances.',
          link: { path: '/us-retirement-calculator', text: 'US Retirement Calculator' },
        },
      ]}
      relatedHubs={[
        { path: '/hubs/pensions-retirement', title: 'Pensions & retirement' },
        { path: '/hubs/uk-salary-tax', title: 'UK salary & tax' },
      ]}
    />
  );
}
