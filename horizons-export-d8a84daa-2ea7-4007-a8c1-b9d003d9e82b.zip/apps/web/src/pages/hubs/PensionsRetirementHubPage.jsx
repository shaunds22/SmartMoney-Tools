import React from 'react';
import TopicHub from '@/components/TopicHub.jsx';

export default function PensionsRetirementHubPage() {
  return (
    <TopicHub
      path="/hubs/pensions-retirement"
      title="Pensions & Retirement"
      intro="Build a retirement pot that will actually support the life you want — and know how to access it. Understand workplace pensions and auto-enrolment, make the most of tax relief and the £60,000 Annual Allowance, decide whether salary sacrifice beats normal contributions, and plan for retiring before State Pension age."
      calculators={[
        {
          path: '/pensions-calculator',
          title: 'Pensions Calculator',
          desc: 'Project your pension pot from current contributions, growth and time to retirement, and estimate the income it could produce.',
        },
        {
          path: '/us-retirement-calculator',
          title: 'US Retirement Calculator',
          desc: 'For US readers: Social Security, 401(k) and IRA projections and your retirement savings gap.',
        },
      ]}
      groups={[
        {
          need: 'Planning how much I need to retire',
          context: 'Start with the end — the income you want — and work back to the contributions that get you there.',
          guides: [
            {
              path: '/guides/pension-planning',
              title: 'Pension planning & retirement target',
              desc: 'How to estimate your retirement income needs and plan a drawdown strategy to meet them.',
            },
          ],
        },
        {
          need: 'Making the most of contributions and tax relief',
          context: 'Tax relief is free money from the government. Get the contribution level, the collection method and the allowances right.',
          guides: [
            {
              path: '/guides/pension-contributions',
              title: 'Optimising pension contributions and tax relief',
              desc: 'How much to pay in, what it really costs your take-home, the three collection methods, the Annual Allowance and the £100,000 trap.',
            },
            {
              path: '/guides/workplace-pensions',
              title: 'Workplace pensions & auto-enrolment',
              desc: 'Employer contributions, minimums, tax relief and how to get more than the default into your pot.',
            },
          ],
        },
        {
          need: 'Salary sacrifice vs normal contributions',
          context: 'How you pay in changes both your take-home pay and your pot — and the difference is not always obvious.',
          guides: [
            {
              path: '/guides/salary-sacrifice-vs-normal-pension',
              title: 'Salary sacrifice vs normal pension',
              desc: 'How the two contribution methods differ in NI savings, take-home pay and long-term pot growth — and the trade-offs before signing.',
            },
          ],
        },
        {
          need: 'Retiring before State Pension age',
          context: 'Accessing your pot early means bridging the gap until the State Pension kicks in.',
          guides: [
            {
              path: '/guides/early-retirement',
              title: 'Early retirement planning guide',
              desc: 'Pension access rules from age 55, bridging income, and the cost of retiring before State Pension age.',
            },
          ],
        },
      ]}
      chooseRightGuide={[
        {
          question: '“How much do I need to save for retirement?”',
          answer: 'The pension planning guide helps you set the target.',
          link: { path: '/guides/pension-planning', text: 'Pension planning & retirement target' },
        },
        {
          question: '“How much should I contribute, and what does it cost my take-home?”',
          answer: 'The contributions guide covers tax relief, the collection methods and the Annual Allowance.',
          link: { path: '/guides/pension-contributions', text: 'Optimising pension contributions and tax relief' },
        },
        {
          question: '“Should I use salary sacrifice?”',
          answer: 'The salary-sacrifice guide compares the two contribution methods.',
          link: { path: '/guides/salary-sacrifice-vs-normal-pension', text: 'Salary sacrifice vs normal pension' },
        },
      ]}
      relatedHubs={[
        { path: '/hubs/uk-salary-tax', title: 'UK salary & tax' },
        { path: '/hubs/savings', title: 'Savings & compound interest' },
        { path: '/hubs/us-salary-tax', title: 'US salary & tax' },
      ]}
    />
  );
}
