import React from 'react';
import TopicHub from '@/components/TopicHub.jsx';

export default function UKSalaryTaxHubPage() {
  return (
    <TopicHub
      path="/hubs/uk-salary-tax"
      title="UK Salary & Tax"
      intro="Understand every line on your payslip and keep more of what you earn. From gross-to-net pay and tax codes to National Insurance, student loan deductions and legal ways to reduce your bill — built around the 2026/27 UK tax year."
      calculators={[
        {
          path: '/uk-salary-calculator',
          title: 'UK Salary Calculator 2026/27',
          desc: 'Enter your gross salary and see income tax, National Insurance, student loan and pension deductions itemised down to net pay.',
        },
        {
          path: '/budget-planner',
          title: 'Budget Planner',
          desc: 'Lay your take-home pay against your real monthly spending to see exactly what is left to save or overpay.',
        },
      ]}
      groups={[
        {
          need: 'Understanding my payslip and take-home pay',
          context: 'What each deduction is, how gross pay becomes the number that hits your account, and how take-home compares across salaries.',
          guides: [
            {
              path: '/guides/calculate-take-home-pay',
              title: 'How to calculate your UK take-home pay',
              desc: 'A complete gross-to-net walkthrough: tax codes, PAYE, every deduction, take-home at common salaries, and the decisions that move the number.',
            },
          ],
        },
        {
          need: 'How income tax and National Insurance work',
          context: 'The two biggest deductions — the bands, thresholds and allowances behind them.',
          guides: [
            {
              path: '/guides/uk-income-tax',
              title: 'Comprehensive UK income tax guide',
              desc: 'Tax bands, the Personal Allowance, the higher-rate trap and relief strategies to optimise net income.',
            },
            {
              path: '/guides/national-insurance',
              title: 'National Insurance guide',
              desc: 'NI contribution classes, thresholds and how paying NI secures your State Pension and benefits.',
            },
          ],
        },
        {
          need: 'Student loan repayments',
          context: 'Repayments that behave like a graduate tax — understand them so you can plan around them.',
          guides: [
            {
              path: '/guides/student-loan-repayments',
              title: 'Student loan repayments guide',
              desc: 'Plan thresholds, repayment rates, and how deductions change as your salary rises.',
            },
          ],
        },
        {
          need: 'Legally reducing my tax bill',
          context: 'Use the allowances and reliefs you are entitled to — within the rules.',
          guides: [
            {
              path: '/guides/tax-planning',
              title: 'Advanced tax planning guide',
              desc: 'Legal strategies to lower your tax bill through pensions, ISAs and allowances.',
            },
            {
              path: '/guides/marriage-allowance',
              title: 'Marriage Allowance guide',
              desc: 'Eligibility and the claiming process for transferring £1,260 of Personal Allowance between couples.',
            },
          ],
        },
      ]}
      chooseRightGuide={[
        {
          question: '“What will my actual take-home pay be, and how do I read my payslip?”',
          answer: 'Use the calculator, then read the take-home-pay guide for what each line means and how take-home compares across salaries.',
          link: { path: '/guides/calculate-take-home-pay', text: 'How to calculate your UK take-home pay' },
        },
        {
          question: '“How is my income tax calculated?”',
          answer: 'The income tax guide covers bands and the Personal Allowance.',
          link: { path: '/guides/uk-income-tax', text: 'Comprehensive UK income tax guide' },
        },
      ]}
      relatedHubs={[
        { path: '/hubs/pensions-retirement', title: 'Pensions & retirement' },
        { path: '/hubs/self-employment', title: 'Self-employment' },
        { path: '/hubs/us-salary-tax', title: 'US salary & tax' },
      ]}
    />
  );
}
