import React from 'react';
import TopicHub from '@/components/TopicHub.jsx';

export default function DebtHubPage() {
  return (
    <TopicHub
      path="/hubs/debt"
      title="Debt & Repayment"
      intro="A clear path out of debt, whatever kind you are carrying. Compare payoff strategies that actually work, understand the true cost of borrowing before you take it on, and know when consolidating helps — and when it just digs a deeper hole."
      calculators={[
        {
          path: '/debt-snowball-calculator',
          title: 'Debt Snowball Calculator',
          desc: 'Map every debt, pick a payoff order, and see your debt-free date and total interest saved.',
        },
      ]}
      groups={[
        {
          need: 'Choosing a payoff strategy',
          context: 'Two proven methods — snowball and avalanche — put side by side so you can pick the one that fits your balances and your psychology.',
          guides: [
            {
              path: '/guides/debt-repayment',
              title: 'Debt repayment strategies: snowball vs avalanche',
              desc: 'The shared rule, the two ordering methods compared with worked numbers, when they disagree, and a hybrid that often works best.',
            },
          ],
        },
        {
          need: 'Dealing with credit card debt',
          context: 'The most common — and most expensive — trap. Specific tactics to break the spiral.',
          guides: [
            {
              path: '/guides/credit-card-debt',
              title: 'Escaping credit card debt',
              desc: 'How minimum-payment interest works, balance transfers, and the order to clear multiple cards.',
            },
          ],
        },
        {
          need: 'Understanding a loan before you take it',
          context: 'The monthly payment hides the true cost. Compare properly before signing.',
          guides: [
            {
              path: '/guides/personal-loan',
              title: 'Personal loans explained',
              desc: 'Interest rates, terms, APR and when an unsecured loan makes sense versus other options.',
            },
            {
              path: '/guides/compare-loan-repayments',
              title: 'Compare loan repayments before borrowing',
              desc: 'Look past the monthly payment and calculate the total cost of credit across loans.',
            },
          ],
        },
        {
          need: 'Should I consolidate my debts?',
          context: 'Rolling several debts into one can lower your rate — or just reset the clock.',
          guides: [
            {
              path: '/guides/debt-consolidation',
              title: 'Debt consolidation guide',
              desc: 'When combining debts genuinely helps, how it works, and the traps that leave you worse off.',
            },
          ],
        },
      ]}
      chooseRightGuide={[
        {
          question: '“Which debt should I pay off first, and how do I build a plan?”',
          answer: 'The repayment guide compares snowball vs avalanche and builds the full battle plan.',
          link: { path: '/guides/debt-repayment', text: 'Debt repayment strategies: snowball vs avalanche' },
        },
        {
          question: '“Is this loan a good deal before I take it?”',
          answer: 'Compare the true total cost with the loan-comparison guide.',
          link: { path: '/guides/compare-loan-repayments', text: 'Compare loan repayments before borrowing' },
        },
      ]}
      relatedHubs={[
        { path: '/hubs/savings', title: 'Savings & compound interest' },
        { path: '/hubs/uk-salary-tax', title: 'UK salary & tax' },
      ]}
    />
  );
}
