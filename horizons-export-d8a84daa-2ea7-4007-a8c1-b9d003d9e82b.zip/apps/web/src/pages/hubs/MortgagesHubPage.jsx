import React from 'react';
import TopicHub from '@/components/TopicHub.jsx';

export default function MortgagesHubPage() {
  return (
    <TopicHub
      path="/hubs/mortgages"
      title="Mortgages & Home Buying"
      intro="Everything you need to move from renting to owning — or to manage a mortgage you already have. Work out what you can borrow, budget for the hidden costs of buying, choose the right mortgage type, and decide whether overpaying is worth it for you."
      calculators={[
        {
          path: '/mortgage',
          title: 'Mortgage Repayment Calculator',
          desc: 'See your monthly payment, total interest and full amortisation schedule for any loan amount, rate and term.',
        },
      ]}
      groups={[
        {
          need: 'How much can I borrow?',
          context: 'Before you fall in love with a property, find out what a lender will actually offer you.',
          guides: [
            {
              path: '/guides/mortgage-affordability-first-time-buyers',
              title: 'Mortgage affordability for first-time buyers',
              desc: 'Income multiples, deposit requirements and lender stress tests — how the borrowing cap is actually calculated.',
            },
          ],
        },
        {
          need: 'The full first-time buyer journey: process, costs and budget',
          context: 'From the Agreement in Principle to collecting the keys — including every upfront cost and the ongoing monthly shift from renting to owning.',
          guides: [
            {
              path: '/guides/first-time-buyer',
              title: "First-time buyer's guide: process, costs and budget",
              desc: 'Agreements in Principle, how much you can borrow, the day-one cash checklist, the monthly housing-cost shift, and the process from offer to completion.',
            },
          ],
        },
        {
          need: 'Choosing and understanding a mortgage',
          context: 'Once you know what you can borrow, compare the product types so you pick the right one.',
          guides: [
            {
              path: '/guides/mortgage-comprehensive',
              title: 'Comprehensive mortgage guide',
              desc: 'Fixed vs tracker, repayment vs interest-only, fees and true affordability — how mortgage products differ.',
            },
          ],
        },
        {
          need: 'Should I overpay my mortgage?',
          context: 'Overpaying can save tens of thousands in interest — but it is not always the best use of spare cash.',
          guides: [
            {
              path: '/guides/mortgage-overpayments',
              title: 'Mortgage overpayments & interest savings',
              desc: 'How overpaying strips years off your term, when overpayment limits bite, and when saving or investing beats it.',
            },
          ],
        },
      ]}
      chooseRightGuide={[
        {
          question: '“How much can I borrow?”',
          answer: 'Use the affordability guide — it covers income multiples and stress tests.',
          link: { path: '/guides/mortgage-affordability-first-time-buyers', text: 'Mortgage affordability for first-time buyers' },
        },
        {
          question: '“Walk me through buying, and what will it cost me?”',
          answer: 'The first-time buyer guide covers the whole process, every upfront cost and the monthly shift.',
          link: { path: '/guides/first-time-buyer', text: "First-time buyer's guide: process, costs and budget" },
        },
        {
          question: '“Which mortgage type should I pick?”',
          answer: 'The comprehensive guide compares fixed, tracker and interest-only products.',
          link: { path: '/guides/mortgage-comprehensive', text: 'Comprehensive mortgage guide' },
        },
      ]}
      relatedHubs={[
        { path: '/hubs/savings', title: 'Savings & compound interest' },
        { path: '/hubs/uk-salary-tax', title: 'UK salary & tax' },
      ]}
    />
  );
}
