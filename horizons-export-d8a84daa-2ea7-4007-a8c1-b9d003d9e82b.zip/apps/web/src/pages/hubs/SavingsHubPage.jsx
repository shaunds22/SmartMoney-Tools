import React from 'react';
import TopicHub from '@/components/TopicHub.jsx';

export default function SavingsHubPage() {
  return (
    <TopicHub
      path="/hubs/savings"
      title="Savings & Compound Interest"
      intro="How to turn income into a growing pot of money — whether that is a safety net for emergencies, a house deposit, or long-term wealth. Understand how compound interest actually works, set targets you will stick to, and choose the right account (and tax wrapper) for each goal."
      calculators={[
        {
          path: '/compound-interest',
          title: 'Compound Interest Calculator',
          desc: 'See how a lump sum and regular deposits grow over time at any interest rate, with or without monthly contributions.',
        },
        {
          path: '/savings-goal-calculator',
          title: 'Savings Goal Calculator',
          desc: 'Work backwards from a target amount and deadline to the monthly contribution you need to hit it.',
        },
      ]}
      groups={[
        {
          need: 'Understanding how compound interest works',
          context: 'The core idea that makes saving pay off — the Rule of 72, what monthly deposits grow into, and the pitfalls that quietly destroy compounding.',
          guides: [
            {
              path: '/guides/compound-interest-monthly-deposits',
              title: 'Compound interest: how monthly deposits grow your money',
              desc: 'How compounding works, the Rule of 72, and concrete numbers showing what a regular monthly habit becomes over 10, 20 and 30 years.',
            },
          ],
        },
        {
          need: 'Setting a target I will actually hit',
          context: 'A goal with a number and a deadline is the difference between saving and wishing — and stress-testing it against your budget is what stops it collapsing.',
          guides: [
            {
              path: '/guides/savings-goals',
              title: 'Setting and reaching your savings goals',
              desc: 'The maths of reaching a target and the behavioural side: making a goal specific, stress-testing it, and automating the habit.',
            },
          ],
        },
        {
          need: 'Building an emergency fund',
          context: 'Cash you can reach fast so an unexpected bill does not become debt — how much, in what order, and where to keep it.',
          guides: [
            {
              path: '/guides/emergency-fund',
              title: 'Building an emergency fund',
              desc: 'How to size the target from your real essential spending, build it in the right order, and keep it accessible but beating inflation.',
            },
          ],
        },
        {
          need: 'Getting the best return and paying no tax',
          context: 'Once you are saving, make sure interest is competitive and shielded from tax.',
          guides: [
            {
              path: '/guides/high-interest-savings',
              title: 'Maximising high-interest savings',
              desc: 'How to compare accounts, chase the best rates, and combat inflation erosion on cash.',
            },
            {
              path: '/guides/tax-free-savings',
              title: 'Tax-free savings (ISAs) guide',
              desc: 'Cash ISAs, Lifetime ISAs and Premium Bonds — which wrapper protects which kind of savings.',
            },
          ],
        },
      ]}
      chooseRightGuide={[
        {
          question: '“How does compound interest actually work?”',
          answer: 'The compound interest guide explains the concept, the Rule of 72 and what monthly deposits grow into.',
          link: { path: '/guides/compound-interest-monthly-deposits', text: 'Compound interest: how monthly deposits grow your money' },
        },
        {
          question: '“How do I set and reach a savings target?”',
          answer: 'The savings goals guide covers the maths and the behaviour, with a stress test against your budget.',
          link: { path: '/guides/savings-goals', text: 'Setting and reaching your savings goals' },
        },
        {
          question: '“How big should my emergency fund be?”',
          answer: 'The emergency fund guide sizes it from your real essential spending and income stability.',
          link: { path: '/guides/emergency-fund', text: 'Building an emergency fund' },
        },
      ]}
      relatedHubs={[
        { path: '/hubs/mortgages', title: 'Mortgages & home buying' },
        { path: '/hubs/pensions-retirement', title: 'Pensions & retirement' },
        { path: '/hubs/debt', title: 'Debt & repayment' },
      ]}
    />
  );
}
