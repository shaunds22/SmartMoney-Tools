import React from 'react';
import TopicHub from '@/components/TopicHub.jsx';

export default function SelfEmploymentHubPage() {
  return (
    <TopicHub
      path="/hubs/self-employment"
      title="Self-Employment"
      intro="Run the numbers behind being your own boss — from sole-trader profit and Self Assessment to irregular income and tax on a side hustle. Understand what counts as turnover, what you can claim, and how to plan for the tax bill so it never surprises you."
      calculators={[
        {
          path: '/self-employed-tax-calculator',
          title: 'Self-Employed Tax Calculator UK',
          desc: 'Estimate Self Assessment income tax, National Insurance and the £1,000 Trading Allowance on your sole-trader profit.',
        },
      ]}
      groups={[
        {
          need: 'Understanding my sole-trader income and profit',
          context: 'Turnover is not profit. Get the basics right before you calculate tax.',
          guides: [
            {
              path: '/guides/self-employment-income',
              title: 'Self-employment income guide',
              desc: 'Turnover, allowable expenses and profit — the foundations of your tax obligations as a sole trader.',
            },
          ],
        },
        {
          need: 'Doing my Self Assessment and cutting my tax bill',
          context: 'File correctly and claim everything you are entitled to.',
          guides: [
            {
              path: '/guides/self-employed-tax-planning',
              title: 'Self-employed tax planning basics',
              desc: 'Self Assessment, allowable expenses, Payments on Account and VAT — a survival guide for sole traders.',
            },
          ],
        },
        {
          need: 'Managing irregular or freelance income',
          context: 'When pay arrives in lumps, budgeting and tax forecasting need a different approach.',
          guides: [
            {
              path: '/guides/freelance-income',
              title: 'Freelance income & cash flow guide',
              desc: 'Smooth irregular income, forecast tax and build financial stability as a UK freelancer.',
            },
          ],
        },
        {
          need: 'Tax on a side hustle or extra income',
          context: 'Earning on top of a job? Know the allowances and when you must report it.',
          guides: [
            {
              path: '/guides/side-hustle-tax',
              title: 'Side hustle tax guide',
              desc: 'The £1,000 Trading Allowance, registration thresholds and how to report side income correctly.',
            },
          ],
        },
      ]}
      chooseRightGuide={[
        {
          question: '“What profit do I actually make, and what is taxable?”',
          answer: 'The self-employment income guide covers turnover, expenses and profit.',
          link: { path: '/guides/self-employment-income', text: 'Self-employment income guide' },
        },
        {
          question: '“How do I file and lower my tax bill?”',
          answer: 'The tax-planning guide covers Self Assessment, allowable expenses and VAT.',
          link: { path: '/guides/self-employed-tax-planning', text: 'Self-employed tax planning basics' },
        },
        {
          question: '“My income is irregular — how do I budget for tax?”',
          answer: 'The freelance income guide is built for lumpy cash flow.',
          link: { path: '/guides/freelance-income', text: 'Freelance income & cash flow guide' },
        },
        {
          question: '“Do I need to report my side hustle?”',
          answer: 'The side-hustle guide explains the Trading Allowance and thresholds.',
          link: { path: '/guides/side-hustle-tax', text: 'Side hustle tax guide' },
        },
      ]}
      relatedHubs={[
        { path: '/hubs/uk-salary-tax', title: 'UK salary & tax' },
        { path: '/hubs/pensions-retirement', title: 'Pensions & retirement' },
      ]}
    />
  );
}
