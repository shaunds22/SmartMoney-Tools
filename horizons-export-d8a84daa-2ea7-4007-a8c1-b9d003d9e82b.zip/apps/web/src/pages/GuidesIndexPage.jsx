import React, { useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/card.jsx';
import { Link } from 'react-router-dom';
import { setPageMeta } from '@/utils/seo.js';
import { BookOpen, Star, Compass, ArrowRight } from 'lucide-react';

const topicHubs = [
  { path: '/hubs/mortgages', title: 'Mortgages & Home Buying', desc: 'How much you can borrow, the real cost of buying, choosing a mortgage and overpaying.' },
  { path: '/hubs/savings', title: 'Savings & Compound Interest', desc: 'How compounding works, goals you will stick to, emergency funds and tax-free accounts.' },
  { path: '/hubs/debt', title: 'Debt & Repayment', desc: 'Snowball vs avalanche, escaping credit card debt, comparing loans and consolidation.' },
  { path: '/hubs/uk-salary-tax', title: 'UK Salary & Tax', desc: 'Take-home pay, income tax, National Insurance, student loans and legal tax planning.' },
  { path: '/hubs/us-salary-tax', title: 'US Salary & Tax', desc: 'Federal tax brackets, FICA, the standard deduction and 401(k)/IRA retirement planning.' },
  { path: '/hubs/pensions-retirement', title: 'Pensions & Retirement', desc: 'Workplace pensions, tax relief, salary sacrifice, the Annual Allowance and early retirement.' },
  { path: '/hubs/self-employment', title: 'Self-Employment', desc: 'Sole-trader profit, Self Assessment, allowable expenses, freelance cash flow and side-hustle tax.' },
];

export default function GuidesIndexPage() {
  useEffect(() => {
    setPageMeta(
      'Financial Guides | SmartMoneyTools',
      'Comprehensive UK financial guides covering salary, tax, pensions, savings, debt, and mortgages. Clear, actionable advice for your financial journey.',
      'https://smartmoney-tools.com/guides'
    );
  }, []);

  const categories = [
    {
      title: "Salary & Income",
      guides: [
        { title: "Calculate True Take-Home Pay", desc: "Gross-to-net, tax codes, every deduction, and take-home compared across salaries.", path: "/guides/calculate-take-home-pay", featured: true },
        { title: "Student Loan Repayments", desc: "Understand thresholds and how loans function as a graduate tax.", path: "/guides/student-loan-repayments", featured: true },
        { title: "Self-Employment Income", desc: "Turnover, profit, and tax obligations for sole traders.", path: "/guides/self-employment-income" },
        { title: "Freelance Income Guide", desc: "Managing irregular income and tax planning for freelancers.", path: "/guides/freelance-income" },
        { title: "Side Hustle Tax Guide", desc: "Maximize your trading allowance and report side income.", path: "/guides/side-hustle-tax" }
      ]
    },
    {
      title: "Tax Planning",
      guides: [
        { title: "UK Income Tax Guide", desc: "Master tax bands, personal allowances, and relief.", path: "/guides/uk-income-tax" },
        { title: "Self-Employed Tax Planning", desc: "Navigate Self Assessment and allowable expenses.", path: "/guides/self-employed-tax-planning", featured: true },
        { title: "National Insurance Guide", desc: "Understand NI contributions, thresholds, and state benefits.", path: "/guides/national-insurance" },
        { title: "Tax Planning Guide", desc: "Legal strategies to reduce your tax bill efficiently.", path: "/guides/tax-planning" },
        { title: "Marriage Allowance Guide", desc: "Eligibility and claiming process for couples.", path: "/guides/marriage-allowance" }
      ]
    },
    {
      title: "Pensions & Retirement",
      guides: [
        { title: "Salary Sacrifice vs Normal", desc: "Maximize take-home pay and pension growth effectively.", path: "/guides/salary-sacrifice-vs-normal-pension", featured: true },
        { title: "Workplace Pensions Guide", desc: "Automatic enrolment, contributions, and employer matches.", path: "/guides/workplace-pensions" },
        { title: "Pension Contributions Guide", desc: "Tax relief, NI savings, the Annual Allowance and the £100,000 trap.", path: "/guides/pension-contributions", featured: true },
        { title: "Pension Planning Guide", desc: "Plan your retirement pots and calculate income needs.", path: "/guides/pension-planning" },
        { title: "Early Retirement Guide", desc: "Pension access rules and bridging income to State Pension age.", path: "/guides/early-retirement" }
      ]
    },
    {
      title: "Savings & Investments",
      guides: [
        { title: "Compound Interest Guide", desc: "How compounding works, the Rule of 72, and what monthly deposits grow into over time.", path: "/guides/compound-interest-monthly-deposits", featured: true },
        { title: "Building an Emergency Fund", desc: "How much to save, the build order, and where to keep it accessible and beating inflation.", path: "/guides/emergency-fund" },
        { title: "Savings Goals Guide", desc: "Size a target, stress-test it against your budget, and automate the habit.", path: "/guides/savings-goals" },
        { title: "High-Interest Savings Guide", desc: "Find the best rates and maximize your interest returns.", path: "/guides/high-interest-savings" },
        { title: "Tax-Free Savings Guide", desc: "Utilize ISAs and Premium Bonds to shield your wealth.", path: "/guides/tax-free-savings" }
      ]
    },
    {
      title: "Debt Management",
      guides: [
        { title: "Debt Repayment Guide", desc: "Snowball vs avalanche compared, with worked numbers and when to seek free help.", path: "/guides/debt-repayment", featured: true },
        { title: "Compare Loan Repayments", desc: "Look past the monthly payment and calculate true cost.", path: "/guides/compare-loan-repayments", featured: true },
        { title: "Credit Card Debt Guide", desc: "Understand interest traps and how to escape the spiral.", path: "/guides/credit-card-debt" },
        { title: "Personal Loan Guide", desc: "Navigate interest rates, terms, and affordability.", path: "/guides/personal-loan" },
        { title: "Debt Consolidation Guide", desc: "When combining debts helps, and how to avoid the pitfalls.", path: "/guides/debt-consolidation" }
      ]
    },
    {
      title: "Mortgage & Housing",
      guides: [
        { title: "Mortgage Overpayments", desc: "Strip years off your term and save tens of thousands.", path: "/guides/mortgage-overpayments", featured: true },
        { title: "Mortgage Affordability", desc: "How much can you borrow? Income multiples, deposits and stress tests.", path: "/guides/mortgage-affordability-first-time-buyers" },
        { title: "Comprehensive Mortgage", desc: "Understand mortgage types, rates, and affordability.", path: "/guides/mortgage-comprehensive" },
        { title: "First-Time Buyer Guide", desc: "The full journey: borrowing, every upfront and ongoing cost, and offer to completion.", path: "/guides/first-time-buyer", featured: true }
      ]
    }
  ];

  return (
    <div className="flex flex-col w-full bg-background py-16">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="text-center mb-14">
          <BookOpen className="h-12 w-12 text-primary mx-auto mb-4" />
          <h1 className="text-4xl md:text-5xl font-extrabold mb-4 text-foreground tracking-tight text-balance">Financial Library</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Comprehensive, actionable, UK-focused financial guides. Browse by topic to find the calculators and guides that answer your specific question — from your first payslip to early retirement.
          </p>
        </div>

        {/* Topic hubs — browse by question, not keyword */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-foreground mb-2 flex items-center gap-2">
            <Compass className="h-6 w-6 text-primary" /> Browse by topic
          </h2>
          <p className="text-muted-foreground mb-6 max-w-3xl">
            Each topic hub features the relevant calculators and groups guides by the actual question you are trying to answer — with a short intro and help picking the right page when articles overlap.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {topicHubs.map((hub) => (
              <Link key={hub.path} to={hub.path} className="group flex h-full">
                <Card className="flex flex-col w-full h-full hover:shadow-lg transition-all duration-300 border-border/50 group-hover:border-primary/40 bg-card group-hover:-translate-y-1">
                  <CardHeader className="flex-grow">
                    <CardTitle className="text-lg group-hover:text-primary transition-colors leading-tight mb-2 flex items-center justify-between">
                      {hub.title}
                      <ArrowRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity text-primary" />
                    </CardTitle>
                    <CardDescription className="text-sm leading-relaxed">
                      {hub.desc}
                    </CardDescription>
                  </CardHeader>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        <div className="border-t border-border pt-12">
          <h2 className="text-2xl font-bold text-foreground mb-2">All guides by category</h2>
          <p className="text-muted-foreground mb-10 max-w-3xl">
            The full library, grouped by area. Each guide links back to its topic hub and to the calculators that put the numbers behind the advice.
          </p>
        </div>

        <div className="space-y-16">
          {categories.map((category, idx) => (
            <section key={idx}>
              <h2 className="text-2xl font-bold text-foreground mb-6 border-b pb-2 flex items-center">
                {category.title}
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {category.guides.map((guide, gIdx) => (
                  <Link key={gIdx} to={guide.path} className="group flex h-full">
                    <Card className="flex flex-col w-full h-full hover:shadow-lg transition-all duration-300 border-border/50 group-hover:border-primary/40 bg-card group-hover:-translate-y-1">
                      <CardHeader className="flex-grow">
                        <div className="flex justify-between items-start mb-2 gap-2">
                          <CardTitle className="text-lg group-hover:text-primary transition-colors leading-tight">
                            {guide.title}
                          </CardTitle>
                          {guide.featured && (
                            <span className="flex-shrink-0 bg-primary/10 text-primary text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full flex items-center">
                              <Star className="w-3 h-3 mr-1 fill-primary" /> New
                            </span>
                          )}
                        </div>
                        <CardDescription className="text-sm mt-2 leading-relaxed">
                          {guide.desc}
                        </CardDescription>
                      </CardHeader>
                    </Card>
                  </Link>
                ))}
              </div>
            </section>
          ))}
        </div>

        <div className="mt-16 rounded-2xl border border-border/60 bg-muted/40 px-6 py-6 text-center">
          <p className="text-sm text-muted-foreground leading-relaxed">
            Every guide is written and maintained by{' '}
            <Link to="/author/shaun-da-silva" className="font-medium text-primary hover:underline">Shaun Da Silva</Link>
            , Financial Consultant with over 20 years in the financial sector.{' '}
            <Link to="/author/shaun-da-silva" className="font-medium text-primary hover:underline">View author profile</Link>
            {' '}or read our{' '}
            <Link to="/editorial-policy" className="font-medium text-primary hover:underline">Editorial Policy</Link>.
          </p>
        </div>
      </div>
    </div>
  );
}