import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import DisclaimerBanner from '@/components/DisclaimerBanner.jsx';
import HowWeCalculateThis from '@/components/HowWeCalculateThis.jsx';
import CalculatorContentSection from '@/components/CalculatorContentSection.jsx';
import { Link } from 'react-router-dom';
import { setPageMeta } from '@/utils/seo.js';
import { Trash2, Plus } from 'lucide-react';
import useCurrency from '@/hooks/useCurrency.js';
import AuthorAttribution from '@/components/AuthorAttribution.jsx';

export default function DebtSnowballCalculatorPage() {
  const { currency } = useCurrency();
  const [debts, setDebts] = useState([
    { id: 1, name: 'Credit Card', balance: 3000, rate: 19.9, payment: 100 },
    { id: 2, name: 'Car Loan', balance: 12000, rate: 5.5, payment: 250 }
  ]);
  const [extraPayment, setExtraPayment] = useState(150);

  useEffect(() => {
    // Reset state on mount
    setDebts([
      { id: 1, name: 'Credit Card', balance: 3000, rate: 19.9, payment: 100 },
      { id: 2, name: 'Car Loan', balance: 12000, rate: 5.5, payment: 250 }
    ]);
    setExtraPayment(150);
    
    setPageMeta('Debt Snowball Calculator | SmartMoneyTools', 'Plan your debt-free date using the snowball method.', 'https://smartmoney-tools.com/debt-snowball-calculator');
  }, []);

  const totalDebt = debts.reduce((sum, d) => sum + (Number(d.balance) || 0), 0);
  const minPayments = debts.reduce((sum, d) => sum + (Number(d.payment) || 0), 0);

  return (
    <div className="flex flex-col w-full bg-background py-12">
      <div className="container mx-auto px-4 max-w-5xl">
        <div className="mb-4">
          <span className="inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-sm font-medium text-primary border border-primary/20">Last reviewed: 11 September 2026</span>
        </div>
        <h1 className="text-4xl font-extrabold mb-4 text-balance">Debt Snowball Calculator</h1>
        <AuthorAttribution lastReviewedDate="2026-09-11" />
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-card p-6 rounded-2xl border shadow-sm">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold">Your Debts</h2>
                <Button variant="outline" size="sm" onClick={() => setDebts([...debts, { id: Date.now(), name: 'New Debt', balance: 0, rate: 0, payment: 0 }])}><Plus className="w-4 h-4 mr-1"/> Add Debt</Button>
              </div>
              {debts.map((d) => (
                <div key={d.id} className="grid grid-cols-5 gap-3 items-end mb-4 border-b pb-4 last:border-0">
                  <div className="col-span-2">
                    <Label className="text-xs">Debt Name</Label>
                    <Input value={d.name} onChange={(e) => setDebts(debts.map(x => x.id === d.id ? {...x, name: e.target.value} : x))} aria-label="Debt Name" />
                  </div>
                  <div>
                    <Label className="text-xs">Balance ({currency.symbol})</Label>
                    <Input type="number" value={d.balance} onChange={(e) => setDebts(debts.map(x => x.id === d.id ? {...x, balance: e.target.value} : x))} aria-label={`Balance in ${currency.symbol}`} />
                  </div>
                  <div>
                    <Label className="text-xs">Rate %</Label>
                    <Input type="number" value={d.rate} onChange={(e) => setDebts(debts.map(x => x.id === d.id ? {...x, rate: e.target.value} : x))} aria-label="Interest Rate" />
                  </div>
                  <div className="flex gap-2">
                    <div className="flex-1">
                      <Label className="text-xs">Min Pay ({currency.symbol})</Label>
                      <Input type="number" value={d.payment} onChange={(e) => setDebts(debts.map(x => x.id === d.id ? {...x, payment: e.target.value} : x))} aria-label={`Minimum Payment in ${currency.symbol}`} />
                    </div>
                    <Button variant="ghost" size="icon" className="mt-6" onClick={() => setDebts(debts.filter(x => x.id !== d.id))} aria-label="Delete Debt"><Trash2 className="w-4 h-4 text-destructive"/></Button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-card p-6 rounded-2xl border shadow-sm">
              <h2 className="text-xl font-bold mb-4">Snowball Strategy</h2>
              <div className="mb-6">
                <Label>Extra Monthly Payment ({currency.symbol})</Label>
                <Input type="number" value={extraPayment} onChange={(e) => setExtraPayment(Number(e.target.value))} />
              </div>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Total Debt</span>
                  <span className="font-bold">{currency.symbol}{totalDebt.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Min Payments</span>
                  <span className="font-bold">{currency.symbol}{minPayments.toLocaleString()}</span>
                </div>
                <div className="flex justify-between font-bold pt-2 border-t text-primary text-lg">
                  <span>Total Monthly</span>
                  <span>{currency.symbol}{(minPayments + extraPayment).toLocaleString()}</span>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-4">
                The Snowball method focuses your extra payment on the smallest balance first to build momentum.
              </p>
            </div>
          </div>
        </div>

        <HowWeCalculateThis region="UK" />

        <DisclaimerBanner />

        <div className="mt-16 max-w-4xl mx-auto">
          <CalculatorContentSection title="Who this calculator is for">
            <p>This tool is for anyone juggling several debts — credit cards, store cards, a car loan, a personal loan — who feels like they're treading water. It applies the <strong>Debt Snowball</strong> method, a strategy built on behavioural momentum rather than pure maths: you clear the smallest balance first for a quick psychological win, then roll that freed-up payment into the next debt, and so on until you're debt-free.</p>
            <p>If you owe money across multiple accounts and want a clear, motivating plan rather than a spreadsheet of minimum payments, this is the place to start.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="What you need before you start">
            <ul>
              <li>The <strong>current balance</strong> on each debt — not the original amount you borrowed.</li>
              <li>The <strong>interest rate (APR)</strong> on each, from your statement or online account.</li>
              <li>The <strong>minimum monthly payment</strong> each lender asks for.</li>
              <li>An honest figure for the <strong>extra</strong> you can throw at debt each month on top of all the minimums. Use our <Link to="/budget-planner" className="text-primary hover:underline">Budget Planner</Link> to find it — it's your income minus essential spending.</li>
            </ul>
            <p>Keep a small starter emergency fund (around {currency.symbol}1,000) before going all-in on debt; otherwise the next unexpected bill sends you straight back to the credit card.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="What each input means">
            <ul>
              <li><strong>Debt Name</strong> — a label so you can tell your cards and loans apart (e.g. "Barclaycard", "Car Loan").</li>
              <li><strong>Balance ({currency.symbol})</strong> — what you still owe today.</li>
              <li><strong>Rate %</strong> — the annual interest rate. The snowball ignores this for ordering purposes, but it's useful context and matters if you're comparing against the avalanche method.</li>
              <li><strong>Min Pay ({currency.symbol})</strong> — the minimum the lender requires each month. You keep paying this on every debt throughout the plan.</li>
              <li><strong>Extra Monthly Payment ({currency.symbol})</strong> — the additional amount you direct at your smallest balance. This is the fuel for the snowball; the bigger it is, the faster you finish.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="How the snowball method works">
            <p>The snowball ignores interest rates when choosing what to attack first. Instead it ranks debts by balance, smallest to largest:</p>
            <ol>
              <li>List every debt from smallest balance to largest, regardless of APR.</li>
              <li>Pay the minimum on every debt except the smallest.</li>
              <li>Throw your entire "extra" payment at the smallest balance until it's gone.</li>
              <li>When it's cleared, take the money you were paying on it (minimum + extra) and add it to the next-smallest debt's minimum.</li>
              <li>Repeat. Each cleared debt "snowballs" into the next, so your payment on the final debt is the sum of everything — powerful and motivating.</li>
            </ol>
            <p>The summary panel shows your total debt, total minimums, and the combined monthly amount you'll commit throughout the plan.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Worked example">
            <p>Three debts and {currency.symbol}150 extra each month:</p>
            <ul>
              <li><strong>Store Card:</strong> {currency.symbol}500 balance (Min pay: {currency.symbol}25)</li>
              <li><strong>Credit Card:</strong> {currency.symbol}2,000 balance (Min pay: {currency.symbol}60)</li>
              <li><strong>Car Loan:</strong> {currency.symbol}8,000 balance (Min pay: {currency.symbol}200)</li>
            </ul>
            <p>You pay minimums on the Credit Card and Car Loan, and attack the Store Card with its {currency.symbol}25 minimum <em>plus</em> your {currency.symbol}150 extra ({currency.symbol}175 total). The Store Card clears in about 3 months. Now you roll that {currency.symbol}175 onto the Credit Card's {currency.symbol}60 minimum — {currency.symbol}235 a month — and it disappears fast. Finally, the full {currency.symbol}435 a month lands on the Car Loan. Each step is faster than the last because the payment keeps growing.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Snowball versus avalanche">
            <p>The snowball's rival is the <strong>avalanche</strong>, which targets the highest interest rate first. Mathematically the avalanche saves more money, because you kill the most expensive debt earliest. But research on real people shows the snowball has a higher completion rate, because the early "win" of clearing a whole account keeps motivation high. If you have a single debt at a punitive rate — a payday loan, for example — clear that first regardless of balance, then snowball the rest. For a deeper comparison, read our <Link to="/guides/debt-repayment" className="text-primary hover:underline">debt repayment guide</Link>.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Common mistakes to avoid">
            <ul>
              <li><strong>Taking on new debt mid-plan.</strong> The snowball only works if you stop digging. Cut up or freeze the cards while you execute it.</li>
              <li><strong>Absorbing freed-up payments.</strong> When a debt clears, the temptation is to spend that minimum on lifestyle. You must roll it into the next debt or the maths collapses.</li>
              <li><strong>Skipping the emergency fund.</strong> Without a small cash buffer, every surprise expense becomes new debt and resets your progress.</li>
              <li><strong>Ignoring a predatory rate.</strong> The snowball orders by balance, but a payday loan at four-figure APR should be cleared immediately regardless of size.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Sensible next steps">
            <ul>
              <li>Use the <Link to="/budget-planner" className="text-primary hover:underline">Budget Planner</Link> to maximise your "extra" payment — even an extra {currency.symbol}50 a month shaves months off the plan.</li>
              <li>Once debt-free, redirect the entire snowball payment into savings so the habit isn't lost — your first goal should be a full 3–6 month emergency fund.</li>
              <li>If you're struggling to meet minimums, contact a free debt charity such as <a href="https://www.stepchange.org/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">StepChange</a> before things escalate.</li>
              <li>Check whether a 0% balance-transfer card could reduce interest while you snowball — but only if you won't be tempted to spend on it.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Related guides and calculators">
            <ul>
              <li><Link to="/budget-planner" className="text-primary hover:underline">Budget Planner</Link>: Find the extra cash to fuel your snowball.</li>
              <li><Link to="/savings-goal-calculator" className="text-primary hover:underline">Savings Goal Calculator</Link>: Plan your emergency fund before tackling debt.</li>
              <li><Link to="/guides/debt-repayment" className="text-primary hover:underline">Debt Repayment Guide</Link>: The full comparison of the two methods.</li>
              <li><Link to="/guides/credit-card-debt" className="text-primary hover:underline">Escaping Credit Card Debt Guide</Link>: Balance transfers and breaking the debt spiral.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Sources and references">
            <p className="text-sm bg-primary/5 p-3 rounded-lg border border-primary/20 mb-4">SmartMoneyTools checks statutory rates and thresholds against official government publications. Results are estimates for educational purposes and may not reflect every individual circumstance. <strong>Last reviewed: 11 September 2026.</strong></p>
            <p>The debt reduction strategies discussed align with guidance from major financial counselling organisations:</p>
            <ul>
              <li><a href="https://www.stepchange.org/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">StepChange Debt Charity — free independent debt advice</a></li>
              <li><a href="https://www.moneyhelper.org.uk/en/dealing-with-debt" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">MoneyHelper — dealing with debt</a></li>
              <li><a href="https://www.citizensadvice.org.uk/debt-and-money/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Citizens Advice — managing creditors and debt solutions</a></li>
            </ul>
          </CalculatorContentSection>
          
          <div className="mt-12 pt-8 border-t border-border text-center">
            <p className="text-muted-foreground text-sm">
              Want to know exactly how we calculate these numbers? <Link to="/calculation-methodology" className="text-primary hover:underline font-medium">See our calculation methodology</Link>.
            </p>
          </div>
          
        </div>
      </div>
    </div>
  );
}
