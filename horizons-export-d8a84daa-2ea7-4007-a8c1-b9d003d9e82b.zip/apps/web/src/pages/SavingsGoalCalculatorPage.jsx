import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import DisclaimerBanner from '@/components/DisclaimerBanner.jsx';
import HowWeCalculateThis from '@/components/HowWeCalculateThis.jsx';
import CalculatorContentSection from '@/components/CalculatorContentSection.jsx';
import { Link } from 'react-router-dom';
import { setPageMeta } from '@/utils/seo.js';
import useCurrency from '@/hooks/useCurrency.js';
import AuthorAttribution from '@/components/AuthorAttribution.jsx';

export default function SavingsGoalCalculatorPage() {
  const { currency } = useCurrency();
  const [goal, setGoal] = useState(20000);
  const [current, setCurrent] = useState(5000);
  const [years, setYears] = useState(5);
  const [rate, setRate] = useState(4);
  const [monthlyRequired, setMonthlyRequired] = useState(0);

  useEffect(() => {
    // Reset state on mount
    setGoal(20000);
    setCurrent(5000);
    setYears(5);
    setRate(4);
    setMonthlyRequired(0);
    
    setPageMeta('Savings Goal Calculator | SmartMoneyTools', 'Calculate how much you need to save monthly to hit your financial goals.', 'https://smartmoney-tools.com/savings-goal-calculator');
  }, []);

  useEffect(() => {
    let months = years * 12;
    let r = (rate / 100) / 12;
    
    if (r === 0) {
      setMonthlyRequired(Math.max(0, (goal - current) / months));
    } else {
      let fvCurrent = current * Math.pow(1 + r, months);
      let shortfall = goal - fvCurrent;
      if (shortfall <= 0) {
        setMonthlyRequired(0);
      } else {
        let pmt = shortfall / ((Math.pow(1 + r, months) - 1) / r);
        setMonthlyRequired(pmt);
      }
    }
  }, [goal, current, years, rate]);

  return (
    <div className="flex flex-col w-full bg-background py-12">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="mb-4 text-center">
          <span className="inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-sm font-medium text-primary border border-primary/20">Last reviewed: 11 September 2026</span>
        </div>
        <h1 className="text-4xl font-extrabold mb-4 text-center text-balance">Savings Goal Calculator</h1>
        <AuthorAttribution lastReviewedDate="2026-09-11" />
        
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="space-y-6 bg-card p-6 rounded-2xl border shadow-sm">
            <div>
              <Label>Target Amount ({currency.symbol})</Label>
              <Input type="number" value={goal} onChange={(e) => setGoal(Number(e.target.value))} />
            </div>
            <div>
              <Label>Current Savings ({currency.symbol})</Label>
              <Input type="number" value={current} onChange={(e) => setCurrent(Number(e.target.value))} />
            </div>
            <div>
              <Label>Years to Goal</Label>
              <Input type="number" value={years} onChange={(e) => setYears(Number(e.target.value))} />
            </div>
            <div>
              <Label>Expected Annual Return (%)</Label>
              <Input type="number" value={rate} onChange={(e) => setRate(Number(e.target.value))} />
            </div>
          </div>
          
          <div className="bg-primary text-primary-foreground p-8 rounded-2xl border shadow-sm flex flex-col justify-center text-center">
            <h2 className="text-xl font-medium mb-2 opacity-90">Required Monthly Savings</h2>
            <div className="text-5xl font-extrabold mb-6">
              {currency.symbol}{monthlyRequired.toLocaleString(undefined, {maximumFractionDigits: 2})}
            </div>
            <p className="text-sm opacity-80 max-w-xs mx-auto">
              Save this amount every month to reach your {currency.symbol}{goal.toLocaleString()} target in {years} years, assuming a {rate}% annual return.
            </p>
          </div>
        </div>

        <HowWeCalculateThis region="UK" />

        <DisclaimerBanner />

        <div className="mt-16">
          <CalculatorContentSection title="What this calculator answers">
            <p>Most savings tools ask "what will my money be worth?" This one works in reverse: you tell it the target, the deadline, and the return you expect, and it tells you the <strong>monthly deposit</strong> required to get there. It's the difference between a vague ambition ("I want to save for a house deposit") and a concrete, dated plan ("I need to put away {currency.symbol}468 a month for four years").</p>
            <p>It factors in the growth your existing savings and your ongoing contributions will earn, so the figure it returns is the gap that's actually left after compounding has done some of the work for you.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Who it is designed for">
            <ul>
              <li><strong>Prospective homebuyers</strong> working out the monthly savings rate needed to build a 10% or 20% deposit by a target date.</li>
              <li><strong>Emergency-fund builders</strong> mapping a realistic timeline to 3–6 months of essential spending.</li>
              <li><strong>Parents</strong> saving towards university costs or a nest egg for a child.</li>
              <li><strong>Anyone with a specific target</strong> — a wedding, a car, a trip — who wants to turn a wish into a dated monthly commitment.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="What you need before you start">
            <ul>
              <li>A <strong>specific target figure</strong> in today's money. If the goal is years away, consider whether inflation means you should aim higher (see common mistakes below).</li>
              <li>Your <strong>current savings</strong> earmarked for this goal — what's already in the pot.</li>
              <li>A realistic <strong>timeframe</strong> in years.</li>
              <li>An honest <strong>expected return</strong>. Match it to the asset: 3–5% for cash savings or a Cash ISA, 6–8% for a diversified Stocks & Shares ISA over 5+ years. Don't plug in 10% for a risk-free account.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="What each input means">
            <ul>
              <li><strong>Target Amount ({currency.symbol})</strong> — the lump sum you want to have saved by your deadline, in today's money.</li>
              <li><strong>Current Savings ({currency.symbol})</strong> — what you've already put aside for this goal. The calculator projects its growth and subtracts it from the target.</li>
              <li><strong>Years to Goal</strong> — how long you have. More time means compounding does more of the heavy lifting, so your required monthly amount drops.</li>
              <li><strong>Expected Annual Return (%)</strong> — the yearly growth you assume on the whole pot. The higher (and riskier) the return, the less of your own cash you need to contribute.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="How to read your result">
            <p>The big number is the <strong>fixed monthly deposit</strong> you'd need to make every month, on time, to hit your target. If it shows {currency.symbol}0, your current savings are projected to grow to the target on their own — no further contributions needed. If the figure feels unaffordable, you have three levers: extend the timeframe, lower the target, or seek a higher (but riskier) return. Extending the timeframe is usually the most powerful because compounding is exponential — a small increase in years can cut the monthly requirement dramatically.</p>
            <p>Treat the result as a floor, not a ceiling. Real returns fluctuate, so saving slightly more than the calculator suggests gives you a buffer against disappointing years.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Worked example">
            <p>A first-time buyer aiming for a house deposit:</p>
            <ul>
              <li><strong>Target Goal:</strong> {currency.symbol}30,000</li>
              <li><strong>Current Savings:</strong> {currency.symbol}5,000</li>
              <li><strong>Timeframe:</strong> 4 years</li>
              <li><strong>Interest Rate:</strong> 4.5% (a typical regular-saver or Cash ISA rate)</li>
            </ul>
            <p>Without interest, they'd need {currency.symbol}520 a month. But because the pot grows at 4.5%, the calculator shows they only need to save <strong>{currency.symbol}468.42 a month</strong>. Over four years, compound interest contributes more than {currency.symbol}2,500 toward the deposit — a meaningful reduction in the monthly burden.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Assumptions and exclusions">
            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">Assumptions</h3>
            <ul>
              <li>A constant interest rate for the whole period. Real savings rates move with the Bank of England base rate.</li>
              <li>The exact calculated deposit made at the end of every month, without fail.</li>
              <li>No withdrawals from the pot during the accumulation phase.</li>
              <li>Monthly compounding of interest.</li>
            </ul>
            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">What is not included</h3>
            <ul>
              <li>The tax benefits of UK wrappers like ISAs and Lifetime ISAs (LISAs). A LISA adds a 25% government bonus on contributions up to {currency.symbol}4,000/year, which can dramatically reduce the monthly amount you need to find yourself.</li>
              <li>Inflation. A {currency.symbol}50,000 goal in ten years buys less than {currency.symbol}50,000 today — consider raising the target for long horizons.</li>
              <li>Tax on interest earned outside an ISA (the Personal Savings Allowance is {currency.symbol}1,000 for basic-rate, {currency.symbol}500 for higher-rate taxpayers).</li>
              <li>Market volatility for investment-based goals (sequence-of-returns risk).</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Common mistakes to avoid">
            <ul>
              <li><strong>Ignoring inflation.</strong> A distant goal in nominal pounds will under-deliver in real purchasing power. For horizons over five years, consider raising the target or using a Stocks & Shares ISA.</li>
              <li><strong>Overstating the return.</strong> Assuming 10% on a cash account produces a plan that fails. Match the rate to the asset's real risk and return.</li>
              <li><strong>Forgetting the LISA bonus.</strong> First-time buyers under 50 can get {currency.symbol}1,000 of government money for every {currency.symbol}4,000 saved — not using it is leaving free money on the table.</li>
              <li><strong>Setting an unaffordable monthly figure.</strong> If the result is more than your budget allows, adjust the goal or timeframe rather than abandoning the plan entirely.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Sensible next steps">
            <ul>
              <li>Check the result against your <Link to="/budget-planner" className="text-primary hover:underline">Budget Planner</Link> surplus. If it fits, set up a standing order so the money leaves your account on payday — you won't miss what you never see.</li>
              <li>Choose the right home for the money: a Cash ISA or regular saver for goals under 5 years, a Stocks & Shares ISA for 5+ years where you can tolerate short-term dips.</li>
              <li>If you're a first-time buyer, open a Lifetime ISA to claim the 25% government bonus — see <a href="https://www.gov.uk/lifetime-isa" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Lifetime ISA</a>.</li>
              <li>Re-run the calculation whenever your circumstances change — a pay rise, a moved deadline, or a new target all shift the monthly requirement.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Related guides and calculators">
            <ul>
              <li><Link to="/compound-interest" className="text-primary hover:underline">Compound Interest Calculator</Link>: See how your money grows if you simply leave it alone.</li>
              <li><Link to="/budget-planner" className="text-primary hover:underline">Budget Planner</Link>: Find the monthly surplus to meet your new savings target.</li>
              <li><Link to="/guides/savings-goals" className="text-primary hover:underline">Savings Goals Guide</Link>: Strategies for accelerating your savings rate.</li>
              <li><Link to="/guides/tax-free-savings" className="text-primary hover:underline">Tax-Free Savings (ISAs) Guide</Link>: Shielding your goal's growth from tax.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Sources and references">
            <p className="text-sm bg-primary/5 p-3 rounded-lg border border-primary/20 mb-4">SmartMoneyTools checks statutory rates and thresholds against official government publications. Results are estimates for educational purposes and may not reflect every individual circumstance. <strong>Last reviewed: 11 September 2026.</strong></p>
            <ul>
              <li><a href="https://www.gov.uk/individual-savings-accounts" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Individual Savings Accounts (ISAs)</a></li>
              <li><a href="https://www.gov.uk/lifetime-isa" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Lifetime ISA</a></li>
              <li><a href="https://www.moneyhelper.org.uk/en/savings/types-of-savings" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">MoneyHelper – Types of savings accounts</a></li>
              <li><a href="https://www.fca.org.uk/consumers/savings-accounts" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">FCA – Savings accounts guidance</a></li>
            </ul>
          </CalculatorContentSection>
          
          <div className="mt-12 pt-8 border-t border-border text-center">
            <p className="text-muted-foreground text-sm">
              Want to know exactly how we calculate these numbers? <Link to="/calculation-methodology" className="text-primary hover:underline font-medium">See our calculation methodology</Link>.
            </p>
          </div>
          
        </div>
      </div>
    </div>
  );
}
