import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import DisclaimerBanner from '@/components/DisclaimerBanner.jsx';
import HowWeCalculateThis from '@/components/HowWeCalculateThis.jsx';
import CalculatorContentSection from '@/components/CalculatorContentSection.jsx';
import { Link } from 'react-router-dom';
import { setPageMeta } from '@/utils/seo.js';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { Trash2, Plus } from 'lucide-react';
import useCurrency from '@/hooks/useCurrency.js';
import AuthorAttribution from '@/components/AuthorAttribution.jsx';

export default function BudgetPlannerPage() {
  const { currency } = useCurrency();
  const [incomes, setIncomes] = useState([{ id: 1, name: 'Salary', amount: 3000 }]);
  const [expenses, setExpenses] = useState([
    { id: 1, name: 'Housing', amount: 1000 },
    { id: 2, name: 'Groceries', amount: 400 },
    { id: 3, name: 'Transport', amount: 200 }
  ]);

  useEffect(() => {
    // Reset state on mount to ensure clean slate without persistence
    setIncomes([{ id: 1, name: 'Salary', amount: 3000 }]);
    setExpenses([
      { id: 1, name: 'Housing', amount: 1000 },
      { id: 2, name: 'Groceries', amount: 400 },
      { id: 3, name: 'Transport', amount: 200 }
    ]);
    
    setPageMeta('Budget Planner | SmartMoneyTools', 'Manage your monthly budget and track expenses.', 'https://smartmoney-tools.com/budget-planner');
  }, []);

  const totalIncome = incomes.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
  const totalExpense = expenses.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
  const remaining = totalIncome - totalExpense;

  const chartData = expenses.filter(e => e.amount > 0).map(e => ({ name: e.name, value: Number(e.amount) }));
  const COLORS = ['hsl(var(--calc-chart-1))', 'hsl(var(--calc-chart-2))', 'hsl(var(--calc-chart-3))', 'hsl(var(--calc-chart-4))', 'hsl(var(--calc-chart-5))'];

  return (
    <div className="flex flex-col w-full bg-background py-12">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="mb-4">
          <span className="inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-sm font-medium text-primary border border-primary/20">Last reviewed: 11 September 2026</span>
        </div>
        <h1 className="text-4xl font-extrabold mb-4 text-balance">Monthly Budget Planner</h1>
        <AuthorAttribution lastReviewedDate="2026-09-11" />
        <div className="grid lg:grid-cols-12 gap-8 mb-12">
          <div className="lg:col-span-7 space-y-8">
            
            {/* Income */}
            <div className="bg-card p-6 rounded-2xl border shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">Income ({currency.symbol})</h2>
                <Button variant="outline" size="sm" onClick={() => setIncomes([...incomes, { id: Date.now(), name: 'New Income', amount: 0 }])}><Plus className="w-4 h-4 mr-1"/> Add</Button>
              </div>
              {incomes.map(inc => (
                <div key={inc.id} className="flex gap-4 items-center mb-3">
                  <Input value={inc.name} onChange={(e) => setIncomes(incomes.map(i => i.id === inc.id ? {...i, name: e.target.value} : i))} className="flex-1" aria-label="Income Name" />
                  <Input type="number" value={inc.amount} onChange={(e) => setIncomes(incomes.map(i => i.id === inc.id ? {...i, amount: e.target.value} : i))} className="w-32" aria-label={`Income Amount in ${currency.symbol}`} />
                  <Button variant="ghost" size="icon" onClick={() => setIncomes(incomes.filter(i => i.id !== inc.id))} aria-label="Delete Income"><Trash2 className="w-4 h-4 text-destructive"/></Button>
                </div>
              ))}
            </div>

            {/* Expenses */}
            <div className="bg-card p-6 rounded-2xl border shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">Expenses ({currency.symbol})</h2>
                <Button variant="outline" size="sm" onClick={() => setExpenses([...expenses, { id: Date.now(), name: 'New Expense', amount: 0 }])}><Plus className="w-4 h-4 mr-1"/> Add</Button>
              </div>
              {expenses.map(exp => (
                <div key={exp.id} className="flex gap-4 items-center mb-3">
                  <Input value={exp.name} onChange={(e) => setExpenses(expenses.map(x => x.id === exp.id ? {...x, name: e.target.value} : x))} className="flex-1" aria-label="Expense Name" />
                  <Input type="number" value={exp.amount} onChange={(e) => setExpenses(expenses.map(x => x.id === exp.id ? {...x, amount: e.target.value} : x))} className="w-32" aria-label={`Expense Amount in ${currency.symbol}`} />
                  <Button variant="ghost" size="icon" onClick={() => setExpenses(expenses.filter(x => x.id !== exp.id))} aria-label="Delete Expense"><Trash2 className="w-4 h-4 text-destructive"/></Button>
                </div>
              ))}
            </div>

          </div>

          <div className="lg:col-span-5 bg-card p-6 rounded-2xl border shadow-sm flex flex-col">
            <h2 className="text-2xl font-bold mb-6">Summary</h2>
            <div className="space-y-4 mb-8">
              <div className="flex justify-between items-center p-3 bg-secondary rounded-lg">
                <span className="font-medium">Total Income</span>
                <span className="font-bold">{currency.symbol}{totalIncome.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-secondary rounded-lg">
                <span className="font-medium">Total Expenses</span>
                <span className="font-bold">{currency.symbol}{totalExpense.toLocaleString()}</span>
              </div>
              <div className={`flex justify-between items-center p-3 rounded-lg text-white ${remaining >= 0 ? 'bg-primary' : 'bg-destructive'}`}>
                <span className="font-medium">Remaining</span>
                <span className="font-bold text-xl">{currency.symbol}{remaining.toLocaleString()}</span>
              </div>
            </div>
            
            <div className="h-64 w-full mt-4">
              {chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={chartData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80}>
                      {chartData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                    </Pie>
                    <Tooltip formatter={(value) => `${currency.symbol}${value}`} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-muted-foreground">Add expenses to see chart</div>
              )}
            </div>
          </div>
        </div>

        <HowWeCalculateThis region="UK" />

        <DisclaimerBanner />

        <div className="mt-16 max-w-4xl mx-auto">
          <CalculatorContentSection title="Who this planner is for">
            <p>This is a back-to-basics cash-flow tool. It subtracts what you spend from what you earn to reveal your monthly surplus — the money available to save, invest, or throw at debt. It suits anyone who has never written down their numbers, households recalibrating after a change in income, and people who have found extra cash in their budget and want to deploy it deliberately rather than let it drift away.</p>
            <p>It is deliberately simple. If you already track spending in a banking app and want forecasting or bank-sync features, this tool is not trying to replace that — it is a quick, honest snapshot you can build in two minutes.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="What you need before you start">
            <ul>
              <li>Your <strong>net (take-home) pay</strong>, not gross salary — the amount that actually lands in your account after tax, NI, pension, and student loan deductions. Use our <Link to="/uk-salary-calculator" className="text-primary hover:underline">UK Salary Calculator</Link> if you're unsure.</li>
              <li>Any other regular income — benefits, side income, child benefit, rental income.</li>
              <li>A rough breakdown of monthly spending. The fastest way is to open your last two months of bank statements and group transactions into categories.</li>
              <li>Annual costs that don't appear every month (car insurance, Christmas, holidays) — divide each by 12 and add as a line so they don't ambush you later.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="What each input means">
            <ul>
              <li><strong>Income rows</strong> — each source of money coming in this month, named and amounted in {currency.symbol}. Add as many as you need (salary, freelance, benefits).</li>
              <li><strong>Expense rows</strong> — each category of spending this month. Group similar items (e.g. one "Groceries" line rather than every receipt) so the chart stays readable.</li>
              <li><strong>Add / Delete buttons</strong> — create new rows or remove ones you don't need. The totals and chart update instantly.</li>
              <li><strong>Summary panel</strong> — totals your income and expenses and shows the <strong>Remaining</strong> balance, colour-coded green (surplus) or red (deficit).</li>
              <li><strong>Pie chart</strong> — shows each expense as a share of total spending, so you can see at a glance which category dominates.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="How to read your summary">
            <p>The single most important number is <strong>Remaining</strong>. A positive figure is your monthly savings capacity — the engine behind every other financial goal on this site. A negative figure means you are spending more than you earn and accumulating debt, and the priority is to close that gap before anything else.</p>
            <p>The pie chart tells you <em>where</em> the money goes. A common benchmark is the <strong>50/30/20 rule</strong>: roughly 50% of net income on needs (housing, bills, groceries, transport), 30% on wants (dining out, subscriptions, hobbies), and 20% on savings or debt repayment. If your "needs" slice swallows 70% of income, housing or transport is likely the pressure point. If a single category dominates the chart, that's the first place to look for savings.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Worked example">
            <p>A two-person household with combined net pay of {currency.symbol}3,200 a month:</p>
            <ul>
              <li><strong>Income:</strong> {currency.symbol}3,200 (Combined net salaries)</li>
              <li><strong>Housing (Rent/Mortgage):</strong> {currency.symbol}1,100</li>
              <li><strong>Utilities & Council Tax:</strong> {currency.symbol}350</li>
              <li><strong>Groceries:</strong> {currency.symbol}450</li>
              <li><strong>Transport (Fuel/Fares):</strong> {currency.symbol}250</li>
              <li><strong>Subscriptions & Entertainment:</strong> {currency.symbol}150</li>
            </ul>
            <p>Total expenses equal {currency.symbol}2,300, leaving a <strong>Remaining balance of {currency.symbol}900</strong>. Housing consumes roughly 34% of net income — within healthy guidelines — and the surplus gives this household real options: an emergency fund, overpaying the mortgage, or boosting pension contributions.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Common mistakes to avoid">
            <ul>
              <li><strong>Forgetting annual costs.</strong> Car MOTs, Christmas, and annual subscriptions quietly break budgets. Divide each by 12 and add it as a monthly "sinking fund" line.</li>
              <li><strong>Guessing instead of checking.</strong> People routinely underestimate grocery spend by 30–40%. Base your figures on the last two months of actual statements, not optimistic guesses.</li>
              <li><strong>Leaving the surplus unassigned.</strong> A {currency.symbol}900 surplus that sits in a current account gets spent. Give every pound a job the moment it arrives — move it to savings or a debt overpayment the same day.</li>
              <li><strong>Using gross pay.</strong> Budgeting against pre-tax salary hides the real constraint and leads to overspending.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Sensible next steps">
            <ul>
              <li>If you have a surplus, point it at your highest-priority goal first — usually a starter emergency fund of {currency.symbol}1,000, then high-interest debt, then 3–6 months of essential spending.</li>
              <li>If you have a deficit, the pie chart shows which category to attack. Housing and transport are the biggest levers; subscriptions and dining out are the quickest wins.</li>
              <li>Revisit this planner whenever your income changes — a new job, a pay rise, or a new recurring bill all shift the picture.</li>
              <li>For irregular income (freelance, zero-hours), build the budget around a conservative monthly average, not a bumper month.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Related guides and calculators">
            <ul>
              <li><Link to="/uk-salary-calculator" className="text-primary hover:underline">UK Salary Calculator</Link>: Determine your exact net income to input into this budget.</li>
              <li><Link to="/debt-snowball-calculator" className="text-primary hover:underline">Debt Snowball Calculator</Link>: Use your "Remaining" balance to aggressively pay down debts.</li>
              <li><Link to="/savings-goal-calculator" className="text-primary hover:underline">Savings Goal Calculator</Link>: Allocate your surplus cash to hit specific financial targets.</li>
              <li><Link to="/guides/savings-goals" className="text-primary hover:underline">Savings Goals Guide</Link>: Strategies for turning a monthly surplus into real progress.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Sources and references">
            <p className="text-sm bg-primary/5 p-3 rounded-lg border border-primary/20 mb-4">SmartMoneyTools checks statutory rates and thresholds against official government publications. Results are estimates for educational purposes and may not reflect every individual circumstance. <strong>Last reviewed: 11 September 2026.</strong></p>
            <p>Budgeting principles and average household spending data are informed by:</p>
            <ul>
              <li><a href="https://www.ons.gov.uk/peoplepopulationandcommunity/personalandhouseholdfinances/expenditure" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Office for National Statistics — Family spending in the UK</a></li>
              <li><a href="https://www.moneyhelper.org.uk/en/everyday-money/budgeting" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">MoneyHelper — Budgeting guidance</a></li>
              <li><a href="https://www.citizensadvice.org.uk/debt-and-money/budgeting/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Citizens Advice — Managing living costs</a></li>
            </ul>
          </CalculatorContentSection>

          <div className="mt-12 pt-8 border-t border-border text-center">
            <p className="text-muted-foreground text-sm">
              Want to know exactly how we calculate these numbers? <Link to="/calculation-methodology" className="text-primary hover:underline font-medium">See our calculation methodology</Link>.
            </p>
          </div>

        </div>
      </div>
    </div>
  );
}
