import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Mail, ShieldCheck, Phone, Loader2, MessageSquare, Bug, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { toast } from 'sonner';
import { setPageMeta } from '@/utils/seo.js';
import pb from '@/lib/pocketbaseClient.js';
import { Link } from 'react-router-dom';

function ContactPage() {
  const initialFormState = {
    name: '',
    email: '',
    phone: '',
    category: '',
    subject: '',
    message: ''
  };

  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    setPageMeta(
      'Contact SmartMoneyTools | Get Help',
      'Have questions? Contact SmartMoneyTools. We\'re here to help with any questions about our financial calculators.',
      'https://smartmoney-tools.com/contact'
    );
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleSelectChange = (value) => {
    setFormData(prev => ({ ...prev, category: value }));
  };

  const validateForm = () => {
    const newErrors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    if (!formData.subject.trim()) newErrors.subject = 'Subject is required';
    if (!formData.message.trim()) newErrors.message = 'Message is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error("Please fix the errors in the form before submitting.");
      return;
    }

    setIsSubmitting(true);
    
    try {
      await pb.collection('contact_submissions').create({
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        category: formData.category,
        subject: formData.subject,
        message: formData.message
      }, { $autoCancel: false });
      
      toast.success('Thank you! Your message has been sent to support@smartmoney-tools.com');
      setFormData(initialFormState);
    } catch (error) {
      console.error('Contact submission error:', error);
      toast.error(error.message || 'Failed to send message. Please try emailing us directly at support@smartmoney-tools.com');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col w-full">
      <section className="bg-primary text-primary-foreground py-16 lg:py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-3xl mx-auto text-center"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight" style={{ letterSpacing: '-0.02em' }}>
              Get in Touch
            </h1>
            <p className="text-xl text-primary-foreground/90 leading-relaxed max-w-2xl mx-auto">
              Have a question, suggestion, or found a bug? We're here to help you navigate our financial tools.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-20 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-12 lg:gap-16">
            
            {/* Sidebar */}
            <div className="lg:col-span-1 space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-4">Contact Information</h2>
                <p className="text-muted-foreground mb-6 text-base">
                  Fill out the form to send us a message, or reach out directly via email. We aim to respond to all enquiries within 24–48 hours.
                </p>
              </div>

              {/* Direct Email Card */}
              <div className="bg-card border border-border rounded-2xl p-6 shadow-sm relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-5">
                  <Mail className="w-24 h-24" />
                </div>
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <MessageSquare className="h-5 w-5 text-primary" />
                    </div>
                    <h3 className="font-semibold text-foreground text-lg">Direct Email</h3>
                  </div>
                  <a 
                    href="mailto:support@smartmoney-tools.com" 
                    className="text-primary hover:text-primary/80 font-medium text-base break-all transition-colors block mb-2"
                  >
                    support@smartmoney-tools.com
                  </a>
                  <p className="text-sm text-muted-foreground">
                    For urgent enquiries, email us directly.
                  </p>
                </div>
              </div>

              {/* Privacy Note */}
              <div className="bg-muted/50 p-5 rounded-xl border border-border">
                <h3 className="font-semibold text-foreground mb-2 flex items-center gap-2">
                  <ShieldCheck className="h-5 w-5 text-primary shrink-0" /> Privacy
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Your contact details are used only to respond to your enquiry. For more information, see our{' '}
                  <Link to="/privacy" className="text-primary hover:underline font-medium">Privacy Policy</Link>.
                </p>
              </div>

              {/* Bug Report Guidance */}
              <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
                <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                  <Bug className="h-5 w-5 text-primary shrink-0" /> Reporting a Calculation Issue?
                </h3>
                <p className="text-sm text-muted-foreground mb-3 leading-relaxed">
                  To help us investigate quickly, please include:
                </p>
                <ul className="text-sm text-muted-foreground space-y-1.5">
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold mt-0.5">•</span>
                    <span>Calculator name (e.g., UK Salary Calculator)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold mt-0.5">•</span>
                    <span>Page URL</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold mt-0.5">•</span>
                    <span>Inputs you entered</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold mt-0.5">•</span>
                    <span>Expected result</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <div className="bg-card p-6 sm:p-8 md:p-10 rounded-2xl shadow-lg border border-border relative">
                
                <div className="absolute top-0 left-0 w-full h-1.5 bg-primary rounded-t-2xl"></div>

                <div className="mb-6 border-b border-border pb-6">
                  <h2 className="text-2xl font-bold text-foreground">Send us a message</h2>
                  <p className="text-muted-foreground mt-2">All fields marked with an asterisk (*) are required.</p>
                </div>

                {/* Security Notice */}
                <div className="flex gap-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl p-4 mb-6">
                  <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                  <p className="text-sm text-amber-800 dark:text-amber-300 leading-relaxed">
                    <span className="font-semibold">Security notice:</span> Please do not submit sensitive financial information (such as account numbers, passwords, or detailed personal financial data) through this form. For security-sensitive matters, contact us directly by email.
                  </p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Name & Email Row */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2.5">
                      <Label htmlFor="name" className="text-foreground font-medium">
                        Full Name <span className="text-destructive">*</span>
                      </Label>
                      <Input 
                        id="name" 
                        name="name" 
                        value={formData.name} 
                        onChange={handleChange} 
                        placeholder="Your full name"
                        className={`text-foreground bg-background ${errors.name ? 'border-destructive focus-visible:ring-destructive' : ''}`}
                        disabled={isSubmitting}
                      />
                      {errors.name && <p className="text-sm text-destructive mt-1">{errors.name}</p>}
                    </div>
                    <div className="space-y-2.5">
                      <Label htmlFor="email" className="text-foreground font-medium">
                        Email Address <span className="text-destructive">*</span>
                      </Label>
                      <Input 
                        id="email" 
                        name="email" 
                        type="email" 
                        value={formData.email} 
                        onChange={handleChange} 
                        placeholder="your.email@example.com"
                        className={`text-foreground bg-background ${errors.email ? 'border-destructive focus-visible:ring-destructive' : ''}`}
                        disabled={isSubmitting}
                      />
                      {errors.email && <p className="text-sm text-destructive mt-1">{errors.email}</p>}
                    </div>
                  </div>
                  
                  {/* Phone & Category Row */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2.5">
                      <Label htmlFor="phone" className="text-foreground font-medium flex items-center justify-between">
                        <span>Phone Number</span>
                        <span className="text-xs text-muted-foreground font-normal">Optional</span>
                      </Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input 
                          id="phone" 
                          name="phone" 
                          type="tel"
                          value={formData.phone} 
                          onChange={handleChange} 
                          placeholder="+44 7700 900000"
                          className="text-foreground bg-background pl-9"
                          disabled={isSubmitting}
                        />
                      </div>
                    </div>
                    <div className="space-y-2.5">
                      <Label htmlFor="category" className="text-foreground font-medium flex items-center justify-between">
                        <span>Enquiry Category</span>
                        <span className="text-xs text-muted-foreground font-normal">Optional</span>
                      </Label>
                      <Select value={formData.category} onValueChange={handleSelectChange} disabled={isSubmitting}>
                        <SelectTrigger className="bg-background">
                          <SelectValue placeholder="Select a category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="general">General Enquiry</SelectItem>
                          <SelectItem value="technical">Technical Support</SelectItem>
                          <SelectItem value="bug">Calculation Issue / Bug Report</SelectItem>
                          <SelectItem value="billing">Billing / Advertising</SelectItem>
                          <SelectItem value="privacy">Privacy Enquiry</SelectItem>
                          <SelectItem value="accessibility">Accessibility Feedback</SelectItem>
                          <SelectItem value="feedback">Product Feedback</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Subject Row */}
                  <div className="space-y-2.5">
                    <Label htmlFor="subject" className="text-foreground font-medium">
                      Subject <span className="text-destructive">*</span>
                    </Label>
                    <Input 
                      id="subject" 
                      name="subject" 
                      value={formData.subject} 
                      onChange={handleChange} 
                      placeholder="How can we help you today?"
                      className={`text-foreground bg-background ${errors.subject ? 'border-destructive focus-visible:ring-destructive' : ''}`}
                      disabled={isSubmitting}
                    />
                    {errors.subject && <p className="text-sm text-destructive mt-1">{errors.subject}</p>}
                  </div>
                  
                  {/* Message Row */}
                  <div className="space-y-2.5">
                    <Label htmlFor="message" className="text-foreground font-medium">
                      Message <span className="text-destructive">*</span>
                    </Label>
                    <Textarea 
                      id="message" 
                      name="message" 
                      value={formData.message} 
                      onChange={handleChange} 
                      placeholder="Please provide as much detail as possible. If reporting a calculation issue, include the calculator name, page URL, inputs used, and expected result."
                      rows={6}
                      className={`text-foreground bg-background resize-y min-h-[120px] ${errors.message ? 'border-destructive focus-visible:ring-destructive' : ''}`}
                      disabled={isSubmitting}
                    />
                    {errors.message && <p className="text-sm text-destructive mt-1">{errors.message}</p>}
                  </div>
                  
                  {/* Submit Button */}
                  <div className="pt-4 border-t border-border mt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <p className="text-sm text-muted-foreground order-2 sm:order-1 text-center sm:text-left">
                      By submitting this form, you agree to our{' '}
                      <Link to="/privacy" className="text-primary hover:underline">Privacy Policy</Link>.
                    </p>
                    <Button 
                      type="submit" 
                      size="lg" 
                      className="w-full sm:w-auto min-w-[160px] order-1 sm:order-2"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Sending...
                        </>
                      ) : (
                        'Send Message'
                      )}
                    </Button>
                  </div>
                </form>
              </div>
            </div>

          </div>
        </div>
      </section>
    </div>
  );
}

export default ContactPage;
