import React from 'react';
import PageSeo from '@/components/PageSeo.jsx';
import { Link } from 'react-router-dom';

export default function CookiePolicyPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <PageSeo
        title="Cookie Policy | SmartMoneyTools"
        description="SmartMoneyTools Cookie Policy. How we use cookies, Google advertising cookies, consent choices, and how to withdraw consent."
        path="/cookie-policy"
      />

      <main className="flex-grow py-16 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">
          <h1 className="text-4xl font-bold text-foreground mb-8">Cookie Policy</h1>

          <div className="prose prose-slate max-w-none text-muted-foreground space-y-6">
            <p><strong>Effective Date:</strong> 6 May 2026 &nbsp;|&nbsp; <strong>Last reviewed:</strong> 6 August 2026</p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">1. What Are Cookies?</h2>
            <p>
              Cookies are small text files placed on your device by websites you visit. They allow websites to remember your preferences, measure how the site is used, and serve relevant advertising. Similar technologies — including browser local storage, session storage, and device fingerprinting — may perform comparable functions.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">2. Cookie Categories We Use</h2>

            <h3 className="text-lg font-semibold text-foreground mt-6 mb-2">2a. Essential (Strictly Necessary)</h3>
            <p>
              These enable core site functionality. They are set without requiring consent because they are necessary for the site to work.
            </p>
            <ul className="list-disc pl-6 space-y-1">
              <li><strong>Session cookies:</strong> Temporary cookies that expire when you close your browser, used to maintain your session state while navigating the site.</li>
              <li><strong>Security cookies:</strong> Used to detect and prevent fraudulent activity.</li>
            </ul>

            <h3 className="text-lg font-semibold text-foreground mt-6 mb-2">2b. Preference (Functional)</h3>
            <p>
              We use <strong>browser Local Storage</strong> (not a traditional cookie) to save interface preferences such as your selected currency symbol and colour theme. This data stays on your device and is never transmitted to our servers. No consent is required as no data leaves your device.
            </p>

            <h3 className="text-lg font-semibold text-foreground mt-6 mb-2">2c. Advertising (Non-Essential — Consent Required)</h3>
            <p>
              SmartMoneyTools uses <strong>Google AdSense</strong> to display third-party advertisements. Google and its advertising partners use cookies and similar tracking technologies to:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Serve <strong>personalised advertisements</strong> based on your browsing history and inferred interests (if you consent).</li>
              <li>Serve <strong>non-personalised advertisements</strong> based solely on the content of the page you are viewing (if you do not consent to personalised advertising).</li>
              <li>Measure the performance of advertisements (impressions, clicks, conversions).</li>
              <li>Detect and prevent ad fraud.</li>
              <li>Frequency-cap advertisements (limit how many times you see the same ad).</li>
            </ul>
            <p>
              Key cookies set by Google AdSense may include:
            </p>
            <div className="overflow-x-auto">
              <table className="w-full text-sm border-collapse not-prose">
                <thead>
                  <tr className="bg-muted text-left">
                    <th className="p-2 font-semibold border border-border text-foreground">Cookie name</th>
                    <th className="p-2 font-semibold border border-border text-foreground">Purpose</th>
                    <th className="p-2 font-semibold border border-border text-foreground">Duration</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td className="p-2 border border-border">__gads / __gpi</td><td className="p-2 border border-border">Google advertising: frequency capping, ad fraud prevention</td><td className="p-2 border border-border">13 months</td></tr>
                  <tr><td className="p-2 border border-border">IDE</td><td className="p-2 border border-border">Google DoubleClick: records ad clicks, serves targeted ads</td><td className="p-2 border border-border">13 months</td></tr>
                  <tr><td className="p-2 border border-border">DSID</td><td className="p-2 border border-border">Google: user identification for personalised ads</td><td className="p-2 border border-border">2 weeks</td></tr>
                  <tr><td className="p-2 border border-border">NID</td><td className="p-2 border border-border">Google: personalises Google services and ads</td><td className="p-2 border border-border">6 months</td></tr>
                  <tr><td className="p-2 border border-border">CONSENT</td><td className="p-2 border border-border">Google: stores your consent decision</td><td className="p-2 border border-border">2 years</td></tr>
                </tbody>
              </table>
            </div>
            <p>
              This list is illustrative. Google's full cookie inventory is documented at <a href="https://policies.google.com/technologies/cookies" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">policies.google.com/technologies/cookies</a>.
            </p>
            <p>
              Data collected by Google's advertising system may include your <strong>IP address</strong>, <strong>device identifiers</strong>, <strong>browser characteristics</strong>, and <strong>browsing behaviour</strong>. This data is processed by Google in accordance with <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Google's Privacy Policy</a>.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">3. Consent — How to Accept or Reject Cookies</h2>
            <p>
              When you first visit SmartMoneyTools, you will see a cookie consent notice. <strong>Both "Accept" and "Reject" options are presented with equal prominence.</strong>
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li><strong>Accept all cookies:</strong> Enables personalised advertising based on your interests and browsing history.</li>
              <li><strong>Reject non-essential cookies:</strong> Google AdSense will serve non-personalised advertising only (based on page content). Essential site functionality is unaffected.</li>
            </ul>
            <p>
              If you close the cookie notice without making a selection, we default to <strong>non-personalised advertising only</strong> — no non-essential cookies are set without your explicit consent.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">4. How to Withdraw Consent</h2>
            <p>
              You can withdraw or change your consent at any time using any of the following methods:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li><strong>Clear site cookies and revisit:</strong> Clear your browser's cookies for smartmoney-tools.com; the cookie consent notice will reappear on your next visit.</li>
              <li><strong>Browser settings:</strong> Most browsers allow you to block or delete all cookies. See your browser's help pages for instructions.</li>
              <li><strong>Google Ads Settings:</strong> Opt out of personalised Google advertising at <a href="https://adssettings.google.com" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">adssettings.google.com</a>.</li>
              <li><strong>Industry opt-out tools:</strong> Opt out of interest-based advertising from multiple vendors at <a href="https://www.aboutads.info/choices/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">aboutads.info/choices</a> or <a href="https://www.youronlinechoices.eu" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">youronlinechoices.eu</a>.</li>
            </ul>
            <p>
              <strong>Note:</strong> Blocking all cookies may affect the appearance of our site (for example, your currency preference may reset on each visit) but will not prevent you from using any calculator.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">5. Third-Party Advertising Vendors</h2>
            <p>
              In addition to Google, advertisements on this site may be served by Google's advertising network partners. A full list of participating vendors and their privacy policies is available via Google's <a href="https://support.google.com/adsense/answer/9012903" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">AdSense partner list</a>.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">6. Changes to This Cookie Policy</h2>
            <p>
              We may update this Cookie Policy when we change the technologies we use or when regulations change. Material changes will be reflected by updating the "Last reviewed" date at the top of this page.
            </p>

            <h2 className="text-2xl font-semibold text-foreground mt-8 mb-4">7. Contact</h2>
            <p>
              For cookie-related questions, contact us at <a href="mailto:support@smartmoney-tools.com" className="text-primary hover:underline">support@smartmoney-tools.com</a>.
            </p>

            <div className="mt-10 pt-8 border-t border-border text-sm text-muted-foreground">
              <p>Related: <Link to="/privacy" className="text-primary hover:underline">Privacy Policy</Link> · <Link to="/advertising-disclosure" className="text-primary hover:underline">Advertising Disclosure</Link></p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
