import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import UKSalaryCalculatorForm from '@/components/UKSalaryCalculatorForm.jsx';
import UKSalaryCalculatorResults from '@/components/UKSalaryCalculatorResults.jsx';
import DisclaimerBanner from '@/components/DisclaimerBanner.jsx';
import HowWeCalculateThis from '@/components/HowWeCalculateThis.jsx';
import AuthorAttribution from '@/components/AuthorAttribution.jsx';
import AuthorBylineBar from '@/components/AuthorBylineBar.jsx';
import FAQAccordion from '@/components/FAQAccordion.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card.jsx';
import { setPageMeta } from '@/utils/seo.js';
import { addWebApplicationSchema } from '@/utils/structuredData.js';
import Breadcrumb from '@/components/Breadcrumb.jsx';
import { 
  BookOpen, 
  Calculator, 
  Target, 
  FileText, 
  PieChart, 
  Briefcase, 
  Landmark, 
  GraduationCap,
  Scale,
  Users,
  AlertTriangle,
  HelpCircle,
  Link as LinkIcon,
  ShieldAlert
} from 'lucide-react';

function UKSalaryCalculator() {
  const [calculatorState, setCalculatorState] = useState(null);

  useEffect(() => {
    // Reset calculator state on mount
    setCalculatorState(null);
    
    setPageMeta(
      'UK Salary Calculator 2026/27 | SmartMoneyTools',
      'Calculate your UK take-home pay after income tax, National Insurance, pension contributions and student loan repayments for 2026/27. Supports England, Wales, Scotland and Northern Ireland.',
      'https://smartmoney-tools.com/uk-salary-calculator'
    );
    addWebApplicationSchema(
      'UK Salary Calculator',
      'https://smartmoney-tools.com/uk-salary-calculator',
      'Free UK salary and PAYE tax calculator to estimate take-home pay, National Insurance, and pension deductions.'
    );
  }, []);

  const handleFormChange = (newFormData) => {
    setCalculatorState(newFormData);
  };

  const sections = [
    { id: 'what-it-estimates', title: '1. What the Calculator Estimates', icon: <Calculator className="w-5 h-5" /> },
    { id: 'who-should-use', title: '2. Who Should Use It', icon: <Users className="w-5 h-5" /> },
    { id: 'tax-year-assumptions', title: '3. 2026/27 Tax Year Assumptions', icon: <FileText className="w-5 h-5" /> },
    { id: 'gross-to-net', title: '4. How Gross Becomes Take-Home Pay', icon: <PieChart className="w-5 h-5" /> },
    { id: 'income-tax-explained', title: '5. Income Tax Explanation', icon: <Landmark className="w-5 h-5" /> },
    { id: 'national-insurance', title: '6. National Insurance Explanation', icon: <Target className="w-5 h-5" /> },
    { id: 'pension-contributions', title: '7. Pension Contributions', icon: <Briefcase className="w-5 h-5" /> },
    { id: 'student-loans', title: '8. Student Loan Repayments', icon: <GraduationCap className="w-5 h-5" /> },
    { id: 'worked-example-30k', title: '9. Worked Example: £30,000 Salary', icon: <Scale className="w-5 h-5" /> },
    { id: 'worked-example-50k', title: '10. Worked Example: £50,000 Salary', icon: <Scale className="w-5 h-5" /> },
    { id: 'payslip-differences', title: '11. Why Your Payslip May Differ', icon: <AlertTriangle className="w-5 h-5" /> },
    { id: 'faq', title: '12. Frequently Asked Questions', icon: <HelpCircle className="w-5 h-5" /> },
    { id: 'related-tools', title: '13. Related Tools', icon: <LinkIcon className="w-5 h-5" /> },
    { id: 'sources-disclaimer', title: '14. Sources and Disclaimer', icon: <ShieldAlert className="w-5 h-5" /> },
  ];

  const faqs = [
    {
      question: 'Why is my payslip different from this calculator?',
      answer: 'The most common reason is a non-standard tax code. This calculator assumes the default 1257L code, but if HMRC has issued an emergency code (such as 1257 W1/M1), a BR code, or a code adjusting for underpaid tax from a previous year, your deductions will differ. Other causes include your employer applying pension contributions to a different base (qualifying earnings versus your full salary), Scottish Income Tax being applied if you live in Scotland, additional voluntary contributions, childcare vouchers, cycle-to-work or union deductions, and the timing of bonus payments. Check your tax code in your HMRC online account and speak to your payroll department if a discrepancy persists.'
    },
    {
      question: 'Does this calculator support Scottish Income Tax?',
      answer: 'Yes. When you select Scotland, the calculator applies the distinct six-band Scottish Income Tax system for 2026/27: Starter rate 19% on £12,571–£16,537, Basic rate 20% on £16,538–£29,526, Intermediate rate 21% on £29,527–£43,662, Higher rate 42% on £43,663–£75,000, Advanced rate 45% on £75,001–£125,140, and Top rate 48% above £125,140. National Insurance is the same across the UK, but Income Tax is calculated differently, so Scottish residents typically see a different take-home figure from someone in England on the same gross salary.'
    },
    {
      question: 'Which Student Loan plan should I select?',
      answer: 'Your plan depends on when and where you studied. Plan 1 applies to English and Welsh borrowers who started before September 2012 (repayment threshold £26,900). Plan 2 applies to English and Welsh borrowers who started on or after 1 September 2012 (threshold £29,385). Plan 4 applies to Scottish borrowers (threshold £33,795). Plan 5 applies to English borrowers who started on or after 1 August 2023 (threshold £25,000, frozen until April 2027). Postgraduate Loans are separate and repaid at 6% above £21,000. If you have more than one loan type, the calculator applies the selected plan; you can check which plans you hold via your Student Loans Company account.'
    },
    {
      question: 'How does salary sacrifice affect take-home pay?',
      answer: 'Under salary sacrifice, your pension contribution is deducted from your gross pay before Income Tax and National Insurance are calculated. This lowers your taxable pay, so you save tax at your marginal rate (20%, 40% or 45%) and also save the 8% (or 2%) employee National Insurance on the sacrificed amount. That makes salary sacrifice more efficient than a Relief at Source arrangement, where you get tax relief but still pay NI on the contributed amount. The trade-off is that salary sacrifice reduces your gross salary, which can affect entitlements based on earnings such as life cover, statutory maternity pay and mortgage affordability assessments.'
    },
    {
      question: 'Why does my Personal Allowance reduce above £100,000?',
      answer: 'Once your adjusted net income exceeds £100,000, the standard £12,570 Personal Allowance is tapered away by £1 for every £2 you earn above the threshold. By the time your income reaches £125,140, the allowance is gone entirely. This creates an effective marginal tax rate of 60% on income between £100,000 and £125,140 (the 40% Higher Rate plus the loss of 20% relief on the tapered allowance). Making pension contributions or charitable donations under Gift Aid reduces your adjusted net income and can restore part of the allowance, which is why pension saving is particularly valuable in this income band.'
    },
    {
      question: 'How are bonuses taxed?',
      answer: 'A bonus is treated as additional earnings and is taxed at your highest (marginal) Income Tax rate through PAYE. If the bonus pushes your total income into a higher band, only the portion above the threshold is taxed at the higher rate. You also pay National Insurance on the bonus at 8% (or 2% above the Upper Earnings Limit), and if your earnings cross your Student Loan repayment threshold you will repay 9% (or 6% for postgraduate loans) on the bonus amount above that threshold. Because PAYE is cumulative for Income Tax, a large bonus paid partway through the year can temporarily alter the tax deducted in that month, but it usually corrects itself over the rest of the tax year.'
    },
    {
      question: 'What tax code does this calculator assume?',
      answer: 'The calculator uses the standard 1257L tax code for England, Wales and Northern Ireland, which grants a £12,570 tax-free Personal Allowance. The letter L denotes the standard entitlement for someone eligible for the full allowance. If your code is different — for example BR (Basic Rate, no allowance), D0 (40%), D1 (45%), or an emergency W1/M1 non-cumulative code — your actual deductions will not match the calculator. You can find your current code on your payslip or in your HMRC online account.'
    },
    {
      question: 'How is National Insurance calculated?',
      answer: 'For 2026/27, employees pay Class 1 National Insurance at 8% on earnings between the Primary Threshold (£12,570 a year, equivalent to £1,048 a month) and the Upper Earnings Limit (£50,270 a year), and 2% on earnings above the Upper Earnings Limit. Unlike Income Tax, which is cumulative across the tax year, NI is calculated separately each pay period. You stop paying employee NI when you reach State Pension age. Employers also pay secondary Class 1 NI at 15% above the £5,000 Secondary Threshold, but this is a cost to the employer and does not appear as a deduction on your payslip.'
    }
  ];

  return (
    <div className="flex flex-col w-full bg-background">
      <section className="bg-primary text-primary-foreground py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-4xl mx-auto text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight text-balance" style={{ letterSpacing: '-0.02em' }}>
              UK Salary Calculator 2026/27
            </h1>
            <p className="text-xl text-primary-foreground/90 leading-relaxed max-w-3xl mx-auto mb-8">
              Use our UK salary calculator to estimate your take-home pay after income tax, National Insurance, pension contributions and student loan repayments.
            </p>
            <AuthorBylineBar variant="hero" />
            <div className="flex justify-center">
              <Button asChild variant="secondary" className="bg-background text-foreground hover:bg-muted font-medium">
                <a href="#comprehensive-guide" className="flex items-center">
                  <BookOpen className="mr-2 h-4 w-4" />
                  Read the Comprehensive Guide
                </a>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Breadcrumb */}
      <div className="bg-background border-b border-border/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <Breadcrumb items={[{ label: 'UK Salary Calculator' }]} />
        </div>
      </div>

      {/* Author Attribution */}
      <div className="bg-background border-b border-border/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-3 max-w-7xl">
          <AuthorAttribution lastReviewedDate="2026-09-11" showByline={false} />
        </div>
      </div>

      {/* Calculator Area */}
      <section className="py-12 bg-background border-b border-border">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <div className="lg:col-span-7">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                <UKSalaryCalculatorForm onResultsChange={handleFormChange} />
              </motion.div>
            </div>

            <div className="lg:col-span-5">
              <div className="space-y-8">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  {calculatorState && (
                    <>
                      <UKSalaryCalculatorResults formData={calculatorState} />
                      <DisclaimerBanner />
                    </>
                  )}
                </motion.div>
                
              </div>
            </div>

          </div>
          <HowWeCalculateThis region="UK" />
        </div>
      </section>

      {/* Comprehensive Guide Area */}
      <section id="comprehensive-guide" className="py-16 lg:py-24 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
          <div className="flex flex-col lg:flex-row gap-12 items-start">
            
            {/* Sidebar TOC - Sticky on Desktop */}
            <aside className="w-full lg:w-1/4 lg:sticky lg:top-24 hidden lg:block border rounded-2xl bg-card p-6 shadow-sm">
              <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-6">Table of Contents</h3>
              <nav className="space-y-1">
                {sections.map((section) => (
                  <a
                    key={section.id}
                    href={`#${section.id}`}
                    className="flex items-center gap-3 py-2.5 px-3 text-sm font-medium rounded-lg text-foreground hover:bg-muted hover:text-primary transition-colors"
                  >
                    <span className="text-muted-foreground shrink-0">{section.icon}</span>
                    <span className="line-clamp-2 leading-snug">{section.title}</span>
                  </a>
                ))}
              </nav>
            </aside>

            {/* Main Guide Content */}
            <div className="w-full lg:w-3/4 prose prose-slate dark:prose-invert max-w-none">
              
              <section id="what-it-estimates" className="guide-section">
                <h2 className="guide-heading">
                  <Calculator className="w-8 h-8 text-primary" />
                  1. What the UK Salary Calculator Estimates
                </h2>
                <p>
                  The UK Salary Calculator is designed to estimate how your gross salary translates into net take-home pay under the UK's Pay As You Earn (PAYE) system. When you receive a job offer or negotiate a pay rise, the figure discussed is always gross pay—the amount before any statutory deductions.
                </p>
                <p>
                  This calculator processes the layers of the tax system for you. It deducts Income Tax, National Insurance contributions, workplace pension deductions, and student loan repayments to estimate the amount that will land in your bank account each month. It is useful for budgeting, evaluating job offers, and understanding the financial impact of increasing your pension contributions. This calculator applies the published HMRC rates and thresholds for 2026/27. It gives an estimate; your payslip may differ. Specific personal tax situations, historical underpayments, and non-standard tax codes may cause variations in your final payslip.
                </p>
              </section>

              <section id="who-should-use" className="guide-section">
                <h2 className="guide-heading">
                  <Users className="w-8 h-8 text-primary" />
                  2. Who Should Use It
                </h2>
                <p>
                  This calculator is essential for any UK resident navigating the PAYE system. It is specifically designed for:
                </p>
                <ul>
                  <li><strong>Employees on PAYE:</strong> To verify that their monthly payslips are accurate and that they are not overpaying on emergency tax codes.</li>
                  <li><strong>Job Seekers & Career Changers:</strong> To translate prospective salary offers into realistic monthly household budgets.</li>
                  <li><strong>Individuals Negotiating Pay Rises:</strong> To determine exactly how much a £5,000 gross salary increase will yield after higher-rate taxes and National Insurance are deducted.</li>
                  <li><strong>Students & Graduates:</strong> To accurately model how different Plan 1, Plan 2, or Plan 5 student loan thresholds impact their early-career take-home pay.</li>
                  <li><strong>Self-Employed Professionals:</strong> To compare their sole-trader profits against equivalent full-time employment packages.</li>
                </ul>
              </section>

              <section id="tax-year-assumptions" className="guide-section">
                <h2 className="guide-heading">
                  <FileText className="w-8 h-8 text-primary" />
                  3. 2026/27 UK Tax Year Assumptions
                </h2>
                <p>
                  The UK tax year runs from 6 April 2026 to 5 April 2027. This calculator is fully updated to reflect the statutory parameters for this specific tax year. The foundational assumption is that the user holds a standard <strong>1257L tax code</strong>, which grants a Personal Allowance of £12,570 per year—meaning the first £12,570 earned is entirely free of Income Tax.
                </p>
                <p>
                  For England, Wales, and Northern Ireland, the Basic Rate (20%) applies up to £50,270, the Higher Rate (40%) up to £125,140, and the Additional Rate (45%) above that. National Insurance is calculated using the standard Class 1 employee rates, assuming an 8% primary rate above the primary threshold and a 2% rate above the upper earnings limit.
                </p>
                <p>
                  The calculator fully supports regional variations. If you select Scotland, it automatically applies the distinct six-band Scottish income tax system (Starter, Basic, Intermediate, Higher, Advanced, Top). It accounts for standard student loan repayment thresholds across all active plans. While the tool covers standard scenarios, it assumes you are not claiming specialized reliefs like Marriage Allowance or Blind Person's Allowance unless specifically toggled. For official confirmation of these thresholds, users should always refer directly to <a href="https://www.gov.uk/income-tax-rates" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK</a>.
                </p>
              </section>

              <section id="gross-to-net" className="guide-section">
                <h2 className="guide-heading">
                  <PieChart className="w-8 h-8 text-primary" />
                  4. How Gross Salary Becomes Take-Home Pay
                </h2>
                <p>
                  Understanding your payslip requires understanding the sequence of deductions. Gross salary is your total contractual pay before anything is removed. Take-home pay (net pay) is the final cleared funds you can spend. Under the PAYE system, your employer calculates and deducts your liabilities before paying you. 
                </p>
                <p>
                  The order of calculations is critical. If your workplace uses a Salary Sacrifice pension scheme, your pension contribution is deducted from your gross pay first. This lowers your "taxable pay," generating significant savings on both Income Tax and National Insurance.
                </p>
                <p>
                  Next, Income Tax is calculated on the remaining taxable pay by applying your Personal Allowance and taxing the rest across the progressive bands. Following this, National Insurance is calculated based on weekly or monthly earnings thresholds. Finally, if applicable, student loan deductions are calculated on earnings that surpass the statutory threshold for your specific loan plan.
                </p>
                <p>
                  Because PAYE is cumulative for Income Tax, your tax-free allowance is split equally across the year. If you earn £30,000 annually, your monthly gross is £2,500. Your monthly tax-free allowance is £1,047.50. You only pay Income Tax on the difference. This system ensures your take-home pay remains consistent month-to-month, provided your salary does not wildly fluctuate.
                </p>
              </section>

              <section id="income-tax-explained" className="guide-section">
                <h2 className="guide-heading">
                  <Landmark className="w-8 h-8 text-primary" />
                  5. Income Tax Explanation
                </h2>
                <p>
                  Income Tax is the primary tax levied on your personal earnings by the UK government. It operates on a progressive tier system. The standard Personal Allowance means you pay 0% on your first £12,570. Earnings between £12,571 and £50,270 are taxed at the Basic Rate of 20%. Earnings from £50,271 to £125,140 face the Higher Rate of 40%, and anything above £125,140 hits the Additional Rate of 45%.
                </p>
                <p>
                  A common misconception is that moving into a higher tax bracket reduces your overall take-home pay. This is mathematically impossible under a progressive system. If you earn £52,000, you do not pay 40% on the entire £52,000. You only pay 40% on the £1,730 that falls <em>above</em> the £50,270 threshold. The rest is still taxed at 20% and 0%.
                </p>
                <p>
                  High earners must be aware of the "£100k trap." Once your adjusted net income surpasses £100,000, your Personal Allowance is reduced by £1 for every £2 you earn over the limit. This creates a punitive effective marginal tax rate of 60% on earnings between £100,000 and £125,140. Strategic tax relief on pensions is the most common method used to mitigate this; contributing to a pension lowers your adjusted net income. For detailed guidance on your tax code, visit the <a href="https://www.gov.uk/tax-codes" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">HMRC Tax Codes portal</a>.
                </p>
              </section>

              <section id="national-insurance" className="guide-section">
                <h2 className="guide-heading">
                  <Target className="w-8 h-8 text-primary" />
                  6. National Insurance Explanation
                </h2>
                <p>
                  National Insurance (NI) is a secondary tax on your earnings, distinct from Income Tax. While Income Tax funds general government spending, NI contributions build your entitlement to specific state benefits, including the State Pension, Statutory Sick Pay, Maternity Allowance, and contribution-based Jobseeker's Allowance.
                </p>
                <p>
                  As an employee, you pay Class 1 National Insurance. Unlike Income Tax, which looks at your annual cumulative earnings, NI is strictly calculated on a per-pay-period basis. For the 2026/27 tax year, the primary threshold dictates that you pay 0% on earnings up to £242 per week (£1,048 per month). You pay the main rate of 8% on earnings between the primary threshold and the Upper Earnings Limit (£967 per week / £4,189 per month). Any earnings above the Upper Earnings Limit are subject to a 2% rate.
                </p>
                <p>
                  Employers also pay secondary Class 1 NI on your earnings, which is an additional cost to the business and does not appear as a deduction on your payslip. There is age-related relief: you stop paying Class 1 NI when you reach State Pension age, even if you continue working. Self-employed individuals operate under a different system, paying Class 4 NI on their annual trading profits.
                </p>
              </section>

              <section id="pension-contributions" className="guide-section">
                <h2 className="guide-heading">
                  <Briefcase className="w-8 h-8 text-primary" />
                  7. Pension Contribution Explanation
                </h2>
                <p>
                  Under UK Automatic Enrolment legislation, employers must provide a workplace pension scheme and automatically enroll eligible staff. The legal minimum total contribution is 8% of your qualifying earnings, of which the employer must contribute at least 3%, leaving the employee to contribute 5%. 
                </p>
                <p>
                  Pensions are the most tax-efficient savings vehicle available. The government provides tax relief on your contributions at your highest marginal rate. If you are a basic rate taxpayer, a £100 contribution into your pension pot only costs you £80 from your take-home pay, because the government adds £20 in tax relief. For higher rate taxpayers, the efficiency is even greater.
                </p>
                <p>
                  There are limits to this generosity. The Annual Allowance caps the total amount of pension savings (including employer contributions and tax relief) you can make each tax year without facing a tax charge; for most people, this is £60,000 or 100% of their earnings, whichever is lower. Almost all modern workplace pensions are Defined Contribution schemes, meaning the final value depends entirely on how much is paid in and how the underlying investments perform. Proper retirement planning requires actively managing these contributions. For further guidance, refer to <a href="https://www.moneyhelper.org.uk/en/pensions-and-retirement" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">MoneyHelper</a>.
                </p>
              </section>

              <section id="student-loans" className="guide-section">
                <h2 className="guide-heading">
                  <GraduationCap className="w-8 h-8 text-primary" />
                  8. Student Loan Repayment Explanation
                </h2>
                <p>
                  UK student loans operate more like a graduate tax than traditional commercial debt. Your monthly repayment is determined entirely by your income, not by the total size of your outstanding balance or the interest rate applied to it.
                </p>
                <p>
                  Repayments are calculated as a percentage of your earnings that fall strictly <em>above</em> a statutory threshold. 
                </p>
                <ul>
                  <li><strong>Plan 1:</strong> 9% on earnings above £26,900 (effective April 2026).</li>
                  <li><strong>Plan 2:</strong> 9% on earnings above £29,385 (effective April 2026).</li>
                  <li><strong>Plan 4 (Scotland):</strong> 9% on earnings above £33,795 (effective April 2026).</li>
                  <li><strong>Plan 5:</strong> 9% on earnings above £25,000 (frozen until April 2027).</li>
                  <li><strong>Postgraduate Loans:</strong> 6% on earnings above £21,000.</li>
                </ul>
                <p>
                  If your income drops below the threshold, your repayments automatically pause. Because the debt accrues interest, many graduates—particularly on Plan 2—will never clear the principal balance before the loan is statutorily written off (typically after 30 or 40 years, depending on the plan). For most earners, making voluntary early repayments is a poor financial decision, as the debt will eventually be wiped regardless. You can check your official balance via the <a href="https://www.gov.uk/sign-in-to-your-student-loan-repayment-account" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Student Loans Company</a>.
                </p>
              </section>

              <section id="worked-example-30k" className="guide-section">
                <h2 className="guide-heading">
                  <Scale className="w-8 h-8 text-primary" />
                  9. Worked Example: £30,000 Salary
                </h2>
                <p>
                  To demonstrate how these rules interact in the real world, let us analyze a standard scenario: an employee living in England, earning a gross salary of <strong>£30,000</strong> a year. They contribute 5% to a workplace pension under a Relief at Source arrangement, and they have a Plan 2 Student Loan.
                </p>
                <div className="worked-example">
                  <h3 className="worked-example-title">Step-by-Step Breakdown (£30,000)</h3>
                  <ul className="space-y-3 text-foreground">
                    <li><strong>1. Gross Income:</strong> £30,000 per year.</li>
                    <li><strong>2. Income Tax:</strong> The first £12,570 is tax-free (Personal Allowance). The remaining £17,430 is taxed at the Basic Rate (20%).
                      <br/><span className="text-muted-foreground ml-4">Tax Liability = £3,486.00.</span>
                    </li>
                    <li><strong>3. National Insurance:</strong> Calculated at 8% on earnings between £12,570 and £50,270.
                      <br/><span className="text-muted-foreground ml-4">NI Liability = £1,394.40.</span>
                    </li>
                    <li><strong>4. Pension Contribution:</strong> 5% of qualifying earnings (the band between £6,240 and £50,270, which is £23,760) = £1,188.00 in total. Under Relief at Source you pay 80% from take-home pay and your provider claims the other 20% basic-rate relief from HMRC.
                      <br/><span className="text-muted-foreground ml-4">You pay = £950.40; provider adds £237.60 tax relief = £1,188.00 total into your pension.</span>
                    </li>
                    <li><strong>5. Student Loan (Plan 2):</strong> 9% on earnings above the £29,385 threshold (£615 exposed).
                      <br/><span className="text-muted-foreground ml-4">Loan Repayment = £55.35.</span>
                    </li>
                    <li className="pt-4 border-t border-border/50 font-bold text-lg">
                      <strong>Take-Home Pay:</strong> £30,000 - (£3,486.00 + £1,394.40 + £950.40 + £55.35) = £24,113.85 per year.
                    </li>
                  </ul>
                </div>
                <p>
                  On a monthly basis, this employee's gross pay is £2,500. After deducting £290.50 for Tax, £116.20 for NI, £79.20 for Pension (you pay), and £4.61 for Student Loan, their monthly net take-home pay is approximately <strong>£2,009</strong>. Total deductions consume approximately 19.6% of their gross salary.
                </p>
              </section>

              <section id="worked-example-50k" className="guide-section">
                <h2 className="guide-heading">
                  <Scale className="w-8 h-8 text-primary" />
                  10. Worked Example: £50,000 Salary
                </h2>
                <p>
                  Now consider a higher earner making <strong>£50,000</strong> a year. They face higher liabilities across all deduction categories. They also contribute 5% to their pension and carry a Plan 2 Student Loan.
                </p>
                <div className="worked-example">
                  <h3 className="worked-example-title">Step-by-Step Breakdown (£50,000)</h3>
                  <ul className="space-y-3 text-foreground">
                    <li><strong>1. Gross Income:</strong> £50,000 per year.</li>
                    <li><strong>2. Income Tax:</strong> The first £12,570 is tax-free. The remaining £37,430 is taxed entirely within the Basic Rate band (20%), stopping just shy of the £50,270 Higher Rate threshold.
                      <br/><span className="text-muted-foreground ml-4">Tax Liability = £7,486.00.</span>
                    </li>
                    <li><strong>3. National Insurance:</strong> 8% on earnings between £12,570 and £50,270 (£37,430 exposed).
                      <br/><span className="text-muted-foreground ml-4">NI Liability = £2,994.40.</span>
                    </li>
                    <li><strong>4. Pension Contribution:</strong> 5% of qualifying earnings between £6,240 and £50,270 (£43,760 exposed) = £2,188.00 in total. Under Relief at Source you pay 80% from take-home pay and your provider claims the other 20%.
                      <br/><span className="text-muted-foreground ml-4">You pay = £1,750.40; provider adds £437.60 tax relief = £2,188.00 total into your pension.</span>
                    </li>
                    <li><strong>5. Student Loan (Plan 2):</strong> 9% on earnings above £29,385 (£20,615 exposed).
                      <br/><span className="text-muted-foreground ml-4">Loan Repayment = £1,855.35.</span>
                    </li>
                    <li className="pt-4 border-t border-border/50 font-bold text-lg">
                      <strong>Take-Home Pay:</strong> £50,000 - (£7,486.00 + £2,994.40 + £1,750.40 + £1,855.35) = £35,913.85 per year.
                    </li>
                  </ul>
                </div>
                <p>
                  On a monthly basis, this employee's gross pay is £4,167. After deducting £623.83 for Tax, £249.53 for NI, £145.87 for Pension (you pay), and £154.61 for Student Loan, their monthly net take-home pay is approximately <strong>£2,993</strong>. Total deductions consume approximately 28.2% of their gross salary, demonstrating the progressive nature of the UK system.
                </p>
              </section>

              <section id="payslip-differences" className="guide-section">
                <h2 className="guide-heading">
                  <AlertTriangle className="w-8 h-8 text-primary" />
                  11. Common Reasons Your Payslip May Differ
                </h2>
                <p>
                  While our calculator provides a highly accurate estimate based on standardized HMRC rules, it is not uncommon for your real-world payslip to differ slightly. The primary cause of discrepancies is <strong>tax code variations</strong>. If HMRC has issued you an emergency tax code (like 1257 W1/M1) or a code adjusting for underpaid tax in previous years, your tax-free allowance will not match the standard calculation.
                </p>
                <p>
                  Other significant factors include regional differences. If you live in Scotland, your employer must apply the Scottish rate of income tax, which operates with six distinct bands rather than three. Furthermore, specialized allowances such as the Marriage Allowance or the Blind Person's Allowance will alter your base taxable income.
                </p>
                <p>
                  Pension scheme variations are another major factor. Some employers apply your contribution percentage to your "Qualifying Earnings" (a restricted band of your salary), while others apply it to your entire base salary. Additionally, if you make Additional Voluntary Contributions (AVCs), participate in a cycle-to-work scheme, pay union fees, or use childcare vouchers, these pre-tax or post-tax deductions will alter the final net pay. Finally, timing differences regarding when a mid-year bonus is paid can cause temporary spikes in National Insurance deductions. If your payslip consistently looks wrong, your first step should be checking your tax code on your HMRC online account and consulting your employer's payroll department.
                </p>
              </section>

              <section id="faq" className="guide-section">
                <h2 className="guide-heading">
                  <HelpCircle className="w-8 h-8 text-primary" />
                  12. Frequently Asked Questions
                </h2>
                <div className="not-prose bg-card rounded-xl border border-border shadow-sm p-2">
                  <FAQAccordion faqItems={faqs} />
                </div>
              </section>

              <section id="related-tools" className="guide-section">
                <h2 className="guide-heading">
                  <LinkIcon className="w-8 h-8 text-primary" />
                  13. Related Tools
                </h2>
                <p>
                  Take control of your entire financial picture by exploring our other specialized calculators and educational guides. Once you understand your take-home pay, use these tools to plan your next steps:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6 not-prose">
                  <Card className="hover:shadow-md transition-shadow">
                    <CardHeader>
                      <CardTitle className="text-lg"><Link to="/pensions-calculator" className="hover:text-primary transition-colors">Pensions Calculator</Link></CardTitle>
                      <CardDescription className="text-sm mt-2">Project how your workplace and personal pension contributions will grow over time and estimate your retirement income.</CardDescription>
                    </CardHeader>
                  </Card>
                  <Card className="hover:shadow-md transition-shadow">
                    <CardHeader>
                      <CardTitle className="text-lg"><Link to="/budget-planner" className="hover:text-primary transition-colors">Budget Planner</Link></CardTitle>
                      <CardDescription className="text-sm mt-2">Take your net pay from this calculator and allocate it effectively using a zero-based budgeting framework.</CardDescription>
                    </CardHeader>
                  </Card>
                  <Card className="hover:shadow-md transition-shadow">
                    <CardHeader>
                      <CardTitle className="text-lg"><Link to="/guides/tax-planning" className="hover:text-primary transition-colors">Tax Planning Guide</Link></CardTitle>
                      <CardDescription className="text-sm mt-2">Learn advanced strategies like salary sacrifice and ISA utilization to legally maximize your net wealth.</CardDescription>
                    </CardHeader>
                  </Card>
                  <Card className="hover:shadow-md transition-shadow">
                    <CardHeader>
                      <CardTitle className="text-lg"><Link to="/guides/student-loan-repayments" className="hover:text-primary transition-colors">Student Loan Guide</Link></CardTitle>
                      <CardDescription className="text-sm mt-2">Deep dive into Plan 1, 2, and 5 repayment thresholds, write-off provisions, and why overpaying is rarely a good idea.</CardDescription>
                    </CardHeader>
                  </Card>
                </div>
              </section>

              <section id="source-table" className="guide-section">
                <h2 className="guide-heading">
                  <ShieldAlert className="w-8 h-8 text-primary" />
                  Data Sources &amp; Accuracy Statement
                </h2>
                <p className="text-sm text-muted-foreground mb-4 p-3 bg-primary/5 rounded-lg border border-primary/20">
                  SmartMoneyTools checks statutory rates and thresholds against official government publications. Results are estimates for educational purposes and may not reflect every individual circumstance. <strong>Last reviewed: 2 November 2026.</strong> Tax year: <strong>6 April 2026 – 5 April 2027</strong>.
                </p>
                <div className="not-prose overflow-x-auto">
                  <table className="w-full text-sm border-collapse">
                    <thead>
                      <tr className="bg-muted text-left">
                        <th className="p-3 font-semibold border border-border">Data Item</th>
                        <th className="p-3 font-semibold border border-border">Value Used</th>
                        <th className="p-3 font-semibold border border-border">Effective Period</th>
                        <th className="p-3 font-semibold border border-border">Official Source</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="hover:bg-muted/30"><td className="p-3 border border-border">Personal Allowance</td><td className="p-3 border border-border">£12,570</td><td className="p-3 border border-border">2026/27</td><td className="p-3 border border-border"><a href="https://www.gov.uk/income-tax-rates" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Income tax rates</a></td></tr>
                      <tr className="hover:bg-muted/30"><td className="p-3 border border-border">Basic Rate (Income Tax)</td><td className="p-3 border border-border">20% on £12,571–£50,270</td><td className="p-3 border border-border">2026/27</td><td className="p-3 border border-border"><a href="https://www.gov.uk/income-tax-rates" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Income tax rates</a></td></tr>
                      <tr className="hover:bg-muted/30"><td className="p-3 border border-border">Higher Rate (Income Tax)</td><td className="p-3 border border-border">40% on £50,271–£125,140</td><td className="p-3 border border-border">2026/27</td><td className="p-3 border border-border"><a href="https://www.gov.uk/income-tax-rates" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Income tax rates</a></td></tr>
                      <tr className="hover:bg-muted/30"><td className="p-3 border border-border">Additional Rate (Income Tax)</td><td className="p-3 border border-border">45% above £125,140</td><td className="p-3 border border-border">2026/27</td><td className="p-3 border border-border"><a href="https://www.gov.uk/income-tax-rates" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Income tax rates</a></td></tr>
                      <tr className="hover:bg-muted/30"><td className="p-3 border border-border">Employee NI (Primary Rate)</td><td className="p-3 border border-border">8% on £12,570–£50,270</td><td className="p-3 border border-border">2026/27</td><td className="p-3 border border-border"><a href="https://www.gov.uk/national-insurance-rates-letters" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – NI rates</a></td></tr>
                      <tr className="hover:bg-muted/30"><td className="p-3 border border-border">Employee NI (Upper Rate)</td><td className="p-3 border border-border">2% above £50,270</td><td className="p-3 border border-border">2026/27</td><td className="p-3 border border-border"><a href="https://www.gov.uk/national-insurance-rates-letters" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – NI rates</a></td></tr>
                      <tr className="hover:bg-muted/30"><td className="p-3 border border-border">Employer NI Rate</td><td className="p-3 border border-border">15% above £5,000</td><td className="p-3 border border-border">2026/27</td><td className="p-3 border border-border"><a href="https://www.gov.uk/guidance/rates-and-thresholds-for-employers-2026-to-2027" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Employer rates</a></td></tr>
                      <tr className="hover:bg-muted/30"><td className="p-3 border border-border">Student Loan Plan 1 Threshold</td><td className="p-3 border border-border">£26,900</td><td className="p-3 border border-border">Apr 2026</td><td className="p-3 border border-border"><a href="https://www.gov.uk/repaying-your-student-loan/what-you-pay" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Student loan repayment</a></td></tr>
                      <tr className="hover:bg-muted/30"><td className="p-3 border border-border">Student Loan Plan 2 Threshold</td><td className="p-3 border border-border">£29,385</td><td className="p-3 border border-border">Apr 2026</td><td className="p-3 border border-border"><a href="https://www.gov.uk/repaying-your-student-loan/what-you-pay" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Student loan repayment</a></td></tr>
                      <tr className="hover:bg-muted/30"><td className="p-3 border border-border">Student Loan Plan 4 Threshold (Scotland)</td><td className="p-3 border border-border">£33,795</td><td className="p-3 border border-border">Apr 2026</td><td className="p-3 border border-border"><a href="https://www.gov.uk/repaying-your-student-loan/what-you-pay" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Student loan repayment</a></td></tr>
                      <tr className="hover:bg-muted/30"><td className="p-3 border border-border">Student Loan Plan 5 Threshold</td><td className="p-3 border border-border">£25,000</td><td className="p-3 border border-border">Frozen until Apr 2027</td><td className="p-3 border border-border"><a href="https://www.gov.uk/repaying-your-student-loan/what-you-pay" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Student loan repayment</a></td></tr>
                      <tr className="hover:bg-muted/30"><td className="p-3 border border-border">Postgraduate Loan Threshold</td><td className="p-3 border border-border">£21,000</td><td className="p-3 border border-border">Unchanged since 2016</td><td className="p-3 border border-border"><a href="https://www.gov.uk/repaying-your-student-loan/what-you-pay" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Student loan repayment</a></td></tr>
                      <tr className="hover:bg-muted/30"><td className="p-3 border border-border">Pension Annual Allowance</td><td className="p-3 border border-border">£60,000 or 100% of earnings</td><td className="p-3 border border-border">From Apr 2023</td><td className="p-3 border border-border"><a href="https://www.gov.uk/tax-on-your-private-pension/annual-allowance" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Pension annual allowance</a></td></tr>
                    </tbody>
                  </table>
                </div>
              </section>

              <section id="sources-disclaimer" className="guide-section">
                <h2 className="guide-heading">
                  <ShieldAlert className="w-8 h-8 text-primary" />
                  14. Sources and Disclaimer
                </h2>
                <p>
                  The SmartMoneyTools UK Salary Calculator is built upon strict adherence to official UK statutory data. Our underlying logic, tax bands, and thresholds are sourced directly from authoritative bodies including HM Revenue & Customs (HMRC), GOV.UK, the Student Loans Company, and the Pensions Regulator. We commit to updating our tools promptly following major legislative announcements such as the Chancellor's Spring Budget and Autumn Statement.
                </p>
                <p>
                  <strong>Financial Disclaimer:</strong> The results provided by this calculator are estimates intended for educational, informational, and illustrative purposes only. Nothing on this website constitutes regulated financial advice, tax advice, or legal advice. Because individual circumstances, historical tax positions, and employer payroll software configurations vary, your actual payslip may differ from these estimates. 
                </p>
                <p>
                  We accept no liability for any errors, omissions, or financial actions taken based on the outputs of this tool. If you require absolute certainty regarding your tax liabilities, we strongly recommend consulting with a qualified accountant or an Independent Financial Adviser (IFA) registered with the Financial Conduct Authority (FCA). For comprehensive details on our accuracy standards, please review our <Link to="/editorial-policy" className="text-primary hover:underline font-medium">Editorial Policy</Link> and <Link to="/financial-disclaimer" className="text-primary hover:underline font-medium">Full Disclaimer</Link>.
                </p>
              </section>

            </div>
          </div>
        </div>
      </section>

    </div>
  );
}

export default UKSalaryCalculator;