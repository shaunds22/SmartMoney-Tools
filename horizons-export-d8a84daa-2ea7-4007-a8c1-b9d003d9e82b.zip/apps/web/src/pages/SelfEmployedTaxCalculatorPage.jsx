import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import DisclaimerBanner from '@/components/DisclaimerBanner.jsx';
import HowWeCalculateThis from '@/components/HowWeCalculateThis.jsx';
import CalculatorContentSection from '@/components/CalculatorContentSection.jsx';
import { Link } from 'react-router-dom';
import { setPageMeta } from '@/utils/seo.js';
import useCurrency from '@/hooks/useCurrency.js';
import useCurrencyDefault from '@/hooks/useCurrencyDefault.js';
import AuthorAttribution from '@/components/AuthorAttribution.jsx';
import { taxYear2026_27 as UK_TAX } from '@/config/taxYear2026_27.js';

export default function SelfEmployedTaxCalculatorPage() {
  const { currency } = useCurrency();

  // UK-specific page: default to British pounds until the visitor picks a currency
  useCurrencyDefault('GBP');

  const [income, setIncome] = useState(50000);
  const [expenses, setExpenses] = useState(5000);
  const [results, setResults] = useState(null);

  useEffect(() => {
    // Reset state on mount
    setIncome(50000);
    setExpenses(5000);
    setResults(null);
    
    setPageMeta('UK Self-Employed Tax Calculator | SmartMoneyTools', 'Estimate tax and National Insurance for the self-employed in the UK.', 'https://smartmoney-tools.com/self-employed-tax-calculator');
  }, []);

  useEffect(() => {
    let profit = Math.max(0, income - expenses);
    const { base: paBase, reductionThreshold: paRedThreshold, reductionRate: paRedRate } = UK_TAX.personalAllowance;
    let personalAllowance = paBase;
    if (profit > paRedThreshold) {
      personalAllowance = Math.max(0, personalAllowance - (profit - paRedThreshold) * paRedRate);
    }

    let taxable = Math.max(0, profit - personalAllowance);
    let tax = 0;

    // Income Tax bands are expressed relative to the Personal Allowance.
    const bands = UK_TAX.incomeTax.englandWalesNI;
    for (let i = 0; i < bands.length; i++) {
      const band = bands[i];
      if (taxable > band.threshold) {
        const bandWidth = Math.min(taxable, band.limit) - band.threshold;
        tax += Math.max(0, bandWidth) * band.rate;
      }
    }

    // Class 4 NI on profits
    const { lowerProfitsLimit, upperProfitsLimit, mainRate, upperRate } = UK_TAX.nationalInsurance.class4;
    let class4NI = 0;
    if (profit > lowerProfitsLimit) {
      class4NI += Math.min(profit - lowerProfitsLimit, upperProfitsLimit - lowerProfitsLimit) * mainRate;
      if (profit > upperProfitsLimit) {
        class4NI += (profit - upperProfitsLimit) * upperRate;
      }
    }

    let totalDeductions = tax + class4NI;
    let net = profit - totalDeductions;

    setResults({
      profit,
      taxable,
      tax,
      class4NI,
      totalDeductions,
      net,
      effectiveRate: profit > 0 ? (totalDeductions / profit) * 100 : 0
    });
  }, [income, expenses]);

  return (
    <div className="flex flex-col w-full bg-background py-12">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="mb-4 text-center">
          <span className="inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-sm font-medium text-primary border border-primary/20">Tax Year: 2026/27 (6 April 2026 – 5 April 2027) · Last reviewed: 11 September 2026</span>
        </div>
        <h1 className="text-4xl font-extrabold mb-4 text-center text-balance">UK Self-Employed Tax Calculator</h1>
        <AuthorAttribution lastReviewedDate="2026-09-11" />
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="space-y-6 bg-card p-6 rounded-2xl border shadow-sm">
            <div>
              <Label>Annual Trading Income ({currency.symbol})</Label>
              <Input type="number" value={income} onChange={(e) => setIncome(Number(e.target.value))} />
            </div>
            <div>
              <Label>Allowable Business Expenses ({currency.symbol})</Label>
              <Input type="number" value={expenses} onChange={(e) => setExpenses(Number(e.target.value))} />
            </div>
            <p className="text-sm text-muted-foreground mt-4">
              Uses UK 2026/27 tax bands and Class 4 NI rates. Simplified estimate for educational purposes only.
            </p>
          </div>
          
          <div className="bg-card p-6 rounded-2xl border shadow-sm">
            <h2 className="text-2xl font-bold mb-6">Tax Breakdown</h2>
            {results && (
              <div className="space-y-4">
                <div className="flex justify-between border-b pb-2">
                  <span className="text-muted-foreground">Net Profit</span>
                  <span className="font-semibold">{currency.symbol}{results.profit.toLocaleString(undefined, {maximumFractionDigits:2})}</span>
                </div>
                <div className="flex justify-between border-b pb-2">
                  <span className="text-muted-foreground">Income Tax</span>
                  <span className="font-semibold text-destructive">{currency.symbol}{results.tax.toLocaleString(undefined, {maximumFractionDigits:2})}</span>
                </div>
                <div className="flex justify-between border-b pb-2">
                  <span className="text-muted-foreground">Class 4 NI</span>
                  <span className="font-semibold text-destructive">{currency.symbol}{results.class4NI.toLocaleString(undefined, {maximumFractionDigits:2})}</span>
                </div>
                <div className="flex justify-between border-b pb-2">
                  <span className="font-bold">Total Take-Home</span>
                  <span className="font-bold text-primary text-xl">{currency.symbol}{results.net.toLocaleString(undefined, {maximumFractionDigits:2})}</span>
                </div>
                <div className="flex justify-between pt-4">
                  <span className="text-sm text-muted-foreground">Effective Tax Rate</span>
                  <span className="font-semibold text-sm">{results.effectiveRate.toFixed(1)}%</span>
                </div>
              </div>
            )}
          </div>
        </div>

        <HowWeCalculateThis region="UK" />

        <DisclaimerBanner />

        <div className="mt-16">
          <CalculatorContentSection title="What this calculator estimates">
            <p>Unlike employees, who have tax deducted automatically through PAYE, sole traders and freelancers must work out and pay their own tax via HMRC's Self Assessment. This tool estimates the two charges you'll face on your trading profit: <strong>Income Tax</strong> and <strong>Class 4 National Insurance</strong>. Enter your turnover and allowable expenses, and it shows your net profit, the tax split, your take-home, and an effective tax rate — so you know roughly how much to set aside for the January bill.</p>
            <p>It is a simplified estimate for a sole trader with no other income. It does not handle Limited Companies (Corporation Tax and dividends), VAT, or Payments on Account — see the exclusions below.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="What you need before you start">
            <ul>
              <li>Your <strong>total turnover</strong> for the tax year — all sales and business income before any costs.</li>
              <li>Your <strong>allowable expenses</strong> — costs incurred wholly and exclusively for your trade (software, equipment, travel, a portion of home bills if you work from home). Keep receipts; HMRC can ask for them.</li>
              <li>Whether you have <strong>any other income</strong> (a PAYE job, rental income, dividends). If you do, this estimate will be wrong because your Personal Allowance may already be used up.</li>
              <li>Your <strong>VAT status</strong> — the figures you enter should exclude VAT if you're registered, because VAT you collect belongs to HMRC, not to your profit.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="What each input means">
            <ul>
              <li><strong>Annual Trading Income ({currency.symbol})</strong> — your gross turnover for the tax year: everything you invoiced or sold, before deducting any costs.</li>
              <li><strong>Allowable Business Expenses ({currency.symbol})</strong> — the total of costs you can legitimately set against that income to reduce your taxable profit. Only claim costs that are wholly and exclusively for your business — personal spending does not count.</li>
            </ul>
            <p>The calculator subtracts expenses from income to find your <strong>net profit</strong>, then applies the Personal Allowance, tax bands, and Class 4 NI to that profit.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="How to read your tax breakdown">
            <p><strong>Net Profit</strong> is what's actually taxed — turnover minus expenses. <strong>Income Tax</strong> is charged on profit above the {currency.symbol}12,570 Personal Allowance, at 20% (basic), 40% (higher, above {currency.symbol}50,270), or 45% (additional, above {currency.symbol}125,140). <strong>Class 4 NI</strong> is charged at 6% on profits between {currency.symbol}12,570 and {currency.symbol}50,270, and 2% above that. <strong>Total Take-Home</strong> is your profit minus both charges — the money you actually keep. The <strong>Effective Tax Rate</strong> is your total deductions as a percentage of profit, which is usually lower than people expect because the Personal Allowance shields the first chunk of profit entirely.</p>
            <p>A practical rule: if your effective rate is around 18%, set aside roughly 20–25% of every invoice to cover tax <em>and</em> Payments on Account (explained below).</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Worked example">
            <p>A freelance graphic designer with {currency.symbol}50,000 turnover and {currency.symbol}8,000 of allowable expenses (software, equipment, travel, home-office portion):</p>
            <ul>
              <li><strong>Net Profit:</strong> {currency.symbol}42,000</li>
              <li><strong>Income Tax</strong> (20% on profit above {currency.symbol}12,570): <strong>{currency.symbol}5,886</strong></li>
              <li><strong>Class 4 NI</strong> (6% on profit between {currency.symbol}12,570 and {currency.symbol}42,000): <strong>{currency.symbol}1,765.80</strong></li>
              <li><strong>Total Deductions:</strong> {currency.symbol}7,651.80</li>
              <li><strong>Net Take-Home:</strong> <strong>{currency.symbol}34,348.20</strong></li>
            </ul>
            <p>An effective rate of about 18%. This freelancer should move roughly {currency.symbol}1,450 a month into a separate HMRC savings account so the January bill never catches them short.</p>
          </CalculatorContentSection>

          <CalculatorContentSection title="Assumptions and exclusions">
            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">Assumptions</h3>
            <ul>
              <li>Standard UK 2026/27 income tax bands (England, Wales, NI). Scottish rates are not applied.</li>
              <li>Personal Allowance {currency.symbol}12,570, reducing by {currency.symbol}1 per {currency.symbol}2 earned above {currency.symbol}100,000.</li>
              <li>Class 4 NI: 6% on profits {currency.symbol}12,570–{currency.symbol}50,270; 2% above {currency.symbol}50,270.</li>
              <li>Class 2 NI abolished from 6 April 2024 for most self-employed (not calculated here).</li>
              <li>No other income sources; figures exclude VAT.</li>
            </ul>
            <h3 className="text-lg font-semibold mt-4 mb-2 text-foreground">What is not included</h3>
            <ul>
              <li><strong>Payments on Account</strong> — if your bill exceeds {currency.symbol}1,000, HMRC demands advance payments toward next year's tax in January and July (each 50% of the prior bill). This can roughly double what you owe in your second year.</li>
              <li>Student Loan repayments collected via Self Assessment.</li>
              <li>Capital allowances or loss carry-forward.</li>
              <li>Corporation Tax (Limited Companies only) and dividend tax.</li>
              <li>VAT obligations (registration threshold: {currency.symbol}90,000).</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Common mistakes to avoid">
            <ul>
              <li><strong>Spending the gross.</strong> The classic first-year error. The moment an invoice is paid, move 20–30% into a separate account — it is not yours to spend.</li>
              <li><strong>Being caught by Payments on Account.</strong> A {currency.symbol}7,000 bill in year one becomes {currency.symbol}10,500 due the following January (the year-two bill plus the first payment on account). Budget for it from day one.</li>
              <li><strong>Missing allowable expenses.</strong> Forgetting a portion of home utilities, mileage, or software inflates your profit and overpays tax. Keep a simple log.</li>
              <li><strong>Confusing turnover with profit.</strong> {currency.symbol}50,000 of sales is not {currency.symbol}50,000 of taxable income. Only profit is taxed.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Sensible next steps">
            <ul>
              <li>Open a separate, dull savings account purely for tax and transfer your estimated percentage into it every time you're paid.</li>
              <li>Register for Self Assessment by 5 October after your first tax year of self-employment if you haven't already — see <a href="https://www.gov.uk/register-for-self-assessment" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK – Register for Self Assessment</a>.</li>
              <li>Keep digital records of income and expenses; the Making Tax Digital rules are extending to sole traders, so good records are becoming mandatory, not optional.</li>
              <li>If your profit is volatile or you're approaching the VAT threshold, consider speaking to a qualified accountant — the saving usually exceeds the fee.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Related guides and calculators">
            <ul>
              <li><Link to="/uk-salary-calculator" className="text-primary hover:underline">UK Salary Calculator</Link>: Compare your self-employed take-home against an equivalent PAYE salary.</li>
              <li><Link to="/budget-planner" className="text-primary hover:underline">Budget Planner</Link>: Manage fluctuating self-employed income against fixed monthly costs.</li>
              <li><Link to="/guides/self-employed-tax-planning" className="text-primary hover:underline">Self-Employed Tax Planning Guide</Link>: Allowable expenses, Self Assessment deadlines, and VAT in depth.</li>
              <li><Link to="/guides/side-hustle-tax" className="text-primary hover:underline">Side Hustle Tax Guide</Link>: The {currency.symbol}1,000 Trading Allowance and reporting thresholds.</li>
            </ul>
          </CalculatorContentSection>

          <CalculatorContentSection title="Sources and references">
            <p className="text-sm bg-primary/5 p-3 rounded-lg border border-primary/20 mb-4">SmartMoneyTools checks statutory rates and thresholds against official government publications. Results are estimates for educational purposes and may not reflect every individual circumstance. <strong>Last reviewed: 11 September 2026.</strong></p>
            <div className="overflow-x-auto">
              <table className="w-full text-sm border-collapse">
                <thead><tr className="bg-muted text-left"><th className="p-2 font-semibold border border-border">Data Item</th><th className="p-2 font-semibold border border-border">Value Used</th><th className="p-2 font-semibold border border-border">Period</th><th className="p-2 font-semibold border border-border">Source</th></tr></thead>
                <tbody>
                  <tr><td className="p-2 border border-border">Personal Allowance</td><td className="p-2 border border-border">£12,570</td><td className="p-2 border border-border">2026/27</td><td className="p-2 border border-border"><a href="https://www.gov.uk/income-tax-rates" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK</a></td></tr>
                  <tr><td className="p-2 border border-border">Basic/Higher/Additional Rate</td><td className="p-2 border border-border">20% / 40% / 45%</td><td className="p-2 border border-border">2026/27</td><td className="p-2 border border-border"><a href="https://www.gov.uk/income-tax-rates" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK</a></td></tr>
                  <tr><td className="p-2 border border-border">Class 4 NI (main / upper)</td><td className="p-2 border border-border">6% / 2%</td><td className="p-2 border border-border">2026/27</td><td className="p-2 border border-border"><a href="https://www.gov.uk/self-employed-national-insurance-rates" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK</a></td></tr>
                  <tr><td className="p-2 border border-border">Lower Profits Limit</td><td className="p-2 border border-border">£12,570</td><td className="p-2 border border-border">2026/27</td><td className="p-2 border border-border"><a href="https://www.gov.uk/self-employed-national-insurance-rates" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK</a></td></tr>
                  <tr><td className="p-2 border border-border">VAT Registration Threshold</td><td className="p-2 border border-border">£90,000</td><td className="p-2 border border-border">From Apr 2024</td><td className="p-2 border border-border"><a href="https://www.gov.uk/vat-registration/when-to-register" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">GOV.UK</a></td></tr>
                </tbody>
              </table>
            </div>
          </CalculatorContentSection>
          
          <div className="mt-12 pt-8 border-t border-border text-center">
            <p className="text-muted-foreground text-sm">
              Want to know exactly how we calculate these numbers? <Link to="/calculation-methodology" className="text-primary hover:underline font-medium">See our calculation methodology</Link>.
            </p>
          </div>
          
        </div>
      </div>
    </div>
  );
}
