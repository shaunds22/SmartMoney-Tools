import React, { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Search, Home, ArrowRight, Calculator, BookOpen, Mail, Compass } from 'lucide-react';
import { Button } from '@/components/ui/button';

// Searchable index of popular destinations shown on the 404 page.
const SEARCH_INDEX = [
  { name: 'UK Salary Calculator', path: '/uk-salary-calculator', kind: 'Calculator' },
  { name: 'US Salary Calculator', path: '/us-salary-calculator', kind: 'Calculator' },
  { name: 'US Retirement Calculator', path: '/us-retirement-calculator', kind: 'Calculator' },
  { name: 'Compound Interest Calculator', path: '/compound-interest', kind: 'Calculator' },
  { name: 'Mortgage Calculator', path: '/mortgage', kind: 'Calculator' },
  { name: 'Pensions Calculator', path: '/pensions-calculator', kind: 'Calculator' },
  { name: 'Budget Planner', path: '/budget-planner', kind: 'Calculator' },
  { name: 'Self-Employed Tax Calculator', path: '/self-employed-tax-calculator', kind: 'Calculator' },
  { name: 'Debt Snowball Calculator', path: '/debt-snowball-calculator', kind: 'Calculator' },
  { name: 'Savings Goal Calculator', path: '/savings-goal-calculator', kind: 'Calculator' },
  { name: 'All Calculators', path: '/#calculators', kind: 'Calculator' },
  { name: 'Financial Guides Library', path: '/guides', kind: 'Guide' },
  { name: 'UK Income Tax Guide', path: '/guides/uk-income-tax', kind: 'Guide' },
  { name: 'National Insurance Guide', path: '/guides/national-insurance', kind: 'Guide' },
  { name: 'Pension Planning Guide', path: '/guides/pension-planning', kind: 'Guide' },
  { name: 'Mortgage Comprehensive Guide', path: '/guides/mortgage-comprehensive', kind: 'Guide' },
  { name: 'First-Time Buyer Guide', path: '/guides/first-time-buyer', kind: 'Guide' },
  { name: 'Debt Repayment Guide', path: '/guides/debt-repayment', kind: 'Guide' },
  { name: 'Emergency Fund Guide', path: '/guides/emergency-fund', kind: 'Guide' },
  { name: 'Savings Goals Guide', path: '/guides/savings-goals', kind: 'Guide' },
  { name: 'About SmartMoneyTools', path: '/about', kind: 'Page' },
  { name: 'Contact Support', path: '/contact', kind: 'Page' },
  { name: 'FAQ', path: '/faq', kind: 'Page' },
];

function NotFound() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');

  useEffect(() => {
    document.title = 'Page Not Found (404) | SmartMoneyTools';
  }, []);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return SEARCH_INDEX.slice(0, 6);
    return SEARCH_INDEX.filter((item) => item.name.toLowerCase().includes(q)).slice(0, 8);
  }, [query]);

  const onSubmit = (e) => {
    e.preventDefault();
    if (results.length > 0) {
      navigate(results[0].path);
    }
  };

  return (
    <>
      <Helmet>
        <title>Page Not Found (404) | SmartMoneyTools</title>
        <meta name="description" content="Sorry, the page you were looking for could not be found. Use our navigation to find free financial calculators and guides." />
        <meta name="robots" content="noindex, follow" />
      </Helmet>

      <div className="min-h-[70vh] flex items-center py-20 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-2xl mx-auto">
            <div className="mb-8 flex justify-center">
              <div className="h-24 w-24 rounded-full bg-muted flex items-center justify-center">
                <Compass className="h-10 w-10 text-muted-foreground" />
              </div>
            </div>

            <h1 className="text-5xl md:text-6xl font-extrabold text-foreground mb-4" style={{ letterSpacing: '-0.02em' }}>
              404
            </h1>
            <h2 className="text-2xl font-bold text-foreground mb-4">
              Page Not Found
            </h2>
            <p className="text-lg text-muted-foreground mb-4 leading-relaxed">
              Sorry, the page you are looking for does not exist or has been moved.
            </p>
            <p className="text-sm text-muted-foreground mb-10">
              If you believe this is an error, contact us at{' '}
              <a href="mailto:support@smartmoney-tools.com" className="text-primary hover:underline">
                support@smartmoney-tools.com
              </a>
            </p>

            <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
              <Button asChild size="lg" className="px-8">
                <Link to="/">
                  <Home className="mr-2 h-5 w-5" /> Back to Home
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="px-8">
                <Link to="/#calculators">
                  <Calculator className="mr-2 h-5 w-5" /> Calculator Library
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="px-8">
                <Link to="/guides">
                  <BookOpen className="mr-2 h-5 w-5" /> Browse Guides
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="px-8">
                <Link to="/contact">
                  <Mail className="mr-2 h-5 w-5" /> Contact Us
                </Link>
              </Button>
            </div>

            {/* Search / navigation */}
            <div className="bg-card rounded-2xl p-8 border border-border shadow-sm text-left mb-8">
              <h3 className="text-lg font-semibold text-foreground mb-2 flex items-center gap-2">
                <Search className="h-5 w-5 text-primary" /> Find what you need
              </h3>
              <p className="text-sm text-muted-foreground mb-5">
                Search our calculators and guides, or pick a popular destination below.
              </p>
              <form onSubmit={onSubmit} className="mb-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <input
                    type="search"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search calculators and guides…"
                    aria-label="Search calculators and guides"
                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-input bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>
              </form>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {results.map(({ name, path, kind }) => (
                  <Link
                    key={`${kind}-${path}`}
                    to={path}
                    className="group p-3 bg-muted/50 rounded-xl hover:bg-primary/5 transition-colors border border-transparent hover:border-primary/20"
                  >
                    <span className="font-medium text-foreground group-hover:text-primary flex items-center justify-between text-sm">
                      <span className="flex items-center gap-2">
                        <span className="text-[10px] uppercase tracking-wider font-semibold text-muted-foreground">{kind}</span>
                        {name}
                      </span>
                      <ArrowRight className="h-4 w-4 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                    </span>
                  </Link>
                ))}
                {results.length === 0 && (
                  <p className="text-sm text-muted-foreground col-span-full py-4">
                    No matches. Try another term, or{' '}
                    <Link to="/guides" className="text-primary hover:underline">browse all guides</Link>.
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default NotFound;
