import React from 'react';
import PageSeo from '@/components/PageSeo.jsx';
import { Link } from 'react-router-dom';
import Breadcrumb from '@/components/Breadcrumb.jsx';

function FinancialDisclaimerPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <PageSeo
        title="Financial Disclaimer | SmartMoneyTools"
        description="Important financial disclaimer for SmartMoneyTools. Our calculators provide educational estimates only and do not constitute professional financial, tax, mortgage, pension, or investment advice."
        path="/financial-disclaimer"
      />

      <section className="bg-primary text-primary-foreground py-12 border-b border-primary/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">
          <h1 className="text-4xl md:text-5xl font-extrabold mb-4 leading-tight" style={{ letterSpacing: '-0.02em' }}>
            Financial Disclaimer
          </h1>
          <p className="text-lg text-primary-foreground/85">
            Important information about the limitations and intended use of SmartMoneyTools calculators and guides.
          </p>
        </div>
      </section>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl pt-6 pb-0">
        <Breadcrumb items={[{ label: 'Financial Disclaimer' }]} />
      </div>

      <main className="flex-grow py-10 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">

          <div className="bg-destructive/10 border border-destructive/20 rounded-xl px-6 py-4 mb-10 text-sm text-destructive">
            <strong className="text-destructive">Important Notice:</strong> Please read this disclaimer carefully before using SmartMoneyTools. By accessing or using this website, you acknowledge and accept the limitations and disclaimers outlined below.
          </div>

          <div className="prose prose-slate max-w-none text-muted-foreground prose-headings:text-foreground prose-a:text-primary hover:prose-a:text-primary/80 prose-strong:text-foreground space-y-2">

            {/* 1 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">1. Important Notice</h2>
            <p>
              SmartMoneyTools is a free online platform that provides financial calculators and educational guides. This disclaimer sets out the important limitations and conditions that apply to your use of our calculators, tools, and content.
            </p>
            <p>
              <strong>By using SmartMoneyTools, you accept full responsibility for any decisions you make based on information obtained from this website.</strong> We strongly recommend that you seek professional advice before making any significant financial decision.
            </p>

            {/* 2 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">2. Educational Information Only</h2>
            <p>
              All content on SmartMoneyTools — including calculator outputs, results, tables, charts, articles, and guides — is provided <strong>solely for educational and general informational purposes</strong>. Our calculators are designed to help you understand financial concepts and explore illustrative scenarios based on your own inputs.
            </p>
            <p>
              Nothing on this website should be treated as a substitute for professional advice from a qualified adviser, accountant, tax specialist, mortgage broker, pensions adviser, solicitor, or other suitable professional.
            </p>

            {/* 3 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">3. No Regulated Financial Advice</h2>
            <p>
              SmartMoneyTools does <strong>NOT</strong> provide personalised financial advice. We do not:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>Recommend specific financial products or services</li>
              <li>Advise you on whether a particular investment, loan, or financial product is suitable for your circumstances</li>
              <li>Provide guidance tailored to your individual financial situation</li>
              <li>Make recommendations about how you should manage your money</li>
            </ul>
            <p className="mt-4">
              Our calculators produce mathematical estimates based on standard formulas and publicly available statutory data. They do not account for your personal circumstances, tax code, benefits, allowances, or other individual factors that may affect the accuracy of results.
            </p>

            {/* 4 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">4. Not FCA-Authorised to Provide Personal Advice</h2>
            <p>
              SmartMoneyTools is <strong>not authorised or regulated by the Financial Conduct Authority (FCA)</strong> or any other financial regulatory body. We are not permitted to provide personalised financial advice, and we do not hold any professional qualifications in financial planning, investment advice, mortgage brokerage, tax advice, pensions advice, or legal services.
            </p>
            <p>
              If you require advice on any financial matter, you should consult an appropriately qualified and regulated professional. For a list of FCA-regulated advisers, visit <a href="https://register.fca.org.uk" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">the FCA register</a>.
            </p>

            {/* 5 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">5. Calculator Results Are Estimates</h2>
            <p>
              All calculator results are <strong>estimates only</strong> and should not be treated as definitive or guaranteed figures. Our calculators:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>Use publicly available statutory data (such as HMRC tax bands, National Insurance thresholds, and IRS withholding tables)</li>
              <li>Apply standard mathematical formulas to your inputs</li>
              <li>May differ from figures produced by HMRC, your employer's payroll system, your mortgage lender, or any other official source</li>
              <li>Cannot replicate the full complexity of your personal financial situation</li>
              <li>May contain errors or omissions</li>
              <li>May not reflect the most recent statutory changes or tax year updates</li>
            </ul>
            <p className="mt-4">
              <strong>Always verify calculator results against official sources</strong> (such as your payslip, HMRC's own tools, or your lender's documentation) before relying on them for any decision.
            </p>

            {/* 6 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">6. Tax, Pension, Mortgage, Debt, Savings, and Investment Limitations</h2>
            
            <h3 className="text-xl font-semibold text-foreground mt-6 mb-3">Tax Calculations</h3>
            <p>
              Our tax calculators provide estimates based on standard tax codes and statutory rates. They do not account for:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-2">
              <li>Personalised tax codes or adjustments</li>
              <li>Benefits in kind or taxable expenses</li>
              <li>Multiple income sources or complex tax situations</li>
              <li>Tapering reliefs, marriage allowance, or other allowances specific to your circumstances</li>
              <li>Recent tax code changes or mid-year adjustments</li>
            </ul>
            <p className="mt-4">
              For accurate tax calculations, consult HMRC directly, use their official calculators, or speak to a qualified accountant or tax adviser.
            </p>

            <h3 className="text-xl font-semibold text-foreground mt-6 mb-3">Pension Calculations</h3>
            <p>
              Our pension calculators provide illustrative projections only. They do not account for:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-2">
              <li>Actual investment performance or market volatility</li>
              <li>Pension scheme-specific rules or restrictions</li>
              <li>Lifetime Allowance, Annual Allowance, or other regulatory limits specific to your situation</li>
              <li>Salary sacrifice arrangements or employer contributions</li>
              <li>Drawdown rules or annuity rates at retirement</li>
            </ul>
            <p className="mt-4">
              Before making pension decisions, consult a qualified pensions adviser or contact your pension provider directly.
            </p>

            <h3 className="text-xl font-semibold text-foreground mt-6 mb-3">Mortgage Calculations</h3>
            <p>
              Our mortgage calculators provide estimates based on standard assumptions. They do not account for:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-2">
              <li>Actual interest rates offered by your lender</li>
              <li>Arrangement fees, valuation fees, or legal fees</li>
              <li>Mortgage protection insurance or other add-ons</li>
              <li>Stress testing or affordability assessments by lenders</li>
              <li>Early repayment charges or overpayment restrictions</li>
            </ul>
            <p className="mt-4">
              Always obtain a formal mortgage offer from a regulated lender before committing to a purchase. Consult a mortgage broker or FCA-regulated financial adviser for personalised guidance.
            </p>

            <h3 className="text-xl font-semibold text-foreground mt-6 mb-3">Debt and Savings Calculations</h3>
            <p>
              Our debt and savings calculators provide illustrative scenarios only. They do not account for:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-2">
              <li>Variable interest rates or changes to lending terms</li>
              <li>Missed payments or penalties</li>
              <li>Credit score impacts or affordability checks</li>
              <li>Actual savings rates offered by financial institutions</li>
              <li>Tax on savings interest (Personal Savings Allowance, etc.)</li>
            </ul>
            <p className="mt-4">
              For debt advice, contact <a href="https://www.stepchange.org" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">StepChange</a>, <a href="https://www.nationaldebtline.org" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">National Debtline</a>, or <a href="https://www.citizensadvice.org.uk" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Citizens Advice</a>.
            </p>

            <h3 className="text-xl font-semibold text-foreground mt-6 mb-3">Investment Calculations</h3>
            <p>
              Our investment and compound interest calculators use hypothetical rates of return. They do not account for:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-2">
              <li>Actual market performance or volatility</li>
              <li>Investment fees, charges, or platform costs</li>
              <li>Capital gains tax or income tax on investment returns</li>
              <li>Inflation or changes in purchasing power</li>
              <li>Risk factors or suitability for your circumstances</li>
            </ul>
            <p className="mt-4">
              <strong>Past performance is never a guarantee of future results.</strong> Before investing, consult an FCA-regulated financial adviser who can assess your risk tolerance and financial goals.
            </p>

            {/* 7 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">7. Individual Circumstances Vary</h2>
            <p>
              Every person's financial situation is unique. Our calculators use simplified assumptions and cannot account for:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>Your personal income, expenses, and financial obligations</li>
              <li>Your age, health, family situation, or life circumstances</li>
              <li>Your risk tolerance, investment experience, or financial goals</li>
              <li>Your tax residency status or international tax obligations</li>
              <li>Specific allowances, reliefs, or exemptions available to you</li>
              <li>Changes in legislation, tax rates, or regulatory requirements</li>
            </ul>
            <p className="mt-4">
              Results produced by our calculators may be significantly different from your actual financial position. Always seek personalised professional advice before making important financial decisions.
            </p>

            {/* 8 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">8. Third-Party and Official Source Information</h2>
            <p>
              Our calculators and guides reference publicly available information from official sources such as:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>HM Revenue & Customs (HMRC)</li>
              <li>GOV.UK</li>
              <li>The UK Pensions Regulator</li>
              <li>The Pensions Advisory Service</li>
              <li>MoneyHelper</li>
              <li>The US Internal Revenue Service (IRS)</li>
              <li>The US Social Security Administration (SSA)</li>
            </ul>
            <p className="mt-4">
              Whilst we make every effort to keep this information current and accurate, there may be delays in updating our calculators after official changes. We do not guarantee that all information is complete, accurate, or up to date. For the most current information, always consult the official sources directly.
            </p>

            {/* 9 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">9. Professional Advice Recommendation</h2>
            <p>
              Before making any significant financial decision, you should seek advice from an appropriately qualified and regulated professional. Depending on your needs, this may include:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li><strong>Financial Adviser:</strong> An FCA-authorised financial adviser for investment, savings, and general financial planning advice</li>
              <li><strong>Accountant or Tax Adviser:</strong> A qualified accountant (ICAEW, ACCA, CIOT member) for tax planning and tax return preparation</li>
              <li><strong>Mortgage Broker:</strong> An FCA-regulated mortgage broker for mortgage advice and applications</li>
              <li><strong>Pensions Adviser:</strong> A qualified pensions adviser or actuary for pension planning and retirement projections</li>
              <li><strong>Solicitor:</strong> An SRA-regulated solicitor for legal advice on property purchases, contracts, and other legal matters</li>
              <li><strong>Debt Adviser:</strong> A qualified debt adviser from StepChange, National Debtline, or Citizens Advice for debt management</li>
            </ul>
            <p className="mt-4">
              Free, impartial guidance is also available from:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li><a href="https://www.moneyhelper.org.uk" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">MoneyHelper</a> (formerly the Money Advice Service)</li>
              <li><a href="https://www.pensionsadvisoryservice.org.uk" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">The Pensions Advisory Service</a></li>
              <li><a href="https://www.citizensadvice.org.uk" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Citizens Advice</a></li>
              <li><a href="https://www.stepchange.org" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">StepChange Debt Charity</a></li>
            </ul>

            {/* 10 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">10. No Liability for Decisions</h2>
            <p>
              To the fullest extent permitted by applicable law, SmartMoneyTools, its owners, developers, and contributors shall not be liable for:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>Any financial loss, loss of profits, loss of data, or any indirect, incidental, consequential, or special damages arising from your use of this website</li>
              <li>Any inaccuracy, omission, or error in calculator results or content</li>
              <li>Any decision you make — financial or otherwise — based on information obtained from this website</li>
              <li>Interruptions to or unavailability of the website or calculators</li>
              <li>Any content, information, or advice obtained from third-party websites linked from this website</li>
              <li>Any loss or damage caused by reliance on outdated statutory data or tax rates</li>
            </ul>
            <p className="mt-4">
              <strong>You use SmartMoneyTools entirely at your own risk.</strong> You accept full responsibility for verifying calculator results and seeking professional advice before making any financial decision.
            </p>

            {/* 11 */}
            <h2 className="text-2xl font-semibold text-foreground mt-10 mb-4">11. Contact Details</h2>
            <p>
              If you have questions about this Financial Disclaimer, believe you have found an error in a calculator, or wish to contact us for any other reason, please get in touch:
            </p>
            <ul className="list-none pl-0 mt-3 space-y-1">
              <li><strong>Email:</strong> <a href="mailto:support@smartmoney-tools.com" className="text-primary hover:underline">support@smartmoney-tools.com</a></li>
              <li><strong>Contact form:</strong> <Link to="/contact" className="text-primary hover:underline">smartmoney-tools.com/contact</Link></li>
            </ul>

            <div className="mt-12 pt-8 border-t border-border text-sm text-muted-foreground">
              <p>
                For related policies, see our <Link to="/privacy" className="text-primary hover:underline">Privacy Policy</Link>, <Link to="/terms" className="text-primary hover:underline">Terms of Use</Link>, and <Link to="/cookie-policy" className="text-primary hover:underline">Cookie Policy</Link>.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default FinancialDisclaimerPage;
