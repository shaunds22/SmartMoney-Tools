import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import USRetirementCalculator from '@/components/USRetirementCalculator.jsx';
import RetirementResults from '@/components/RetirementResults.jsx';
import FAQAccordion from '@/components/FAQAccordion.jsx';
import DisclaimerBanner from '@/components/DisclaimerBanner.jsx';
import HowWeCalculateThis from '@/components/HowWeCalculateThis.jsx';
import { setPageMeta } from '@/utils/seo.js';
import { CheckCircle2, PiggyBank, Briefcase, TrendingUp } from 'lucide-react';
import AuthorAttribution from '@/components/AuthorAttribution.jsx';
import AuthorBylineBar from '@/components/AuthorBylineBar.jsx';
import useCurrencyDefault from '@/hooks/useCurrencyDefault.js';

export default function USRetirementCalculatorPage() {
  const [results, setResults] = useState(null);

  // US-specific page: default to US dollars until the visitor picks a currency
  useCurrencyDefault('USD');

  useEffect(() => {
    // Clear any stored session values from previous instances
    sessionStorage.removeItem('us-retirement-calc');
    setResults(null);
    
    setPageMeta(
      'US Retirement Calculator | Estimate Savings and Income',
      'Free comprehensive US retirement calculator. Project 401(k), IRA savings, employer match, Social Security, and see if your money will last through retirement.',
      'https://smartmoney-tools.com/us-retirement-calculator'
    );
  }, []);

  const handleCalculate = (calcResults) => {
    setResults(calcResults);
  };

  const faqItems = [
    { question: 'How much money do I need to retire?', answer: 'A common rule of thumb is aiming for a portfolio that equals 25 times your expected annual expenses, allowing you to withdraw 4% annually. However, your exact number depends heavily on your lifestyle, Social Security benefits, inflation, and lifespan.' },
    { question: 'How does the retirement calculator work?', answer: 'It builds a year-by-year projection. During your working years, it adds your contributions, employer match, and investment returns while subtracting fees. In retirement, it calculates your income target, subtracts Social Security/Pensions, and withdraws the shortfall from your investments to see how long they last.' },
    { question: 'What is a 401(k) and how does employer matching work?', answer: 'A 401(k) is a tax-advantaged retirement account offered by US employers. Employer matching is "free money" where your company contributes to your account based on your own contributions—often up to a certain percentage of your salary (e.g., matching 100% of your first 3% contributed).' },
    { question: 'What is the difference between traditional and Roth contributions?', answer: 'Traditional contributions are made pre-tax (lowering your current tax bill) but are taxed upon withdrawal in retirement. Roth contributions are made with after-tax money, but grow tax-free and withdrawals in retirement are completely tax-free.' },
    { question: 'How much should I contribute to retirement savings?', answer: 'Financial planners generally recommend saving 10% to 15% of your gross income for retirement, starting in your 20s. At a minimum, you should always contribute enough to get your full employer match.' },
    { question: 'What is Social Security and when should I claim it?', answer: 'Social Security is a federal safety net providing guaranteed monthly income in retirement. You can claim it as early as 62 (for a reduced benefit), at your Full Retirement Age (usually 67), or delay until 70 for the maximum possible monthly benefit.' },
    { question: 'How do investment returns and fees affect retirement savings?', answer: 'Compound interest is powerful, but fees drag it down. A seemingly small 1% annual investment fee can devour hundreds of thousands of dollars over a 30-year investing horizon.' },
    { question: 'What is the 4% rule?', answer: 'The 4% rule is a withdrawal strategy that suggests you can safely withdraw 4% of your initial retirement portfolio in your first year, adjusting for inflation thereafter, with a high probability your money will last 30 years.' },
    { question: 'How does inflation affect retirement planning?', answer: 'Inflation reduces the purchasing power of money. While $1 million sounds like a lot today, at 3% inflation, its purchasing power will be cut in half in 24 years. You must invest to outpace inflation.' },
    { question: 'What is a defined-benefit pension?', answer: 'A pension is a guaranteed monthly income provided by an employer (often government or union jobs) based on your final salary and years of service, rather than your investment returns. They often include a COLA (Cost of Living Adjustment) to fight inflation.' },
    { question: 'How long will my retirement savings last?', answer: 'This depends on your withdrawal rate, investment returns, and inflation. Our calculator runs a depletion check to explicitly show you what age your funds might run out based on your stated assumptions.' },
    { question: 'Can I retire early?', answer: 'Yes, if you save aggressively (often via the FIRE movement—Financial Independence, Retire Early). However, you must bridge the gap to age 59.5 (when you can access 401k/IRAs penalty-free) and 62+ for Social Security.' },
    { question: 'What if I have multiple jobs or employers?', answer: 'Your total employee contribution limit applies across all 401(k) plans you have. For 2026, you cannot exceed $24,500 (or the catch-up limit) in total employee contributions, even if you have three different jobs.' },
    { question: 'Should I prioritize 401(k) or IRA contributions?', answer: 'A standard order of operations: 1) 401(k) up to the employer match. 2) Max out an IRA (for better fund choices and lower fees). 3) Go back and max out the rest of the 401(k).' }
  ];

  return (
    <div className="flex flex-col w-full bg-background min-h-screen">
      <Helmet>
        <meta property="og:title" content="US Retirement Calculator | Estimate Savings and Income" />
        <meta property="og:description" content="Project your 401(k), IRA, and Social Security to see if you are on track to retire comfortably." />
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": faqItems.slice(0, 10).map(faq => ({
              "@type": "Question",
              "name": faq.question,
              "acceptedAnswer": {
                "@type": "Answer",
                "text": faq.answer
              }
            }))
          })}
        </script>
      </Helmet>

      <section className="bg-primary text-primary-foreground py-16 lg:py-24 border-b border-primary/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 leading-tight text-balance">
            US Retirement Calculator
          </h1>
          <p className="text-xl text-primary-foreground/90 leading-relaxed max-w-2xl mx-auto mb-4">
            Estimate your retirement savings and future income. Model your 401(k), IRA, employer match, and Social Security to see if your money will last.
          </p>
          <span className="inline-flex items-center rounded-full bg-white/20 px-3 py-1 text-sm font-medium text-white border border-white/30">Based on 2026 IRS limits · Last reviewed: 11 September 2026</span>
          <AuthorBylineBar variant="hero" />
        </div>
      </section>

      <div className="bg-background border-b border-border/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-3 max-w-7xl">
          <AuthorAttribution lastReviewedDate="2026-09-11" showByline={false} />
        </div>
      </div>

      <section className="py-12 bg-background border-b border-border">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-5 xl:col-span-4">
              <div className="sticky top-24">
                <USRetirementCalculator onCalculate={handleCalculate} />
              </div>
            </div>
            
            <div className="lg:col-span-7 xl:col-span-8">
              {results ? (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <RetirementResults results={results} />
                  <div className="mt-8">
                    <DisclaimerBanner text="This calculator provides hypothetical estimates for general educational and planning purposes only. It is not financial, investment, tax, legal, pension or Social Security advice. Results depend on the assumptions entered, including investment returns, inflation, fees, contributions, retirement spending and future laws. Actual results may differ, and investment returns are not guaranteed." />
                  </div>
                </div>
              ) : (
                <div className="h-full min-h-[400px] flex flex-col items-center justify-center text-center p-8 bg-muted/30 rounded-2xl border border-dashed border-border">
                  <PiggyBank className="h-16 w-16 text-muted-foreground mb-4 opacity-50" />
                  <h3 className="text-xl font-medium text-foreground mb-2">Awaiting Parameters</h3>
                  <p className="text-muted-foreground max-w-sm">Adjust the inputs on the left and click Calculate to view your projected retirement timeline.</p>
                </div>
              )}
            </div>
          </div>
          <HowWeCalculateThis region="US" />
        </div>
      </section>

      <section className="py-20 bg-background">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          <div className="prose prose-slate prose-lg dark:prose-invert max-w-none prose-headings:scroll-mt-28">
            
            <h2>How the retirement calculator works</h2>
            <p>
              Planning for retirement in the US involves coordinating multiple moving parts. Our calculator acts as a comprehensive simulation engine for your financial future. It models the two distinct phases of your financial life: the <strong>Accumulation Phase</strong> (your working years) and the <strong>Distribution Phase</strong> (your retirement years).
            </p>
            <p>
              During accumulation, the tool applies compound interest to your current balances while adding your ongoing 401(k) and IRA contributions. It explicitly factors in your employer match using standard industry formulas, ensuring you don't underestimate "free money". When you hit your retirement age, the tool pivots. It begins withdrawing money from your portfolio to meet your income target, supplementing your withdrawals with your stated Social Security and pension benefits, while applying inflation to maintain your purchasing power.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-12 not-prose">
              <div className="bg-card border p-6 rounded-xl shadow-sm">
                <Briefcase className="h-8 w-8 text-primary mb-4" />
                <h3 className="text-lg font-bold text-foreground mb-2">401(k) and Employer Matching</h3>
                <p className="text-sm text-muted-foreground">Always contribute enough to secure your full employer match. The calculator enforces IRS limits automatically, ensuring your projections remain legally realistic.</p>
              </div>
              <div className="bg-card border p-6 rounded-xl shadow-sm">
                <TrendingUp className="h-8 w-8 text-primary mb-4" />
                <h3 className="text-lg font-bold text-foreground mb-2">Inflation and Fees</h3>
                <p className="text-sm text-muted-foreground">A 1% investment fee combined with 3% inflation destroys nominal growth. The simulation explicitly subtracts fees and models purchasing power decay.</p>
              </div>
            </div>

            <h2>How much money may be needed for retirement</h2>
            <p>
              A widely cited benchmark is targeting an income replacement ratio of 70% to 80% of your pre-retirement salary. If you earn $100,000 immediately before retiring, you might need $80,000 annually to maintain your lifestyle, as you no longer pay payroll taxes or save for retirement.
            </p>
            <p>
              To generate that $80,000, you will combine Social Security (e.g., $30,000) and portfolio withdrawals ($50,000). Using the 4% rule, generating $50,000 annually requires a portfolio of approximately $1.25 million. 
            </p>

            <h2>Traditional versus Roth contributions</h2>
            <p>
              While this calculator models total balance growth, it is crucial to understand tax treatment. Traditional 401(k) and IRA contributions are made pre-tax, meaning your withdrawals in retirement will be subject to ordinary income tax. Roth contributions are made after-tax; the balance grows tax-free, and withdrawals are tax-free. If you expect to be in a higher tax bracket in retirement, Roth accounts are highly advantageous.
            </p>

            <h2>Social Security and retirement</h2>
            <p>
              Social Security forms the bedrock of most American retirements. You can claim benefits at age 62, but they will be permanently reduced by up to 30%. Waiting until your Full Retirement Age (FRA, typically 67) grants 100% of your earned benefit. Delaying to age 70 increases your benefit by 8% per year. The calculator assumes the dollar value you input is the value at your designated claiming age, and inflates it from that point forward.
            </p>

            <h2>Who this calculator is for</h2>
            <p>This tool is for US workers planning a self-funded retirement — anyone with a 401(k), 403(b), IRA, or taxable investments who wants to know whether they're on track. It suits mid-career savers stress-testing their contribution rate, near-retirees checking a withdrawal strategy, and early-career workers seeing how starting now beats starting later.</p>
            <p>It models Defined Contribution accounts and Social Security. It does <em>not</em> value a traditional pension (Defined Benefit) beyond the simple monthly figure you can enter, and it does not replace a full financial plan from a regulated adviser.</p>

            <h2>What you need before you start</h2>
            <ul>
              <li>Your <strong>current age</strong> and the age you plan to <strong>retire</strong> (start drawing the portfolio).</li>
              <li>Your <strong>current retirement balances</strong> — 401(k), IRA, and any other invested savings.</li>
              <li>Your <strong>annual contribution</strong> and any <strong>employer match</strong> (often a 100% match on your first 3%, for example).</li>
              <li>An <strong>expected annual return</strong> before and after retirement (commonly 6–8% pre-retirement, 4–5% post-retirement for a more conservative mix).</li>
              <li>Your estimated <strong>annual spending</strong> in retirement and your expected <strong>Social Security</strong> benefit — get an official estimate at <a href="https://www.ssa.gov/myaccount/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">my Social Security</a>.</li>
            </ul>

            <h2>What each input means</h2>
            <ul>
              <li><strong>Current age / Retirement age</strong> — set the accumulation window; the gap between them is how long contributions compound.</li>
              <li><strong>Current balances</strong> — the total already invested across all retirement accounts today.</li>
              <li><strong>Annual contribution</strong> — what you add each year. The calculator enforces the 2026 IRS employee limit ($24,500 for 401(k), with catch-ups at 50+).</li>
              <li><strong>Employer match</strong> — your company's contribution, modelled per the formula you select. Always contribute at least enough to capture the full match.</li>
              <li><strong>Pre- and post-retirement returns</strong> — separate rates so you can model a more conservative portfolio after you stop working.</li>
              <li><strong>Inflation</strong> — escalates your retirement spending target each year to preserve purchasing power.</li>
              <li><strong>Social Security / pension</strong> — monthly income from guaranteed sources, stated in today's dollars and inflated from your claiming age.</li>
            </ul>

            <h2>How to interpret your results</h2>
            <p>The projection runs in two phases. During <strong>accumulation</strong>, your balance grows from contributions, employer match, and investment returns, minus fees. At retirement it switches to <strong>distribution</strong>: it calculates your income target, subtracts Social Security and any pension, and withdraws the shortfall from your portfolio to test how long the money lasts.</p>
            <p>The key outputs are your projected balance at retirement, the annual income that balance can support, and a <strong>depletion age</strong> — the point at which the portfolio would run out under your assumptions. If the depletion age falls short of your life expectancy, you have three levers: save more, work longer, or spend less in retirement. A balance that lasts beyond age 95 under your assumptions is generally considered robust.</p>

            <h2>Worked example</h2>
            <p>A 35-year-old earning $85,000, planning to retire at 67, with $40,000 already saved, contributing 10% with a 3% employer match, expecting 7% pre-retirement and 4% post-retirement returns, 3% inflation, $60,000 annual retirement spending, and $30,000/year Social Security claimed at 67:</p>
            <ul>
              <li>Over 32 years, contributions plus match and 7% growth compound the $40,000 starting balance toward a projected pot in the low seven figures.</li>
              <li>In retirement, the $60,000 target (inflated annually) is partly met by $30,000 of Social Security, so the portfolio must cover the gap.</li>
              <li>The depletion check shows whether the pot survives past age 95 — if it does, the plan is on track; if not, increasing the contribution rate by 2–3% typically closes it.</li>
            </ul>
            <p>Figures are illustrative; actual outcomes depend on market returns, inflation, and the assumptions you enter.</p>

            <h2>Common mistakes to avoid</h2>
            <ul>
              <li><strong>Leaving employer match on the table.</strong> Not contributing up to the match is turning down guaranteed, immediate 100% returns.</li>
              <li><strong>Using an overly optimistic return.</strong> Assuming 10% every year ignores downturns and fees. 6–7% pre-retirement is a prudent long-run assumption.</li>
              <li><strong>Forgetting inflation.</strong> $60,000 of spending in 30 years is far more in nominal dollars — the calculator handles this, but only if you enter a realistic inflation rate.</li>
              <li><strong>Ignoring fees.</strong> A 1% annual fee over 30 years can consume six figures of potential growth. Enter your net expected return after fund expenses.</li>
              <li><strong>Underestimating longevity.</strong> Planning to age 85 when many retirees live past 90 risks running out of money. Stress-test to age 95.</li>
            </ul>

            <h2>Sensible next steps</h2>
            <ul>
              <li>Pull your official Social Security estimate from <a href="https://www.ssa.gov/myaccount/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">my Social Security</a> and enter the figure at your planned claiming age.</li>
              <li>If the depletion age is too early, increase your 401(k) contribution by 1–2% and re-run — small early increases have outsized effects.</li>
              <li>Check whether your plan offers a Roth option; mixing traditional and Roth gives you tax flexibility in retirement.</li>
              <li>For a personalised plan, consult a fee-only fiduciary adviser — find one through the <a href="https://www.napfa.org/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">National Association of Personal Financial Advisors</a>.</li>
            </ul>

            <div className="my-16">
              <h2 className="border-b pb-4 mb-8">Frequently Asked Questions</h2>
              <FAQAccordion faqItems={faqItems} />
            </div>

            <div className="bg-muted p-6 rounded-xl text-sm text-muted-foreground border mt-12">
              <h3 className="text-foreground font-semibold text-base mb-2">Sources, Assumptions &amp; Accuracy Statement</h3>
              <p className="mb-3 text-xs bg-primary/5 p-2 rounded border border-primary/20 text-foreground">SmartMoneyTools checks statutory rates and thresholds against official government publications. Results are estimates for educational purposes and may not reflect every individual circumstance. <strong>Tax year: 2026. Last reviewed: 2 November 2026.</strong></p>
              
              <h4 className="font-semibold text-foreground mb-1 mt-3">Key Assumptions</h4>
              <ul className="list-disc pl-5 space-y-1 mb-4">
                <li>401(k)/403(b) employee contribution cap: $24,500 (2026 IRS limit). Age 50+ catch-up: $8,000. Super catch-up (age 60–63): $11,250.</li>
                <li>IRA annual limit: $7,500; catch-up (50+): $1,100.</li>
                <li>Social Security wage base: $184,500 (2026).</li>
                <li>Employer matching applied per selected formula; capped at annual compensation limit ($350,000).</li>
                <li>Pre-retirement return and post-retirement return applied separately.</li>
                <li>Inflation applied annually in retirement to escalate income target.</li>
                <li>Social Security benefit stated in today’s dollars and inflated from claiming age.</li>
                <li>Pension COLA applied annually from pension start age.</li>
              </ul>

              <h4 className="font-semibold text-foreground mb-1">What This Calculator Does Not Include</h4>
              <ul className="list-disc pl-5 space-y-1 mb-4">
                <li>Tax impact of traditional vs Roth contributions (both modelled as pre-tax for simplicity).</li>
                <li>State income taxes on withdrawals.</li>
                <li>Required Minimum Distributions (RMDs) starting at age 73 (SECURE 2.0).</li>
                <li>Sequence-of-returns risk or Monte Carlo variability.</li>
                <li>Healthcare costs in retirement.</li>
              </ul>

              <h4 className="font-semibold text-foreground mb-2">Data Source Table</h4>
              <div className="overflow-x-auto">
                <table className="w-full text-xs border-collapse">
                  <thead><tr className="bg-muted/80 text-left"><th className="p-2 font-semibold border border-border">Data Item</th><th className="p-2 font-semibold border border-border">Value</th><th className="p-2 font-semibold border border-border">Period</th><th className="p-2 font-semibold border border-border">Source</th></tr></thead>
                  <tbody>
                    <tr><td className="p-2 border border-border">401(k) employee limit</td><td className="p-2 border border-border">$24,500</td><td className="p-2 border border-border">2026</td><td className="p-2 border border-border"><a href="https://www.irs.gov/newsroom/401k-limit-increases-to-24500-for-2026-ira-limit-increases-to-7500" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">IRS</a></td></tr>
                    <tr><td className="p-2 border border-border">401(k) catch-up (age 50+)</td><td className="p-2 border border-border">$8,000</td><td className="p-2 border border-border">2026</td><td className="p-2 border border-border"><a href="https://www.irs.gov/newsroom/401k-limit-increases-to-24500-for-2026-ira-limit-increases-to-7500" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">IRS</a></td></tr>
                    <tr><td className="p-2 border border-border">Super catch-up (age 60–63, SECURE 2.0)</td><td className="p-2 border border-border">$11,250</td><td className="p-2 border border-border">2026</td><td className="p-2 border border-border"><a href="https://www.dol.gov/agencies/ebsa/laws-and-regulations/laws/secure-2-0-act" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">DOL – SECURE 2.0 Act</a></td></tr>
                    <tr><td className="p-2 border border-border">Total DC limit (employer + employee)</td><td className="p-2 border border-border">$72,000</td><td className="p-2 border border-border">2026</td><td className="p-2 border border-border"><a href="https://www.irs.gov/retirement-plans/cola-increases-for-dollar-limitations-on-benefits-and-contributions" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">IRS COLA limits</a></td></tr>
                    <tr><td className="p-2 border border-border">IRA contribution limit</td><td className="p-2 border border-border">$7,500 (+$1,100 catch-up)</td><td className="p-2 border border-border">2026</td><td className="p-2 border border-border"><a href="https://www.irs.gov/newsroom/401k-limit-increases-to-24500-for-2026-ira-limit-increases-to-7500" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">IRS</a></td></tr>
                    <tr><td className="p-2 border border-border">Social Security wage base</td><td className="p-2 border border-border">$184,500</td><td className="p-2 border border-border">2026</td><td className="p-2 border border-border"><a href="https://www.ssa.gov/oact/cola/cbb.html" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">SSA – Contribution and Benefit Bases</a></td></tr>
                    <tr><td className="p-2 border border-border">Annual compensation limit</td><td className="p-2 border border-border">$350,000</td><td className="p-2 border border-border">2026</td><td className="p-2 border border-border"><a href="https://www.irs.gov/retirement-plans/cola-increases-for-dollar-limitations-on-benefits-and-contributions" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">IRS COLA limits</a></td></tr>
                    <tr><td className="p-2 border border-border">RMD start age (SECURE 2.0)</td><td className="p-2 border border-border">73</td><td className="p-2 border border-border">From 2023</td><td className="p-2 border border-border"><a href="https://www.dol.gov/agencies/ebsa/laws-and-regulations/laws/secure-2-0-act" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">DOL – SECURE 2.0 Act</a></td></tr>
                  </tbody>
                </table>
              </div>
            </div>
            
          </div>
        </div>
      </section>

      <section className="py-16 bg-muted/30 border-t border-border">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-6xl text-center">
          <h2 className="text-2xl font-bold text-foreground mb-8">Related Financial Tools</h2>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/us-salary-calculator" className="bg-card border px-6 py-3 rounded-lg hover:border-primary/50 hover:text-primary transition-colors font-medium shadow-sm">US Salary Calculator</Link>
            <Link to="/compound-interest" className="bg-card border px-6 py-3 rounded-lg hover:border-primary/50 hover:text-primary transition-colors font-medium shadow-sm">Compound Interest Calculator</Link>
            <Link to="/savings-goal-calculator" className="bg-card border px-6 py-3 rounded-lg hover:border-primary/50 hover:text-primary transition-colors font-medium shadow-sm">Savings Goal Calculator</Link>
            <Link to="/budget-planner" className="bg-card border px-6 py-3 rounded-lg hover:border-primary/50 hover:text-primary transition-colors font-medium shadow-sm">Budget Planner</Link>
          </div>
        </div>
      </section>

    </div>
  );
}