import React, { createContext, useState, useEffect } from 'react';
import { currencyData } from '@/utils/currencyData.js';

export const DEFAULT_CURRENCY_CODE = 'GBP';

export const CurrencyContext = createContext();

function readStoredUserCurrency() {
  if (typeof window === 'undefined') return null;
  // Only treat the stored currency as a saved user preference when the
  // visitor explicitly picked one (flag written by the selector). Values
  // saved automatically by earlier versions of the site are ignored so the
  // GBP default applies cleanly.
  if (window.localStorage.getItem('currencyUserSet') !== 'true') return null;
  const stored = window.localStorage.getItem('selectedCurrency');
  return stored && currencyData[stored] ? stored : null;
}

export function CurrencyProvider({ children }) {
  // Explicit user choice (persisted). Null until the visitor picks a currency.
  const [userCurrencyCode, setUserCurrencyCode] = useState(readStoredUserCurrency);

  // Transient page-level default (e.g. USD on the US calculator pages).
  // Cleared on unmount so other pages fall back to the site default.
  const [pageDefaultCode, setPageDefaultCode] = useState(null);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (userCurrencyCode) {
      window.localStorage.setItem('selectedCurrency', userCurrencyCode);
      window.localStorage.setItem('currencyUserSet', 'true');
    } else {
      window.localStorage.removeItem('currencyUserSet');
    }
  }, [userCurrencyCode]);

  const currencyCode = userCurrencyCode || pageDefaultCode || DEFAULT_CURRENCY_CODE;
  const currency = currencyData[currencyCode] || currencyData[DEFAULT_CURRENCY_CODE];

  // Explicit choice from the currency selector — persists across sessions
  // and overrides every page-level default.
  const setCurrencyCode = (code) => {
    if (code && currencyData[code]) setUserCurrencyCode(code);
  };

  return (
    <CurrencyContext.Provider
      value={{
        currency,
        currencyCode,
        setCurrencyCode,
        pageDefaultCode,
        setPageCurrencyDefault: setPageDefaultCode,
        userCurrencyCode,
      }}
    >
      {children}
    </CurrencyContext.Provider>
  );
}
