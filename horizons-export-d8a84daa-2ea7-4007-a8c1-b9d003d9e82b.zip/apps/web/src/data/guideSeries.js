/**
 * guideSeries.js
 *
 * Declares the "More in this series" link groups for guides that cover
 * overlapping topics. Each entry's `blurb` names what is *different* about
 * that guide so the cross-links are genuinely useful rather than repetitive.
 *
 * Redirect-only URLs that were consolidated into another guide are intentionally
 * omitted (e.g. /guides/first-time-buyer-budgeting → /guides/first-time-buyer,
 * and /guides/pension-tax-take-home → /guides/pension-contributions).
 */

export const MORTGAGE_SERIES = [
  {
    path: '/guides/mortgage-comprehensive',
    label: 'Comprehensive Mortgage Guide',
    blurb: 'Mortgage types, rates, LTV bands and fees — the product and rate guide.',
  },
  {
    path: '/guides/first-time-buyer',
    label: "First-Time Buyer's Guide",
    blurb: 'The full buying process end to end — Agreements in Principle, costs and the journey from offer to completion.',
  },
  {
    path: '/guides/mortgage-affordability-first-time-buyers',
    label: 'Mortgage Affordability for First-Time Buyers',
    blurb: 'How much you can borrow — income multiples, deposit requirements and lender stress tests.',
  },
  {
    path: '/guides/mortgage-overpayments',
    label: 'Mortgage Overpayments',
    blurb: 'Overpaying to strip years off your term and save tens of thousands in interest.',
  },
];

export const PENSION_SERIES = [
  {
    path: '/guides/pension-planning',
    label: 'Pension Planning & Retirement Target',
    blurb: 'How big your pot needs to be and whether you are on track — the planning counterpart.',
  },
  {
    path: '/guides/pension-contributions',
    label: 'Optimising Pension Contributions',
    blurb: 'How much to pay in, tax relief, the Annual Allowance and the £100,000 trap.',
  },
  {
    path: '/guides/workplace-pensions',
    label: 'Workplace Pensions & Auto-Enrolment',
    blurb: 'Employer contributions, auto-enrolment and maximising your workplace pension.',
  },
  {
    path: '/guides/early-retirement',
    label: 'Early Retirement Planning',
    blurb: 'Retiring before State Pension age and bridging the income gap.',
  },
  {
    path: '/guides/salary-sacrifice-vs-normal-pension',
    label: 'Salary Sacrifice vs Normal Pension',
    blurb: 'How the contribution method changes your take-home pay and pot growth.',
  },
];
