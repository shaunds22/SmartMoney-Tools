/**
 * author — single source of truth for the SmartMoneyTools author profile.
 *
 * Only truthful, supplied details are recorded here. Do NOT infer or add
 * employer, membership, registration, award, regulated status, organisation,
 * or reviewer information. The reviewer field is intentionally absent because
 * no genuine, page-specific review record exists in this project.
 */
export const AUTHOR = {
  name: 'Shaun Da Silva',
  role: 'Financial Consultant',
  experience: 'Over 20 years in the Financial Sector',
  qualification: 'BTech Information Systems',
  slug: 'shaun-da-silva',
  profilePath: '/author/shaun-da-silva',
  profileUrl: 'https://smartmoney-tools.com/author/shaun-da-silva',
  // Short description reused in the Person / Article structured data.
  shortDescription:
    'Shaun Da Silva is a financial consultant with over 20 years of experience in financial consulting. He created SmartMoneyTools in 2026 to make UK tax, pension, savings and mortgage calculations clear and transparent. Every calculator and guide on the site is written and maintained by Shaun and checked against published HMRC and GOV.UK rates and thresholds. SmartMoneyTools provides general information and estimates, not personal financial advice.',
  longDescription:
    'Shaun Da Silva is a financial consultant with over 20 years of experience in financial consulting. He created SmartMoneyTools in 2026 to make UK tax, pension, savings and mortgage calculations clear and transparent. Every calculator and guide on the site is written and maintained by Shaun and checked against published HMRC and GOV.UK rates and thresholds. SmartMoneyTools provides general information and estimates, not personal financial advice.',
};

/**
 * Person reference WITHOUT @context — for nesting inside another schema
 * (e.g. as the `author` of an Article). The enclosing object carries @context.
 */
export function personRef() {
  return {
    '@type': 'Person',
    name: AUTHOR.name,
    jobTitle: AUTHOR.role,
    description: AUTHOR.shortDescription,
    url: AUTHOR.profileUrl,
    sameAs: ['https://www.linkedin.com/in/shaun-da-silva-748b91a2/'],
    knowsAbout: [
      'UK income tax',
      'National Insurance',
      'pensions',
      'mortgages',
      'savings',
      'debt repayment',
      'personal finance',
    ],
  };
}

/**
 * Standalone Person schema (with @context) for the author profile page.
 */
export function personSchema() {
  return {
    '@context': 'https://schema.org',
    ...personRef(),
  };
}
