/**
 * authors — single source of truth for the SmartMoneyTools author directory.
 *
 * Each entry is the "content data" behind the byline system: every guide and
 * calculator page carries an authorName, authorBio and authorCredential, and
 * those values resolve to an entry here. The /about/team page lists every
 * author in this file with their bio.
 *
 * Only one author is recorded today. The `bio` field is a short, one-sentence
 * placeholder the author can edit later.
 */
export const AUTHORS = [
  {
    slug: 'shaun-da-silva',
    name: 'Shaun Da Silva',
    credential: 'Financial Consultant',
    bio: 'Shaun Da Silva is a financial consultant with over 20 years of experience in financial consulting. He created SmartMoneyTools in 2026 and checks every calculator and guide against published HMRC and GOV.UK rates.',
    fullBio: 'Shaun Da Silva is a financial consultant with over 20 years of experience in financial consulting. He created SmartMoneyTools in 2026 to make UK tax, pension, savings and mortgage calculations clear and transparent. Every calculator and guide on the site is written and maintained by Shaun and checked against published HMRC and GOV.UK rates and thresholds. SmartMoneyTools provides general information and estimates, not personal financial advice.',
    profilePath: '/author/shaun-da-silva',
    profileUrl: 'https://smartmoney-tools.com/author/shaun-da-silva',
  },
];

export const DEFAULT_AUTHOR = AUTHORS[0];

export function getAuthorBySlug(slug) {
  return AUTHORS.find((author) => author.slug === slug) || DEFAULT_AUTHOR;
}
