import React from 'react';
import { Link } from 'react-router-dom';
import { Rss, Apple } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';

function Footer() {
  const currentYear = new Date().getFullYear();
  const appStoreUrl = "https://apps.apple.com/gb/app/smart-money-tools-app/id6781715915";

  return (
    <footer className="bg-card text-card-foreground border-t mt-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12">
          {/* Brand Section */}
          <div className="lg:col-span-3">
            <div className="flex items-center space-x-2 mb-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary shadow-sm">
                <span className="text-xl font-bold text-primary-foreground">$</span>
              </div>
              <span className="text-xl font-bold text-foreground tracking-tight">SmartMoneyTools</span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed mb-6">
              Clear, fast, and accurate financial calculators. We build tools that help you project your savings, plan your mortgage, and take control of your financial future without the confusing jargon.
            </p>
            <div className="flex space-x-4">
              <a href="/feed.xml" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors flex items-center text-sm" aria-label="RSS Feed">
                <Rss className="h-4 w-4 mr-1" /> RSS Feed
              </a>
              <a href="/feed.json" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors flex items-center text-sm" aria-label="JSON Feed">
                <span className="font-mono font-bold mr-1 text-xs">JSON</span> Feed
              </a>
            </div>
          </div>

          {/* Tools Section */}
          <div className="lg:col-span-2">
            <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-6">Calculators & Tools</h3>
            <ul className="space-y-3">
              <li><Link to="/us-salary-calculator" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">US Salary Calculator</Link></li>
              <li><Link to="/us-retirement-calculator" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">US Retirement Calculator</Link></li>
              <li><Link to="/uk-salary-calculator" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">UK Salary Calculator</Link></li>
              <li><Link to="/compound-interest" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Compound Interest</Link></li>
              <li><Link to="/mortgage" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Mortgage Calculator</Link></li>
              <li><Link to="/pensions-calculator" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Pensions Calculator</Link></li>
              <li><Link to="/budget-planner" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Budget Planner</Link></li>
              <li><Link to="/self-employed-tax-calculator" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">UK Self-Employed Tax</Link></li>
              <li><Link to="/debt-snowball-calculator" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Debt Snowball</Link></li>
              <li><Link to="/savings-goal-calculator" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Savings Goal</Link></li>
            </ul>
          </div>

          {/* Download App Section */}
          <div className="lg:col-span-2">
            <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-6">Download App</h3>
            <div className="flex flex-col gap-6">
              <a 
                href={appStoreUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-3 px-4 py-3 rounded-lg bg-muted/50 border border-border hover:bg-muted hover:text-primary transition-all duration-200 group w-fit"
                aria-label="Download SmartMoneyTools on Apple App Store"
              >
                <Apple className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                <span className="text-sm font-medium text-muted-foreground group-hover:text-primary transition-colors">Download on App Store</span>
              </a>

              <div className="flex flex-col items-start gap-3">
                <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Scan to Download</span>
                <a 
                  href={appStoreUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="block p-3 bg-white rounded-xl border border-border/50 shadow-sm transition-all duration-300 hover:scale-105 hover:shadow-md"
                  aria-label="Scan QR Code to download the app"
                >
                  <QRCodeSVG 
                    value={appStoreUrl}
                    size={120}
                    bgColor="#ffffff"
                    fgColor="#000000"
                    level="L"
                    includeMargin={false}
                  />
                </a>
              </div>
            </div>
          </div>

          {/* Guides Section */}
          <div className="lg:col-span-3">
            <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-6">Financial Guides</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              {/* Column 1 */}
              <div className="space-y-8">
                <div>
                  <h4 className="text-xs font-medium text-foreground mb-3">Income & Tax</h4>
                  <ul className="space-y-2">
                    <li><Link to="/guides/uk-income-tax" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Understanding UK Income Tax</Link></li>
                    <li><Link to="/guides/national-insurance" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">National Insurance Explained</Link></li>
                    <li><Link to="/guides/pension-contributions" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Pension Contributions & Tax Relief</Link></li>
                    <li><Link to="/guides/tax-planning" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Tax Planning Strategies</Link></li>
                    <li><Link to="/guides/calculate-take-home-pay" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Maximizing Take-Home Pay</Link></li>
                    <li><Link to="/guides/self-employed-tax-planning" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">UK Self-Employed Tax Guide</Link></li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-xs font-medium text-foreground mb-3">Savings & Investment</h4>
                  <ul className="space-y-2">
                    <li><Link to="/guides/compound-interest-monthly-deposits" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Compound Interest Guide</Link></li>
                    <li><Link to="/guides/savings-goals" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Savings Goals Guide</Link></li>
                    <li><Link to="/guides/emergency-fund" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Emergency Fund Guide</Link></li>
                    <li><Link to="/guides/high-interest-savings" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">High-Interest Savings</Link></li>
                  </ul>
                </div>
              </div>
              
              {/* Column 2 */}
              <div className="space-y-8">
                <div>
                  <h4 className="text-xs font-medium text-foreground mb-3">Debt & Budget</h4>
                  <ul className="space-y-2">
                    <li><Link to="/guides/debt-repayment" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Debt Repayment Guide</Link></li>
                    <li><Link to="/guides/credit-card-debt" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Credit Card Debt</Link></li>
                    <li><Link to="/budget-planner" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Budget Planner</Link></li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-xs font-medium text-foreground mb-3">Retirement & Mortgages</h4>
                  <ul className="space-y-2">
                    <li><Link to="/guides/pension-planning" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Pension Planning Guide</Link></li>
                    <li><Link to="/pensions-calculator" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Pensions Calculator</Link></li>
                    <li><Link to="/guides/early-retirement" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Early Retirement Guide</Link></li>
                    <li><Link to="/guides/mortgage-comprehensive" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Mortgage Comprehensive Guide</Link></li>
                    <li><Link to="/guides/first-time-buyer" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">First-Time Buyer Guide</Link></li>
                    <li><Link to="/uk-salary-calculator" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">UK Salary Calculator</Link></li>
                    <li><Link to="/guides/student-loan-repayments" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Student Loan Repayments</Link></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Legal & Company Links */}
          <div className="lg:col-span-2">
            <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-6">Company</h3>
            <ul className="space-y-3 mb-8">
              <li><Link to="/" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Home</Link></li>
              <li><Link to="/about" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">About Us</Link></li>
              <li><Link to="/about/team" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Our Team</Link></li>
              <li><Link to="/author/shaun-da-silva" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Author: Shaun Da Silva</Link></li>
              <li><Link to="/contact" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Contact Support</Link></li>
              <li><Link to="/accessibility" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Accessibility</Link></li>
            </ul>
            <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-3">Editorial</h3>
            <ul className="space-y-3 mb-8">
              <li><Link to="/calculation-methodology" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Calculation Methodology</Link></li>
              <li><Link to="/editorial-policy" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Editorial Policy</Link></li>
              <li><Link to="/corrections-policy" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Corrections Policy</Link></li>
              <li><Link to="/advertising-disclosure" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Advertising Disclosure</Link></li>
            </ul>
            <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-3">Legal</h3>
            <ul className="space-y-3">
              <li><Link to="/privacy" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Privacy Policy</Link></li>
              <li><Link to="/cookie-policy" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Cookie Policy</Link></li>
              <li><Link to="/terms" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Terms of Use</Link></li>
              <li><Link to="/financial-disclaimer" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">Financial Disclaimer</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border mt-16 pt-8">
          <div className="bg-muted/30 rounded-xl p-6 border border-border/50 mb-8">
            <h4 className="font-semibold text-foreground mb-2 text-sm">Important Disclosures</h4>
            <div className="space-y-4 text-sm text-muted-foreground leading-relaxed">
              <p>
                <strong>Financial Information:</strong> SmartMoneyTools provides calculators and guides for educational and informational purposes only. The results are estimates based on your inputs and standard mathematical formulas. They should not be considered professional financial, investment, or tax advice. Please consult a qualified financial advisor before making any major financial decisions.
              </p>
              <p>
                <strong>Advertising & Tracking:</strong> This site uses Google AdSense to display advertisements. Google and third-party vendors use cookies to serve ads based on your prior visits to this website or other websites. You can manage your ad preferences by visiting Google's Ads Settings.
              </p>
            </div>
          </div>
          
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
            <p>
              © {currentYear} SmartMoneyTools. All rights reserved. | <a href="mailto:support@smartmoney-tools.com" className="hover:text-primary transition-colors">support@smartmoney-tools.com</a>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;