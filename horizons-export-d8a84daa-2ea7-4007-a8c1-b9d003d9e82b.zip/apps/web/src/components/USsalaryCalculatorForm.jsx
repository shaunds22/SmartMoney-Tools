import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { STATE_OPTIONS } from '../config/stateTaxData2026.js';
import { PAY_FREQUENCIES, FILING_STATUSES } from '../config/usPayrollTaxData2026.js';

export default function USsalaryCalculatorForm({ onCalculate }) {
  const [formData, setFormData] = useState({
    baseAmount: 75000,
    frequency: 'annual',
    hoursPerWeek: 40,
    weeksPerYear: 52,
    overtimeHours: 0,
    overtimeMultiplier: 1.5,
    bonuses: 0,
    stateCode: 'NY',
    filingStatus: 'single',
    deductions: [
      { id: 1, name: '401(k)', amount: 5, isPercentage: true, type: 'pre' }
    ],
    isPaycheckMode: false
  });

  const [isDeductionsOpen, setIsDeductionsOpen] = useState(false);

  useEffect(() => {
    onCalculate(formData);
  }, [formData, onCalculate]);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleNumberChange = (field, value) => {
    const num = parseFloat(value) || 0;
    setFormData(prev => ({ ...prev, [field]: num }));
  };

  return (
    <Card className="w-full shadow-lg border-0 bg-card text-card-foreground">
      <CardHeader className="bg-primary/5 rounded-t-xl border-b border-border/50">
        <CardTitle className="text-xl font-bold text-foreground">Salary Details</CardTitle>
      </CardHeader>
      <CardContent className="p-6 space-y-8">
        
        {/* Salary Input Section */}
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="baseAmount" className="text-foreground">Gross Salary / Rate</Label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-muted-foreground">$</span>
                <Input 
                  id="baseAmount" 
                  type="number" 
                  className="pl-8 text-foreground"
                  value={formData.baseAmount || ''} 
                  onChange={(e) => handleNumberChange('baseAmount', e.target.value)} 
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="frequency" className="text-foreground">Pay Frequency</Label>
              <Select value={formData.frequency} onValueChange={(v) => handleChange('frequency', v)}>
                <SelectTrigger className="text-foreground">
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(PAY_FREQUENCIES).map(([key, data]) => (
                    <SelectItem key={key} value={key}>{data.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {formData.frequency === 'hourly' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-border/50">
              <div className="space-y-2">
                <Label htmlFor="hoursPerWeek" className="text-foreground">Hours Per Week</Label>
                <Input id="hoursPerWeek" type="number" className="text-foreground" value={formData.hoursPerWeek} onChange={(e) => handleNumberChange('hoursPerWeek', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="weeksPerYear" className="text-foreground">Weeks Per Year</Label>
                <Input id="weeksPerYear" type="number" className="text-foreground" value={formData.weeksPerYear} onChange={(e) => handleNumberChange('weeksPerYear', e.target.value)} />
              </div>
            </div>
          )}
        </div>

        {/* Location Section */}
        <div className="space-y-4 pt-4 border-t border-border/50">
          <h3 className="text-lg font-semibold text-foreground">Location & Filing</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="stateCode" className="text-foreground">State of Residence</Label>
              <Select value={formData.stateCode} onValueChange={(v) => handleChange('stateCode', v)}>
                <SelectTrigger className="text-foreground">
                  <SelectValue placeholder="Select state" />
                </SelectTrigger>
                <SelectContent>
                  {STATE_OPTIONS.map((state) => (
                    <SelectItem key={state.value} value={state.value}>{state.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="filingStatus" className="text-foreground">Filing Status</Label>
              <Select value={formData.filingStatus} onValueChange={(v) => handleChange('filingStatus', v)}>
                <SelectTrigger className="text-foreground">
                  <SelectValue placeholder="Select filing status" />
                </SelectTrigger>
                <SelectContent>
                  {FILING_STATUSES.map((status) => (
                    <SelectItem key={status.value} value={status.value}>{status.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Deductions Section */}
        <div className="pt-4 border-t border-border/50">
          <Collapsible open={isDeductionsOpen} onOpenChange={setIsDeductionsOpen}>
            <CollapsibleTrigger asChild>
              <Button variant="outline" className="w-full flex justify-between items-center text-foreground hover:bg-muted">
                <span>Payroll Deductions (401k, Health, etc.)</span>
                {isDeductionsOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="pt-4 space-y-4">
               {formData.deductions.map((deduction, index) => (
                 <div key={deduction.id} className="grid grid-cols-12 gap-2 items-center bg-muted/50 p-3 rounded-lg border border-border/50">
                   <div className="col-span-5">
                     <Label className="text-xs text-muted-foreground mb-1 block">Name</Label>
                     <Input 
                       value={deduction.name} 
                       className="h-8 text-sm text-foreground bg-background"
                       onChange={(e) => {
                         const newDeds = [...formData.deductions];
                         newDeds[index].name = e.target.value;
                         setFormData({...formData, deductions: newDeds});
                       }}
                     />
                   </div>
                   <div className="col-span-3">
                     <Label className="text-xs text-muted-foreground mb-1 block">Amount</Label>
                     <Input 
                       type="number" 
                       value={deduction.amount} 
                       className="h-8 text-sm text-foreground bg-background"
                       onChange={(e) => {
                         const newDeds = [...formData.deductions];
                         newDeds[index].amount = parseFloat(e.target.value) || 0;
                         setFormData({...formData, deductions: newDeds});
                       }}
                     />
                   </div>
                   <div className="col-span-4 flex items-center justify-between mt-5">
                     <div className="flex items-center space-x-2">
                       <Switch 
                         checked={deduction.isPercentage}
                         onCheckedChange={(checked) => {
                           const newDeds = [...formData.deductions];
                           newDeds[index].isPercentage = checked;
                           setFormData({...formData, deductions: newDeds});
                         }}
                       />
                       <span className="text-xs text-foreground">{deduction.isPercentage ? '%' : '$'}</span>
                     </div>
                     <Button 
                       variant="ghost" 
                       size="sm" 
                       className="h-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                       onClick={() => {
                         const newDeds = formData.deductions.filter((_, i) => i !== index);
                         setFormData({...formData, deductions: newDeds});
                       }}
                     >
                       Remove
                     </Button>
                   </div>
                 </div>
               ))}
               <Button 
                 variant="secondary" 
                 className="w-full text-secondary-foreground"
                 onClick={() => {
                   setFormData({
                     ...formData, 
                     deductions: [...formData.deductions, { id: Date.now(), name: 'New Deduction', amount: 0, isPercentage: false, type: 'pre' }]
                   });
                 }}
               >
                 + Add Deduction
               </Button>
            </CollapsibleContent>
          </Collapsible>
        </div>

      </CardContent>
    </Card>
  );
}