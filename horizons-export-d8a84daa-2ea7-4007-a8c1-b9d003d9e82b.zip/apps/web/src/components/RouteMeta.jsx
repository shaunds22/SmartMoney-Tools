/**
 * RouteMeta — global per-route <title> and <meta name="description">.
 *
 * Mounted once in <AppRoutes> so every route emits a unique, specific
 * title and description via React Helmet. Helmet renders during both
 * client hydration and server-side prerendering, so the static HTML
 * Google crawls carries the correct per-route metadata (not the generic
 * homepage copy from index.html).
 *
 * Routes not present in routeMetadata (e.g. individual guide pages, the
 * 404 fallback) render nothing here and keep their own page-level metadata.
 */
import { useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import routeMetadata from '@/config/routeMetadata';

export default function RouteMeta() {
  const location = useLocation();
  let pathname = location.pathname || '/';
  // Normalise: strip trailing slash except for the homepage.
  if (pathname.length > 1 && pathname.endsWith('/')) {
    pathname = pathname.replace(/\/+$/, '');
  }

  const meta = routeMetadata[pathname];
  if (!meta) return null;

  const canonical = `https://smartmoney-tools.com${pathname === '/' ? '/' : pathname}`;

  return (
    <Helmet>
      <title>{meta.title}</title>
      <meta name="description" content={meta.description} />
      <meta property="og:url" content={canonical} />
    </Helmet>
  );
}
