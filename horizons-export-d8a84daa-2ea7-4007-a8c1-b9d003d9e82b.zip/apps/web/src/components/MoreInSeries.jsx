import React from 'react';
import { Link } from 'react-router-dom';
import { BookMarked } from 'lucide-react';

/**
 * MoreInSeries — a "More in this series" cross-link block rendered at the foot
 * of a guide. Pass the full `items` array for the series and the `currentPath`
 * of the guide it appears on; the current guide is omitted from the list.
 *
 * Each item carries a `blurb` that names what is *different* about that guide,
 * so the links read as a genuine "what to read next" rather than a tag cloud.
 */
export default function MoreInSeries({
  currentPath,
  items,
  title = 'More in this series',
}) {
  const others = (items || []).filter((i) => i.path !== currentPath);
  if (others.length === 0) return null;

  return (
    <section className="not-prose mt-16 border-t border-border pt-10">
      <div className="flex items-center gap-2 mb-3">
        <BookMarked className="h-5 w-5 text-primary" />
        <h2 className="!mt-0 !mb-0 text-2xl font-bold">{title}</h2>
      </div>
      <p className="text-muted-foreground mb-6">
        Related guides that each cover a different angle of the same topic.
      </p>
      <ul className="grid gap-3 sm:grid-cols-2 list-none p-0">
        {others.map((item) => (
          <li key={item.path} className="m-0 p-0">
            <Link
              to={item.path}
              className="group block h-full rounded-xl border border-border bg-card p-4 transition-all hover:shadow-md hover:border-primary/40"
            >
              <span className="font-semibold text-foreground group-hover:text-primary transition-colors">
                {item.label}
              </span>
              <span className="block text-sm text-muted-foreground mt-1 leading-relaxed">
                {item.blurb}
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}
