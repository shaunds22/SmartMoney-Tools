/**
 * CanonicalLink — emits a self-referencing <link rel="canonical"> for the
 * current route via react-helmet. Mounted once globally in AppRoutes so every
 * route (client-side via BrowserRouter and during prerender via StaticRouter)
 * outputs a canonical URL matching its own pathname.
 *
 *   "/"                  -> https://smartmoney-tools.com/
 *   "/uk-salary-calculator" -> https://smartmoney-tools.com/uk-salary-calculator
 */
import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { setCanonicalTag } from '@/utils/seo';

const BASE_URL = 'https://smartmoney-tools.com';

export default function CanonicalLink() {
  const location = useLocation();
  // Normalise pathname: ensure it starts with "/" and strip any trailing slash
  // (except for the homepage itself).
  let pathname = location.pathname || '/';
  if (pathname.length > 1 && pathname.endsWith('/')) {
    pathname = pathname.replace(/\/+$/, '');
  }
  const canonical = `${BASE_URL}${pathname}`;

  // Keep the DOM <link rel="canonical"> in sync for the hydrated client app.
  useEffect(() => {
    setCanonicalTag(canonical);
  }, [canonical]);

  return (
    <Helmet>
      <link rel="canonical" href={canonical} />
    </Helmet>
  );
}
