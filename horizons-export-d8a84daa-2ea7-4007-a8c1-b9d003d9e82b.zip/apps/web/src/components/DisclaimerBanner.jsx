import React from 'react';
import { AlertTriangle, BookOpen } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function DisclaimerBanner() {
  return (
    <div className="bg-accent/10 border border-accent/20 p-6 rounded-xl flex flex-col gap-4 text-accent-foreground my-8 shadow-sm">
      <div className="flex gap-4 items-start">
        <AlertTriangle className="h-6 w-6 shrink-0 mt-0.5 text-accent" aria-hidden="true" />
        <div className="text-sm leading-relaxed">
          <strong className="font-semibold block mb-1 text-base">Important Disclaimer</strong>
          The results provided by this calculator are estimates only and should not be considered financial advice. They are based on the information and assumptions you provide. Actual results may vary significantly based on individual circumstances, market conditions, and other factors. We strongly recommend speaking with a qualified financial adviser before making any financial decisions based on these calculations. Past performance is not indicative of future results.
        </div>
      </div>
      <div className="ml-10 pt-3 border-t border-accent/10 flex items-center">
        <BookOpen className="h-4 w-4 mr-2 text-accent/80" aria-hidden="true" />
        <Link 
          to="/calculation-methodology" 
          className="text-sm font-medium text-accent-foreground hover:text-accent transition-colors underline-offset-4 hover:underline"
        >
          See our detailed calculation methodology
        </Link>
      </div>
    </div>
  );
}