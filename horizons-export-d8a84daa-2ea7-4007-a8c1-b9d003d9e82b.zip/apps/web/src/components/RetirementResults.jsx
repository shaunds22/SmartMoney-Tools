import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend, ComposedChart, Line } from 'recharts';
import { Download, AlertTriangle, CheckCircle, TrendingUp, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import formatCurrency from '@/utils/formatCurrency.js';

export default function RetirementResults({ results }) {
  // All hooks declared at top level, unconditionally
  const [tableExpanded, setTableExpanded] = useState(false);

  // Early return after hooks are declared
  if (!results) {
    return null;
  }

  const { projection, summary } = results;

  // Status determination
  let status = { text: 'On Track', color: 'text-success', bg: 'status-indicator-success', icon: <CheckCircle className="h-6 w-6" /> };
  if (summary.isDepleted) {
    status = { text: `Potential Shortfall at Age ${summary.ageDepleted}`, color: 'text-destructive', bg: 'status-indicator-danger', icon: <AlertTriangle className="h-6 w-6" /> };
  } else if (summary.monthlyShortfall > 0) {
    status = { text: 'Close to Target (Slight Shortfall)', color: 'text-warning', bg: 'status-indicator-warning', icon: <AlertTriangle className="h-6 w-6" /> };
  }

  const exportCSV = () => {
    const headers = ['Age', 'Year', 'Salary', 'Employee Contrib', 'Employer Contrib', 'Growth', 'Withdrawals', 'Social Security', 'Pension', 'Balance'];
    const csvContent = [
      headers.join(','),
      ...projection.map(row => [
        row.age,
        row.year,
        Math.round(row.salary),
        Math.round(row.employeeContrib + row.iraContrib),
        Math.round(row.employerContrib),
        Math.round(row.growth),
        Math.round(row.withdrawal),
        Math.round(row.ssIncome),
        Math.round(row.pensionInc),
        Math.round(row.balance)
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'retirement_projection.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const chartData = projection.map(p => ({
    ...p,
    totalContributions: p.employeeContrib + p.employerContrib + p.iraContrib
  }));

  return (
    <div className="space-y-6">
      {/* Status Banner */}
      <div className={`p-4 rounded-xl border flex items-center gap-4 ${status.bg}`}>
        {status.icon}
        <div>
          <h3 className="font-bold text-lg">{status.text}</h3>
          <p className="text-sm opacity-90">
            {summary.isDepleted 
              ? "Your projected savings may run out before your planning age. Consider saving more, retiring later, or reducing retirement spending."
              : "Your current plan provides sufficient funds to last through your planning age."}
          </p>
        </div>
      </div>

      {/* High Level Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-6">
            <p className="text-sm font-medium text-muted-foreground mb-1">Projected Balance at Retirement</p>
            <p className="text-3xl font-bold text-foreground">{formatCurrency(summary.balanceAtRetirement)}</p>
            <p className="text-sm text-muted-foreground mt-1">In Today's Dollars: {formatCurrency(summary.balanceAtRetirementTodaysDollars)}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <p className="text-sm font-medium text-muted-foreground mb-1">First Year Retirement Income</p>
            <p className="text-3xl font-bold text-foreground">{formatCurrency(summary.firstYearRetirementIncomeGenerated)}</p>
            <p className="text-sm text-muted-foreground mt-1">
              Target: {formatCurrency(summary.firstYearRetirementIncomeTarget)}
              {summary.monthlyShortfall > 0 && <span className="text-destructive font-medium ml-2">(Shortfall: {formatCurrency(summary.monthlyShortfall)}/mo)</span>}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="bg-muted/50 border-none shadow-none">
          <CardContent className="p-4 text-center">
            <DollarSign className="w-5 h-5 mx-auto mb-2 text-muted-foreground" />
            <p className="text-xs text-muted-foreground uppercase tracking-wider">Your Contributions</p>
            <p className="font-bold text-lg">{formatCurrency(summary.totalPersonalContributions)}</p>
          </CardContent>
        </Card>
        <Card className="bg-muted/50 border-none shadow-none">
          <CardContent className="p-4 text-center">
            <CheckCircle className="w-5 h-5 mx-auto mb-2 text-muted-foreground" />
            <p className="text-xs text-muted-foreground uppercase tracking-wider">Employer Match</p>
            <p className="font-bold text-lg">{formatCurrency(summary.totalEmployerContributions)}</p>
          </CardContent>
        </Card>
        <Card className="bg-muted/50 border-none shadow-none">
          <CardContent className="p-4 text-center">
            <TrendingUp className="w-5 h-5 mx-auto mb-2 text-muted-foreground" />
            <p className="text-xs text-muted-foreground uppercase tracking-wider">Investment Growth</p>
            <p className="font-bold text-lg text-primary">{formatCurrency(summary.totalInvestmentGrowth)}</p>
          </CardContent>
        </Card>
      </div>

      {/* Visualizations */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Projection Charts</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="balance" className="w-full">
            <TabsList className="w-full grid grid-cols-2 mb-6">
              <TabsTrigger value="balance">Portfolio Balance</TabsTrigger>
              <TabsTrigger value="income">Retirement Income</TabsTrigger>
            </TabsList>
            
            <TabsContent value="balance" className="h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--calc-chart-1))" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="hsl(var(--calc-chart-1))" stopOpacity={0.1}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                  <XAxis dataKey="age" tickFormatter={(value) => `Age ${value}`} stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis tickFormatter={(value) => `$${(value/1000).toFixed(0)}k`} stroke="hsl(var(--muted-foreground))" fontSize={12} width={60} />
                  <Tooltip 
                    formatter={(value) => formatCurrency(value)}
                    labelFormatter={(label) => `Age: ${label}`}
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))' }}
                  />
                  <Area type="monotone" dataKey="balance" name="Portfolio Balance" stroke="hsl(var(--calc-chart-1))" fillOpacity={1} fill="url(#colorBalance)" />
                </AreaChart>
              </ResponsiveContainer>
            </TabsContent>
            
            <TabsContent value="income" className="h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={chartData.filter(d => d.targetIncome > 0)} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                  <XAxis dataKey="age" tickFormatter={(value) => `Age ${value}`} stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis tickFormatter={(value) => `$${(value/1000).toFixed(0)}k`} stroke="hsl(var(--muted-foreground))" fontSize={12} width={60} />
                  <Tooltip 
                    formatter={(value) => formatCurrency(value)}
                    labelFormatter={(label) => `Age: ${label}`}
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))' }}
                  />
                  <Legend />
                  <Bar dataKey="withdrawal" name="Portfolio Withdrawal" stackId="a" fill="hsl(var(--calc-chart-4))" />
                  <Bar dataKey="ssIncome" name="Social Security" stackId="a" fill="hsl(var(--calc-chart-5))" />
                  <Bar dataKey="pensionInc" name="Pension" stackId="a" fill="hsl(var(--calc-chart-2))" />
                  <Line type="step" dataKey="targetIncome" name="Target Income" stroke="hsl(var(--destructive))" strokeWidth={2} dot={false} />
                </ComposedChart>
              </ResponsiveContainer>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Data Table */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-lg">Year by Year Projection</CardTitle>
          <Button variant="outline" size="sm" onClick={exportCSV}>
            <Download className="w-4 h-4 mr-2" /> Export CSV
          </Button>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto rounded-lg border border-border">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-muted-foreground bg-muted/50 uppercase">
                <tr>
                  <th className="px-4 py-3 font-semibold">Age</th>
                  <th className="px-4 py-3 font-semibold text-right">Contributions</th>
                  <th className="px-4 py-3 font-semibold text-right">Growth</th>
                  <th className="px-4 py-3 font-semibold text-right">Income</th>
                  <th className="px-4 py-3 font-semibold text-right">Ending Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {(tableExpanded ? projection : projection.filter((_, i) => i % 5 === 0 || i === projection.length - 1)).map((row, i) => (
                  <tr key={i} className="hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3 font-medium">{row.age} <span className="text-muted-foreground text-xs font-normal">({row.year})</span></td>
                    <td className="px-4 py-3 text-right">
                      {row.salary > 0 ? (
                        <>
                          <div className="text-foreground">{formatCurrency(row.employeeContrib + row.iraContrib)}</div>
                          <div className="text-xs text-muted-foreground">+{formatCurrency(row.employerContrib)} match</div>
                        </>
                      ) : '-'}
                    </td>
                    <td className={`px-4 py-3 text-right ${row.growth >= 0 ? 'text-success' : 'text-destructive'}`}>
                      {row.growth > 0 ? '+' : ''}{formatCurrency(row.growth)}
                    </td>
                    <td className="px-4 py-3 text-right">
                      {row.totalIncome > 0 ? formatCurrency(row.totalIncome) : '-'}
                    </td>
                    <td className="px-4 py-3 text-right font-semibold">
                      {formatCurrency(row.balance)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!tableExpanded && (
            <Button variant="ghost" className="w-full mt-4" onClick={() => setTableExpanded(true)}>
              Show All Years
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  );
}