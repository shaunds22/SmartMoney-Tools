import React, { useState, useEffect } from 'react';
import InputField from './InputField.jsx';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import useCurrency from '@/hooks/useCurrency.js';

function MortgageCalculator({ onResultsChange }) {
  const { currency } = useCurrency();
  const [propertyValue, setPropertyValue] = useState('250000');
  const [deposit, setDeposit] = useState('25000');
  const [interestRate, setInterestRate] = useState('5.5');
  const [mortgageTerm, setMortgageTerm] = useState('25');
  const [repaymentType, setRepaymentType] = useState('repayment');
  const [councilTax, setCouncilTax] = useState('150');
  const [buildingsInsurance, setBuildingsInsurance] = useState('25');
  const [serviceCharge, setServiceCharge] = useState('0');
  const [groundRent, setGroundRent] = useState('0');
  const [maintenance, setMaintenance] = useState('0');
  const [extraPayment, setExtraPayment] = useState('0');

  const [errors, setErrors] = useState({});

  const validateInputs = () => {
    const newErrors = {};

    const propertyValueNum = parseFloat(propertyValue) || 0;
    const depositNum = parseFloat(deposit) || 0;

    if (!propertyValue || propertyValueNum <= 0) {
      newErrors.propertyValue = 'Please enter a valid property value';
    }
    if (!deposit || depositNum < 0) {
      newErrors.deposit = 'Please enter a valid deposit';
    }
    if (depositNum >= propertyValueNum) {
      newErrors.deposit = 'Deposit must be less than the property value';
    }
    if (!interestRate || parseFloat(interestRate) < 0 || parseFloat(interestRate) > 100) {
      newErrors.interestRate = 'Please enter a rate between 0 and 100';
    }
    if (!mortgageTerm || parseFloat(mortgageTerm) <= 0 || parseFloat(mortgageTerm) > 50) {
      newErrors.mortgageTerm = 'Please enter a term between 1 and 50 years';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const calculateResults = () => {
    if (!validateInputs()) {
      return null;
    }

    const propertyValueNum = parseFloat(propertyValue) || 0;
    const depositNum = parseFloat(deposit) || 0;
    const principal = Math.max(0, propertyValueNum - depositNum);
    const monthlyRate = (parseFloat(interestRate) || 0) / 100 / 12;
    const months = (parseFloat(mortgageTerm) || 0) * 12;
    const extraMonthly = parseFloat(extraPayment) || 0;

    const councilTaxMonthly = parseFloat(councilTax) || 0;
    const insuranceMonthly = parseFloat(buildingsInsurance) || 0;
    const serviceChargeMonthly = parseFloat(serviceCharge) || 0;
    const groundRentMonthly = parseFloat(groundRent) || 0;
    const maintenanceMonthly = parseFloat(maintenance) || 0;

    const monthlyHousingCost =
      councilTaxMonthly + insuranceMonthly + serviceChargeMonthly + groundRentMonthly + maintenanceMonthly;

    const isInterestOnly = repaymentType === 'interest-only';

    let monthlyMortgagePayment = 0;
    let totalInterest = 0;
    let totalRepaid = 0;

    const amortizationData = [];
    const yearlyData = [];

    if (isInterestOnly) {
      // Interest-only: pay interest each month, repay the capital as a lump at the end.
      monthlyMortgagePayment = principal * monthlyRate;
      totalInterest = monthlyMortgagePayment * months;
      totalRepaid = totalInterest + principal;

      for (let month = 1; month <= months; month++) {
        if (month <= 360) {
          amortizationData.push({
            month,
            principal: 0,
            interest: monthlyMortgagePayment,
            balance: principal,
          });
        }
      }
      for (let year = 1; year <= Math.min(parseFloat(mortgageTerm), 30); year++) {
        yearlyData.push({
          year,
          principal: 0,
          interest: monthlyMortgagePayment * 12,
        });
      }
    } else {
      // Repayment (capital + interest) mortgage.
      if (monthlyRate > 0) {
        monthlyMortgagePayment =
          (principal * (monthlyRate * Math.pow(1 + monthlyRate, months))) /
          (Math.pow(1 + monthlyRate, months) - 1);
      } else {
        monthlyMortgagePayment = principal / months;
      }

      const totalPaid = monthlyMortgagePayment * months;
      totalInterest = totalPaid - principal;
      totalRepaid = totalPaid;

      let remainingBalance = principal;
      for (let month = 1; month <= months; month++) {
        const interestPayment = remainingBalance * monthlyRate;
        const principalPayment = monthlyMortgagePayment - interestPayment;
        remainingBalance -= principalPayment;

        if (month <= 360) {
          amortizationData.push({
            month,
            principal: principalPayment,
            interest: interestPayment,
            balance: Math.max(0, remainingBalance),
          });
        }
      }

      for (let year = 1; year <= Math.min(parseFloat(mortgageTerm), 30); year++) {
        const startMonth = (year - 1) * 12;
        const endMonth = Math.min(year * 12, months);

        let yearPrincipal = 0;
        let yearInterest = 0;

        for (let i = startMonth; i < endMonth && i < amortizationData.length; i++) {
          yearPrincipal += amortizationData[i].principal;
          yearInterest += amortizationData[i].interest;
        }

        yearlyData.push({
          year,
          principal: yearPrincipal,
          interest: yearInterest,
        });
      }
    }

    const totalMonthlyCost = monthlyMortgagePayment + monthlyHousingCost;
    const totalMonthlyWithExtra = totalMonthlyCost + extraMonthly;
    const ltv = propertyValueNum > 0 ? (principal / propertyValueNum) * 100 : 0;

    return {
      mortgageAmount: principal,
      propertyValue: propertyValueNum,
      deposit: depositNum,
      ltv,
      repaymentType,
      monthlyMortgagePayment,
      principalAndInterest: monthlyMortgagePayment,
      totalInterest,
      totalRepaid,
      monthlyHousingCost,
      totalMonthlyCost,
      councilTaxMonthly,
      insuranceMonthly,
      serviceChargeMonthly,
      groundRentMonthly,
      maintenanceMonthly,
      extraPayment: extraMonthly,
      totalMonthlyWithExtra,
      amortizationData,
      yearlyData,
    };
  };

  useEffect(() => {
    const results = calculateResults();
    if (results && onResultsChange) {
      onResultsChange(results);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    propertyValue,
    deposit,
    interestRate,
    mortgageTerm,
    repaymentType,
    councilTax,
    buildingsInsurance,
    serviceCharge,
    groundRent,
    maintenance,
    extraPayment,
  ]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <InputField
          label="Property value"
          id="propertyValue"
          value={propertyValue}
          onChange={(e) => setPropertyValue(e.target.value)}
          prefix={currency.symbol}
          placeholder="250000"
          error={errors.propertyValue}
          min="0"
          required
        />

        <InputField
          label="Deposit"
          id="deposit"
          value={deposit}
          onChange={(e) => setDeposit(e.target.value)}
          prefix={currency.symbol}
          placeholder="25000"
          error={errors.deposit}
          min="0"
          required
        />

        <InputField
          label="Interest rate"
          id="interestRate"
          value={interestRate}
          onChange={(e) => setInterestRate(e.target.value)}
          suffix="%"
          placeholder="5.5"
          error={errors.interestRate}
          min="0"
          max="100"
          step="0.01"
          required
        />

        <InputField
          label="Mortgage term"
          id="mortgageTerm"
          value={mortgageTerm}
          onChange={(e) => setMortgageTerm(e.target.value)}
          suffix="years"
          placeholder="25"
          error={errors.mortgageTerm}
          min="1"
          max="50"
          required
        />

        <div className="space-y-2 md:col-span-2">
          <Label htmlFor="repaymentType" className="text-sm font-medium text-foreground">
            Repayment type
          </Label>
          <Select value={repaymentType} onValueChange={setRepaymentType}>
            <SelectTrigger id="repaymentType" className="text-foreground">
              <SelectValue placeholder="Select repayment type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="repayment">Repayment (capital &amp; interest)</SelectItem>
              <SelectItem value="interest-only">Interest-only</SelectItem>
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">
            {repaymentType === 'interest-only'
              ? 'You pay only the interest each month and repay the full loan amount at the end of the term.'
              : 'You pay capital and interest each month, clearing the loan by the end of the term.'}
          </p>
        </div>
      </div>

      <div className="border-t border-border pt-6">
        <h4 className="text-sm font-semibold text-foreground mb-1">Optional monthly housing costs</h4>
        <p className="text-xs text-muted-foreground mb-4">
          These are shown separately from your mortgage payment and combined into an estimated monthly housing cost.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <InputField
            label="Council Tax (monthly)"
            id="councilTax"
            value={councilTax}
            onChange={(e) => setCouncilTax(e.target.value)}
            prefix={currency.symbol}
            placeholder="150"
            min="0"
          />

          <InputField
            label="Buildings insurance (monthly)"
            id="buildingsInsurance"
            value={buildingsInsurance}
            onChange={(e) => setBuildingsInsurance(e.target.value)}
            prefix={currency.symbol}
            placeholder="25"
            min="0"
          />

          <InputField
            label="Service charge (monthly)"
            id="serviceCharge"
            value={serviceCharge}
            onChange={(e) => setServiceCharge(e.target.value)}
            prefix={currency.symbol}
            placeholder="0"
            min="0"
          />

          <InputField
            label="Ground rent (monthly)"
            id="groundRent"
            value={groundRent}
            onChange={(e) => setGroundRent(e.target.value)}
            prefix={currency.symbol}
            placeholder="0"
            min="0"
          />

          <InputField
            label="Estimated maintenance (monthly)"
            id="maintenance"
            value={maintenance}
            onChange={(e) => setMaintenance(e.target.value)}
            prefix={currency.symbol}
            placeholder="0"
            min="0"
          />

          {repaymentType === 'repayment' && (
            <InputField
              label="Extra monthly overpayment"
              id="extraPayment"
              value={extraPayment}
              onChange={(e) => setExtraPayment(e.target.value)}
              prefix={currency.symbol}
              placeholder="0"
              min="0"
            />
          )}
        </div>
      </div>
    </div>
  );
}

export default MortgageCalculator;
