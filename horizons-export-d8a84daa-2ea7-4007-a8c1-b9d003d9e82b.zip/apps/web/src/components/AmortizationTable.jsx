import React, { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import formatCurrency from '@/utils/formatCurrency.js';

function AmortizationTable({ data, currencyCode }) {
  const [currentPage, setCurrentPage] = useState(0);
  const itemsPerPage = 12;

  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center py-12 bg-muted/30 rounded-xl">
        <p className="text-muted-foreground">No data to display</p>
      </div>
    );
  }

  const totalPages = Math.ceil(data.length / itemsPerPage);
  const startIndex = currentPage * itemsPerPage;
  const endIndex = Math.min(startIndex + itemsPerPage, data.length);
  const currentData = data.slice(startIndex, endIndex);

  const formatValue = (value) => formatCurrency(value, currencyCode);

  const handlePrevious = () => {
    setCurrentPage(prev => Math.max(0, prev - 1));
  };

  const handleNext = () => {
    setCurrentPage(prev => Math.min(totalPages - 1, prev + 1));
  };

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="font-semibold">Payment #</TableHead>
                <TableHead className="font-semibold text-right">Principal</TableHead>
                <TableHead className="font-semibold text-right">Interest</TableHead>
                <TableHead className="font-semibold text-right">Balance</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {currentData.map((row, index) => (
                <TableRow key={index} className={index % 2 === 0 ? 'bg-card' : 'bg-muted/20'}>
                  <TableCell className="font-medium">{row.month}</TableCell>
                  <TableCell className="text-right" style={{ fontVariantNumeric: 'tabular-nums' }}>
                    {formatValue(row.principal)}
                  </TableCell>
                  <TableCell className="text-right" style={{ fontVariantNumeric: 'tabular-nums' }}>
                    {formatValue(row.interest)}
                  </TableCell>
                  <TableCell className="text-right font-semibold" style={{ fontVariantNumeric: 'tabular-nums' }}>
                    {formatValue(row.balance)}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Showing {startIndex + 1}-{endIndex} of {data.length} payments
          </p>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrevious}
              disabled={currentPage === 0}
              className="transition-all duration-200"
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              Previous
            </Button>
            <span className="text-sm text-muted-foreground">
              Page {currentPage + 1} of {totalPages}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={handleNext}
              disabled={currentPage === totalPages - 1}
              className="transition-all duration-200"
            >
              Next
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

export default AmortizationTable;