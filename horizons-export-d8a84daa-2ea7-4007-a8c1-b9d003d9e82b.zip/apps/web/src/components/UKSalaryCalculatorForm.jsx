import React, { useState, useEffect } from 'react';
import InputField from './InputField.jsx';
import { AlertCircle } from 'lucide-react';

function SelectField({ label, id, value, onChange, options, helperText }) {
  return (
    <div className="space-y-2">
      <label htmlFor={id} className="text-sm font-medium text-foreground">{label}</label>
      <select
        id={id}
        value={value}
        onChange={onChange}
        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 text-foreground"
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>
      {helperText && <p className="text-xs text-muted-foreground">{helperText}</p>}
    </div>
  );
}

function CheckboxField({ label, id, checked, onChange, helperText }) {
  return (
    <div className="flex items-start space-x-2 pt-2">
      <input
        type="checkbox"
        id={id}
        checked={checked}
        onChange={onChange}
        className="mt-1 h-4 w-4 rounded border-primary text-primary focus:ring-primary bg-background"
      />
      <div>
        <label htmlFor={id} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-foreground cursor-pointer">
          {label}
        </label>
        {helperText && <p className="text-xs text-muted-foreground mt-1">{helperText}</p>}
      </div>
    </div>
  );
}

function UKSalaryCalculatorForm({ onResultsChange }) {
  const [formData, setFormData] = useState({
    salaryInput: 50000,
    salaryFrequency: 'Annual',
    hoursPerWeek: 37.5,
    region: 'England',
    taxCode: '1257L',
    useCustomPA: false,
    customPA: 12570,
    pensionPercentage: 5,
    employerPensionPercentage: 3,
    pensionReliefType: 'Salary Sacrifice',
    pensionBasis: 'Qualifying Earnings',
    bonus: 0,
    displayFrequency: 'Annual',
    studentLoans: {
      plan1: false,
      plan2: false,
      plan4: false,
      plan5: false,
      postgrad: false,
    }
  });

  const handleInputChange = (field, value) => {
    setFormData(prev => {
      const newData = { ...prev, [field]: value };
      
      // Prevent negative values for numbers
      if (['salaryInput', 'hoursPerWeek', 'customPA', 'pensionPercentage', 'employerPensionPercentage', 'bonus'].includes(field)) {
        if (parseFloat(newData[field]) < 0) {
          newData[field] = 0;
        }
      }
      return newData;
    });
  };

  const handleStudentLoanChange = (plan, checked) => {
    setFormData(prev => ({
      ...prev,
      studentLoans: {
        ...prev.studentLoans,
        [plan]: checked
      }
    }));
  };

  useEffect(() => {
    onResultsChange(formData);
  }, [formData, onResultsChange]);

  return (
    <div className="space-y-8">
      {/* Primary Income Section */}
      <div className="space-y-6 bg-card p-6 rounded-2xl border border-border shadow-sm">
        <h3 className="text-xl font-semibold text-foreground border-b border-border pb-2">Salary & Core Details</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <InputField
            label="Gross Income"
            id="salaryInput"
            value={formData.salaryInput}
            onChange={(e) => handleInputChange('salaryInput', e.target.value)}
            prefix="£"
            min="0"
          />
          <SelectField
            label="Pay Frequency"
            id="salaryFrequency"
            value={formData.salaryFrequency}
            onChange={(e) => handleInputChange('salaryFrequency', e.target.value)}
            options={[
              { label: 'Annual', value: 'Annual' },
              { label: 'Monthly', value: 'Monthly' },
              { label: 'Weekly', value: 'Weekly' },
              { label: 'Daily', value: 'Daily' },
              { label: 'Hourly', value: 'Hourly' },
            ]}
          />
        </div>
        
        {formData.salaryFrequency === 'Hourly' && (
          <InputField
            label="Hours per week"
            id="hoursPerWeek"
            value={formData.hoursPerWeek}
            onChange={(e) => handleInputChange('hoursPerWeek', e.target.value)}
            min="1"
            max="168"
          />
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <SelectField
            label="Tax Region"
            id="region"
            value={formData.region}
            onChange={(e) => handleInputChange('region', e.target.value)}
            options={[
              { label: 'England', value: 'England' },
              { label: 'Wales', value: 'Wales' },
              { label: 'Northern Ireland', value: 'Northern Ireland' },
              { label: 'Scotland', value: 'Scotland' },
            ]}
            helperText="Scottish rates vary from the rest of the UK."
          />
          <InputField
            label="Annual Bonus / Taxable Benefits"
            id="bonus"
            value={formData.bonus}
            onChange={(e) => handleInputChange('bonus', e.target.value)}
            prefix="£"
            min="0"
            helperText="Applied to the full tax year."
          />
        </div>

        <div className="pt-2 border-t border-border">
          <CheckboxField
            label="Use Custom Personal Allowance"
            id="useCustomPA"
            checked={formData.useCustomPA}
            onChange={(e) => handleInputChange('useCustomPA', e.target.checked)}
            helperText="Check this if you have a non-standard tax code."
          />
          {formData.useCustomPA && (
            <div className="mt-4">
              <InputField
                label="Custom Personal Allowance"
                id="customPA"
                value={formData.customPA}
                onChange={(e) => handleInputChange('customPA', e.target.value)}
                prefix="£"
                min="0"
                helperText="Standard for 26/27 is £12,570 (1257L)."
              />
            </div>
          )}
        </div>
      </div>

      {/* Pension Section */}
      <div className="space-y-6 bg-card p-6 rounded-2xl border border-border shadow-sm">
        <h3 className="text-xl font-semibold text-foreground border-b border-border pb-2">Pension Contributions</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <InputField
            label="Employee Contribution"
            id="pensionPercentage"
            value={formData.pensionPercentage}
            onChange={(e) => handleInputChange('pensionPercentage', e.target.value)}
            suffix="%"
            min="0"
            max="100"
          />
          <InputField
            label="Employer Contribution"
            id="employerPensionPercentage"
            value={formData.employerPensionPercentage}
            onChange={(e) => handleInputChange('employerPensionPercentage', e.target.value)}
            suffix="%"
            min="0"
            max="100"
            helperText="Does not affect your take-home pay."
          />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <SelectField
            label="Pension Relief Type"
            id="pensionReliefType"
            value={formData.pensionReliefType}
            onChange={(e) => handleInputChange('pensionReliefType', e.target.value)}
            options={[
              { label: 'Salary Sacrifice', value: 'Salary Sacrifice' },
              { label: 'Net Pay Arrangement', value: 'Net Pay' },
              { label: 'Relief at Source', value: 'Relief at Source' },
            ]}
            helperText="Salary sacrifice saves both Income Tax and NI."
          />
          <SelectField
            label="Calculation Basis"
            id="pensionBasis"
            value={formData.pensionBasis}
            onChange={(e) => handleInputChange('pensionBasis', e.target.value)}
            options={[
              { label: 'Qualifying Earnings', value: 'Qualifying Earnings' },
              { label: 'Full Salary', value: 'Full Salary' },
            ]}
            helperText="Auto-enrolment default is Qualifying Earnings."
          />
        </div>
      </div>

      {/* Student Loan Section */}
      <div className="space-y-6 bg-card p-6 rounded-2xl border border-border shadow-sm">
        <h3 className="text-xl font-semibold text-foreground border-b border-border pb-2">Student Loans</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <CheckboxField
            label="Plan 1"
            id="plan1"
            checked={formData.studentLoans.plan1}
            onChange={(e) => handleStudentLoanChange('plan1', e.target.checked)}
            helperText="Started before Sep 2012"
          />
          <CheckboxField
            label="Plan 2"
            id="plan2"
            checked={formData.studentLoans.plan2}
            onChange={(e) => handleStudentLoanChange('plan2', e.target.checked)}
            helperText="Started after Sep 2012 (Eng/Wal)"
          />
          <CheckboxField
            label="Plan 4"
            id="plan4"
            checked={formData.studentLoans.plan4}
            onChange={(e) => handleStudentLoanChange('plan4', e.target.checked)}
            helperText="Scottish students"
          />
          <CheckboxField
            label="Plan 5"
            id="plan5"
            checked={formData.studentLoans.plan5}
            onChange={(e) => handleStudentLoanChange('plan5', e.target.checked)}
            helperText="Started after Aug 2023 (Eng)"
          />
          <div className="sm:col-span-2">
            <CheckboxField
              label="Postgraduate Loan"
              id="postgrad"
              checked={formData.studentLoans.postgrad}
              onChange={(e) => handleStudentLoanChange('postgrad', e.target.checked)}
            />
          </div>
        </div>
      </div>

      {/* Display Settings Section */}
      <div className="space-y-6 bg-muted/40 p-6 rounded-2xl border border-border shadow-sm">
        <div className="flex items-center gap-3">
          <AlertCircle className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-semibold text-foreground">Results Display</h3>
        </div>
        <SelectField
          label="Show results as"
          id="displayFrequency"
          value={formData.displayFrequency}
          onChange={(e) => handleInputChange('displayFrequency', e.target.value)}
          options={[
            { label: 'Annual breakdown', value: 'Annual' },
            { label: 'Monthly breakdown', value: 'Monthly' },
            { label: 'Weekly breakdown', value: 'Weekly' },
          ]}
        />
      </div>
    </div>
  );
}

export default UKSalaryCalculatorForm;