import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { AlertCircle } from 'lucide-react';
import { DEFAULT_AUTHOR } from '@/data/authors.js';
import { personRef } from '@/data/author.js';

/**
 * AuthorByline — author bio box for guide (article) pages.
 *
 * Rendered below the hero byline. Shows the author bio (authorBio), links to
 * the Editorial Policy and the error-reporting contact form, and emits the
 * Article + Person JSON-LD structured data.
 *
 * The compact "Written by [authorName] — [authorCredential]" line and the
 * "Last updated" date are rendered separately by <AuthorBylineBar> directly
 * under the H1, so they are intentionally not repeated here.
 */
export default function AuthorByline({
  title,
  url,
  lastUpdated,
  authorName = DEFAULT_AUTHOR.name,
  authorBio = DEFAULT_AUTHOR.bio,
  authorCredential = DEFAULT_AUTHOR.credential,
}) {
  const fmtDate = (iso) => {
    if (!iso) return null;
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return null;
    return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  };
  const updated = fmtDate(lastUpdated);

  const articleSchema = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: title,
    author: personRef(),
    mainEntityOfPage: `https://smartmoney-tools.com${url}`,
    ...(updated ? { dateModified: new Date(lastUpdated).toISOString() } : {}),
  };

  return (
    <>
      <Helmet>
        <script type="application/ld+json">{JSON.stringify(articleSchema)}</script>
      </Helmet>

      <div className="not-prose mb-8 flex flex-col gap-3 rounded-xl border border-border/60 bg-muted/40 px-4 py-4 sm:px-6">
        <p className="text-sm leading-relaxed text-muted-foreground">
          <span className="font-medium text-foreground">About the author:</span>{' '}
          {authorBio}{' '}
          <Link
            to={DEFAULT_AUTHOR.profilePath}
            className="font-medium text-primary hover:underline"
          >
            View author profile
          </Link>
          {' \u00b7 '}
          <a
            href="https://www.linkedin.com/in/shaun-da-silva-748b91a2/"
            target="_blank"
            rel="noopener noreferrer"
            className="font-medium text-primary hover:underline"
          >
            LinkedIn
          </a>
        </p>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
          <Link to="/editorial-policy" className="font-medium text-primary hover:underline">
            Editorial Policy
          </Link>
          <Link
            to="/contact?category=bug"
            className="flex items-center gap-1 font-medium text-primary hover:underline"
          >
            <AlertCircle className="h-4 w-4" /> Report an error
          </Link>
        </div>
      </div>
    </>
  );
}
