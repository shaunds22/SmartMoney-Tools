import React from 'react';

function ResultsCard({ results }) {
  return (
    <div className="bg-primary/5 rounded-xl p-6 border border-primary/20">
      <h3 className="text-lg font-semibold text-foreground mb-4">Results</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {results.map((result, index) => (
          <div key={index} className="space-y-1">
            <p className="text-sm font-medium text-muted-foreground">{result.label}</p>
            <p className="text-3xl font-bold text-foreground" style={{ fontVariantNumeric: 'tabular-nums' }}>
              {result.value}
            </p>
            {result.subtitle && (
              <p className="text-xs text-muted-foreground">{result.subtitle}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

export default ResultsCard;