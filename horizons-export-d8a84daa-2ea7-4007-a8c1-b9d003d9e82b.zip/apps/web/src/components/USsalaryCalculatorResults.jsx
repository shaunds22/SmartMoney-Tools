import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend } from 'recharts';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ChevronDown, ShieldAlert } from 'lucide-react';

const formatCurrency = (val) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);

export default function USsalaryCalculatorResults({ results }) {
  if (!results) return null;

  const {
    annualGross,
    federalTax,
    stateTax,
    fica,
    preTaxDeductions,
    postTaxDeductions,
    netPay,
    effectiveTaxRate,
    takeHomePercentage
  } = results;

  const chartData = [
    { name: 'Net Pay', value: netPay, color: 'hsl(var(--calc-chart-1))' },
    { name: 'Federal Tax', value: federalTax, color: 'hsl(var(--calc-chart-2))' },
    { name: 'State Tax', value: stateTax, color: 'hsl(var(--calc-chart-3))' },
    { name: 'FICA', value: fica.totalFICA, color: 'hsl(var(--calc-chart-4))' },
    { name: 'Deductions', value: preTaxDeductions + postTaxDeductions, color: 'hsl(var(--calc-chart-5))' }
  ].filter(item => item.value > 0);

  return (
    <div className="space-y-6">
      <Card className="shadow-lg border-0 bg-card text-card-foreground overflow-hidden">
        <CardHeader className="bg-primary text-primary-foreground p-6 rounded-t-xl text-center">
          <CardTitle className="text-sm font-medium opacity-90 uppercase tracking-wider">Estimated Net Pay (Annual)</CardTitle>
          <div className="text-5xl font-extrabold mt-2 tracking-tight">{formatCurrency(netPay)}</div>
          <div className="text-sm opacity-80 mt-2">
            Take home: {takeHomePercentage.toFixed(1)}% | Effective Tax Rate: {effectiveTaxRate.toFixed(1)}%
          </div>
        </CardHeader>
        
        <CardContent className="p-6">
          <div className="h-64 mb-6">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <RechartsTooltip 
                  formatter={(value) => formatCurrency(value)}
                  contentStyle={{ backgroundColor: 'hsl(var(--popover))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--popover-foreground))', borderRadius: '8px' }}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between font-bold text-lg border-b border-border/50 pb-2">
              <span>Gross Income</span>
              <span>{formatCurrency(annualGross)}</span>
            </div>
            
            <div className="space-y-2 text-sm">
              <div className="flex justify-between text-muted-foreground">
                <span>Federal Income Tax</span>
                <span className="text-destructive">-{formatCurrency(federalTax)}</span>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <span>State Income Tax</span>
                <span className="text-destructive">-{formatCurrency(stateTax)}</span>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <span>Social Security & Medicare</span>
                <span className="text-destructive">-{formatCurrency(fica.totalFICA)}</span>
              </div>
              {(preTaxDeductions > 0 || postTaxDeductions > 0) && (
                <div className="flex justify-between text-muted-foreground">
                  <span>Benefits & Deductions</span>
                  <span className="text-destructive">-{formatCurrency(preTaxDeductions + postTaxDeductions)}</span>
                </div>
              )}
            </div>
            
            <div className="flex justify-between font-bold text-xl pt-2 border-t border-border/50 text-primary">
              <span>Net Take-Home Pay</span>
              <span>{formatCurrency(netPay)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Collapsible>
        <CollapsibleTrigger className="flex items-center justify-between w-full p-4 bg-muted text-muted-foreground rounded-lg hover:bg-muted/80 transition-colors">
          <span className="font-medium text-sm">How your US salary was calculated</span>
          <ChevronDown className="h-4 w-4" />
        </CollapsibleTrigger>
        <CollapsibleContent className="p-4 mt-2 bg-card border border-border rounded-lg text-sm space-y-4 text-card-foreground">
          <p>This estimate uses the 2026 Federal tax brackets and standard deductions. State taxes are simplified estimates based on selected state rules.</p>
          <div className="bg-destructive/10 text-destructive-foreground p-3 rounded-md flex items-start gap-3">
            <ShieldAlert className="h-5 w-5 shrink-0 text-destructive" />
            <p className="text-xs leading-relaxed text-foreground">
              <strong>Disclaimer:</strong> This calculator provides an estimate for general informational and budgeting purposes only. It does not constitute tax, payroll, accounting, legal or financial advice. Actual withholding and take-home pay can differ because of your Form W-4 elections, employer payroll methods, benefits, state and local rules, reciprocity agreements, tax credits, and deductions.
            </p>
          </div>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
}