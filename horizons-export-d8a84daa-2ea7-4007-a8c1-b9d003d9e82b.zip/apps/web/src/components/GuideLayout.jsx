import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import AuthorBylineBar from '@/components/AuthorBylineBar.jsx';
import AuthorByline from '@/components/AuthorByline.jsx';
import Breadcrumb from '@/components/Breadcrumb.jsx';
import GuideSection from '@/components/GuideSection.jsx';
import MoreInSeries from '@/components/MoreInSeries.jsx';
import { setPageMeta } from '@/utils/seo.js';
import { BookOpen } from 'lucide-react';
import { DEFAULT_AUTHOR } from '@/data/authors.js';

/**
 * GuideLayout — shared shell for every guide (article) page.
 *
 * Carries the guide's author content data (authorName, authorBio,
 * authorCredential) with sensible defaults pointing at the site's default
 * author, so every guide shows a "Written by [authorName] — [authorCredential]"
 * byline directly under the H1.
 */
export default function GuideLayout({
  title,
  description,
  url,
  children,
  sections,
  series,
  lastUpdated,
  authorName = DEFAULT_AUTHOR.name,
  authorBio = DEFAULT_AUTHOR.bio,
  authorCredential = DEFAULT_AUTHOR.credential,
}) {
  useEffect(() => {
    setPageMeta(
      `${title} | SmartMoneyTools`,
      description,
      `https://smartmoney-tools.com${url}`
    );
  }, [title, description, url]);

  return (
    <div className="min-h-screen flex flex-col">
      <section className="bg-primary text-primary-foreground py-16 lg:py-20 border-b border-primary/20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl text-center">
          <div className="mb-6 flex justify-center">
            <Link to="/guides" className="inline-flex items-center text-primary-foreground/80 hover:text-white transition-colors text-sm font-medium">
              <BookOpen className="h-4 w-4 mr-2" /> Back to Guides Library
            </Link>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 leading-tight text-balance" style={{ letterSpacing: '-0.02em' }}>
            {title}
          </h1>
          <p className="text-xl text-primary-foreground/90 leading-relaxed max-w-2xl mx-auto">
            {description}
          </p>
          <AuthorBylineBar
            variant="hero"
            authorName={authorName}
            authorCredential={authorCredential}
            profilePath={DEFAULT_AUTHOR.profilePath}
            lastReviewed={lastUpdated}
          />
        </div>
      </section>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl pt-6 pb-0">
        <Breadcrumb items={[{ label: 'Guides', href: '/guides' }, { label: title }]} />
      </div>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl py-12 lg:py-16">
        <AuthorByline
          title={title}
          url={url}
          lastUpdated={lastUpdated}
          authorName={authorName}
          authorBio={authorBio}
          authorCredential={authorCredential}
        />
        <article className="prose prose-lg prose-slate max-w-none text-muted-foreground prose-headings:text-foreground prose-a:text-primary hover:prose-a:text-primary/80 prose-strong:text-foreground">
          {Array.isArray(sections) && sections.length > 0
            ? sections.map((section, index) => (
                <GuideSection key={index} {...section} />
              ))
            : children}
          {series && (
            <MoreInSeries currentPath={url} items={series} />
          )}
          <div className="mt-12 pt-8 border-t border-border text-center not-prose">
            <p className="text-muted-foreground text-sm">
              Written and maintained by{' '}
              <Link to={DEFAULT_AUTHOR.profilePath} className="text-primary hover:underline font-medium">
                {authorName}
              </Link>
              , {authorCredential}. Learn how we ensure accuracy and quality in our{' '}
              <Link to="/editorial-policy" className="text-primary hover:underline font-medium">Editorial Policy</Link>{' '}
              or <Link to="/contact?category=bug" className="text-primary hover:underline font-medium">report an error</Link>.
            </p>
          </div>
        </article>
      </div>
    </div>
  );
}
