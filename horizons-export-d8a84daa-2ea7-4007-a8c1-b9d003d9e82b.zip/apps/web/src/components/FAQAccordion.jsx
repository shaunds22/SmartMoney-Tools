import React from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

function FAQAccordion({ faqItems = [] }) {
  // If no FAQ items are supplied, render nothing rather than showing an
  // unfinished "No FAQs available" placeholder to the visitor.
  if (!Array.isArray(faqItems) || faqItems.length === 0) {
    return null;
  }

  return (
    <Accordion type="single" collapsible className="w-full space-y-4">
      {faqItems.map((faqItem, index) => {
        // Ensure each faqItem has required properties
        if (!faqItem || typeof faqItem !== 'object' || !faqItem.question || !faqItem.answer) {
          return null;
        }

        return (
          <AccordionItem 
            key={index} 
            value={`item-${index}`}
            className="bg-card rounded-xl border border-border px-6"
          >
            <AccordionTrigger className="text-left font-medium text-card-foreground hover:no-underline py-5">
              {faqItem.question}
            </AccordionTrigger>
            {/* forceMount keeps the answer in the DOM (and therefore in the
                prerendered HTML Google crawls) even when the accordion is
                collapsed. Radix sets the `hidden` attribute on closed items,
                so the text is in the raw HTML but visually hidden until the
                visitor opens it — crawlable, not gated behind interaction. */}
            <AccordionContent forceMount className="text-muted-foreground leading-relaxed pb-5 data-[state=closed]:hidden">
              {faqItem.answer}
            </AccordionContent>
          </AccordionItem>
        );
      })}
    </Accordion>
  );
}

export default FAQAccordion;