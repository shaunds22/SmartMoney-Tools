import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Collapsible, CollapsibleTrigger, CollapsibleContent } from '@/components/ui/collapsible.jsx';
import { ChevronDown, ShieldCheck } from 'lucide-react';

/**
 * HowWeCalculateThis — a collapsible methodology summary shown directly on a
 * calculator page, so the sources-checked / review-process statement is
 * visible in context instead of only living behind a link to the Editorial
 * Policy.
 *
 * The summary text is drawn from the Editorial Policy page (sections on
 * Sources & Fact-Checking and Review & Quality Checks). Pass `region` to
 * tailor the named primary sources to the calculator's jurisdiction, and an
 * optional `extra` node for any calculator-specific methodology note.
 *
 * Props:
 *   region: 'UK' | 'US' | 'both'  (default 'both')
 *   extra:  ReactNode — optional calculator-specific note appended to the summary
 *   className: string — optional wrapper className
 */
function sourceList(region) {
  if (region === 'UK') {
    return 'GOV.UK, HM Revenue & Customs (HMRC), The Pensions Regulator, and MoneyHelper';
  }
  if (region === 'US') {
    return 'the Internal Revenue Service (IRS) and the Social Security Administration (SSA)';
  }
  return 'GOV.UK, HMRC, The Pensions Regulator, and MoneyHelper for UK figures, and the IRS and Social Security Administration (SSA) for US figures';
}

export default function HowWeCalculateThis({ region = 'both', extra = null, className = '' }) {
  const [open, setOpen] = useState(false);

  return (
    <div className={`not-prose my-6 ${className}`}>
      <Collapsible open={open} onOpenChange={setOpen}>
        <div className="rounded-xl border border-border bg-card shadow-sm overflow-hidden">
          <CollapsibleTrigger className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left hover:bg-muted/50 transition-colors">
            <span className="flex items-center gap-3">
              <ShieldCheck className="h-5 w-5 text-primary shrink-0" />
              <span className="font-semibold text-foreground">How we calculate this</span>
            </span>
            <ChevronDown
              className={`h-5 w-5 text-muted-foreground shrink-0 transition-transform duration-200 ${open ? 'rotate-180' : ''}`}
            />
          </CollapsibleTrigger>
          <CollapsibleContent>
            <div className="px-5 pb-5 pt-1 text-sm text-muted-foreground leading-relaxed space-y-3 border-t border-border">
              <p>
                Every statutory rate, threshold, and allowance used by this calculator is checked
                against official primary sources — {sourceList(region)} — and the calculation logic
                is tested against known worked examples before publication. Each page carries a
                &ldquo;Last reviewed&rdquo; date that is refreshed whenever a material change is made.
              </p>
              <p>
                Results are estimates for educational purposes and may not reflect every individual
                circumstance. For the full standards behind our figures, see our{' '}
                <Link to="/editorial-policy" className="text-primary hover:underline font-medium">
                  Editorial Policy
                </Link>
                .
              </p>
              {extra && <div className="text-foreground">{extra}</div>}
            </div>
          </CollapsibleContent>
        </div>
      </Collapsible>
    </div>
  );
}
