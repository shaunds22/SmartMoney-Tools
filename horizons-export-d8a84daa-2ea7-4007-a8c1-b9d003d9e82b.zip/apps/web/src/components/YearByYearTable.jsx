import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import formatCurrency from '@/utils/formatCurrency.js';

function YearByYearTable({ data, currencyCode }) {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center py-12 bg-muted/30 rounded-xl">
        <p className="text-muted-foreground">No data to display</p>
      </div>
    );
  }

  const formatValue = (value) => formatCurrency(value, currencyCode);

  return (
    <div className="rounded-xl border border-border overflow-hidden">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead className="font-semibold">Year</TableHead>
              <TableHead className="font-semibold text-right">Starting Balance</TableHead>
              <TableHead className="font-semibold text-right">Interest Earned</TableHead>
              <TableHead className="font-semibold text-right">Contributions</TableHead>
              <TableHead className="font-semibold text-right">Ending Balance</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((row, index) => (
              <TableRow key={index} className={index % 2 === 0 ? 'bg-card' : 'bg-muted/20'}>
                <TableCell className="font-medium">{row.year}</TableCell>
                <TableCell className="text-right" style={{ fontVariantNumeric: 'tabular-nums' }}>
                  {formatValue(row.startingBalance)}
                </TableCell>
                <TableCell className="text-right text-secondary" style={{ fontVariantNumeric: 'tabular-nums' }}>
                  {formatValue(row.interestEarned)}
                </TableCell>
                <TableCell className="text-right" style={{ fontVariantNumeric: 'tabular-nums' }}>
                  {formatValue(row.contributions)}
                </TableCell>
                <TableCell className="text-right font-semibold" style={{ fontVariantNumeric: 'tabular-nums' }}>
                  {formatValue(row.endingBalance)}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

export default YearByYearTable;