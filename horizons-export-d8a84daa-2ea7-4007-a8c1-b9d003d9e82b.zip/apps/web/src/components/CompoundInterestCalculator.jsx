import React, { useState, useEffect } from 'react';
import InputField from './InputField.jsx';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import useCurrency from '@/hooks/useCurrency.js';

function CompoundInterestCalculator({ onResultsChange }) {
  const { currency } = useCurrency();
  const [initialInvestment, setInitialInvestment] = useState('10000');
  const [monthlyContribution, setMonthlyContribution] = useState('500');
  const [annualRate, setAnnualRate] = useState('7');
  const [years, setYears] = useState('20');
  const [compoundFrequency, setCompoundFrequency] = useState('12');

  const [errors, setErrors] = useState({});

  const validateInputs = () => {
    const newErrors = {};
    
    if (!initialInvestment || parseFloat(initialInvestment) < 0) {
      newErrors.initialInvestment = 'Please enter a valid initial investment';
    }
    if (!monthlyContribution || parseFloat(monthlyContribution) < 0) {
      newErrors.monthlyContribution = 'Please enter a valid monthly contribution';
    }
    if (!annualRate || parseFloat(annualRate) < 0 || parseFloat(annualRate) > 100) {
      newErrors.annualRate = 'Please enter a rate between 0 and 100';
    }
    if (!years || parseFloat(years) <= 0 || parseFloat(years) > 100) {
      newErrors.years = 'Please enter years between 1 and 100';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const calculateResults = () => {
    if (!validateInputs()) {
      return null;
    }

    const P = parseFloat(initialInvestment) || 0;
    const PMT = parseFloat(monthlyContribution) || 0;
    const r = (parseFloat(annualRate) || 0) / 100;
    const t = parseFloat(years) || 0;
    const n = parseFloat(compoundFrequency) || 12;

    const initialGrowth = P * Math.pow(1 + r / n, n * t);

    let contributionsGrowth = 0;
    if (PMT > 0 && r > 0) {
      contributionsGrowth = PMT * ((Math.pow(1 + r / n, n * t) - 1) / (r / n));
    } else if (PMT > 0) {
      contributionsGrowth = PMT * 12 * t;
    }

    const finalBalance = initialGrowth + contributionsGrowth;
    const totalContributions = P + (PMT * 12 * t);
    const totalInterest = finalBalance - totalContributions;

    const yearlyData = [];
    for (let year = 0; year <= t; year++) {
      const yearInitialGrowth = P * Math.pow(1 + r / n, n * year);
      let yearContributionsGrowth = 0;
      
      if (PMT > 0 && r > 0 && year > 0) {
        yearContributionsGrowth = PMT * ((Math.pow(1 + r / n, n * year) - 1) / (r / n));
      } else if (PMT > 0 && year > 0) {
        yearContributionsGrowth = PMT * 12 * year;
      }

      const yearEndBalance = yearInitialGrowth + yearContributionsGrowth;
      const yearStartBalance = year === 0 ? P : yearlyData[year - 1].endingBalance;
      const yearContributions = year === 0 ? 0 : PMT * 12;
      const yearInterest = yearEndBalance - yearStartBalance - yearContributions;

      yearlyData.push({
        year,
        startingBalance: yearStartBalance,
        interestEarned: yearInterest,
        contributions: yearContributions,
        endingBalance: yearEndBalance
      });
    }

    return {
      finalBalance,
      totalContributions,
      totalInterest,
      yearlyData
    };
  };

  useEffect(() => {
    const results = calculateResults();
    if (results && onResultsChange) {
      onResultsChange(results);
    }
  }, [initialInvestment, monthlyContribution, annualRate, years, compoundFrequency]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <InputField
          label="Initial investment"
          id="initialInvestment"
          value={initialInvestment}
          onChange={(e) => setInitialInvestment(e.target.value)}
          prefix={currency.symbol}
          placeholder="10000"
          error={errors.initialInvestment}
          min="0"
          required
        />

        <InputField
          label="Monthly contribution"
          id="monthlyContribution"
          value={monthlyContribution}
          onChange={(e) => setMonthlyContribution(e.target.value)}
          prefix={currency.symbol}
          placeholder="500"
          error={errors.monthlyContribution}
          min="0"
          required
        />

        <InputField
          label="Annual interest rate"
          id="annualRate"
          value={annualRate}
          onChange={(e) => setAnnualRate(e.target.value)}
          suffix="%"
          placeholder="7"
          error={errors.annualRate}
          min="0"
          max="100"
          step="0.1"
          required
        />

        <InputField
          label="Number of years"
          id="years"
          value={years}
          onChange={(e) => setYears(e.target.value)}
          placeholder="20"
          error={errors.years}
          min="1"
          max="100"
          required
        />

        <div className="space-y-2">
          <Label htmlFor="compoundFrequency" className="text-sm font-medium text-foreground">
            Compound frequency
          </Label>
          <Select value={compoundFrequency} onValueChange={setCompoundFrequency}>
            <SelectTrigger id="compoundFrequency" className="text-foreground">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">Annually</SelectItem>
              <SelectItem value="2">Semi-annually</SelectItem>
              <SelectItem value="4">Quarterly</SelectItem>
              <SelectItem value="12">Monthly</SelectItem>
              <SelectItem value="365">Daily</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
}

export default CompoundInterestCalculator;