/**
 * PageSeo — drop-in SEO component for every indexable page.
 *
 * Renders (via React Helmet, so it works during prerendering):
 *   - <link rel="canonical">  (HTTPS, non-www, self-referencing)
 *   - <meta name="robots">
 *   - Open Graph tags (og:type, og:title, og:description, og:url, og:image, og:site_name)
 *   - Twitter Card tags
 *
 * The <title> and <meta name="description"> are owned by the global
 * <RouteMeta> component (single source of truth in routeMetadata), so this
 * component does NOT emit them — it only reads the same config values to
 * populate the OG / Twitter cards so social previews always match the page.
 *
 * Usage:
 *   <PageSeo
 *     path="/uk-salary-calculator"
 *     type="website"          // optional, default "website"
 *     image="/og-default.png" // optional
 *     noindex={false}         // optional
 *   />
 */
import { Helmet } from 'react-helmet';
import routeMetadata from '@/config/routeMetadata';

const BASE_URL = 'https://smartmoney-tools.com';
const SITE_NAME = 'SmartMoneyTools';

export default function PageSeo({
  path,
  type = 'website',
  image,
  noindex = false,
  title,
  description,
}) {
  // Prefer the central config so OG/Twitter cards always match the page's
  // actual <title>/<meta description>. Fall back to explicit props only if a
  // route is not yet in the config.
  const meta = routeMetadata[path] || {};
  const finalTitle = meta.title || title;
  const finalDescription = meta.description || description;

  const canonical = `${BASE_URL}${path}`;
  const ogImage = image
    ? image.startsWith('http')
      ? image
      : `${BASE_URL}${image}`
    : null;

  return (
    <Helmet>
      <meta name="robots" content={noindex ? 'noindex, nofollow' : 'index, follow'} />

      {/* Open Graph */}
      <meta property="og:type" content={type} />
      <meta property="og:title" content={finalTitle} />
      <meta property="og:description" content={finalDescription} />
      <meta property="og:url" content={canonical} />
      {ogImage && <meta property="og:image" content={ogImage} />}
      <meta property="og:site_name" content={SITE_NAME} />

      {/* Twitter Card */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={finalTitle} />
      <meta name="twitter:description" content={finalDescription} />
      {ogImage && <meta name="twitter:image" content={ogImage} />}
    </Helmet>
  );
}
