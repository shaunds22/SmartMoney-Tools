import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import useCurrency from '@/hooks/useCurrency.js';
import { currencyData } from '@/utils/currencyData.js';

export default function CurrencySelector() {
  const { currencyCode, setCurrencyCode } = useCurrency();
  const currencies = Object.values(currencyData);

  return (
    <Select value={currencyCode} onValueChange={setCurrencyCode}>
      <SelectTrigger className="w-[110px] h-9 bg-background border-border text-foreground font-medium">
        <SelectValue placeholder="Currency" />
      </SelectTrigger>
      <SelectContent className="max-h-[300px]">
        {currencies.map((c) => (
          <SelectItem key={c.code} value={c.code}>
            {c.code} ({c.symbol})
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}