import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import formatCurrency from '@/utils/formatCurrency.js';

function GrowthChart({ data, currencyCode }) {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-[400px] bg-muted/30 rounded-xl">
        <p className="text-muted-foreground">No data to display</p>
      </div>
    );
  }

  const formatValue = (value) => formatCurrency(value, currencyCode);

  const chartData = data.map(item => ({
    year: item.year,
    'Total Balance': item.endingBalance,
    'Total Contributions': item.startingBalance + item.contributions
  }));

  return (
    <div className="w-full h-[400px]">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
          <XAxis 
            dataKey="year" 
            stroke="hsl(var(--muted-foreground))"
            label={{ value: 'Year', position: 'insideBottom', offset: -5 }}
          />
          <YAxis 
            stroke="hsl(var(--muted-foreground))"
            tickFormatter={formatValue}
          />
          <Tooltip 
            formatter={formatValue}
            contentStyle={{
              backgroundColor: 'hsl(var(--card))',
              border: '1px solid hsl(var(--border))',
              borderRadius: '8px',
              color: 'hsl(var(--card-foreground))'
            }}
          />
          <Legend />
          <Line 
            type="monotone" 
            dataKey="Total Contributions" 
            stroke="hsl(var(--muted-foreground))" 
            strokeWidth={2}
            dot={false}
          />
          <Line 
            type="monotone" 
            dataKey="Total Balance" 
            stroke="hsl(var(--primary))" 
            strokeWidth={3}
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export default GrowthChart;