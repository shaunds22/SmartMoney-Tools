import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import formatCurrency from '@/utils/formatCurrency.js';

function PaymentBreakdownChart({ data, currencyCode }) {
  if (!data) {
    return (
      <div className="flex items-center justify-center h-[400px] bg-muted/30 rounded-xl">
        <p className="text-muted-foreground">No data to display</p>
      </div>
    );
  }

  const chartData = [
    { name: 'Mortgage payment', value: data.principalAndInterest },
    { name: 'Council Tax', value: data.councilTaxMonthly },
    { name: 'Buildings insurance', value: data.insuranceMonthly },
    { name: 'Service charge', value: data.serviceChargeMonthly },
    { name: 'Ground rent', value: data.groundRentMonthly },
    { name: 'Maintenance', value: data.maintenanceMonthly },
  ].filter((item) => item.value > 0);

  const COLORS = [
    'hsl(160, 100%, 25%)',
    'hsl(142, 71%, 45%)',
    'hsl(160, 40%, 60%)',
    'hsl(38, 92%, 50%)',
    'hsl(210, 58%, 55%)',
    'hsl(280, 50%, 60%)',
  ];

  const formatValue = (value) => formatCurrency(value, currencyCode);

  if (chartData.length === 0) {
    return (
      <div className="flex items-center justify-center h-[400px] bg-muted/30 rounded-xl">
        <p className="text-muted-foreground">No data to display</p>
      </div>
    );
  }

  return (
    <div className="w-full h-[400px]">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={chartData}
            cx="50%"
            cy="50%"
            labelLine={false}
            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(1)}%`}
            outerRadius={120}
            fill="#8884d8"
            dataKey="value"
          >
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip
            formatter={formatValue}
            contentStyle={{
              backgroundColor: 'hsl(var(--card))',
              border: '1px solid hsl(var(--border))',
              borderRadius: '8px',
              color: 'hsl(var(--card-foreground))',
            }}
          />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

export default PaymentBreakdownChart;
