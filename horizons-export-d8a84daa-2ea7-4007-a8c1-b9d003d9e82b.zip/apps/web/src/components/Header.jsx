import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, ChevronDown } from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import CurrencySelector from '@/components/CurrencySelector.jsx';

function Header() {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const isActive = (path) => location.pathname === path || location.pathname.startsWith(path + '/');
  
  const calculators = [
    { name: 'US Salary Calculator', path: '/us-salary-calculator' },
    { name: 'US Retirement Calculator', path: '/us-retirement-calculator' },
    { name: 'UK Salary Calculator', path: '/uk-salary-calculator' },
    { name: 'Compound Interest', path: '/compound-interest' },
    { name: 'Mortgage Calculator', path: '/mortgage' },
    { name: 'Pensions Calculator', path: '/pensions-calculator' },
    { name: 'Budget Planner', path: '/budget-planner' },
    { name: 'UK Self-Employed Tax', path: '/self-employed-tax-calculator' },
    { name: 'Debt Snowball', path: '/debt-snowball-calculator' },
    { name: 'Savings Goal', path: '/savings-goal-calculator' }
  ];

  const isCalculatorActive = calculators.some(calc => isActive(calc.path));

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary shadow-sm">
              <span className="text-xl font-bold text-primary-foreground">$</span>
            </div>
            <span className="text-xl font-bold text-foreground hidden sm:inline-block tracking-tight">SmartMoneyTools</span>
          </Link>

          <nav className="hidden lg:flex items-center space-x-2 flex-1 justify-center">
            <Link
              to="/"
              className={`px-3 py-2 text-sm font-medium rounded-md transition-all duration-200 ${
                location.pathname === '/' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              Home
            </Link>
            
            <DropdownMenu open={isDropdownOpen} onOpenChange={setIsDropdownOpen}>
              <DropdownMenuTrigger className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-all duration-200 outline-none ${
                isCalculatorActive ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}>
                Calculators <ChevronDown className="ml-1 h-4 w-4" />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="center" className="w-64 max-h-96 overflow-y-auto">
                {calculators.map((calc) => (
                  <DropdownMenuItem key={calc.path} asChild>
                    <Link 
                      to={calc.path} 
                      onClick={() => setIsDropdownOpen(false)} 
                      className="w-full cursor-pointer"
                    >
                      {calc.name}
                    </Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <Link
              to="/guides"
              className={`px-3 py-2 text-sm font-medium rounded-md transition-all duration-200 ${
                isActive('/guides') ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              Guides
            </Link>
            <Link
              to="/about"
              className={`px-3 py-2 text-sm font-medium rounded-md transition-all duration-200 ${
                isActive('/about') ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              About
            </Link>
          </nav>

          <div className="flex items-center space-x-4">
            <CurrencySelector />
            
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild className="lg:hidden">
                <Button variant="ghost" size="icon">
                  <Menu className="h-6 w-6" />
                  <span className="sr-only">Toggle menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px] overflow-y-auto">
                <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
                <nav className="flex flex-col space-y-2 mt-8">
                  <Link to="/" onClick={() => setIsOpen(false)} className="px-4 py-3 text-base font-medium rounded-lg hover:bg-muted">Home</Link>
                  <div className="px-4 py-2 mt-2 text-sm font-semibold text-muted-foreground uppercase tracking-wider">Calculators</div>
                  {calculators.map(calc => (
                    <Link 
                      key={calc.path} 
                      to={calc.path} 
                      onClick={() => setIsOpen(false)} 
                      className="px-4 py-2 text-base font-medium rounded-lg hover:bg-muted pl-8"
                    >
                      {calc.name}
                    </Link>
                  ))}
                  <div className="h-px bg-border my-2"></div>
                  <Link to="/guides" onClick={() => setIsOpen(false)} className="px-4 py-3 text-base font-medium rounded-lg hover:bg-muted">Guides</Link>
                  <Link to="/about" onClick={() => setIsOpen(false)} className="px-4 py-3 text-base font-medium rounded-lg hover:bg-muted">About</Link>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;