import React, { useState } from 'react';
import { Copy, Check, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { calculateTakeHomePay, convertToAnnualSalary, calculateMarginalTaxRate } from '../utils/ukSalaryCalculations.js';

const formatGbp = (value) => {
  return new Intl.NumberFormat('en-GB', {
    style: 'currency',
    currency: 'GBP',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value || 0);
};

function BreakdownRow({ label, amount, isSubtracted = false, isHighlighted = false }) {
  return (
    <div className={`flex justify-between py-3 border-b border-border/50 last:border-0 ${isHighlighted ? 'font-bold text-foreground bg-muted/30 px-3 rounded-lg -mx-3' : 'text-muted-foreground'}`}>
      <span>{label}</span>
      <span className={isSubtracted ? 'text-destructive' : 'text-foreground'}>
        {isSubtracted ? '- ' : ''}{formatGbp(amount)}
      </span>
    </div>
  );
}

function UKSalaryCalculatorResults({ formData }) {
  const [copied, setCopied] = useState(false);
  const [showEmployer, setShowEmployer] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);

  // Derive annual gross from inputs
  const annualGross = convertToAnnualSalary(formData.salaryInput, formData.salaryFrequency, formData.hoursPerWeek);
  
  // Calculate full results
  const results = calculateTakeHomePay(annualGross, {
    region: formData.region,
    customPA: formData.useCustomPA ? formData.customPA : null,
    pensionPercentage: formData.pensionPercentage,
    pensionReliefType: formData.pensionReliefType,
    pensionBasis: formData.pensionBasis,
    employerPensionPercentage: formData.employerPensionPercentage,
    studentLoans: formData.studentLoans,
    bonus: formData.bonus
  });

  const marginalRate = calculateMarginalTaxRate(annualGross, formData.region);

  // Relief at Source: the employee pays only 80% of their gross contribution
  // from take-home pay; the provider claims the other 20% basic-rate relief.
  const isReliefAtSource = formData.pensionReliefType === 'Relief at Source';
  const pensionPaid = isReliefAtSource ? results.employeePensionPaid : results.employeePension;
  const pensionRelief = isReliefAtSource ? results.pensionTaxRelief : 0;
  const pensionTotal = results.employeePension;

  // Handle Display Frequency Division
  const divisor = formData.displayFrequency === 'Monthly' ? 12 : formData.displayFrequency === 'Weekly' ? 52 : 1;
  const periodLabel = formData.displayFrequency;

  const handleCopy = () => {
    const pensionLine = isReliefAtSource
      ? `Pension (you pay): -${formatGbp(results.employeePensionPaid)}\n+ ${formatGbp(results.pensionTaxRelief)} tax relief added by your pension provider = ${formatGbp(results.employeePension)} total into your pension`
      : `Pension Contribution: -${formatGbp(results.employeePension)}`;
    const textToCopy = `
UK Salary Estimate (2026/27)
---------------------------
Gross Pay: ${formatGbp(results.totalGross)}
Taxable Income: ${formatGbp(results.taxableIncome)}
Income Tax: -${formatGbp(results.incomeTax)}
National Insurance: -${formatGbp(results.employeeNI)}
${pensionLine}
Student Loans: -${formatGbp(results.studentLoan)}
---------------------------
Take Home Pay: ${formatGbp(results.netAnnual)} / year
Monthly Pay: ${formatGbp(results.netAnnual / 12)} / month
Effective Tax Rate: ${results.effectiveTaxRate.toFixed(1)}%
    `.trim();

    navigator.clipboard.writeText(textToCopy).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="space-y-6">
      <div className="bg-card rounded-2xl shadow-lg border border-border overflow-hidden">
        
        {/* Net Pay Highlight Header */}
        <div className="bg-primary p-6 text-primary-foreground text-center">
          <h2 className="text-lg font-medium text-primary-foreground/80 mb-2 uppercase tracking-wider">Estimated Take-Home Pay</h2>
          <div className="text-4xl md:text-5xl font-bold tracking-tight mb-2">
            {formatGbp(results.netAnnual / divisor)}
          </div>
          <p className="text-primary-foreground/90 font-medium">per {periodLabel.toLowerCase().replace('ly', '')}</p>
        </div>

        {/* Full Breakdown */}
        <div className="p-6 md:p-8">
          <h3 className="text-xl font-bold text-foreground mb-4 pb-2 border-b border-border">{periodLabel} Breakdown</h3>
          
          <div className="space-y-1 mb-8">
            <BreakdownRow label={`Gross ${periodLabel} Pay`} amount={results.totalGross / divisor} />
            <BreakdownRow
              label={isReliefAtSource ? 'Pension (you pay)' : 'Pension Contribution'}
              amount={pensionPaid / divisor}
              isSubtracted={pensionPaid > 0}
            />
            {isReliefAtSource && pensionTotal > 0 && (
              <p className="text-xs text-muted-foreground -mt-2 mb-1 pl-1 leading-snug">
                + {formatGbp(pensionRelief / divisor)} tax relief added by your pension provider = {formatGbp(pensionTotal / divisor)} total into your pension
              </p>
            )}
            <BreakdownRow label="Taxable Income" amount={results.taxableIncome / divisor} />
            <BreakdownRow label="Tax-Free Allowance Used" amount={results.personalAllowance / divisor} />
            <BreakdownRow label="Income Tax" amount={results.incomeTax / divisor} isSubtracted={results.incomeTax > 0} />
            <BreakdownRow label="National Insurance" amount={results.employeeNI / divisor} isSubtracted={results.employeeNI > 0} />
            <BreakdownRow label="Student Loan" amount={results.studentLoan / divisor} isSubtracted={results.studentLoan > 0} />
            <div className="pt-2 mt-2 border-t-2 border-border/80">
              <BreakdownRow label={`Net ${periodLabel} Pay`} amount={results.netAnnual / divisor} isHighlighted />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="bg-muted/40 p-4 rounded-xl border border-border text-center">
              <div className="text-sm text-muted-foreground mb-1">Effective Tax Rate</div>
              <div className="text-xl font-bold text-foreground">{results.effectiveTaxRate.toFixed(1)}%</div>
            </div>
            <div className="bg-muted/40 p-4 rounded-xl border border-border text-center">
              <div className="text-sm text-muted-foreground mb-1">Marginal Tax Rate</div>
              <div className="text-xl font-bold text-foreground">{marginalRate.toFixed(1)}%</div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <Button onClick={handleCopy} className="w-full sm:flex-1" variant="outline">
              {copied ? <Check className="mr-2 h-4 w-4 text-primary" /> : <Copy className="mr-2 h-4 w-4" />}
              {copied ? 'Copied!' : 'Copy Results'}
            </Button>
            <Button onClick={() => window.location.reload()} className="w-full sm:flex-1" variant="ghost">
              Reset Calculator
            </Button>
          </div>
        </div>
      </div>

      {/* Employer Costs Accordion */}
      <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden transition-all duration-200">
        <button 
          onClick={() => setShowEmployer(!showEmployer)} 
          className="w-full flex items-center justify-between p-5 text-left font-medium text-foreground hover:bg-muted/30 transition-colors"
        >
          <span>Employer Costs & Summaries</span>
          {showEmployer ? <ChevronUp className="h-5 w-5 text-muted-foreground" /> : <ChevronDown className="h-5 w-5 text-muted-foreground" />}
        </button>
        {showEmployer && (
          <div className="p-5 pt-0 border-t border-border">
            <p className="text-sm text-muted-foreground mb-4">
              These costs are paid by your employer on top of your gross salary and do not directly reduce your take-home pay.
            </p>
            <div className="space-y-1">
              <BreakdownRow label="Employer National Insurance" amount={results.employerNI / divisor} />
              <BreakdownRow label="Employer Pension Contribution" amount={results.employerPension / divisor} />
              <div className="pt-2 mt-2 border-t border-border/50">
                <BreakdownRow label="Total Cost to Employer" amount={(results.totalGross + results.employerNI + results.employerPension) / divisor} isHighlighted />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* How is this calculated Accordion */}
      <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden transition-all duration-200">
        <button 
          onClick={() => setShowExplanation(!showExplanation)} 
          className="w-full flex items-center justify-between p-5 text-left font-medium text-foreground hover:bg-muted/30 transition-colors"
        >
          <span>How is this calculated?</span>
          {showExplanation ? <ChevronUp className="h-5 w-5 text-muted-foreground" /> : <ChevronDown className="h-5 w-5 text-muted-foreground" />}
        </button>
        {showExplanation && (
          <div className="p-5 pt-0 border-t border-border text-sm text-muted-foreground leading-relaxed space-y-4">
            <p>
              Your <strong>Effective Tax Rate</strong> is the total percentage of your gross income taken by all deductions (Income Tax, NI, Pension, Student Loans). 
            </p>
            <p>
              Your <strong>Marginal Tax Rate</strong> is the percentage of tax you would pay on the <em>next</em> £100 you earn. It highlights how much of any future raise or bonus you actually get to keep.
            </p>
            <p>
              <strong>Pension Relief:</strong> If you use "Salary Sacrifice", your contribution lowers both your income tax and National Insurance. "Net Pay" reduces income tax but not NI. "Relief at Source" is taken from net pay, and your provider claims basic rate tax relief directly from HMRC.
            </p>
          </div>
        )}
      </div>

      <div className="text-xs text-muted-foreground text-center px-4">
        This calculator provides an estimate only and should not be treated as payroll, tax, legal, or financial advice. PAYE deductions can vary depending on your tax code, benefits, bonuses, pension scheme, pay frequency, previous earnings, and employer payroll setup.
      </div>
    </div>
  );
}

export default UKSalaryCalculatorResults;