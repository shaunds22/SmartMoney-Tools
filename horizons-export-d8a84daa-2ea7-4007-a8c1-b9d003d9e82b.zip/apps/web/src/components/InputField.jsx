import React from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';

function InputField({ 
  label, 
  id, 
  type = 'number', 
  value, 
  onChange, 
  placeholder, 
  prefix, 
  suffix,
  error,
  min,
  max,
  step = 'any',
  required = false
}) {
  return (
    <div className="space-y-2">
      <Label htmlFor={id} className="text-sm font-medium text-foreground">
        {label}
        {required && <span className="text-destructive ml-1">*</span>}
      </Label>
      <div className="relative">
        {prefix && (
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
            {prefix}
          </span>
        )}
        <Input
          id={id}
          type={type}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          min={min}
          max={max}
          step={step}
          className={`${prefix ? 'pl-8' : ''} ${suffix ? 'pr-12' : ''} text-foreground transition-all duration-200 ${
            error ? 'border-destructive focus-visible:ring-destructive' : ''
          }`}
        />
        {suffix && (
          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
            {suffix}
          </span>
        )}
      </div>
      {error && (
        <p className="text-sm text-destructive">{error}</p>
      )}
    </div>
  );
}

export default InputField;