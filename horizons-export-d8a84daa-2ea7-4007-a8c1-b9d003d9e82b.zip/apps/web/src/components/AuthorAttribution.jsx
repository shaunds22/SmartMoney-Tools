import React from 'react';
import { Link } from 'react-router-dom';
import { User, CalendarDays, AlertCircle } from 'lucide-react';
import { DEFAULT_AUTHOR } from '@/data/authors.js';

/**
 * AuthorAttribution — compact trust bar for calculator pages.
 *
 * Shows the written-by author (linked to the author profile), the published
 * and last-reviewed dates, and links to the Editorial Policy and the
 * error-reporting contact form.
 *
 * Pass showByline={false} when a separate <AuthorBylineBar> already renders
 * the "Written by" line under the H1 (e.g. calculator pages with a coloured
 * hero); the bar then carries only the dates and editorial links.
 *
 * The "Reviewed by" line is rendered ONLY when a genuine, named reviewer is
 * passed via the `reviewer` prop. No reviewer is shown by default, because no
 * page-specific review record exists in this project.
 */
export default function AuthorAttribution({
  publishedDate,
  lastReviewedDate = '2026-09-11',
  reviewer,
  authorName = DEFAULT_AUTHOR.name,
  authorCredential = DEFAULT_AUTHOR.credential,
  authorBio,
  profilePath = DEFAULT_AUTHOR.profilePath,
  showByline = true,
}) {
  const fmtDate = (iso) => {
    const d = new Date(iso);
    return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  };

  return (
    <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-muted-foreground py-3 px-4 bg-muted/40 rounded-lg border border-border/60 mb-6">
      {showByline && (
        <span className="flex items-center gap-1.5">
          <User className="w-3.5 h-3.5 shrink-0" />
          <span>
            Written by{' '}
            <Link to={profilePath} className="text-foreground font-medium hover:underline">
              {authorName}
            </Link>
            <span className="text-muted-foreground"> &mdash; {authorCredential}</span>
          </span>
        </span>
      )}
      {reviewer && (
        <span className="flex items-center gap-1.5">
          <User className="w-3.5 h-3.5 shrink-0" />
          <span>Reviewed by <strong className="text-foreground font-medium">{reviewer}</strong></span>
        </span>
      )}
      {publishedDate && (
        <span className="flex items-center gap-1.5">
          <CalendarDays className="w-3.5 h-3.5 shrink-0" />
          <span>Published {fmtDate(publishedDate)}</span>
        </span>
      )}
      <span className="flex items-center gap-1.5">
        <CalendarDays className="w-3.5 h-3.5 shrink-0" />
        <span>Last reviewed {fmtDate(lastReviewedDate)}</span>
      </span>
      <span className="flex items-center gap-1.5 ml-auto flex-wrap gap-x-3">
        <Link to="/editorial-policy" className="text-primary hover:underline font-medium">Editorial Policy</Link>
        <Link to="/contact?category=bug" className="flex items-center gap-1 text-primary hover:underline font-medium">
          <AlertCircle className="w-3.5 h-3.5" />Report an error
        </Link>
      </span>
    </div>
  );
}
