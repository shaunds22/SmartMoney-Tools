import React from 'react';
import FAQAccordion from '@/components/FAQAccordion.jsx';

/**
 * GuideSection — renders a single configurable section of a guide.
 *
 * Each guide declares its own ordered `sections` array (see GuideLayout), so
 * sections can be added, removed, reordered or renamed per guide instead of
 * being hardcoded in a shared template.
 *
 * Section descriptor shape:
 *   {
 *     type:    one of SECTION_TYPES below,
 *     title?:  string — rendered as an <h2> (prose-styled, same as before),
 *     content?: ReactNode — the section body,
 *     items?:   array — faqItems for type 'faq',
 *   }
 *
 * Visual styling is unchanged from the previous freeform guides: titled
 * sections render a plain prose <h2> followed by their content, exactly as
 * the guides already did. Only the two new opt-in types — 'comparison-table'
 * and 'data-chart' — add a distinct container, because they are new capabilities.
 */
export const SECTION_TYPES = [
  'introduction',
  'uk-examples',
  'step-by-step',
  'worked-example',
  'when-useful',
  'limitations',
  'faq',
  'resources',
  'comparison-table',
  'data-chart',
  'content',
];

export default function GuideSection({ type = 'content', title, content, items }) {
  const hasTitle = typeof title === 'string' && title.trim().length > 0;

  // FAQ — title + accessible accordion (answers stay in the prerendered HTML).
  if (type === 'faq') {
    return (
      <section data-section-type="faq">
        {hasTitle && <h2>{title}</h2>}
        <FAQAccordion faqItems={items} />
      </section>
    );
  }

  // Comparison Table — title + horizontally scrollable table container,
  // matching the table wrapper the guides already used inline.
  if (type === 'comparison-table') {
    return (
      <section data-section-type="comparison-table">
        {hasTitle && <h2>{title}</h2>}
        <div className="overflow-x-auto my-6">{content}</div>
      </section>
    );
  }

  // Data Chart — title + a distinct chart surface (new opt-in capability).
  // `not-prose` escapes prose typography so chart markup renders cleanly.
  if (type === 'data-chart') {
    return (
      <section data-section-type="data-chart">
        {hasTitle && <h2>{title}</h2>}
        <div className="not-prose my-6 rounded-xl border border-border bg-card p-4 sm:p-6">
          {content}
        </div>
      </section>
    );
  }

  // Default — title + content. Output is identical to the previous freeform
  // guides (a prose <h2> followed by the section body).
  return (
    <section data-section-type={type}>
      {hasTitle && <h2>{title}</h2>}
      {content}
    </section>
  );
}
