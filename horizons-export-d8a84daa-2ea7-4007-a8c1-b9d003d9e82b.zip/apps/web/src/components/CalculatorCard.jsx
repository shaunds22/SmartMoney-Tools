import React from 'react';

function CalculatorCard({ title, description, children, className = '' }) {
  return (
    <div className={`bg-card rounded-2xl shadow-lg p-6 md:p-8 border border-border ${className}`}>
      {(title || description) && (
        <div className="mb-6">
          {title && (
            <h2 className="text-2xl md:text-3xl font-semibold text-card-foreground mb-2">
              {title}
            </h2>
          )}
          {description && (
            <p className="text-muted-foreground leading-relaxed">
              {description}
            </p>
          )}
        </div>
      )}
      {children}
    </div>
  );
}

export default CalculatorCard;