import React from 'react';
import { Link } from 'react-router-dom';
import { Compass } from 'lucide-react';

/**
 * ChooseGuide — a compact "Choose the right guide" callout dropped into
 * articles that overlap with a related page. It points readers at the page
 * that best answers a specific adjacent question, so two similar guides
 * complement rather than duplicate each other.
 *
 * `items` is an array of { question, path, text } — each rendered as a
 * short question with a descriptive link to the related guide.
 */
export default function ChooseGuide({ items }) {
  if (!items || items.length === 0) return null;
  return (
    <aside
      className="not-prose my-8 rounded-xl border border-primary/20 bg-primary/5 p-5 sm:p-6"
      aria-label="Choose the right guide"
    >
      <h2 className="flex items-center gap-2 text-base font-bold text-foreground mb-3">
        <Compass className="h-4 w-4 text-primary" /> Choose the right guide
      </h2>
      <ul className="space-y-2 text-sm text-muted-foreground">
        {items.map((item, idx) => (
          <li key={idx} className="flex flex-col sm:flex-row sm:items-baseline sm:gap-2">
            <span className="font-medium text-foreground sm:max-w-[18rem]">{item.question}</span>
            <span>
              See{' '}
              <Link to={item.path} className="text-primary font-medium hover:underline">
                {item.text}
              </Link>
              {item.tail && <> — {item.tail}</>}
            </span>
          </li>
        ))}
      </ul>
    </aside>
  );
}
