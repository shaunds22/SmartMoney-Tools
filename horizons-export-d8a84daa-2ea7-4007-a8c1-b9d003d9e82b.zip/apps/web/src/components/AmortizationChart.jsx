import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import formatCurrency from '@/utils/formatCurrency.js';

function AmortizationChart({ data, currencyCode = 'GBP' }) {
  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-[400px] bg-muted/30 rounded-xl">
        <p className="text-muted-foreground">No data to display</p>
      </div>
    );
  }

  const formatValue = (value) => formatCurrency(value, currencyCode);

  return (
    <div className="w-full h-[400px]">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
          <XAxis 
            dataKey="year" 
            stroke="hsl(var(--muted-foreground))"
            label={{ value: 'Year', position: 'insideBottom', offset: -5 }}
          />
          <YAxis 
            stroke="hsl(var(--muted-foreground))"
            tickFormatter={formatValue}
          />
          <Tooltip 
            formatter={formatValue}
            contentStyle={{
              backgroundColor: 'hsl(var(--card))',
              border: '1px solid hsl(var(--border))',
              borderRadius: '8px',
              color: 'hsl(var(--card-foreground))'
            }}
          />
          <Legend />
          <Bar dataKey="principal" stackId="a" fill="hsl(var(--primary))" name="Principal" />
          <Bar dataKey="interest" stackId="a" fill="hsl(var(--secondary))" name="Interest" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export default AmortizationChart;