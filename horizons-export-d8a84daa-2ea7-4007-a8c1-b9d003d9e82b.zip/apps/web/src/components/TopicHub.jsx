import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import PageSeo from '@/components/PageSeo.jsx';
import { Calculator, ArrowRight, Compass, BookOpen } from 'lucide-react';

const BASE_URL = 'https://smartmoney-tools.com';

/**
 * TopicHub — shared layout for the seven topic-hub destinations.
 *
 * Each hub is a genuinely useful destination: a reader-focused introduction,
 * the relevant calculators featured prominently, guides grouped by the
 * distinct question or task they answer (not by keyword), a "Choose the
 * right guide" callout where related articles overlap, and contextual
 * cross-links to neighbouring hubs. No thin tag/archive lists.
 */
export default function TopicHub({
  path,
  title,
  intro,
  calculators = [],
  groups = [],
  chooseRightGuide = [],
  relatedHubs = [],
}) {
  // BreadcrumbList mirrors the visible Guides / <hub> breadcrumb trail.
  const breadcrumbSchema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Home', item: `${BASE_URL}/` },
      { '@type': 'ListItem', position: 2, name: 'Guides', item: `${BASE_URL}/guides` },
      { '@type': 'ListItem', position: 3, name: title },
    ],
  };

  // ItemList mirrors the hub's visible contents (featured calculators, then
  // every grouped guide) so the structured data matches what readers see.
  const listedItems = [
    ...calculators.map((calc) => ({ name: calc.title, path: calc.path })),
    ...groups.flatMap((group) => group.guides.map((guide) => ({ name: guide.title, path: guide.path }))),
  ];
  const itemListSchema = {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    itemListElement: listedItems.map((item, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: item.name,
      url: `${BASE_URL}${item.path}`,
    })),
  };

  return (
    <div className="flex flex-col w-full bg-background">
      <PageSeo path={path} type="website" />

      <Helmet>
        <script type="application/ld+json">{JSON.stringify(breadcrumbSchema)}</script>
        <script type="application/ld+json">{JSON.stringify(itemListSchema)}</script>
      </Helmet>

      {/* Hero */}
      <section className="border-b border-border bg-secondary/40">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-5xl py-14 lg:py-20">
          <div className="mb-5 flex items-center gap-2 text-sm font-medium text-muted-foreground">
            <Compass className="h-4 w-4 text-primary" />
            <Link to="/guides" className="hover:text-primary transition-colors">Guides</Link>
            <span aria-hidden="true">/</span>
            <span className="text-foreground">{title}</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold text-foreground tracking-tight text-balance mb-5">
            {title}
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-3xl">
            {intro}
          </p>
        </div>
      </section>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-5xl py-12 lg:py-16 space-y-14">

        {/* Featured calculators */}
        {calculators.length > 0 && (
          <section aria-labelledby="calc-heading">
            <h2 id="calc-heading" className="text-2xl font-bold text-foreground mb-2">
              Start with a calculator
            </h2>
            <p className="text-muted-foreground mb-6 max-w-3xl">
              Put your own numbers in first — the guides below explain what the results mean and what to do next.
            </p>
            <div className={`grid gap-5 ${calculators.length > 1 ? 'sm:grid-cols-2' : ''}`}>
              {calculators.map((calc) => (
                <Link
                  key={calc.path}
                  to={calc.path}
                  className="group flex flex-col rounded-xl border border-border bg-card p-6 transition-all duration-300 hover:shadow-md hover:border-primary/40 hover:-translate-y-0.5"
                >
                  <div className="flex items-center gap-3 mb-3">
                    <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                      <Calculator className="h-5 w-5" />
                    </span>
                    <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                      {calc.title}
                    </h3>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed flex-grow">
                    {calc.desc}
                  </p>
                  <span className="mt-4 inline-flex items-center text-sm font-medium text-primary">
                    Open calculator <ArrowRight className="ml-1.5 h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                  </span>
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* Guide groups by user need */}
        {groups.map((group, idx) => (
          <section key={idx} aria-labelledby={`group-${idx}`}>
            <h2 id={`group-${idx}`} className="text-xl font-bold text-foreground mb-1">
              {group.need}
            </h2>
            {group.context && (
              <p className="text-sm text-muted-foreground mb-5 max-w-3xl">{group.context}</p>
            )}
            <ul className="divide-y divide-border rounded-xl border border-border bg-card overflow-hidden">
              {group.guides.map((guide) => (
                <li key={guide.path}>
                  <Link
                    to={guide.path}
                    className="group flex flex-col gap-1 p-5 transition-colors hover:bg-muted/40 sm:flex-row sm:items-baseline sm:gap-4"
                  >
                    <span className="font-semibold text-foreground group-hover:text-primary transition-colors sm:flex-shrink-0 sm:max-w-[16rem]">
                      {guide.title}
                    </span>
                    <span className="text-sm text-muted-foreground leading-relaxed">
                      {guide.desc}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        ))}

        {/* Choose the right guide — only where articles genuinely overlap */}
        {chooseRightGuide.length > 0 && (
          <section
            aria-labelledby="choose-heading"
            className="rounded-2xl border border-primary/20 bg-primary/5 p-6 lg:p-8"
          >
            <h2 id="choose-heading" className="text-xl font-bold text-foreground mb-2 flex items-center gap-2">
              <Compass className="h-5 w-5 text-primary" /> Choose the right guide
            </h2>
            <p className="text-sm text-muted-foreground mb-5 max-w-3xl">
              Several pages in this area cover related questions. Use this to pick the one that matches what you are actually trying to do.
            </p>
            <dl className="space-y-4">
              {chooseRightGuide.map((item, idx) => (
                <div key={idx} className="grid gap-1 sm:grid-cols-[auto_1fr] sm:gap-4">
                  <dt className="font-medium text-foreground sm:max-w-[20rem]">
                    {item.question}
                  </dt>
                  <dd className="text-sm text-muted-foreground leading-relaxed">
                    {item.answer}{' '}
                    {item.link && (
                      <Link to={item.link.path} className="text-primary font-medium hover:underline">
                        {item.link.text}
                      </Link>
                    )}
                  </dd>
                </div>
              ))}
            </dl>
          </section>
        )}

        {/* Related hubs */}
        {relatedHubs.length > 0 && (
          <section aria-labelledby="related-heading" className="border-t border-border pt-10">
            <h2 id="related-heading" className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-primary" /> Related topic hubs
            </h2>
            <div className="flex flex-wrap gap-3">
              {relatedHubs.map((hub) => (
                <Link
                  key={hub.path}
                  to={hub.path}
                  className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm font-medium text-foreground transition-colors hover:border-primary/40 hover:text-primary"
                >
                  {hub.title}
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* Author footer */}
        <div className="rounded-2xl border border-border/60 bg-muted/40 px-6 py-6 text-center">
          <p className="text-sm text-muted-foreground leading-relaxed">
            Every guide in this hub is written and maintained by{' '}
            <Link to="/author/shaun-da-silva" className="font-medium text-primary hover:underline">Shaun Da Silva</Link>
            , Financial Consultant. SmartMoneyTools provides educational estimates only — not financial advice. Read our{' '}
            <Link to="/financial-disclaimer" className="font-medium text-primary hover:underline">financial disclaimer</Link>{' '}and{' '}
            <Link to="/editorial-policy" className="font-medium text-primary hover:underline">editorial policy</Link>.
          </p>
        </div>
      </div>
    </div>
  );
}
