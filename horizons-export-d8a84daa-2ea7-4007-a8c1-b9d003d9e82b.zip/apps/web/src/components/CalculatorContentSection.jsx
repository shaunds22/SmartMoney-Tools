import React from 'react';

export default function CalculatorContentSection({ title, children }) {
  return (
    <section className="mb-12">
      {title && (
        <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-6 text-balance">
          {title}
        </h2>
      )}
      <div className="prose prose-slate dark:prose-invert max-w-none text-muted-foreground leading-relaxed">
        {children}
      </div>
    </section>
  );
}