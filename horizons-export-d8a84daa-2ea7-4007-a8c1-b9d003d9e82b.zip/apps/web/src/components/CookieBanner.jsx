import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { X } from 'lucide-react';
import { getConsent, setConsent } from '@/lib/adsense.js';

export default function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = getConsent();
    if (!stored) {
      setVisible(true);
    }
  }, []);

  const accept = () => {
    // setConsent('accepted') persists the decision and loads the AdSense
    // script so queued ad slots can fill. Advertising cookies only load now.
    setConsent('accepted');
    setVisible(false);
  };

  const reject = () => {
    // setConsent('rejected') persists the decision without loading AdSense.
    // Non-personalised ads are not served because the script never loads.
    setConsent('rejected');
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div
      role="dialog"
      aria-label="Cookie consent"
      aria-live="polite"
      className="fixed bottom-0 left-0 right-0 z-50 bg-card border-t border-border shadow-2xl"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 max-w-7xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="flex-1 text-sm text-muted-foreground leading-relaxed">
            <p>
              <strong className="text-foreground">Cookies &amp; Advertising:</strong>{' '}
              We use Google AdSense to serve ads and keep our calculators free. If you accept, Google may serve
              personalised ads based on your browsing history. If you reject, you will see non-personalised ads only.
              Essential site cookies are always set. See our{' '}
              <Link to="/cookie-policy" className="text-primary hover:underline underline-offset-2">Cookie Policy</Link>
              {' '}and{' '}
              <Link to="/privacy" className="text-primary hover:underline underline-offset-2">Privacy Policy</Link>.
            </p>
          </div>
          <div className="flex items-center gap-3 flex-shrink-0">
            <button
              onClick={reject}
              className="px-5 py-2.5 rounded-lg text-sm font-medium border border-border bg-background text-foreground hover:bg-muted transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
              aria-label="Reject non-essential cookies"
            >
              Reject
            </button>
            <button
              onClick={accept}
              className="px-5 py-2.5 rounded-lg text-sm font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
              aria-label="Accept all cookies"
            >
              Accept All
            </button>
            <button
              onClick={reject}
              className="p-1.5 rounded text-muted-foreground hover:text-foreground transition-colors focus:outline-none focus:ring-2 focus:ring-primary"
              aria-label="Close cookie banner without accepting"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
