import React from 'react';
import { Link } from 'react-router-dom';
import { User, Calendar } from 'lucide-react';
import { DEFAULT_AUTHOR } from '@/data/authors.js';

/**
 * AuthorBylineBar — compact "Written by [authorName] — [authorCredential]"
 * byline rendered directly under the H1 of every guide and calculator page.
 *
 * variant="hero"  → light text for use on the primary-coloured hero band.
 * variant="page"  → muted text for use on a plain background.
 *
 * `lastReviewed` is optional; pass it when no separate date bar is shown
 * elsewhere on the page (e.g. guides). Omit it when a dedicated attribution
 * bar already carries the date (e.g. calculator pages).
 */
export default function AuthorBylineBar({
  authorName = DEFAULT_AUTHOR.name,
  authorCredential = DEFAULT_AUTHOR.credential,
  profilePath = DEFAULT_AUTHOR.profilePath,
  lastReviewed,
  variant = 'page',
}) {
  const fmtDate = (iso) => {
    if (!iso) return null;
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return null;
    return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  };
  const reviewed = fmtDate(lastReviewed);

  if (variant === 'hero') {
    return (
      <div className="mt-6 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-sm text-primary-foreground/80">
        <span className="flex items-center gap-1.5">
          <User className="h-4 w-4 shrink-0" />
          <span>
            Written by{' '}
            <Link
              to={profilePath}
              className="font-medium text-primary-foreground underline-offset-2 hover:underline"
            >
              {authorName}
            </Link>
            <span className="text-primary-foreground/70"> &mdash; {authorCredential}</span>
          </span>
        </span>
        {reviewed && (
          <span className="flex items-center gap-1.5">
            <Calendar className="h-4 w-4 shrink-0" />
            <span>Last reviewed {reviewed}</span>
          </span>
        )}
      </div>
    );
  }

  return (
    <div className="mb-6 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
      <span className="flex items-center gap-1.5">
        <User className="h-4 w-4 shrink-0" />
        <span>
          Written by{' '}
          <Link
            to={profilePath}
            className="font-medium text-foreground underline-offset-2 hover:underline"
          >
            {authorName}
          </Link>
          <span> &mdash; {authorCredential}</span>
        </span>
      </span>
      {reviewed && (
        <span className="flex items-center gap-1.5">
          <Calendar className="h-4 w-4 shrink-0" />
          <span>Last reviewed {reviewed}</span>
        </span>
      )}
    </div>
  );
}
