import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Info, RefreshCw, Calculator } from 'lucide-react';
import { projectRetirement } from '@/utils/usRetirementCalculations.js';

const DEFAULT_STATE = {
  currentAge: 35,
  retireAge: 65,
  planningAge: 90,
  currentSalary: 75000,
  salaryGrowthRate: 2.5,
  currentBalance: 50000,
  employeeContribPct: 10,
  matchType: '100_up_to_3',
  customTier1Match: 100,
  customTier1Limit: 3,
  customTier2Match: 50,
  customTier2Limit: 5,
  iraContribAmount: 0,
  annualIncreasePct: 0,
  preRetirementReturn: 7,
  postRetirementReturn: 5,
  inflationRate: 2.5,
  investmentFees: 0.5,
  incomeGoalPct: 80,
  socialSecurityMonthly: 2000,
  ssClaimAge: 67,
  pensionMonthly: 0,
  pensionStartAge: 65,
  pensionCola: 0
};

export default function USRetirementCalculator({ onCalculate }) {
  const [formData, setFormData] = useState(() => {
    // SSR-safe: sessionStorage is unavailable when the page is prerendered.
    if (typeof sessionStorage === 'undefined') return DEFAULT_STATE;
    const saved = sessionStorage.getItem('us-retirement-calc');
    return saved ? JSON.parse(saved) : DEFAULT_STATE;
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (typeof sessionStorage === 'undefined') return;
    sessionStorage.setItem('us-retirement-calc', JSON.stringify(formData));
  }, [formData]);

  // Initial calculation on mount
  useEffect(() => {
    handleCalculate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    const numValue = value === '' ? '' : Number(value);
    setFormData(prev => ({ ...prev, [name]: numValue }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: null }));
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const newErrors = {};
    if (formData.currentAge < 18 || formData.currentAge > 80) newErrors.currentAge = "Valid age 18-80";
    if (formData.retireAge <= formData.currentAge) newErrors.retireAge = "Must be > current age";
    if (formData.planningAge <= formData.retireAge) newErrors.planningAge = "Must be > retire age";
    if (formData.currentSalary < 0) newErrors.currentSalary = "Cannot be negative";
    if (formData.employeeContribPct < 0 || formData.employeeContribPct > 100) newErrors.employeeContribPct = "0-100%";
    if (formData.incomeGoalPct < 0 || formData.incomeGoalPct > 200) newErrors.incomeGoalPct = "0-200%";
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleCalculate = () => {
    if (!validate()) return;
    
    const params = {
      ...formData,
      customMatchParams: formData.matchType === 'custom' ? {
        tier1Match: formData.customTier1Match,
        tier1Limit: formData.customTier1Limit,
        tier2Match: formData.customTier2Match,
        tier2Limit: formData.customTier2Limit
      } : null
    };

    const results = projectRetirement(params);
    if (onCalculate) onCalculate(results);
  };

  const handleReset = () => {
    setFormData(DEFAULT_STATE);
    setErrors({});
    sessionStorage.removeItem('us-retirement-calc');
    setTimeout(() => {
      const results = projectRetirement(DEFAULT_STATE);
      if (onCalculate) onCalculate(results);
    }, 0);
  };

  const HelpTooltip = ({ text }) => (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger type="button" tabIndex={-1} className="ml-1 focus:outline-none">
          <Info className="h-4 w-4 text-muted-foreground hover:text-primary transition-colors inline" />
        </TooltipTrigger>
        <TooltipContent className="max-w-xs text-sm">
          <p>{text}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );

  return (
    <div className="bg-card border border-border shadow-lg rounded-2xl overflow-hidden">
      <div className="bg-primary/5 p-6 border-b border-border flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground">Retirement Parameters</h2>
          <p className="text-sm text-muted-foreground">Adjust inputs to see how they impact your future.</p>
        </div>
        <Button variant="outline" size="sm" onClick={handleReset} className="hidden sm:flex">
          <RefreshCw className="h-4 w-4 mr-2" /> Reset
        </Button>
      </div>

      <div className="p-6">
        <Tabs defaultValue="personal" className="w-full">
          <TabsList className="w-full grid grid-cols-2 md:grid-cols-4 mb-6 h-auto p-1">
            <TabsTrigger value="personal" className="py-2 text-xs sm:text-sm">Personal</TabsTrigger>
            <TabsTrigger value="savings" className="py-2 text-xs sm:text-sm">Savings</TabsTrigger>
            <TabsTrigger value="assumptions" className="py-2 text-xs sm:text-sm">Assumptions</TabsTrigger>
            <TabsTrigger value="income" className="py-2 text-xs sm:text-sm">Other Income</TabsTrigger>
          </TabsList>

          <TabsContent value="personal" className="space-y-6 animate-in fade-in-50 duration-300">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Current Age</Label>
                <Input name="currentAge" type="number" value={formData.currentAge} onChange={handleChange} className={errors.currentAge ? "border-destructive" : ""} />
                {errors.currentAge && <p className="text-xs text-destructive">{errors.currentAge}</p>}
              </div>
              <div className="space-y-2">
                <Label>Retirement Age <HelpTooltip text="The age you plan to stop working and begin drawing down your portfolio." /></Label>
                <Input name="retireAge" type="number" value={formData.retireAge} onChange={handleChange} className={errors.retireAge ? "border-destructive" : ""} />
                {errors.retireAge && <p className="text-xs text-destructive">{errors.retireAge}</p>}
              </div>
              <div className="space-y-2">
                <Label>Planning Age (Life Expectancy) <HelpTooltip text="The age until which you want your money to last." /></Label>
                <Input name="planningAge" type="number" value={formData.planningAge} onChange={handleChange} className={errors.planningAge ? "border-destructive" : ""} />
                {errors.planningAge && <p className="text-xs text-destructive">{errors.planningAge}</p>}
              </div>
              <div className="space-y-2">
                <Label>Current Salary ($)</Label>
                <Input name="currentSalary" type="number" value={formData.currentSalary} onChange={handleChange} />
              </div>
              <div className="space-y-2">
                <Label>Expected Salary Growth (%) <HelpTooltip text="Annual raise percentage. Keeps pace with inflation or reflects career advancement." /></Label>
                <Input name="salaryGrowthRate" type="number" step="0.1" value={formData.salaryGrowthRate} onChange={handleChange} />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="savings" className="space-y-6 animate-in fade-in-50 duration-300">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Current Retirement Balance ($)</Label>
                <Input name="currentBalance" type="number" value={formData.currentBalance} onChange={handleChange} />
              </div>
              <div className="space-y-2">
                <Label>Your 401(k)/403(b) Contribution (%) <HelpTooltip text="Percentage of your gross salary contributed to workplace plans. Capped at IRS limits." /></Label>
                <Input name="employeeContribPct" type="number" step="0.1" value={formData.employeeContribPct} onChange={handleChange} />
              </div>
              
              <div className="space-y-2">
                <Label>Employer Match Policy</Label>
                <Select value={formData.matchType} onValueChange={(val) => handleSelectChange('matchType', val)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No Match</SelectItem>
                    <SelectItem value="100_up_to_3">100% up to 3%</SelectItem>
                    <SelectItem value="50_up_to_6">50% up to 6%</SelectItem>
                    <SelectItem value="100_to_3_50_to_5">100% up to 3%, 50% on next 2%</SelectItem>
                    <SelectItem value="custom">Custom Formula</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Annual IRA Contribution ($) <HelpTooltip text="Fixed dollar amount added yearly to a Traditional or Roth IRA." /></Label>
                <Input name="iraContribAmount" type="number" value={formData.iraContribAmount} onChange={handleChange} />
              </div>
            </div>

            {formData.matchType === 'custom' && (
              <div className="p-4 bg-muted/50 rounded-lg border grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs">Tier 1 Match (%)</Label>
                  <Input name="customTier1Match" type="number" value={formData.customTier1Match} onChange={handleChange} />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Up to Limit (%)</Label>
                  <Input name="customTier1Limit" type="number" value={formData.customTier1Limit} onChange={handleChange} />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Tier 2 Match (%)</Label>
                  <Input name="customTier2Match" type="number" value={formData.customTier2Match} onChange={handleChange} />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Up to Total Limit (%)</Label>
                  <Input name="customTier2Limit" type="number" value={formData.customTier2Limit} onChange={handleChange} />
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="assumptions" className="space-y-6 animate-in fade-in-50 duration-300">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label>Pre-Retirement Annual Return (%) <HelpTooltip text="Nominal investment growth before retiring. Historically, stocks average 7-10%." /></Label>
                <Input name="preRetirementReturn" type="number" step="0.1" value={formData.preRetirementReturn} onChange={handleChange} />
              </div>
              <div className="space-y-2">
                <Label>Post-Retirement Annual Return (%) <HelpTooltip text="Usually lower as portfolios shift to safer bonds in retirement." /></Label>
                <Input name="postRetirementReturn" type="number" step="0.1" value={formData.postRetirementReturn} onChange={handleChange} />
              </div>
              <div className="space-y-2">
                <Label>Inflation Rate (%) <HelpTooltip text="Reduces purchasing power over time. Federal Reserve target is typically 2-3%." /></Label>
                <Input name="inflationRate" type="number" step="0.1" value={formData.inflationRate} onChange={handleChange} />
              </div>
              <div className="space-y-2">
                <Label>Investment Fees (%) <HelpTooltip text="Expense ratios or advisor fees deducted from returns annually." /></Label>
                <Input name="investmentFees" type="number" step="0.1" value={formData.investmentFees} onChange={handleChange} />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>Income Replacement Goal (%) <HelpTooltip text="Target retirement income as a percentage of your final pre-retirement salary. Typically 70-80%." /></Label>
                <Input name="incomeGoalPct" type="number" value={formData.incomeGoalPct} onChange={handleChange} className={errors.incomeGoalPct ? "border-destructive" : ""} />
                {errors.incomeGoalPct && <p className="text-xs text-destructive">{errors.incomeGoalPct}</p>}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="income" className="space-y-6 animate-in fade-in-50 duration-300">
            <div className="p-4 border rounded-xl bg-card">
              <h3 className="font-semibold mb-4 text-foreground flex items-center gap-2">Social Security</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Expected Monthly Benefit ($) <HelpTooltip text="Stated in today's dollars. The calculator will inflate this automatically." /></Label>
                  <Input name="socialSecurityMonthly" type="number" value={formData.socialSecurityMonthly} onChange={handleChange} />
                </div>
                <div className="space-y-2">
                  <Label>Claiming Age</Label>
                  <Input name="ssClaimAge" type="number" value={formData.ssClaimAge} onChange={handleChange} />
                </div>
              </div>
            </div>

            <div className="p-4 border rounded-xl bg-card">
              <h3 className="font-semibold mb-4 text-foreground flex items-center gap-2">Defined Benefit Pension (Optional)</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <Label>Monthly Benefit ($)</Label>
                  <Input name="pensionMonthly" type="number" value={formData.pensionMonthly} onChange={handleChange} />
                </div>
                <div className="space-y-2">
                  <Label>Start Age</Label>
                  <Input name="pensionStartAge" type="number" value={formData.pensionStartAge} onChange={handleChange} />
                </div>
                <div className="space-y-2">
                  <Label>Annual COLA (%) <HelpTooltip text="Cost of Living Adjustment. Fixed percentage your pension increases annually." /></Label>
                  <Input name="pensionCola" type="number" step="0.1" value={formData.pensionCola} onChange={handleChange} />
                </div>
              </div>
            </div>
          </TabsContent>

        </Tabs>
      </div>

      <div className="p-6 bg-muted/30 border-t border-border flex flex-col sm:flex-row gap-4 items-center justify-end">
        <Button variant="outline" onClick={handleReset} className="w-full sm:w-auto sm:hidden">
          Reset
        </Button>
        <Button onClick={handleCalculate} size="lg" className="w-full sm:w-auto px-8">
          <Calculator className="h-4 w-4 mr-2" /> Calculate Projection
        </Button>
      </div>
    </div>
  );
}