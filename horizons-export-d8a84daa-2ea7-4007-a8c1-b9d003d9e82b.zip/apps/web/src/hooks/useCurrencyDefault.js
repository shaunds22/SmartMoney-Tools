import { useEffect } from 'react';
import useCurrency from '@/hooks/useCurrency.js';

/**
 * Sets a page-level currency default (e.g. 'USD' on US calculator pages).
 * Applies only while the page is mounted and only until the visitor
 * explicitly picks a currency, which then takes precedence everywhere.
 */
export default function useCurrencyDefault(code) {
  const { setPageCurrencyDefault } = useCurrency();

  useEffect(() => {
    setPageCurrencyDefault(code);
    return () => setPageCurrencyDefault(null);
  }, [code, setPageCurrencyDefault]);
}
