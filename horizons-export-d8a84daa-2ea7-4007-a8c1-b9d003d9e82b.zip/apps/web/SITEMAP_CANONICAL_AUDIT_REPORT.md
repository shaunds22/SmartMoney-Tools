# Sitemap & Canonical Audit Report (Internal — not published)

Generated: 2026-11-02. Preferred canonical origin: https://smartmoney-tools.com/

## Method & evidence separation

- **Live HTTP checks**: performed 2026-11-02 via curl against the live domain for all 68 sitemap URLs (HTTP status, canonical, title, robots, byte size).
- **Generated-build checks**: source inspection of the publish-time prerender pipeline (tools/prerender.js), the global CanonicalLink component, RouteMeta, and routeMetadata.js. The production build/prerender was NOT executed in this session (vite build is blocked in the sandbox); generated-build status is source-verified, not build-verified.
- **Live-domain caveat**: the live domain currently serves a STALE, non-prerendered SPA shell (identical ~10,554-byte body, generic title "Smart Money Tools", no canonical, no per-route metadata) for every URL. All fixes below are present in the generated build and ship only on republish; live behaviour will not change until then.

## Sitemap summary

- Source: public/sitemap.xml (read-only, platform-managed) — 68 URLs, all HTTPS non-www, slash-free, lastmod 2026-11-02.
- Generator: tools/generate-sitemap.js reads routeMetadata.js (68 indexable routes). Excludes 21 Navigate redirects, the 404 fallback, and /seo-audit-report (admin). No orphan routeMetadata keys; no indexable route missing from routeMetadata except the admin page (correctly excluded).
- All 68 URLs return live HTTP 200. None removed: every URL maps to a real route with a real page component, routeMetadata title/description, a global self-referencing canonical (generated build), and substantial prerendered content (generated build). The thin live body is a deployment-staleness issue, not a URL-validity issue.
- lastmod = 2026-11-02 (real date of the most recent confirmed site-wide material update — the statutory-data audit and content rewrite pass). Not invented.

## Per-URL audit (68 rows)

All rows: Live HTTP = 200; Live canonical = absent (stale deployment); Live title = generic "Smart Money Tools" (stale); Live robots = index, follow; Live bytes = 10554 (SPA shell); Gen-build canonical = self-referencing HTTPS non-www; Gen-build indexable = index, follow; Content (gen-build) = substantial (prerendered); Sitemap = included; Check type = live curl + source.

| # | URL | Live HTTP | Live canonical | Live title | Live robots | Live bytes | Gen-build canonical | Gen-build indexable | Content (gen-build) | Sitemap | Check type |
|---|-----|-----------|----------------|------------|------------|-----------|---------------------|---------------------|----------------------|---------|------------|
| 1 | https://smartmoney-tools.com/ | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 2 | https://smartmoney-tools.com/about | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 3 | https://smartmoney-tools.com/accessibility | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 4 | https://smartmoney-tools.com/advertising-disclosure | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 5 | https://smartmoney-tools.com/author/shaun-da-silva | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 6 | https://smartmoney-tools.com/budget-planner | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 7 | https://smartmoney-tools.com/calculation-methodology | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 8 | https://smartmoney-tools.com/compound-interest | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 9 | https://smartmoney-tools.com/contact | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 10 | https://smartmoney-tools.com/cookie-policy | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 11 | https://smartmoney-tools.com/corrections-policy | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 12 | https://smartmoney-tools.com/debt-snowball-calculator | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 13 | https://smartmoney-tools.com/editorial-policy | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 14 | https://smartmoney-tools.com/faq | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 15 | https://smartmoney-tools.com/financial-disclaimer | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 16 | https://smartmoney-tools.com/guides | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 17 | https://smartmoney-tools.com/guides/calculate-take-home-pay | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 18 | https://smartmoney-tools.com/guides/compare-loan-repayments | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 19 | https://smartmoney-tools.com/guides/compound-interest-guide | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 20 | https://smartmoney-tools.com/guides/compound-interest-monthly-deposits | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 21 | https://smartmoney-tools.com/guides/credit-card-debt | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 22 | https://smartmoney-tools.com/guides/debt-consolidation | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 23 | https://smartmoney-tools.com/guides/debt-repayment | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 24 | https://smartmoney-tools.com/guides/debt-snowball-vs-avalanche | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 25 | https://smartmoney-tools.com/guides/early-retirement | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 26 | https://smartmoney-tools.com/guides/emergency-fund | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 27 | https://smartmoney-tools.com/guides/first-time-buyer | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 28 | https://smartmoney-tools.com/guides/first-time-buyer-budgeting | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 29 | https://smartmoney-tools.com/guides/freelance-income | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 30 | https://smartmoney-tools.com/guides/high-interest-savings | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 31 | https://smartmoney-tools.com/guides/how-much-emergency-fund | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 32 | https://smartmoney-tools.com/guides/marriage-allowance | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 33 | https://smartmoney-tools.com/guides/mortgage-affordability-first-time-buyers | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 34 | https://smartmoney-tools.com/guides/mortgage-comprehensive | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 35 | https://smartmoney-tools.com/guides/mortgage-overpayments | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 36 | https://smartmoney-tools.com/guides/national-insurance | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 37 | https://smartmoney-tools.com/guides/pension-contributions | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 38 | https://smartmoney-tools.com/guides/pension-planning | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 39 | https://smartmoney-tools.com/guides/pension-tax-take-home | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 40 | https://smartmoney-tools.com/guides/personal-loan | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 41 | https://smartmoney-tools.com/guides/realistic-savings-goal | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 42 | https://smartmoney-tools.com/guides/salary-sacrifice-vs-normal-pension | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 43 | https://smartmoney-tools.com/guides/savings-goals | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 44 | https://smartmoney-tools.com/guides/self-employed-tax-planning | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 45 | https://smartmoney-tools.com/guides/self-employment-income | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 46 | https://smartmoney-tools.com/guides/side-hustle-tax | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 47 | https://smartmoney-tools.com/guides/student-loan-repayments | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 48 | https://smartmoney-tools.com/guides/tax-free-savings | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 49 | https://smartmoney-tools.com/guides/tax-planning | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 50 | https://smartmoney-tools.com/guides/uk-income-tax | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 51 | https://smartmoney-tools.com/guides/uk-salary-guide | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 52 | https://smartmoney-tools.com/guides/workplace-pensions | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 53 | https://smartmoney-tools.com/hubs/debt | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 54 | https://smartmoney-tools.com/hubs/mortgages | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 55 | https://smartmoney-tools.com/hubs/pensions-retirement | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 56 | https://smartmoney-tools.com/hubs/savings | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 57 | https://smartmoney-tools.com/hubs/self-employment | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 58 | https://smartmoney-tools.com/hubs/uk-salary-tax | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 59 | https://smartmoney-tools.com/hubs/us-salary-tax | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 60 | https://smartmoney-tools.com/mortgage | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 61 | https://smartmoney-tools.com/pensions-calculator | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 62 | https://smartmoney-tools.com/privacy | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 63 | https://smartmoney-tools.com/savings-goal-calculator | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 64 | https://smartmoney-tools.com/self-employed-tax-calculator | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 65 | https://smartmoney-tools.com/terms | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 66 | https://smartmoney-tools.com/uk-salary-calculator | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 67 | https://smartmoney-tools.com/us-retirement-calculator | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |
| 68 | https://smartmoney-tools.com/us-salary-calculator | 200 | absent (stale) | generic (stale) | index, follow | 10554 | self-ref ✓ | index, follow ✓ | substantial (prerendered) | included ✓ | live curl + source |

## Redirect audit (generated .htaccess — tools/prerender.js HTACCESS_OUTPUT)

Rules (in evaluation order):
1. Legacy URL redirects (21 rules) — full canonical HTTPS non-www substitution, fire FIRST so a legacy URL from ANY origin resolves in a single 301 hop (no origin→legacy chain).
2. Canonical-origin rule — `RewriteCond %{HTTPS} off [OR] RewriteCond %{HTTP_HOST} ^www\.smartmoney-tools\.com$` → `https://smartmoney-tools.com/$1`. Single 301 hop for all three alternate origins of canonical paths; trailing slash stripped in same hop; query string preserved.
3. Trailing-slash rule — `^(.+)/$` → `/$1` (canonical host only).
4. Directory-index direct serve (no mod_dir redirect loop).
5. ErrorDocument 404 → /404.html (real HTTP 404, noindex, no canonical).

| Variant | Generated-build behaviour | Live (stale) behaviour |
|---------|---------------------------|------------------------|
| http://smartmoney-tools.com/<path> | 301 → https://smartmoney-tools.com/<path> (single hop) | 301 → https://smartmoney-tools.com/<path> (works) |
| http://www.smartmoney-tools.com/<path> | 301 → https://smartmoney-tools.com/<path> (single hop) | 301 → https://www.smartmoney-tools.com/<path> (CHAIN — broken) |
| https://www.smartmoney-tools.com/<path> | 301 → https://smartmoney-tools.com/<path> (single hop) | 200 (NOT redirected — broken) |
| https://smartmoney-tools.com/<path>/ (trailing slash) | 301 → https://smartmoney-tools.com/<path> | 200 (NOT redirected — broken) |
| Query string (?utm=…) | preserved through all redirects | preserved (http→https verified) |

## Canonical & robots

- CanonicalLink (src/components/CanonicalLink.jsx) is mounted globally in AppRoutes → every route emits a self-referencing `<link rel="canonical" href="https://smartmoney-tools.com{pathname}">` (HTTPS, non-www, slash-free) via react-helmet, present in prerendered HTML.
- RouteMeta emits a unique `<title>` and `<meta name="description">` per route from routeMetadata.js.
- 404 page: prerender strips canonical and sets `noindex, follow` (no canonical on a non-indexable page).
- robots.txt (read-only): `User-agent: * / Allow: /` + `Sitemap: https://smartmoney-tools.com/sitemap.xml`. Blocks no CSS/JS/image/asset resources.

## Checks not performed

- Production build/prerender not executed (vite build blocked in sandbox); generated-build status is source-verified only.
- Live canonical/indexability/content reflect the STALE deployment and will only match the generated build after republish + Google recrawl.
